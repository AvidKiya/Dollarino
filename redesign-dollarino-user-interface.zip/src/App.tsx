import { useCallback, useEffect, useState } from 'react';
import {
  Bot,
  CandlestickChart,
  Crown,
  Globe,
  Palette,
  QrCode,
  Sprout,
  Zap,
} from 'lucide-react';
import { AppearanceModal, type LookId } from './components/AppearanceModal';
import { DollarinoBrandMark } from './components/BrandGraphics';
import { Layout, type UiMode } from './components/Layout';
import type { ExchangeMarket } from './components/SymbolPickerModal';
import { TelegramBotModal } from './components/TelegramBotModal';
import { apiFetch, setStoredToken } from './lib/api';
import type { Lang } from './lib/i18n';
import { getTelegramWebApp, initTelegramMiniApp, isInsideTelegramMiniApp } from './lib/telegram';
import type { AuthUserInfo, DashboardPayload, NavTab } from './lib/types';
import { AdminPage } from './pages/AdminPage';
import { AuthPage } from './pages/AuthPage';
import { CopyConnectPage } from './pages/CopyConnectPage';
import { FaqPage } from './pages/FaqPage';
import { LandingPage } from './pages/LandingPage';
import { MarketsPage } from './pages/MarketsPage';
import { OverviewPage } from './pages/OverviewPage';
import { PortfolioPage } from './pages/PortfolioPage';
import { RadarLabPage } from './pages/RadarLabPage';
import { ServicesPage } from './pages/ServicesPage';
import { SubscriptionPage } from './pages/SubscriptionPage';
import { TerminalPage } from './pages/TerminalPage';
import { VerifyCardPage } from './pages/VerifyCardPage';
import { WeeklyCardPage } from './pages/WeeklyCardPage';

function applyLookToRoot(look: LookId) {
  const root = document.documentElement;
  root.setAttribute('data-theme', look);
  const isLight = look === 'paper';
  root.classList.toggle('theme-light', isLight);
  root.classList.toggle('dark', !isLight);
  root.style.colorScheme = isLight ? 'light' : 'dark';
  localStorage.setItem('dollarino_look', look);
  localStorage.setItem('dollarino_theme', isLight ? 'light' : 'dark');
}

export function App() {
  const [lang, setLang] = useState<Lang>(() => (localStorage.getItem('dollarino_lang') === 'en' ? 'en' : 'fa'));
  const [look, setLook] = useState<LookId>(() => {
    const saved = localStorage.getItem('dollarino_look') as LookId | null;
    if (saved === 'paper' || saved === 'cosmic' || saved === 'obsidian' || saved === 'midnight') return saved;
    return 'cosmic';
  });
  const [uiMode, setUiMode] = useState<UiMode>(() => {
    const saved = localStorage.getItem('dollarino_ui_mode');
    if (saved === 'simple' || saved === 'pro') return saved;
    return 'pro';
  });

  const [user, setUser] = useState<AuthUserInfo | null>(null);
  const [authChecked, setAuthChecked] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);
  const [publicScreen, setPublicScreen] = useState<'landing' | 'auth'>('landing');
  const [authMode, setAuthMode] = useState<'login' | 'register'>('register');
  const [previewLanding, setPreviewLanding] = useState(false);

  const [activeTab, setActiveTab] = useState<NavTab>('overview');
  const [marketType, setMarketType] = useState<'SPOT' | 'FUTURES'>('FUTURES');
  const [terminalSymbol, setTerminalSymbol] = useState('BTCUSDT');
  const [dashboard, setDashboard] = useState<DashboardPayload | null>(null);
  const [markets, setMarkets] = useState<ExchangeMarket[]>([]);
  const [tgBotOpen, setTgBotOpen] = useState(false);
  const [appearanceOpen, setAppearanceOpen] = useState(false);
  const [verifyCardId, setVerifyCardId] = useState<string | null>(() => {
    const m = window.location.pathname.match(/^\/verify-card\/([A-Za-z0-9_-]+)/);
    return m?.[1] ?? null;
  });

  useEffect(() => {
    applyLookToRoot(look);
  }, [look]);

  useEffect(() => {
    initTelegramMiniApp(look === 'paper' ? '#F3F7FF' : '#040917');
  }, [look]);

  const handleSetLang = (l: Lang) => {
    setLang(l);
    localStorage.setItem('dollarino_lang', l);
  };

  const handleSetUiMode = (next: UiMode) => {
    setUiMode(next);
    localStorage.setItem('dollarino_ui_mode', next);
  };

  const handleSelectLook = (next: LookId) => {
    setLook(next);
    applyLookToRoot(next);
  };

  const handleToggleDaylight = () => {
    handleSelectLook(look === 'paper' ? 'cosmic' : 'paper');
  };

  const loadSessionAndDashboard = useCallback(async () => {
    try {
      setAuthError(null);
      const urlParams = new URLSearchParams(window.location.search);
      const tgLoginToken = urlParams.get('tg_login');
      if (tgLoginToken) {
        const magicRes = await apiFetch<{ token: string; user: AuthUserInfo }>('/api/auth/telegram-magic-login', {
          method: 'POST',
          body: JSON.stringify({ token: tgLoginToken }),
        });
        setStoredToken(magicRes.token);
        urlParams.delete('tg_login');
        const nextQuery = urlParams.toString();
        window.history.replaceState({}, '', `${window.location.pathname}${nextQuery ? `?${nextQuery}` : ''}`);
      }

      let me: { user: AuthUserInfo };
      try {
        me = await apiFetch<{ user: AuthUserInfo }>('/api/auth/me');
      } catch (firstErr) {
        if (isInsideTelegramMiniApp()) {
          const tg = getTelegramWebApp();
          if (tg?.initData) {
            const authRes = await apiFetch<{ token: string; user: AuthUserInfo }>('/api/auth/telegram-webapp', {
              method: 'POST',
              body: JSON.stringify({ initData: tg.initData }),
            });
            setStoredToken(authRes.token);
            me = { user: authRes.user };
          } else {
            throw firstErr;
          }
        } else {
          throw firstErr;
        }
      }
      setUser(me.user);
      const dash = await apiFetch<DashboardPayload>('/api/trading/dashboard');
      const activeMkt: 'SPOT' | 'FUTURES' = dash.config?.market_type === 'SPOT' ? 'SPOT' : 'FUTURES';
      setMarketType(activeMkt);
      const mkts = await apiFetch<{ markets: ExchangeMarket[] }>(`/api/trading/markets?marketType=${activeMkt}`).catch(() => ({ markets: [] }));
      setDashboard(dash);
      if (dash.config?.symbol) setTerminalSymbol((prev) => prev || dash.config.symbol);
      if (mkts.markets.length) setMarkets(mkts.markets);
    } catch (err) {
      setUser(null);
      setDashboard(null);
      const msg = err instanceof Error ? err.message : '';
      if (msg && !msg.includes('Authentication required')) setAuthError(msg);
    } finally {
      setAuthChecked(true);
    }
  }, []);

  useEffect(() => {
    void loadSessionAndDashboard();
  }, [loadSessionAndDashboard]);

  useEffect(() => {
    if (!user) return;
    const iv = setInterval(() => {
      void apiFetch<DashboardPayload>('/api/trading/dashboard')
        .then((d) => setDashboard(d))
        .catch(() => {});
    }, 5_000);
    return () => clearInterval(iv);
  }, [user]);

  const handleQuickDemo = async () => {
    const res = await apiFetch<{ token: string }>('/api/auth/quick-demo', { method: 'POST' });
    setStoredToken(res.token);
    setPreviewLanding(false);
    await loadSessionAndDashboard();
  };

  const handleLogout = async () => {
    await apiFetch('/api/auth/logout', { method: 'POST' }).catch(() => {});
    setStoredToken(null);
    setUser(null);
    setDashboard(null);
    setPublicScreen('landing');
  };

  const handleTopbarStartStop = async () => {
    if (!dashboard) return;
    const running = dashboard.config.bot_state.startsWith('RUNNING');
    if (running) {
      await apiFetch('/api/trading/bot/stop', { method: 'POST', body: JSON.stringify({ settleOpen: false }) });
    } else {
      await apiFetch('/api/trading/bot/start', { method: 'POST', body: JSON.stringify({ scanScope: dashboard.config.scan_scope || 'ALL_MARKET' }) });
    }
    await loadSessionAndDashboard();
  };

  const handleKillSwitch = async () => {
    await apiFetch('/api/trading/bot/kill-switch', { method: 'POST' });
    await loadSessionAndDashboard();
  };

  const handleResetDemo = async () => {
    await apiFetch('/api/trading/wallet/reset', { method: 'POST' });
    await loadSessionAndDashboard();
  };

  const handleChangeMarketType = useCallback(async (nextMkt: 'SPOT' | 'FUTURES') => {
    setMarketType(nextMkt);
    const mkts = await apiFetch<{ markets: ExchangeMarket[] }>(`/api/trading/markets?marketType=${nextMkt}`).catch(() => ({ markets: [] }));
    if (mkts.markets.length) setMarkets(mkts.markets);
  }, []);

  const openTerminalWithSymbol = (sym?: string, mkt?: 'SPOT' | 'FUTURES') => {
    if (sym) setTerminalSymbol(sym);
    if (mkt && mkt !== marketType) void handleChangeMarketType(mkt);
    setPreviewLanding(false);
    setActiveTab('terminal');
  };

  const isFa = lang === 'fa';

  // Top Quick-Experience Strip for seamless navigation across Landing, Simple, Pro, IDE, Telegram Bot & Admin
  const renderExperienceStrip = () => (
    <div
      dir={isFa ? 'rtl' : 'ltr'}
      className="sticky top-0 z-40 bg-gradient-to-r from-[#091534] via-[#0d2254] to-[#08132c] border-b border-sky-400/25 text-white px-3 py-1.5 shadow-lg"
    >
      <div className="mx-auto max-w-7xl flex items-center justify-between gap-2 overflow-x-auto no-scrollbar">
        <div className="flex items-center gap-1.5 shrink-0">
          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-emerald-500/20 border border-emerald-400/40 text-emerald-300 text-[10px] font-black">
            <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-ping" />
            <span>DOLLARINO v7.1 LIVE</span>
          </span>
        </div>

        <div className="flex items-center gap-1 sm:gap-1.5 shrink-0">
          <button
            type="button"
            onClick={() => setPreviewLanding(true)}
            className={`px-2.5 py-1 rounded-xl text-[11px] font-bold inline-flex items-center gap-1.5 transition ${
              previewLanding || !user
                ? 'bg-sky-500 text-white shadow'
                : 'bg-white/10 hover:bg-white/20 text-slate-200'
            }`}
          >
            <Globe className="w-3.5 h-3.5" />
            <span>{isFa ? 'صفحه فرود (Landing)' : 'Landing Page'}</span>
          </button>

          <button
            type="button"
            onClick={() => {
              if (!user) void handleQuickDemo();
              setPreviewLanding(false);
              handleSetUiMode('simple');
              setActiveTab('overview');
            }}
            className={`px-2.5 py-1 rounded-xl text-[11px] font-bold inline-flex items-center gap-1.5 transition ${
              !previewLanding && user && uiMode === 'simple' && activeTab === 'overview'
                ? 'bg-emerald-500 text-slate-950 font-black shadow'
                : 'bg-white/10 hover:bg-white/20 text-slate-200'
            }`}
          >
            <Sprout className="w-3.5 h-3.5" />
            <span>{isFa ? 'حالت ساده (۴ گام)' : 'Simple Mode'}</span>
          </button>

          <button
            type="button"
            onClick={() => {
              if (!user) void handleQuickDemo();
              setPreviewLanding(false);
              handleSetUiMode('pro');
              setActiveTab('overview');
            }}
            className={`px-2.5 py-1 rounded-xl text-[11px] font-bold inline-flex items-center gap-1.5 transition ${
              !previewLanding && user && uiMode === 'pro' && activeTab === 'overview'
                ? 'bg-blue-600 text-white font-black shadow'
                : 'bg-white/10 hover:bg-white/20 text-slate-200'
            }`}
          >
            <Zap className="w-3.5 h-3.5" />
            <span>{isFa ? 'میز کوانت حرفه‌ای' : 'Pro Quant Desk'}</span>
          </button>

          <button
            type="button"
            onClick={() => {
              if (!user) void handleQuickDemo();
              setPreviewLanding(false);
              handleSetUiMode('pro');
              setActiveTab('terminal');
            }}
            className={`px-2.5 py-1 rounded-xl text-[11px] font-bold inline-flex items-center gap-1.5 transition ${
              !previewLanding && user && activeTab === 'terminal'
                ? 'bg-indigo-500 text-white font-black shadow'
                : 'bg-white/10 hover:bg-white/20 text-slate-200'
            }`}
          >
            <CandlestickChart className="w-3.5 h-3.5" />
            <span>{isFa ? 'پایانه چارت + Pine/Py' : 'Chart & Pine IDE'}</span>
          </button>

          <button
            type="button"
            onClick={() => setTgBotOpen(true)}
            className="px-2.5 py-1 rounded-xl text-[11px] font-black inline-flex items-center gap-1.5 bg-sky-500/25 hover:bg-sky-500/40 border border-sky-400/40 text-sky-200 transition"
          >
            <Bot className="w-3.5 h-3.5 text-sky-300" />
            <span>{isFa ? 'ربات تلگرام @Dollarino_bot' : '@Dollarino_bot'}</span>
          </button>

          <button
            type="button"
            onClick={() => {
              if (!user) void handleQuickDemo();
              setPreviewLanding(false);
              setActiveTab('card');
            }}
            className={`px-2.5 py-1 rounded-xl text-[11px] font-bold inline-flex items-center gap-1.5 transition ${
              !previewLanding && user && activeTab === 'card'
                ? 'bg-emerald-500 text-slate-950 font-black shadow'
                : 'bg-white/10 hover:bg-white/20 text-slate-200'
            }`}
          >
            <QrCode className="w-3.5 h-3.5" />
            <span>{isFa ? 'کارت سود HMAC' : 'HMAC Card'}</span>
          </button>

          <button
            type="button"
            onClick={() => {
              if (!user) void handleQuickDemo();
              setPreviewLanding(false);
              handleSetUiMode('pro');
              setActiveTab('admin');
            }}
            className={`px-2.5 py-1 rounded-xl text-[11px] font-bold inline-flex items-center gap-1.5 transition ${
              !previewLanding && user && activeTab === 'admin'
                ? 'bg-amber-500 text-slate-950 font-black shadow'
                : 'bg-amber-500/20 hover:bg-amber-500/30 border border-amber-400/30 text-amber-200'
            }`}
          >
            <Crown className="w-3.5 h-3.5" />
            <span>{isFa ? 'پنل مدیریت' : 'Admin'}</span>
          </button>

          <button
            type="button"
            onClick={() => setAppearanceOpen(true)}
            className="px-2.5 py-1 rounded-xl text-[11px] font-bold inline-flex items-center gap-1 bg-white/10 hover:bg-white/20 text-slate-200 transition"
            title={isFa ? 'تغییر تم ظاهری' : 'Theme'}
          >
            <Palette className="w-3.5 h-3.5 text-sky-300" />
            <span className="hidden xl:inline">{isFa ? '۴ تم ظاهری' : 'Themes'}</span>
          </button>
        </div>
      </div>
    </div>
  );

  if (verifyCardId) {
    return (
      <>
        {renderExperienceStrip()}
        <VerifyCardPage
          cardId={verifyCardId}
          lang={lang}
          onBackHome={() => {
            window.history.pushState({}, '', '/');
            setVerifyCardId(null);
          }}
        />
      </>
    );
  }

  if (!authChecked) {
    return (
      <div className="min-h-screen app-shell flex items-center justify-center">
        <div className="flex flex-col items-center gap-3">
          <DollarinoBrandMark size={52} glow />
          <div className="w-8 h-8 rounded-full border-2 border-[var(--gold)] border-t-transparent animate-spin" />
        </div>
      </div>
    );
  }

  if (!user || previewLanding) {
    return (
      <>
        {renderExperienceStrip()}
        {publicScreen === 'landing' || previewLanding ? (
          <LandingPage
            lang={lang}
            setLang={handleSetLang}
            look={look === 'paper' ? 'paper' : 'cosmic'}
            onToggleDaylight={handleToggleDaylight}
            onQuickDemo={handleQuickDemo}
            onGoAuth={(mode) => {
              setPreviewLanding(false);
              setAuthMode(mode);
              setPublicScreen('auth');
            }}
          />
        ) : (
          <AuthPage
            lang={lang}
            setLang={handleSetLang}
            isLight={look === 'paper'}
            onToggleDaylight={handleToggleDaylight}
            initialMode={authMode}
            externalError={authError}
            onBack={() => setPublicScreen('landing')}
            onSuccess={loadSessionAndDashboard}
          />
        )}
        <TelegramBotModal
          open={tgBotOpen}
          lang={lang}
          data={dashboard}
          onClose={() => setTgBotOpen(false)}
          onRefresh={loadSessionAndDashboard}
        />
        <AppearanceModal
          open={appearanceOpen}
          lang={lang}
          currentLook={look}
          onSelectLook={handleSelectLook}
          onClose={() => setAppearanceOpen(false)}
        />
      </>
    );
  }

  if (!dashboard) {
    return (
      <div className="min-h-screen app-shell flex items-center justify-center p-4">
        <div className="panel rounded-3xl p-6 text-center space-y-3 max-w-sm w-full">
          <DollarinoBrandMark size={44} glow />
          <p className="text-sm font-bold text-main">
            {lang === 'fa' ? 'در حال آماده‌سازی میز کار معاملاتی...' : 'Loading your trading desk...'}
          </p>
        </div>
      </div>
    );
  }

  return (
    <>
      {renderExperienceStrip()}
      <Layout
        lang={lang}
        setLang={handleSetLang}
        uiMode={uiMode}
        onToggleUiMode={handleSetUiMode}
        currentLook={look === 'paper' ? 'paper' : 'cosmic'}
        onSelectLook={handleSelectLook}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        user={user}
        entitlement={dashboard.entitlement}
        botState={dashboard.config.bot_state}
        tradingMode={dashboard.config.trading_mode}
        activeExchangeLabel={dashboard.activeExchange.label}
        freeBalance={dashboard.balance.free}
        markets={markets}
        openTradesCount={dashboard.openTrades.length}
        recentSignalsCount={dashboard.recentSignals.length}
        onStartStop={handleTopbarStartStop}
        onKillSwitch={handleKillSwitch}
        onResetDemo={handleResetDemo}
        onSelectSymbolForTerminal={(sym) => openTerminalWithSymbol(sym)}
        onRefresh={loadSessionAndDashboard}
        onGoLanding={() => setPreviewLanding(true)}
        onLogout={handleLogout}
      >
        {activeTab === 'overview' && (
          <OverviewPage
            lang={lang}
            uiMode={uiMode}
            onToggleUiMode={handleSetUiMode}
            user={user}
            data={dashboard}
            markets={markets}
            onNavigate={setActiveTab}
            onSelectTerminalSymbol={openTerminalWithSymbol}
            onRefresh={loadSessionAndDashboard}
            onUpgradeUser={(u) => setUser(u)}
          />
        )}
        {activeTab === 'terminal' && (
          <TerminalPage
            lang={lang}
            uiMode={uiMode}
            onToggleUiMode={handleSetUiMode}
            symbol={terminalSymbol}
            setSymbol={setTerminalSymbol}
            marketType={marketType}
            onChangeMarketType={handleChangeMarketType}
            data={dashboard}
            markets={markets}
            onRefresh={loadSessionAndDashboard}
          />
        )}
        {activeTab === 'markets' && (
          <MarketsPage
            lang={lang}
            uiMode={uiMode}
            markets={markets}
            marketType={marketType}
            onChangeMarketType={handleChangeMarketType}
            onTradeSymbol={(sym) => openTerminalWithSymbol(sym, marketType)}
          />
        )}
        {activeTab === 'radar' && (
          <RadarLabPage
            lang={lang}
            data={dashboard}
            markets={markets}
            onTradeSymbol={(sym) => openTerminalWithSymbol(sym)}
            onRefresh={loadSessionAndDashboard}
          />
        )}
        {activeTab === 'copy' && (
          <CopyConnectPage
            lang={lang}
            data={dashboard}
            entitlement={dashboard.entitlement}
            onNavigate={setActiveTab}
            onRefresh={loadSessionAndDashboard}
          />
        )}
        {activeTab === 'portfolio' && (
          <PortfolioPage
            lang={lang}
            data={dashboard}
            onOpenTerminal={openTerminalWithSymbol}
            onRefresh={loadSessionAndDashboard}
          />
        )}
        {activeTab === 'services' && (
          <ServicesPage
            lang={lang}
            uiMode={uiMode}
            onToggleUiMode={handleSetUiMode}
            currentLook={look === 'paper' ? 'paper' : 'cosmic'}
            onToggleDaylight={handleToggleDaylight}
            user={user}
            data={dashboard}
            onNavigate={setActiveTab}
            onLogout={handleLogout}
          />
        )}
        {activeTab === 'card' && (
          <WeeklyCardPage
            lang={lang}
            username={user.username || user.email.split('@')[0] || 'Trader'}
            data={dashboard}
          />
        )}
        {activeTab === 'pricing' && (
          <SubscriptionPage lang={lang} onRefreshDashboard={loadSessionAndDashboard} />
        )}
        {activeTab === 'faq' && <FaqPage lang={lang} />}
        {activeTab === 'admin' && (user.role.toUpperCase() === 'ADMIN' || user.role.toUpperCase() === 'OWNER') && (
          <AdminPage lang={lang} currentUser={user} onUserUpdated={() => void loadSessionAndDashboard()} />
        )}
      </Layout>

      <TelegramBotModal
        open={tgBotOpen}
        lang={lang}
        data={dashboard}
        onClose={() => setTgBotOpen(false)}
        onRefresh={loadSessionAndDashboard}
        onNavigateTab={(tab) => {
          setPreviewLanding(false);
          setActiveTab(tab);
        }}
      />

      <AppearanceModal
        open={appearanceOpen}
        lang={lang}
        currentLook={look}
        onSelectLook={handleSelectLook}
        onClose={() => setAppearanceOpen(false)}
      />
    </>
  );
}

export default App;
