import { Gem, Moon, Sparkles, Sun, X } from 'lucide-react';
import type { Lang } from '../lib/i18n';

export type LookId = 'paper' | 'cosmic' | 'obsidian' | 'midnight';

export function AppearanceModal({
  open,
  lang,
  currentLook,
  onSelectLook,
  onClose,
}: {
  open: boolean;
  lang: Lang;
  currentLook: LookId;
  onSelectLook: (look: LookId) => void;
  onClose: () => void;
}) {
  if (!open) return null;
  const isFa = lang === 'fa';

  const themes: Array<{
    id: LookId;
    icon: typeof Sun;
    title: string;
    subtitle: string;
    color: string;
    previewBg: string;
  }> = [
    {
      id: 'cosmic',
      icon: Moon,
      title: isFa ? 'کهکشانی کُبالت' : 'Cosmic Sapphire',
      subtitle: isFa ? 'پوسته رسمی شب اپل و دلارینو' : 'Signature deep sapphire dark',
      color: '#38BDF8',
      previewBg: 'linear-gradient(135deg, #0b152d, #1652f0)',
    },
    {
      id: 'obsidian',
      icon: Gem,
      title: isFa ? 'ابسیدین طلایی' : 'Obsidian Gold',
      subtitle: isFa ? 'کوانت لوکس با طلایی شامپاینی' : 'Carbon black & champagne gold',
      color: '#FBBF24',
      previewBg: 'linear-gradient(135deg, #11131c, #f59e0b)',
    },
    {
      id: 'midnight',
      icon: Sparkles,
      title: isFa ? 'نیمه‌شب نئون' : 'Midnight Quant',
      subtitle: isFa ? 'نیلی عمیق با سیگنال زمردی' : 'Indigo cyber-quant glow',
      color: '#818CF8',
      previewBg: 'linear-gradient(135deg, #0e0e24, #6366f1)',
    },
    {
      id: 'paper',
      icon: Sun,
      title: isFa ? 'روز روشن اپل' : 'Cupertino Daylight',
      subtitle: isFa ? 'کارت‌های سفید با کنتراست بالا' : 'Crisp white cards & cobalt ink',
      color: '#F59E0B',
      previewBg: 'linear-gradient(135deg, #ffffff, #dbeafe)',
    },
  ];

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-md grid place-items-center p-4" onClick={onClose}>
      <div className="pop-in panel rounded-[30px] max-w-md w-full p-6 space-y-5 shadow-2xl" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between">
          <div>
            <h3 className="font-display font-bold text-lg text-main">
              {isFa ? 'پوسته و ظاهر پلتفرم دلارینو' : 'Dollarino Visual Theme'}
            </h3>
            <p className="text-xs text-sub mt-0.5">
              {isFa ? 'انتخاب بین ۴ تم اختصاصی شب و روز با طراحی iOS' : 'Choose from 4 signature Apple-inspired themes'}
            </p>
          </div>
          <button type="button" onClick={onClose} className="h-9 w-9 rounded-full btn-ghost grid place-items-center">
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="grid grid-cols-2 gap-3">
          {themes.map((opt) => {
            const Icon = opt.icon;
            const active = currentLook === opt.id;
            return (
              <button
                key={opt.id}
                type="button"
                onClick={() => {
                  onSelectLook(opt.id);
                  onClose();
                }}
                className={`p-4 rounded-2xl flex flex-col items-start gap-2.5 border-2 text-start transition relative overflow-hidden ${
                  active ? 'border-[var(--gold)] bg-[var(--soft)] shadow-lg' : 'border-transparent surface-soft hover:border-[var(--line-strong)]'
                }`}
              >
                <div className="flex items-center justify-between w-full">
                  <div
                    className="w-9 h-9 rounded-xl grid place-items-center shadow-inner border border-white/20"
                    style={{ background: opt.previewBg }}
                  >
                    <Icon className="w-4 h-4" style={{ color: opt.id === 'paper' ? '#1652f0' : '#ffffff' }} />
                  </div>
                  {active && (
                    <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-[var(--gold)] text-white">
                      {isFa ? 'فعال' : 'Active'}
                    </span>
                  )}
                </div>
                <div>
                  <p className="text-xs font-black text-main">{opt.title}</p>
                  <p className="text-[10px] text-dim mt-0.5">{opt.subtitle}</p>
                </div>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}
