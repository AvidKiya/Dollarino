import { useState } from 'react';
import {
  Bot,
  CheckCircle2,
  ExternalLink,
  Send,
  ShieldCheck,
  Sparkles,
  X,
} from 'lucide-react';
import { apiFetch } from '../lib/api';
import type { Lang } from '../lib/i18n';
import type { DashboardPayload } from '../lib/types';
import { DollarinoBrandMark } from './BrandGraphics';

type TgScreen =
  | 'home'
  | 'confirm_trade'
  | 'positions'
  | 'settings'
  | 'exchange'
  | 'plans'
  | 'admin_9';

export function TelegramBotModal({
  open,
  lang,
  data,
  onClose,
  onRefresh,
  onNavigateTab,
}: {
  open: boolean;
  lang: Lang;
  data: DashboardPayload | null;
  onClose: () => void;
  onRefresh: () => Promise<void>;
  onNavigateTab?: (tab: 'overview' | 'terminal' | 'copy' | 'admin' | 'card') => void;
}) {
  if (!open) return null;
  const isFa = lang === 'fa';
  const [screen, setScreen] = useState<TgScreen>('home');
  const [busy, setBusy] = useState(false);
  const [chatFeed, setChatFeed] = useState<
    Array<{
      id: string;
      time: string;
      title: string;
      lines: string[];
      badge?: string;
      tone?: 'emerald' | 'cobalt' | 'amber' | 'rose';
    }>
  >([
    {
      id: 'msg-welcome',
      time: '21:42 IRST',
      title: '🤖 ربات هوشمند ۲۴/۷ دلارینو (@Dollarino_bot · v7.1)',
      badge: 'CONNECTED · ID 944021185',
      tone: 'cobalt',
      lines: [
        'سلام کیارش عزیز! حساب شما با وب‌اپلیکیشن دلارینو همگام‌سازی شده است.',
        `🏦 صرافی فعال: ${data?.activeExchange.label || 'Toobit USDT-M Futures + Paper'}`,
        `💵 موجودی آزاد (Free): $${data?.balance.free || '11,122.37'} | درگیر (Used): $${data?.balance.used || '3,720.13'}`,
        `💎 کل موجودی (Total Equity): $${data?.balance.total || '14,842.50'} USDT`,
      ],
    },
    {
      id: 'msg-win',
      time: '21:44 IRST',
      title: '🟢 اعلان برد معامله · تارگت اول (TP1) محقق شد!',
      badge: '+$248.14 (+16.5% ROE)',
      tone: 'emerald',
      lines: [
        '💎 نماد: BTCUSDT (Futures · LONG 10×)',
        '🎯 ورود: $94,850.00 ⬅️ قیمت فعلی: $96,420.50',
        '🛡️ استاپ‌لاس خودکار به نقطه ورود منتقل شد (Risk-Free ✅)',
        '🕒 زمان ورود به وقت ایران: ۱۴۰۴/۰۸/۳۰ - ۱۸:۲۰ | بروزرسانی: ۲۱:۴۴',
      ],
    },
  ]);

  const mktType = data?.config.market_type || 'FUTURES';
  const dirMode = data?.config.direction_mode || 'BOTH';
  const hedgeOn = Boolean(data?.config.hedge_mode);
  const lev = data?.config.max_leverage || 10;
  const marginPct = data?.config.margin_pct || 5;

  const pushBotMessage = (
    title: string,
    lines: string[],
    badge?: string,
    tone: 'emerald' | 'cobalt' | 'amber' | 'rose' = 'cobalt'
  ) => {
    const nowTime = new Date().toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' }) + ' IRST';
    setChatFeed((prev) => [
      ...prev,
      {
        id: `msg-${Date.now()}-${Math.random()}`,
        time: nowTime,
        title,
        lines,
        badge,
        tone,
      },
    ]);
  };

  const handleConfirmAutoTrade = async () => {
    setBusy(true);
    try {
      await apiFetch('/api/trading/orders/manual', {
        method: 'POST',
        body: JSON.stringify({
          symbol: 'ETHUSDT',
          direction: 'LONG',
          marketType: mktType,
          leverage: mktType === 'SPOT' ? 1 : lev,
          marginUsd: 300,
        }),
      });
      await apiFetch('/api/trading/bot/start', {
        method: 'POST',
        body: JSON.stringify({ scanScope: 'ALL_MARKET' }),
      });
      await onRefresh();
      pushBotMessage(
        '✅ تایید دو مرحله‌ای انجام شد — معامله و ربات خودکار فعال گردید!',
        [
          '🚀 پوزیشن جدید: ETHUSDT · LONG با موفقیت باز شد.',
          `⚙️ بازار: ${mktType} · اهرم: ${mktType === 'SPOT' ? '1×' : `${lev}×`} · مارجین: $300.00`,
          '🛡️ حد ضرر و ۳ تارگت پله‌ای (TP1/TP2/TP3) روی صرافی ثبت گردید.',
          '🕒 ثبت به وقت ایران: ۱۴۰۴/۰۸/۳۰ - همین الان',
        ],
        'EXECUTED ✅',
        'emerald'
      );
      setScreen('home');
    } finally {
      setBusy(false);
    }
  };

  const handleToggleSpotFutures = async () => {
    const next = mktType === 'FUTURES' ? 'SPOT' : 'FUTURES';
    setBusy(true);
    try {
      await apiFetch('/api/trading/config', {
        method: 'PUT',
        body: JSON.stringify({ market_type: next }),
      });
      await onRefresh();
      pushBotMessage(
        `🔄 نوع بازار ربات به ${next === 'SPOT' ? 'اسپات (Spot 1×)' : 'فیوچرز (Futures تا 50×)'} تغییر یافت`,
        [
          next === 'SPOT'
            ? 'در حالت اسپات، اهرم به‌صورت اجباری روی 1× قفل شده و از معاملات شورت مارجین محافظت می‌شود.'
            : 'در حالت فیوچرز، امکان استفاده از اهرم تا 50× و حالت دوطرفه (Hedge Mode) فعال است.',
        ],
        next,
        'cobalt'
      );
    } finally {
      setBusy(false);
    }
  };

  const handleCycleDirection = async () => {
    const order: Array<'BOTH' | 'LONG_ONLY' | 'SHORT_ONLY'> = ['BOTH', 'LONG_ONLY', 'SHORT_ONLY'];
    const next = order[(order.indexOf(dirMode as 'BOTH') + 1) % order.length]!;
    setBusy(true);
    try {
      await apiFetch('/api/trading/config', {
        method: 'PUT',
        body: JSON.stringify({ direction_mode: next }),
      });
      await onRefresh();
      pushBotMessage(
        `🧭 جهت معامله ربات روی «${next === 'BOTH' ? 'دوطرفه (LONG + SHORT)' : next === 'LONG_ONLY' ? 'فقط خرید (LONG ONLY)' : 'فقط فروش (SHORT ONLY)'}» تنظیم شد`,
        ['تنظیمات جدید بلافاصله روی اسکنر ۸۰۷ جفت‌ارز اعمال گردید.'],
        next,
        'amber'
      );
    } finally {
      setBusy(false);
    }
  };

  const handleToggleHedge = async () => {
    const next = hedgeOn ? 0 : 1;
    setBusy(true);
    try {
      await apiFetch('/api/trading/config', {
        method: 'PUT',
        body: JSON.stringify({ hedge_mode: next }),
      });
      await onRefresh();
      pushBotMessage(
        `🛡️ حالت هج دوطرفه (Hedge Mode): ${next ? 'فعال شد ✅' : 'غیرفعال شد ❌'}`,
        ['نگهداری همزمان پوزیشن لانگ و شورت روی یک ارز در بازار فیوچرز به‌روزرسانی شد.'],
        next ? 'HEDGE ON' : 'ONE-WAY',
        'emerald'
      );
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-md flex items-center justify-center p-3 sm:p-5" onClick={onClose}>
      <div
        className="pop-in w-full max-w-4xl rounded-[32px] overflow-hidden border border-sky-400/30 shadow-2xl grid lg:grid-cols-[1fr_390px] bg-[#071022] text-white max-h-[92vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Left Column: Feature Overview & Direct Commands */}
        <div className="p-6 sm:p-7 flex flex-col justify-between space-y-5 bg-gradient-to-br from-[#0b1938] via-[#071126] to-[#040917] overflow-y-auto">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-sky-500/15 border border-sky-400/30 text-sky-300 text-[11px] font-black">
                <Bot className="w-3.5 h-3.5" />
                <span>TELEGRAM BOT v7.1 · @Dollarino_bot</span>
              </div>
              <button
                type="button"
                onClick={onClose}
                className="lg:hidden h-8 w-8 rounded-full bg-white/10 grid place-items-center"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="flex items-center gap-3.5">
              <DollarinoBrandMark size={48} glow />
              <div>
                <h2 className="font-display font-black text-xl sm:text-2xl text-white">
                  {isFa ? 'ربات جامع ۲۴/۷ تلگرام دلارینو' : 'Dollarino 24/7 Telegram Bot'}
                </h2>
                <p className="text-xs text-slate-300 mt-0.5">
                  {isFa
                    ? 'همگام‌سازی زنده با وب‌اپلیکیشن · کنترل کامل معاملات، موجودی و مدیریت داخل تلگرام'
                    : 'Live bi-directional sync with Web Desk · Full trading, wallet & admin inside Telegram'}
                </p>
              </div>
            </div>

            {/* Live Balance Strip */}
            <div className="grid grid-cols-3 gap-2.5 p-3.5 rounded-2xl bg-white/[0.05] border border-white/10">
              <div>
                <p className="text-[10px] text-slate-400">{isFa ? 'موجودی آزاد (Free)' : 'Free Balance'}</p>
                <p dir="ltr" className="text-sm font-black font-num text-emerald-400 mt-0.5">
                  ${data?.balance.free || '11,122.37'}
                </p>
              </div>
              <div>
                <p className="text-[10px] text-slate-400">{isFa ? 'درگیر معامله (Used)' : 'Used Margin'}</p>
                <p dir="ltr" className="text-sm font-black font-num text-amber-300 mt-0.5">
                  ${data?.balance.used || '3,720.13'}
                </p>
              </div>
              <div>
                <p className="text-[10px] text-slate-400">{isFa ? 'کل موجودی (Total)' : 'Total Equity'}</p>
                <p dir="ltr" className="text-sm font-black font-num text-sky-300 mt-0.5">
                  ${data?.balance.total || '14,842.50'}
                </p>
              </div>
            </div>

            {/* Interactive Bot Slash Commands */}
            <div className="space-y-2">
              <p className="text-[11px] font-black text-slate-300">
                {isFa ? 'دستورات سریع ربات (کلیک برای اجرا در شبیه‌ساز):' : 'Bot Slash Commands (Click to test live):'}
              </p>
              <div className="flex flex-wrap gap-1.5" dir="ltr">
                {[
                  { cmd: '/start', act: () => setScreen('home') },
                  {
                    cmd: '/balance',
                    act: () =>
                      pushBotMessage(
                        '💰 گزارش لحظه‌ای موجودی حساب (Paper + Toobit)',
                        [
                          `• موجودی آزاد (Free): $${data?.balance.free || '11,122.37'} USDT`,
                          `• مارجین درگیر (Used): $${data?.balance.used || '3,720.13'} USDT`,
                          `• ارزش کل (Total): $${data?.balance.total || '14,842.50'} USDT`,
                          `• سود امروز: +$${data?.stats.todayPnl?.toFixed(2) || '1,042.42'} USDT`,
                        ],
                        'BALANCE',
                        'emerald'
                      ),
                  },
                  { cmd: '/positions', act: () => setScreen('positions') },
                  { cmd: '/settings', act: () => setScreen('settings') },
                  { cmd: '/admin', act: () => setScreen('admin_9') },
                  {
                    cmd: '/weblogin',
                    act: () =>
                      pushBotMessage(
                        '🔗 لینک جادویی ورود ۱-کلیکی وب صادر شد',
                        ['https://dollarino.ir/?tg_login=MAGIC_944021185_LIVE', 'انقضا: ۱۵ دقیقه · بدون نیاز به رمز عبور'],
                        'MAGIC LINK',
                        'cobalt'
                      ),
                  },
                ].map((item) => (
                  <button
                    key={item.cmd}
                    type="button"
                    onClick={item.act}
                    className="px-3 py-1.5 rounded-xl bg-sky-500/15 hover:bg-sky-500/25 border border-sky-400/30 text-sky-300 font-mono text-xs font-bold transition"
                  >
                    {item.cmd}
                  </button>
                ))}
              </div>
            </div>

            {/* Key Capabilities Highlight */}
            <div className="grid sm:grid-cols-2 gap-2.5 text-xs">
              <div className="p-3 rounded-2xl bg-white/[0.04] border border-white/10 space-y-1">
                <p className="font-black text-emerald-400 flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>{isFa ? 'تایید دو مرحله‌ای ضدخطا' : '2-Step Trade Confirmation'}</span>
                </p>
                <p className="text-[11px] text-slate-300 leading-relaxed">
                  {isFa
                    ? 'دکمه «👈 دلارینو ترید کن برام 👉» با مرحله تایید «تایید میکنم ✅ / نه دستم خورد ❌».'
                    : 'Protected 2-step inline confirmation before deploying capital.'}
                </p>
              </div>
              <div className="p-3 rounded-2xl bg-white/[0.04] border border-white/10 space-y-1">
                <p className="font-black text-sky-300 flex items-center gap-1.5">
                  <ShieldCheck className="w-3.5 h-3.5" />
                  <span>{isFa ? 'پنل مدیریت ۹ بخشی تلگرام' : '9-Section Admin Panel'}</span>
                </p>
                <p className="text-[11px] text-slate-300 leading-relaxed">
                  {isFa
                    ? 'محدود به مدیر اصلی (944021185) با خروجی اکسل CSV/JSON و تایم‌اوت امنیتی ۱۵ دقیقه‌ای.'
                    : 'Locked to owner ID 944021185 with CSV/JSON export & 15m security timeout.'}
                </p>
              </div>
            </div>
          </div>

          <div className="pt-3 border-t border-white/10 flex flex-wrap items-center justify-between gap-2">
            <a
              href="https://t.me/Dollarino_bot"
              target="_blank"
              rel="noreferrer"
              className="btn-cobalt px-4 py-2.5 rounded-2xl text-xs font-black inline-flex items-center gap-2"
            >
              <Send className="w-3.5 h-3.5" />
              <span>{isFa ? 'باز کردن @Dollarino_bot در تلگرام' : 'Open @Dollarino_bot'}</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-2xl bg-white/10 hover:bg-white/15 text-xs font-bold transition"
            >
              {isFa ? 'بستن پنجره' : 'Close'}
            </button>
          </div>
        </div>

        {/* Right Column: Interactive iPhone Telegram Chat & Inline Keyboard */}
        <div className="flex flex-col bg-[#0e1621] border-s border-white/10 h-[620px] max-h-[88vh]">
          {/* Telegram Top Header */}
          <div className="px-4 py-3 bg-[#17212b] border-b border-white/10 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-full bg-gradient-to-br from-sky-400 to-blue-600 grid place-items-center font-black text-sm shadow">
                D
              </div>
              <div>
                <div className="flex items-center gap-1.5">
                  <span className="text-xs font-black text-white">Dollarino Bot (دلارینو)</span>
                  <span className="px-1.5 py-0.5 rounded bg-sky-500/20 text-sky-300 text-[9px] font-black">BOT</span>
                </div>
                <p className="text-[10px] text-emerald-400">@Dollarino_bot · آنلاین ۲۴/۷</p>
              </div>
            </div>
            <button
              type="button"
              onClick={onClose}
              className="hidden lg:grid h-8 w-8 rounded-full bg-white/5 hover:bg-white/10 place-items-center text-slate-300"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Telegram Messages Stream */}
          <div className="flex-1 overflow-y-auto p-3.5 space-y-3 bg-[#0e1621]">
            {chatFeed.map((msg) => (
              <div
                key={msg.id}
                className="rounded-2xl rounded-tr-sm bg-[#182533] border border-white/10 p-3.5 space-y-2 shadow-md"
              >
                <div className="flex items-center justify-between gap-2">
                  <span className="text-xs font-black text-sky-300">{msg.title}</span>
                  {msg.badge && (
                    <span
                      className={`text-[9px] font-black px-2 py-0.5 rounded-full ${
                        msg.tone === 'emerald'
                          ? 'bg-emerald-500/20 text-emerald-300'
                          : msg.tone === 'amber'
                            ? 'bg-amber-500/20 text-amber-300'
                            : 'bg-sky-500/20 text-sky-300'
                      }`}
                    >
                      {msg.badge}
                    </span>
                  )}
                </div>
                <div className="space-y-1 text-[11px] text-slate-200 leading-relaxed">
                  {msg.lines.map((l, i) => (
                    <p key={i}>{l}</p>
                  ))}
                </div>
                <div className="text-end text-[9px] text-slate-400 font-mono">{msg.time}</div>
              </div>
            ))}

            {/* Dynamic Context Card based on Selected Inline Screen */}
            {screen === 'confirm_trade' && (
              <div className="pop-in rounded-2xl bg-gradient-to-br from-emerald-950/90 to-[#182533] border border-emerald-400/40 p-3.5 space-y-2.5">
                <p className="text-xs font-black text-emerald-300">
                  ⚠️ تایید دو مرحله‌ای شروع معامله هوشمند دلارینو
                </p>
                <p className="text-[11px] text-slate-200 leading-relaxed">
                  آیا مطمئن هستید که دلارینو با سرمایه <b>$300 USDT</b>، اهرم <b>{mktType === 'SPOT' ? '1×' : `${lev}×`}</b> و استراتژی <b>دُرنا V1 + هوش مصنوعی دُرّبین</b> برای شما معامله باز کند؟
                </p>
                <div className="grid grid-cols-2 gap-2 pt-1">
                  <button
                    type="button"
                    disabled={busy}
                    onClick={() => void handleConfirmAutoTrade()}
                    className="py-2.5 px-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs transition shadow-lg"
                  >
                    {busy ? '...' : 'تایید میکنم ✅'}
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      pushBotMessage('❌ درخواست معامله لغو شد', ['هیچ سفارشی ثبت نگردید (نه دستم خورد ❌).'], 'CANCELLED', 'amber');
                      setScreen('home');
                    }}
                    className="py-2.5 px-3 rounded-xl bg-rose-500/25 hover:bg-rose-500/35 border border-rose-400/40 text-rose-200 font-black text-xs transition"
                  >
                    نه دستم خورد ❌
                  </button>
                </div>
              </div>
            )}

            {screen === 'settings' && (
              <div className="pop-in rounded-2xl bg-[#182533] border border-sky-400/30 p-3.5 space-y-2.5">
                <p className="text-xs font-black text-sky-300">🪛 تنظیم مقادیر معاملات و کنترل ربات</p>
                <div className="grid grid-cols-2 gap-1.5 text-[11px]">
                  <button
                    type="button"
                    onClick={() => void handleToggleSpotFutures()}
                    className="p-2 rounded-xl bg-[#243447] hover:bg-[#2c4057] text-white font-bold text-center"
                  >
                    بازار: {mktType === 'SPOT' ? 'اسپات (1×) 🟢' : 'فیوچرز (تا 50×) ⚡'}
                  </button>
                  <button
                    type="button"
                    onClick={() => void handleCycleDirection()}
                    className="p-2 rounded-xl bg-[#243447] hover:bg-[#2c4057] text-white font-bold text-center"
                  >
                    جهت: {dirMode === 'BOTH' ? 'دوطرفه L+S' : dirMode === 'LONG_ONLY' ? 'فقط لانگ' : 'فقط شورت'}
                  </button>
                  <button
                    type="button"
                    onClick={() => void handleToggleHedge()}
                    className="p-2 rounded-xl bg-[#243447] hover:bg-[#2c4057] text-white font-bold text-center"
                  >
                    Hedge Mode: {hedgeOn ? 'فعال ✅' : 'غیرفعال ❌'}
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      pushBotMessage('⚙️ مقادیر اهرم و مارجین ذخیره شد', [`مارجین هر معامله: ${marginPct}% · سقف اهرم: ${lev}×`], 'SAVED', 'emerald');
                    }}
                    className="p-2 rounded-xl bg-[#243447] hover:bg-[#2c4057] text-white font-bold text-center"
                  >
                    اهرم {lev}× · مارجین {marginPct}%
                  </button>
                </div>
                <button
                  type="button"
                  onClick={() => setScreen('home')}
                  className="w-full py-1.5 rounded-xl bg-white/10 text-[11px] font-bold"
                >
                  بازگشت به منوی اصلی 🔙
                </button>
              </div>
            )}

            {screen === 'positions' && (
              <div className="pop-in rounded-2xl bg-[#182533] border border-sky-400/30 p-3.5 space-y-2">
                <p className="text-xs font-black text-sky-300">
                  📊 پوزیشن‌های باز فعلی ({data?.openTrades.length || 0} معامله)
                </p>
                {(data?.openTrades || []).slice(0, 4).map((p) => (
                  <div key={p.id} className="p-2.5 rounded-xl bg-[#0e1621] flex items-center justify-between text-[11px]">
                    <div>
                      <span className="font-black text-white">{p.symbol}</span>{' '}
                      <span className="text-emerald-400 font-bold">
                        {p.direction} {p.leverage}×
                      </span>
                      <p className="text-[10px] text-slate-400">
                        Entry ${p.entry_price} · SL ${p.current_stop_loss}
                      </p>
                    </div>
                    <span className="font-mono font-black text-emerald-400">+${p.unrealized_pnl}</span>
                  </div>
                ))}
                <button
                  type="button"
                  onClick={() => setScreen('home')}
                  className="w-full py-1.5 rounded-xl bg-white/10 text-[11px] font-bold"
                >
                  بازگشت به منوی اصلی 🔙
                </button>
              </div>
            )}

            {screen === 'admin_9' && (
              <div className="pop-in rounded-2xl bg-[#182533] border border-amber-400/40 p-3.5 space-y-2.5">
                <div className="flex items-center justify-between">
                  <p className="text-xs font-black text-amber-300">👑 پنل مدیریت ۹ بخشی تلگرام (ID: 944021185)</p>
                  <span className="text-[9px] px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 font-mono">15m Lock</span>
                </div>
                <div className="grid grid-cols-3 gap-1.5 text-[10px]">
                  {[
                    '۱. آمار کل پلتفرم',
                    '۲. مدیریت کاربران',
                    '۳. تایید واریزی‌ها',
                    '۴. موتورهای AI دُرّبین',
                    '۵. ساخت کد هدیه',
                    '۶. ارسال همگانی',
                    '۷. مانیتورینگ صرافی',
                    '۸. خروجی CSV/JSON',
                    '۹. قفل امنیتی پنل',
                  ].map((sec) => (
                    <button
                      key={sec}
                      type="button"
                      onClick={() =>
                        pushBotMessage(
                          `👑 اجرا در پنل مدیریت: ${sec}`,
                          ['گزارش و عملیات مدیریتی با موفقیت اجرا شد. خروجی CSV/JSON آماده دانلود است.'],
                          'ADMIN OK',
                          'amber'
                        )
                      }
                      className="p-2 rounded-lg bg-[#243447] hover:bg-amber-500/25 text-slate-100 font-bold text-center transition"
                    >
                      {sec}
                    </button>
                  ))}
                </div>
                <div className="flex gap-2">
                  {onNavigateTab && (
                    <button
                      type="button"
                      onClick={() => {
                        onNavigateTab('admin');
                        onClose();
                      }}
                      className="flex-1 py-1.5 rounded-xl bg-amber-500 text-slate-950 text-[11px] font-black"
                    >
                      باز کردن پنل مدیریت کامل در وب 🌐
                    </button>
                  )}
                  <button
                    type="button"
                    onClick={() => setScreen('home')}
                    className="px-3 py-1.5 rounded-xl bg-white/10 text-[11px] font-bold"
                  >
                    بازگشت 🔙
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Persistent Telegram Inline Keyboard Dock */}
          <div className="p-3 bg-[#17212b] border-t border-white/10 space-y-1.5">
            <button
              type="button"
              onClick={() => setScreen('confirm_trade')}
              className="w-full py-2.5 px-3 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:brightness-110 text-slate-950 font-black text-xs shadow-lg transition flex items-center justify-center gap-1.5"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>👈 دلارینو ترید کن برام 👉</span>
            </button>

            <div className="grid grid-cols-2 gap-1.5">
              <button
                type="button"
                onClick={() => setScreen('settings')}
                className="py-2 px-2.5 rounded-xl bg-[#243447] hover:bg-[#2e425a] text-white text-[11px] font-bold transition"
              >
                تنظیم مقادیر معاملات 🪛
              </button>
              <button
                type="button"
                onClick={() => setScreen('positions')}
                className="py-2 px-2.5 rounded-xl bg-[#243447] hover:bg-[#2e425a] text-white text-[11px] font-bold transition"
              >
                پوزیشن‌های باز ({data?.openTrades.length || 0}) 📊
              </button>
              <button
                type="button"
                onClick={() =>
                  pushBotMessage(
                    '🏦 وضعیت اتصال صرافی‌های شما',
                    [
                      '• صرافی فعال: Toobit USDT-M Futures ✅',
                      '• صرافی دوم: KCEX Signal Mirror (آماده)',
                      '• حساب تمرینی: Paper Demo ($14,842.50)',
                    ],
                    'EXCHANGES',
                    'cobalt'
                  )
                }
                className="py-2 px-2.5 rounded-xl bg-[#243447] hover:bg-[#2e425a] text-white text-[11px] font-bold transition"
              >
                صرافی Toobit / KCEX 🔗
              </button>
              <button
                type="button"
                onClick={() => setScreen('admin_9')}
                className="py-2 px-2.5 rounded-xl bg-[#243447] hover:bg-[#2e425a] text-amber-300 text-[11px] font-bold transition"
              >
                پنل مدیریت ۹ بخشی 👑
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
