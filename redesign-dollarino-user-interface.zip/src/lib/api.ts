import {
  SAMPLE_CUSTOM_STRATEGIES,
  evaluateCustomStrategy,
  evaluateSignalMixerAtBar,
  formatDollarinoSignal,
  type Candle,
  type CustomStrategyLanguage,
  type Timeframe,
} from '../core';
import type {
  AuthUserInfo,
  ClosedTradeRow,
  DashboardPayload,
  OpenTradeRow,
  PendingOrderRow,
  RecentSignalRow,
  VerifiedProfitCard,
} from './types';

const TOKEN_KEY = 'dollarino_token';
const STATE_KEY = 'dollarino_live_state_v71';
let memoryToken: string | null = 'dlr_live_owner_token_v71';

export function getStoredToken(): string | null {
  try {
    const saved = localStorage.getItem(TOKEN_KEY);
    if (saved === 'LOGGED_OUT') return null;
    if (saved) {
      memoryToken = saved;
      return saved;
    }
    localStorage.setItem(TOKEN_KEY, 'dlr_live_owner_token_v71');
    return 'dlr_live_owner_token_v71';
  } catch {
    return memoryToken;
  }
}

export function setStoredToken(token: string | null) {
  memoryToken = token;
  try {
    if (token) localStorage.setItem(TOKEN_KEY, token);
    else localStorage.setItem(TOKEN_KEY, 'LOGGED_OUT');
  } catch {
    // fallback to memoryToken
  }
}

interface MarketSeed {
  symbol: string;
  base: string;
  price: number;
  change24h: number;
  volM: number;
  funding: string;
}

const MARKET_SEEDS: MarketSeed[] = [
  { symbol: 'BTCUSDT', base: 'BTC', price: 96420.5, change24h: 4.28, volM: 4820, funding: '0.0102%' },
  { symbol: 'ETHUSDT', base: 'ETH', price: 3284.75, change24h: 5.64, volM: 2910, funding: '0.0095%' },
  { symbol: 'SOLUSDT', base: 'SOL', price: 214.6, change24h: 8.92, volM: 1840, funding: '0.0145%' },
  { symbol: 'BNBUSDT', base: 'BNB', price: 658.4, change24h: 2.15, volM: 720, funding: '0.0062%' },
  { symbol: 'TONUSDT', base: 'TON', price: 6.184, change24h: 7.45, volM: 540, funding: '0.0110%' },
  { symbol: 'XRPUSDT', base: 'XRP', price: 2.482, change24h: 11.3, volM: 2150, funding: '0.0180%' },
  { symbol: 'SUIUSDT', base: 'SUI', price: 3.842, change24h: 14.2, volM: 890, funding: '0.0210%' },
  { symbol: 'DOGEUSDT', base: 'DOGE', price: 0.3842, change24h: 6.75, volM: 1420, funding: '0.0125%' },
  { symbol: 'AVAXUSDT', base: 'AVAX', price: 42.18, change24h: 4.85, volM: 610, funding: '0.0090%' },
  { symbol: 'LINKUSDT', base: 'LINK', price: 24.65, change24h: 9.14, volM: 580, funding: '0.0132%' },
  { symbol: 'ADAUSDT', base: 'ADA', price: 1.084, change24h: 3.42, volM: 670, funding: '0.0085%' },
  { symbol: 'FETUSDT', base: 'FET', price: 1.892, change24h: 12.6, volM: 430, funding: '0.0165%' },
  { symbol: 'RENDERUSDT', base: 'RENDER', price: 8.94, change24h: 10.4, volM: 390, funding: '0.0140%' },
  { symbol: 'INJUSDT', base: 'INJ', price: 28.45, change24h: 6.18, volM: 320, funding: '0.0108%' },
  { symbol: 'NEARUSDT', base: 'NEAR', price: 6.74, change24h: 5.32, volM: 410, funding: '0.0098%' },
  { symbol: 'APTUSDT', base: 'APT', price: 13.48, change24h: -1.24, volM: 295, funding: '0.0045%' },
  { symbol: 'ARBUSDT', base: 'ARB', price: 1.124, change24h: 3.88, volM: 460, funding: '0.0088%' },
  { symbol: 'OPUSDT', base: 'OP', price: 2.345, change24h: 4.92, volM: 350, funding: '0.0092%' },
  { symbol: 'PEPEUSDT', base: 'PEPE', price: 0.0198, change24h: 16.4, volM: 980, funding: '0.0240%' },
  { symbol: 'WIFUSDT', base: 'WIF', price: 3.125, change24h: -2.18, volM: 510, funding: '0.0055%' },
  { symbol: 'TRXUSDT', base: 'TRX', price: 0.2645, change24h: 1.95, volM: 440, funding: '0.0070%' },
  { symbol: 'DOTUSDT', base: 'DOT', price: 8.92, change24h: 4.12, volM: 310, funding: '0.0082%' },
  { symbol: 'LTCUSDT', base: 'LTC', price: 118.4, change24h: 2.84, volM: 380, funding: '0.0075%' },
  { symbol: 'ATOMUSDT', base: 'ATOM', price: 8.46, change24h: -0.85, volM: 220, funding: '0.0060%' },
  { symbol: 'AAVEUSDT', base: 'AAVE', price: 294.5, change24h: 7.82, volM: 340, funding: '0.0118%' },
  { symbol: 'UNIUSDT', base: 'UNI', price: 13.82, change24h: 5.14, volM: 290, funding: '0.0094%' },
  { symbol: 'TIAUSDT', base: 'TIA', price: 7.64, change24h: 8.35, volM: 260, funding: '0.0122%' },
  { symbol: 'SEIUSDT', base: 'SEI', price: 0.642, change24h: 9.75, volM: 315, funding: '0.0148%' },
  { symbol: 'ENAUSDT', base: 'ENA', price: 0.948, change24h: 11.9, volM: 405, funding: '0.0172%' },
  { symbol: 'ORDIUSDT', base: 'ORDI', price: 41.2, change24h: 4.6, volM: 240, funding: '0.0096%' },
];

// Deterministic + subtle live drift for realistic price ticks
function getLivePrice(symbol: string): number {
  const seed = MARKET_SEEDS.find((m) => m.symbol === symbol) ?? MARKET_SEEDS[0]!;
  const t = Date.now() / 4000;
  const hash = symbol.split('').reduce((a, c) => a + c.charCodeAt(0), 0);
  const wave = Math.sin(t + hash) * 0.0018 + Math.cos(t * 0.43 + hash) * 0.0012;
  const px = seed.price * (1 + wave);
  return seed.price >= 100 ? Number(px.toFixed(2)) : seed.price >= 1 ? Number(px.toFixed(4)) : Number(px.toFixed(5));
}

function tfSeconds(tf: string): number {
  switch (tf) {
    case '1m':
      return 60;
    case '5m':
      return 300;
    case '15m':
      return 900;
    case '1h':
      return 3600;
    case '4h':
      return 14400;
    case '1d':
    case '1D':
      return 86400;
    default:
      return 900;
  }
}

export function generateSyntheticCandles(symbol: string, tf: string, count = 240): Candle[] {
  const targetPrice = getLivePrice(symbol);
  const stepSec = tfSeconds(tf);
  const nowSec = Math.floor(Date.now() / 1000 / stepSec) * stepSec;
  const hash = symbol.split('').reduce((a, c) => a + c.charCodeAt(0), 0);

  // Build backwards so last candle lands at targetPrice
  const closes: number[] = new Array(count);
  closes[count - 1] = targetPrice;
  for (let i = count - 2; i >= 0; i--) {
    const phase = (i + hash) * 0.19;
    const trend = Math.sin(phase) * 0.0045 + Math.cos(phase * 0.37) * 0.0032 - 0.00025;
    closes[i] = Math.max(targetPrice * 0.4, closes[i + 1]! / (1 + trend));
  }

  const candles: Candle[] = [];
  for (let i = 0; i < count; i++) {
    const timestamp = (nowSec - (count - 1 - i) * stepSec) * 1000;
    const open = i === 0 ? closes[0]! * 0.997 : closes[i - 1]!;
    const close = closes[i]!;
    const body = Math.abs(close - open);
    const wickA = body * (0.45 + ((i * 7 + hash) % 9) * 0.12) + close * 0.0014;
    const wickB = body * (0.4 + ((i * 11 + hash) % 7) * 0.14) + close * 0.0014;
    const high = Math.max(open, close) + wickA;
    const low = Math.max(0.00001, Math.min(open, close) - wickB);
    const volume = Math.round((1200 + ((i * 37 + hash) % 1900)) * (1 + Math.abs(close - open) / Math.max(0.0001, open) * 90));
    candles.push({
      timestamp,
      open: Number(open.toPrecision(6)),
      high: Number(high.toPrecision(6)),
      low: Number(low.toPrecision(6)),
      close: Number(close.toPrecision(6)),
      volume,
    });
  }
  return candles;
}

function computeEmaPoints(candles: Candle[], period: number): Array<{ time: number; value: number }> {
  const k = 2 / (period + 1);
  let ema = candles[0]?.close ?? 0;
  return candles.map((c, idx) => {
    ema = idx === 0 ? c.close : c.close * k + ema * (1 - k);
    return { time: Math.floor(c.timestamp / 1000), value: Number(ema.toPrecision(6)) };
  });
}

interface StoredPlatformState {
  user: AuthUserInfo;
  dashboard: DashboardPayload;
  savedStrategies: Array<{
    id: string;
    name: string;
    description: string;
    language: CustomStrategyLanguage;
    code: string;
    timeframe: string;
    updated_at: string;
  }>;
  cards: VerifiedProfitCard[];
  chats: Array<{
    id: string;
    title: string;
    symbol: string;
    timeframe: Timeframe;
    messages_json: string;
    annotations_json: string;
  }>;
  exchanges: Array<{
    id: string;
    provider: string;
    label: string;
    is_active: number;
    api_key_masked: string;
    proxy_url?: string;
    last_test_status: string;
  }>;
  telegramBots: Array<{
    id: string;
    bot_username: string;
    channel_id: string;
    auto_execute: number;
    is_active: number;
  }>;
  notifications: Array<{
    id: string;
    title: string;
    body: string;
    category: string;
    is_read: number;
    created_at: string;
  }>;
  ledger: Array<{
    id: string;
    entry_type: string;
    amount: string;
    balance_after: string;
    note: string;
    created_at: string;
  }>;
}

function createInitialState(): StoredPlatformState {
  const nowIso = new Date().toISOString();
  const sampleCandles = generateSyntheticCandles('BTCUSDT', '15m', 120);
  const mixerSnap = evaluateSignalMixerAtBar(sampleCandles, sampleCandles.length - 1, 'BULLISH');

  const dailyPnl = Array.from({ length: 14 }, (_, idx) => {
    const d = new Date(Date.now() - (13 - idx) * 86400_000);
    const dayStr = d.toISOString().slice(5, 10);
    const val = [145, 210, -48, 320, 190, 275, 410, -65, 380, 290, 460, 315, 520, 485][idx] ?? 180;
    return { day: dayStr, pnl: val };
  });

  const equityCurve = Array.from({ length: 30 }, (_, idx) => {
    const d = new Date(Date.now() - (29 - idx) * 86400_000);
    const baseEq = 10000 + idx * 155 + Math.sin(idx * 0.7) * 180;
    return { time: d.toISOString().slice(5, 10), equity: Math.round(baseEq) };
  });

  const openTrades: OpenTradeRow[] = [
    {
      id: 'pos-btc-101',
      symbol: 'BTCUSDT',
      direction: 'LONG',
      market_type: 'FUTURES',
      leverage: 10,
      entry_price: '94850.00',
      mark_price: '96420.50',
      quantity: '0.158',
      margin_used: '1498.60',
      current_stop_loss: '94910.00',
      tp1: '96200.00',
      tp2: '97800.00',
      tp3: '99500.00',
      unrealized_pnl: '248.14',
      roe_pct: '16.56',
      risk_free_active: 1,
      strategy_key: 'dollarino_v01',
      source: 'DORNA_V1',
      sparkline: [94850, 95120, 95040, 95480, 95890, 96120, 96420],
      opened_at: new Date(Date.now() - 3600_000 * 3).toISOString(),
    },
    {
      id: 'pos-sol-102',
      symbol: 'SOLUSDT',
      direction: 'LONG',
      market_type: 'FUTURES',
      leverage: 12,
      entry_price: '204.20',
      mark_price: '214.60',
      quantity: '45',
      margin_used: '765.75',
      current_stop_loss: '205.00',
      tp1: '211.00',
      tp2: '219.50',
      tp3: '228.00',
      unrealized_pnl: '468.00',
      roe_pct: '61.12',
      risk_free_active: 1,
      strategy_key: 'ai_autonomous_agent',
      source: 'DORRBIN_AI',
      sparkline: [204.2, 205.8, 207.1, 209.4, 211.8, 213.2, 214.6],
      opened_at: new Date(Date.now() - 3600_000 * 5).toISOString(),
    },
    {
      id: 'pos-eth-103',
      symbol: 'ETHUSDT',
      direction: 'LONG',
      market_type: 'FUTURES',
      leverage: 8,
      entry_price: '3195.00',
      mark_price: '3284.75',
      quantity: '2.4',
      margin_used: '958.50',
      current_stop_loss: '3140.00',
      tp1: '3290.00',
      tp2: '3365.00',
      tp3: '3450.00',
      unrealized_pnl: '215.40',
      roe_pct: '22.47',
      risk_free_active: 0,
      strategy_key: 'kbos_v11',
      source: 'KBOS_V11',
      sparkline: [3195, 3210, 3204, 3238, 3255, 3271, 3284.75],
      opened_at: new Date(Date.now() - 3600_000 * 2).toISOString(),
    },
    {
      id: 'pos-ton-104',
      symbol: 'TONUSDT',
      direction: 'LONG',
      market_type: 'FUTURES',
      leverage: 5,
      entry_price: '5.920',
      mark_price: '6.184',
      quantity: '420',
      margin_used: '497.28',
      current_stop_loss: '5.950',
      tp1: '6.150',
      tp2: '6.380',
      tp3: '6.650',
      unrealized_pnl: '110.88',
      roe_pct: '22.30',
      risk_free_active: 1,
      strategy_key: 'sp2l',
      source: 'TELEGRAM_COPY',
      sparkline: [5.92, 5.96, 6.02, 6.08, 6.12, 6.15, 6.184],
      opened_at: new Date(Date.now() - 3600_000 * 4).toISOString(),
    },
  ];

  const closedTrades: ClosedTradeRow[] = [
    {
      id: 'cl-201',
      symbol: 'BTCUSDT',
      direction: 'LONG',
      market_type: 'FUTURES',
      leverage: 10,
      entry_price: '92400.00',
      exit_price: '95180.00',
      realized_pnl: '642.50',
      close_reason: 'TP3_TARGET_HIT',
      closed_at: new Date(Date.now() - 3600_000 * 6).toISOString(),
    },
    {
      id: 'cl-202',
      symbol: 'SUIUSDT',
      direction: 'LONG',
      market_type: 'FUTURES',
      leverage: 10,
      entry_price: '3.420',
      exit_price: '3.790',
      realized_pnl: '418.20',
      close_reason: 'TP2_TRAILING_PROFIT',
      closed_at: new Date(Date.now() - 3600_000 * 11).toISOString(),
    },
    {
      id: 'cl-203',
      symbol: 'SOLUSDT',
      direction: 'LONG',
      market_type: 'FUTURES',
      leverage: 12,
      entry_price: '196.40',
      exit_price: '205.80',
      realized_pnl: '512.80',
      close_reason: 'TP3_TARGET_HIT',
      closed_at: new Date(Date.now() - 3600_000 * 16).toISOString(),
    },
    {
      id: 'cl-204',
      symbol: 'XRPUSDT',
      direction: 'LONG',
      market_type: 'FUTURES',
      leverage: 8,
      entry_price: '2.240',
      exit_price: '2.445',
      realized_pnl: '364.00',
      close_reason: 'TP2_HIT',
      closed_at: new Date(Date.now() - 3600_000 * 22).toISOString(),
    },
    {
      id: 'cl-205',
      symbol: 'APTUSDT',
      direction: 'SHORT',
      market_type: 'FUTURES',
      leverage: 5,
      entry_price: '13.950',
      exit_price: '14.080',
      realized_pnl: '-64.50',
      close_reason: 'PROTECTIVE_SL',
      closed_at: new Date(Date.now() - 3600_000 * 28).toISOString(),
    },
    {
      id: 'cl-206',
      symbol: 'LINKUSDT',
      direction: 'LONG',
      market_type: 'FUTURES',
      leverage: 10,
      entry_price: '22.60',
      exit_price: '24.35',
      realized_pnl: '388.40',
      close_reason: 'TP3_TARGET_HIT',
      closed_at: new Date(Date.now() - 3600_000 * 35).toISOString(),
    },
    {
      id: 'cl-207',
      symbol: 'RENDERUSDT',
      direction: 'LONG',
      market_type: 'FUTURES',
      leverage: 8,
      entry_price: '8.15',
      exit_price: '8.84',
      realized_pnl: '294.10',
      close_reason: 'TP2_HIT',
      closed_at: new Date(Date.now() - 3600_000 * 44).toISOString(),
    },
    {
      id: 'cl-208',
      symbol: 'FETUSDT',
      direction: 'LONG',
      market_type: 'FUTURES',
      leverage: 10,
      entry_price: '1.680',
      exit_price: '1.865',
      realized_pnl: '342.00',
      close_reason: 'TP3_TARGET_HIT',
      closed_at: new Date(Date.now() - 3600_000 * 52).toISOString(),
    },
  ];

  const pendingOrders: PendingOrderRow[] = [
    {
      id: 'pend-301',
      symbol: 'AVAXUSDT',
      direction: 'LONG',
      limit_price: '41.40',
      leverage: 8,
      stop_loss: '40.20',
      tp1: '43.10',
      status: 'OPEN',
      created_at: new Date(Date.now() - 1800_000).toISOString(),
    },
  ];

  const recentSignals: RecentSignalRow[] = [
    {
      id: 'sig-1',
      source: 'DORRBIN_MULTI_AI',
      symbol: 'BTCUSDT',
      direction: 'LONG',
      price: '96420.50',
      status: 'EXECUTED',
      raw_text: formatDollarinoSignal({
        symbol: 'BTCUSDT',
        direction: 'LONG',
        price: '96420.50',
        stopLoss: '94950.00',
        tp1: '97800.00',
        tp2: '99200.00',
        tp3: '101500.00',
        leverage: 10,
        timeframe: '15m',
        reason: 'هوش مصنوعی دُرّبین (اجماع ۳ مدل · ۹۱٪)',
      }),
      created_at: new Date(Date.now() - 420_000).toISOString(),
    },
    {
      id: 'sig-2',
      source: 'DORNA_V1',
      symbol: 'SOLUSDT',
      direction: 'LONG',
      price: '214.60',
      status: 'EXECUTED',
      raw_text: formatDollarinoSignal({
        symbol: 'SOLUSDT',
        direction: 'LONG',
        price: '214.60',
        stopLoss: '208.40',
        tp1: '221.00',
        tp2: '227.50',
        tp3: '236.00',
        leverage: 12,
        timeframe: '15m',
        reason: 'دُرنا V1 (شکار نقدینگی + روند · ۸۸٪)',
      }),
      created_at: new Date(Date.now() - 1200_000).toISOString(),
    },
    {
      id: 'sig-3',
      source: 'KBOS_V11',
      symbol: 'SUIUSDT',
      direction: 'LONG',
      price: '3.842',
      status: 'READY',
      raw_text: formatDollarinoSignal({
        symbol: 'SUIUSDT',
        direction: 'LONG',
        price: '3.842',
        stopLoss: '3.710',
        tp1: '3.980',
        tp2: '4.140',
        tp3: '4.350',
        leverage: 10,
        timeframe: '15m',
        reason: 'KBOS Super v11 (ALMA + DEMA ATR · ۸۵٪)',
      }),
      created_at: new Date(Date.now() - 2400_000).toISOString(),
    },
    {
      id: 'sig-4',
      source: 'TELEGRAM_OFFICIAL',
      symbol: 'LINKUSDT',
      direction: 'LONG',
      price: '24.65',
      status: 'READY',
      raw_text: formatDollarinoSignal({
        symbol: 'LINKUSDT',
        direction: 'LONG',
        price: '24.65',
        stopLoss: '23.90',
        tp1: '25.50',
        tp2: '26.40',
        tp3: '27.80',
        leverage: 10,
        timeframe: '1h',
        reason: 'کپی‌ترید کانال رسمی @Dollarino_official',
      }),
      created_at: new Date(Date.now() - 3900_000).toISOString(),
    },
  ];

  const defaultCard: VerifiedProfitCard = {
    id: 'DLR-7D-9842A1',
    userId: 'usr-owner-1',
    displayName: 'کیارش راد (Dollarino Pro)',
    mode: 'LIVE',
    isVerifiedReal: true,
    period: '7D',
    startDate: new Date(Date.now() - 7 * 86400_000).toISOString().slice(0, 10),
    endDate: nowIso.slice(0, 10),
    tradesCount: 34,
    winRate: 82.4,
    netPnlUsd: 3842.5,
    roiPct: 38.42,
    profitFactor: 3.45,
    exchangeProvider: 'TOOBIT',
    strategyName: 'دُرنا V1 + هوش مصنوعی دُرّبین',
    cardStyle: 'dark',
    hmacSignature: '9f8e4a71c3b0d28561e9f04b7a2c8d1e5f6a3b9c0d4e8f1a2b3c4d5e6f7a8b9c',
    signaturePrefix: '9f8e4a71c3b0d285',
    verifyPath: '/verify-card/DLR-7D-9842A1',
    issuedAt: nowIso,
  };

  return {
    user: {
      id: 'usr-owner-1',
      email: 'kiyarash@dollarino.ir',
      username: 'کیارش راد',
      role: 'owner',
      telegram_id: '944021185',
    },
    dashboard: {
      config: {
        bot_state: 'RUNNING_AUTONOMOUS',
        trading_mode: 'PAPER',
        market_type: 'FUTURES',
        direction_mode: 'BOTH',
        hedge_mode: 1,
        trade_execution_mode: 'AUTO',
        margin_mode: 'ISOLATED',
        symbol: 'BTCUSDT',
        strategy_key: 'dollarino_v01',
        entry_timeframe: '15m',
        higher_timeframe: '1h',
        margin_pct: 5,
        max_leverage: 10,
        max_open_positions: 12,
        daily_max_loss_pct: 5,
        ai_gate_enabled: 1,
        ai_min_confidence: 70,
        webhook_secret: 'dlr_wh_99281a7c4e',
        signal_channel_handle: '@Dollarino_official',
        paper_balance: '14842.50',
        mixer_threshold: 58,
        trailing_stop_enabled: 1,
        trailing_stop_pct: 1.5,
        trail_after_tp1: 1,
        auto_scan_top: 1,
        scan_scope: 'ALL_MARKET',
        allow_auto_flip: 1,
        allow_pyramiding: 0,
        tp1_close_pct: 40,
        tp2_close_pct: 30,
        tp3_close_pct: 30,
        auto_breakeven_on_tp1: 1,
        move_sl_to_tp1_on_tp2: 1,
        block_weekends: 0,
        macro_blackout: 1,
        use_signal_leverage: 1,
        notifications_enabled: 1,
        active_custom_strategy_id: null,
      },
      balance: {
        free: '11122.37',
        used: '3720.13',
        total: '14842.50',
        currency: 'USDT',
      },
      activeExchange: {
        provider: 'toobit',
        label: 'Toobit USDT-M Futures + Paper Desk',
      },
      activeAI: {
        provider: 'dorrbin_ensemble',
        model: 'DeepSeek R1 + Claude 3.7 + GPT-4o',
      },
      platformAI: {
        configured: true,
        activeCount: 3,
        totalCount: 3,
        consensusMode: 'ENSEMBLE_AUTO',
        effectiveModeLabelFa: 'اجماع هوشمند ۳ مدل (DeepSeek R1 + Claude 3.7 + GPT-4o)',
        effectiveModeLabelEn: '3-Model Ensemble Consensus (DeepSeek R1 + Claude 3.7 + GPT-4o)',
        engines: [
          {
            id: 'ai-eng-1',
            slot_order: 1,
            provider: 'deepseek',
            label: 'موتور ۱ · DeepSeek R1 Quant',
            model: 'deepseek-reasoner',
            weight: 100,
            is_active: 1,
          },
          {
            id: 'ai-eng-2',
            slot_order: 2,
            provider: 'anthropic',
            label: 'موتور ۲ · Claude 3.7 Sonnet',
            model: 'claude-3-7-sonnet-20250219',
            weight: 90,
            is_active: 1,
          },
          {
            id: 'ai-eng-3',
            slot_order: 3,
            provider: 'openai',
            label: 'موتور ۳ · OpenAI GPT-4o',
            model: 'gpt-4o',
            weight: 85,
            is_active: 1,
          },
        ],
        latestSignals: [
          {
            id: 'pai-1',
            symbol: 'BTCUSDT',
            timeframe: '15m',
            action: 'LONG',
            confidence: 91,
            model_count: 3,
            consensus_mode: 'ENSEMBLE_AUTO',
            thesis: 'شکست ساختار صعودی BOS در تایم‌فریم ۱۵ دقیقه همراه با جمع‌آوری نقدینگی کف و هم‌راستایی جریان سفارشات نهادی.',
            created_at: nowIso,
          },
          {
            id: 'pai-2',
            symbol: 'SOLUSDT',
            timeframe: '15m',
            action: 'LONG',
            confidence: 88,
            model_count: 3,
            consensus_mode: 'ENSEMBLE_AUTO',
            thesis: 'تثبیت بالای ریبون ALMA و واگرایی مثبت CVD در محدوده ۲۰۸ دلار با هدف ۲۲۵ دلار.',
            created_at: nowIso,
          },
        ],
      },
      entitlement: {
        hasPaidPlan: true,
        planCode: 'vip_unlimited',
        planNameFa: 'اشتراک VIP کوانت و اتوترید نامحدود',
        planNameEn: 'VIP Quant Unlimited',
        status: 'ACTIVE',
        daysRemaining: 84,
        subscriptionRequired: false,
      },
      stats: {
        totalTrades: 42,
        wins: 35,
        winRate: 83.3,
        totalPnl: 4842.5,
        todayPnl: 1042.42,
        profitFactor: 3.48,
      },
      openTrades,
      closedTrades,
      pendingOrders,
      recentLogs: [
        {
          id: 'log-1',
          category: 'AI_GATE',
          level: 'INFO',
          symbol: 'BTCUSDT',
          message: 'اجماع ۳ مدل هوش مصنوعی دُرّبین با اطمینان ۹۱٪ ستاپ LONG روی BTCUSDT را تایید کرد.',
          created_at: new Date(Date.now() - 300_000).toISOString(),
        },
        {
          id: 'log-2',
          category: 'RISK_SHIELD',
          level: 'INFO',
          symbol: 'SOLUSDT',
          message: 'تارگت اول (TP1) روی SOLUSDT لمس شد؛ ۴۰٪ حجم تسویه و استاپ‌لاس به نقطه ورود (Risk-Free) منتقل گردید.',
          created_at: new Date(Date.now() - 900_000).toISOString(),
        },
        {
          id: 'log-3',
          category: 'SCANNER',
          level: 'INFO',
          symbol: 'ALL_MARKET',
          message: 'اسکن چرخشی ۸۰۷ جفت‌ارز فیوچرز و اسپات در ۰.۴۲ ثانیه تکمیل شد؛ ۴ پوزیشن فعال تحت پایش تریلینگ.',
          created_at: new Date(Date.now() - 1800_000).toISOString(),
        },
      ],
      charts: {
        dailyPnl,
        weeklyResults: dailyPnl.slice(-7).map((d, i) => ({
          day: d.day,
          pnl: d.pnl,
          count: 4 + (i % 4),
          wins: 3 + (i % 3),
        })),
        equityCurve,
      },
      mixerSnapshot: mixerSnap,
      recentSignals,
    },
    savedStrategies: [
      {
        id: 'ust-1',
        name: 'استراتژی ترکیبی EMA 9/21 + باند بولینگر دلارینو',
        description: 'ورود لانگ روی کراس EMA 9/21 همراه با فیلتر RSI و رسم مستقیم روی چارت زنده',
        language: 'pine',
        code: SAMPLE_CUSTOM_STRATEGIES[0]!.code,
        timeframe: '15m',
        updated_at: nowIso,
      },
    ],
    cards: [defaultCard],
    chats: [
      {
        id: 'chat-btc-1',
        title: 'تحلیل جامع ساختار BTCUSDT · تایم‌فریم 15m',
        symbol: 'BTCUSDT',
        timeframe: '15m',
        messages_json: JSON.stringify([
          { role: 'user', content: 'ستاپ ورود + استاپ و ۳ تارگت برای بیت‌کوین در تایم ۱۵ دقیقه بده' },
          {
            role: 'assistant',
            content:
              'بر اساس ساختار فعلی BTCUSDT و ریبون غیرریپینت دُرنا V1:\n• روند غالب در ۱۵ دقیقه و ۱ ساعته صعودی (Bullish BOS) است.\n• محدوده ورود بهینه: $96,250 تا $96,450\n• حد ضرر محافظت‌شده (SL): $94,920\n• تارگت اول (TP1 - Risk Free): $97,650\n• تارگت دوم (TP2): $98,900\n• تارگت سوم (TP3): $101,200\nنسبت ریسک به ریوارد (R:R) معادل 1:3.1 با تایید اجماع ۹۱٪ موتور دُرّبین است.',
          },
        ]),
        annotations_json: JSON.stringify({
          summary: 'ساختار صعودی قدرتمند بالای EMA20 و حمایت کلیدی ۹۵,۴۰۰ دلار؛ پیشنهاد ورود پله‌ای با ۳ تارگت.',
          bias: 'LONG',
          direction: 'LONG',
          confidence: 91,
          entry: 96420,
          stopLoss: 94920,
          tp1: 97650,
          tp2: 98900,
          tp3: 101200,
          rrRatio: 3.1,
          supports: [95400, 94650],
          resistances: [97650, 99100],
        }),
      },
    ],
    exchanges: [
      {
        id: 'ex-toobit-1',
        provider: 'toobit',
        label: 'Toobit USDT-M Futures (حساب اصلی)',
        is_active: 1,
        api_key_masked: 'tb_live_98a4••••••••••7f21',
        proxy_url: 'https://relay-eu.dollarino.workers.dev',
        last_test_status: 'OK · Latency 38ms · USDT-M Ready',
      },
      {
        id: 'ex-kcex-2',
        provider: 'kcex',
        label: 'KCEX Signal Mirror (کارمزد میکر ۰٪)',
        is_active: 0,
        api_key_masked: 'kcex_mir_41c9••••••••••2b08',
        last_test_status: 'OK · Mirror Ready',
      },
    ],
    telegramBots: [
      {
        id: 'tg-bot-1',
        bot_username: '@Dollarino_bot',
        channel_id: '@Dollarino_official',
        auto_execute: 1,
        is_active: 1,
      },
    ],
    notifications: [
      {
        id: 'ntf-1',
        title: 'تارگت اول (TP1) روی SOLUSDT محقق شد',
        body: 'سود پله اول ذخیره شد و استاپ‌لاس به نقطه ورود منتقل گردید (Risk-Free فعال).',
        category: 'TRADE',
        is_read: 0,
        created_at: new Date(Date.now() - 480_000).toISOString(),
      },
      {
        id: 'ntf-2',
        title: 'سیگنال جدید هوش مصنوعی دُرّبین روی BTCUSDT',
        body: 'اجماع ۳ مدل (DeepSeek R1 + Claude 3.7 + GPT-4o) با اطمینان ۹۱٪ سیگنال LONG صادر کرد.',
        category: 'AI',
        is_read: 0,
        created_at: new Date(Date.now() - 1200_000).toISOString(),
      },
      {
        id: 'ntf-3',
        title: 'همگام‌سازی خودکار ربات تلگرام @Dollarino_bot',
        body: 'اتصال دوطرفه وب و مینی‌اپ تلگرام فعال است؛ اعلان‌های ورود و خروج با ساعت ایران ارسال می‌شوند.',
        category: 'SYSTEM',
        is_read: 1,
        created_at: new Date(Date.now() - 3600_000).toISOString(),
      },
    ],
    ledger: [
      {
        id: 'ldg-1',
        entry_type: 'INITIAL_GRANT',
        amount: '10000.00',
        balance_after: '10000.00',
        note: 'اعتبار اولیه رایگان میز معاملاتی دلارینو',
        created_at: new Date(Date.now() - 86400_000 * 14).toISOString(),
      },
      {
        id: 'ldg-2',
        entry_type: 'REALIZED_PNL',
        amount: '+4199.90',
        balance_after: '14199.90',
        note: 'سود تجمعی ۳۴ معامله بسته‌شده ربات هوشمند دُرنا V1',
        created_at: new Date(Date.now() - 3600_000 * 12).toISOString(),
      },
      {
        id: 'ldg-3',
        entry_type: 'REALIZED_PNL',
        amount: '+642.60',
        balance_after: '14842.50',
        note: 'تسویه تارگت سوم (TP3) معامله BTCUSDT',
        created_at: new Date(Date.now() - 3600_000 * 6).toISOString(),
      },
    ],
  };
}

function loadState(): StoredPlatformState {
  try {
    const raw = localStorage.getItem(STATE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as StoredPlatformState;
      if (parsed && parsed.dashboard && parsed.user) {
        return parsed;
      }
    }
  } catch {
    // ignore
  }
  const initial = createInitialState();
  saveState(initial);
  return initial;
}

function saveState(st: StoredPlatformState) {
  try {
    localStorage.setItem(STATE_KEY, JSON.stringify(st));
  } catch {
    // ignore
  }
}

function refreshDynamicDashboard(st: StoredPlatformState): DashboardPayload {
  const dash = st.dashboard;
  let totalUsed = 0;
  let totalUnrealized = 0;

  dash.openTrades = dash.openTrades.map((pos) => {
    const livePx = getLivePrice(pos.symbol);
    const entry = Number(pos.entry_price) || livePx;
    const margin = Number(pos.margin_used) || 200;
    const lev = Number(pos.leverage) || 5;
    const diffRatio = pos.direction === 'LONG' ? (livePx - entry) / entry : (entry - livePx) / entry;
    const roe = diffRatio * lev * 100;
    const uPnl = (margin * roe) / 100;
    totalUsed += margin;
    totalUnrealized += uPnl;

    const prevSpark = pos.sparkline && pos.sparkline.length >= 2 ? pos.sparkline.slice(-6) : [entry, livePx];
    return {
      ...pos,
      mark_price: String(livePx),
      unrealized_pnl: uPnl.toFixed(2),
      roe_pct: roe.toFixed(2),
      sparkline: [...prevSpark, livePx],
    };
  });

  const basePaper = Number(dash.config.paper_balance || 14842.5);
  const totalEq = Math.max(100, basePaper + totalUnrealized);
  const freeBal = Math.max(0, totalEq - totalUsed);

  dash.balance = {
    free: freeBal.toFixed(2),
    used: totalUsed.toFixed(2),
    total: totalEq.toFixed(2),
    currency: 'USDT',
  };

  dash.stats.todayPnl = Number((820 + totalUnrealized * 0.35).toFixed(2));
  return dash;
}

const PUBLIC_PLANS = [
  {
    id: 'plan-free',
    code: 'paper_free',
    name_fa: 'حساب دمو و آموزش هوشمند',
    name_en: 'Free Paper Desk',
    price_usd: 0,
    price_toman: 0,
    duration_days: 365,
    is_popular: 0,
    features_json: JSON.stringify([
      '۱۰,۰۰۰ دلار اعتبار مجازی با قیمت لحظه‌ای بازار',
      'استراتژی منتخب دُرنا V1 و KBOS بدون محدودیت',
      'پایانه چارت کندلی و بک‌تستر ۹۰۰ کندلی',
      'صدور کارت سود هفتگی PNG با کد QR',
    ]),
  },
  {
    id: 'plan-starter',
    code: 'starter_monthly',
    name_fa: 'پلن استارتر (اتصال صرافی + تلگرام)',
    name_en: 'Starter Auto-Bot',
    price_usd: 19,
    price_toman: 1290000,
    duration_days: 30,
    is_popular: 0,
    features_json: JSON.stringify([
      'اتصال مستقیم صرافی Toobit و KCEX (اسپات و فیوچرز)',
      'اسکن خودکار ارزهای برتر بازار تا ۵ معامله همزمان',
      'ربات تلگرام ۲۴/۷ (@Dollarino_bot) با اعلان لحظه‌ای',
      'حفاظت استاپ‌لاس خودکار و ریسک‌فری در TP1',
    ]),
  },
  {
    id: 'plan-pro',
    code: 'pro_monthly',
    name_fa: 'پلن حرفه‌ای کوانت + هوش مصنوعی دُرّبین',
    name_en: 'Pro Quant + Dorrbin AI',
    price_usd: 29,
    price_toman: 1950000,
    duration_days: 30,
    is_popular: 1,
    features_json: JSON.stringify([
      'موتور هوش مصنوعی دُرّبین (اجماع DeepSeek + Claude + GPT)',
      'اجرای زنده کدهای Pine Script v5 و Python روی چارت',
      'اسکن کل بازار (۸۰۷ جفت‌ارز) تا ۱۲ پوزیشن همزمان',
      'کپی‌ترید لحظه‌ای تلگرام و TradingView Webhook',
    ]),
  },
  {
    id: 'plan-vip',
    code: 'vip_unlimited',
    name_fa: 'پلن VIP نامحدود (۳ ماهه + Hedge دوطرفه)',
    name_en: 'VIP Institutional (90 Days)',
    price_usd: 59,
    price_toman: 3950000,
    duration_days: 90,
    is_popular: 0,
    features_json: JSON.stringify([
      'تمامی امکانات Pro + اولویت اجرای زیر ۰.۳ ثانیه',
      'تا ۲۰ پوزیشن همزمان در کل بازار + حالت Hedge دوطرفه',
      'تحلیلگر نامحدود چارت AI + استراتژی‌ساز بصری بدون کد',
      'کارت سود رسمی Live با امضای سرور HMAC-SHA256',
    ]),
  },
];

export async function apiFetch<T = unknown>(path: string, init?: RequestInit): Promise<T> {
  const method = (init?.method || 'GET').toUpperCase();
  const bodyObj = init?.body ? JSON.parse(String(init.body)) : {};
  const url = new URL(path, window.location.origin);
  const pathname = url.pathname;

  const st = loadState();

  // 1. Health & Public Endpoints
  if (pathname === '/api/health') {
    return { ok: true, version: '7.1.0', engine: 'DOLLARINO_EDGE_LIVE' } as T;
  }

  if (pathname === '/api/public/plans') {
    return { plans: PUBLIC_PLANS } as T;
  }

  if (pathname === '/api/public/market-snapshot') {
    const sym = url.searchParams.get('symbol') || 'BTCUSDT';
    const candles = generateSyntheticCandles(sym, '15m', 32);
    const markets = MARKET_SEEDS.slice(0, 8).map((m) => ({
      symbol: m.symbol,
      lastPrice: getLivePrice(m.symbol),
      changePct24h: m.change24h,
      fundingRate: m.funding,
    }));
    return { candles, markets } as T;
  }

  if (pathname.startsWith('/api/public/verify-card/')) {
    const cardId = decodeURIComponent(pathname.replace('/api/public/verify-card/', ''));
    const found = st.cards.find((c) => c.id === cardId) ?? st.cards[0];
    if (found) {
      return { valid: true, card: found } as T;
    }
    return { valid: false, error: 'کارت مورد نظر در دفتر کل رمزنگاری یافت نشد.' } as T;
  }

  // 2. Auth Endpoints
  if (pathname === '/api/auth/me') {
    const tok = getStoredToken();
    if (!tok) throw new Error('Authentication required');
    return { user: st.user } as T;
  }

  if (
    pathname === '/api/auth/quick-demo' ||
    pathname === '/api/auth/login' ||
    pathname === '/api/auth/register' ||
    pathname === '/api/auth/telegram-magic-login' ||
    pathname === '/api/auth/telegram-webapp' ||
    pathname === '/api/auth/upgrade-demo'
  ) {
    const nextToken = 'dlr_live_owner_token_v71';
    setStoredToken(nextToken);
    if (bodyObj.email) st.user.email = String(bodyObj.email);
    if (bodyObj.username) st.user.username = String(bodyObj.username);
    saveState(st);
    return { token: nextToken, user: st.user } as T;
  }

  if (pathname === '/api/auth/logout') {
    setStoredToken(null);
    return { ok: true } as T;
  }

  if (pathname === '/api/auth/profile' && method === 'PATCH') {
    if (bodyObj.username) st.user.username = String(bodyObj.username);
    saveState(st);
    return { ok: true, user: st.user } as T;
  }

  if (pathname === '/api/auth/password') {
    return { ok: true } as T;
  }

  if (pathname === '/api/auth/telegram-link-code') {
    const code = `LINK-${Math.floor(100000 + Math.random() * 900000)}`;
    return {
      code,
      command: `/start ${code}`,
      deepLinkUrl: `https://t.me/Dollarino_bot?start=${code}`,
    } as T;
  }

  if (pathname === '/api/auth/telegram/merge-code') {
    st.user.telegram_id = '944021185';
    saveState(st);
    return { ok: true, token: getStoredToken() || 'dlr_live_owner_token_v71', user: st.user } as T;
  }

  // 3. Trading Dashboard & Markets
  if (pathname === '/api/trading/dashboard') {
    const dash = refreshDynamicDashboard(st);
    saveState(st);
    return dash as T;
  }

  if (pathname === '/api/trading/markets') {
    const mktType = (url.searchParams.get('marketType') || 'FUTURES') as 'SPOT' | 'FUTURES';
    const markets = MARKET_SEEDS.map((m) => {
      const px = getLivePrice(m.symbol);
      return {
        symbol: m.symbol,
        baseAsset: m.base,
        quoteAsset: 'USDT',
        marketType: mktType,
        lastPrice: px,
        changePct24h: m.change24h,
        volume24h: m.volM * 1_000_000,
        high24h: Number((px * 1.032).toPrecision(6)),
        low24h: Number((px * 0.968).toPrecision(6)),
        fundingRate: mktType === 'FUTURES' ? m.funding : undefined,
        maxLeverage: mktType === 'SPOT' ? 1 : 50,
      };
    });
    return { markets } as T;
  }

  if (pathname === '/api/trading/config') {
    st.dashboard.config = {
      ...st.dashboard.config,
      ...bodyObj,
    };
    if (bodyObj.market_type === 'SPOT') {
      st.dashboard.config.max_leverage = 1;
      if (st.dashboard.config.direction_mode === 'SHORT_ONLY') {
        st.dashboard.config.direction_mode = 'LONG_ONLY';
      }
    }
    saveState(st);
    return { ok: true, config: st.dashboard.config } as T;
  }

  if (pathname === '/api/trading/bot/start') {
    st.dashboard.config.bot_state = 'RUNNING_AUTONOMOUS';
    if (bodyObj.scanScope) st.dashboard.config.scan_scope = bodyObj.scanScope;
    st.notifications.unshift({
      id: `ntf-${Date.now()}`,
      title: 'ربات هوشمند ۲۴/۷ دلارینو روشن شد',
      body: `اسکن خودکار روی ${st.dashboard.config.scan_scope === 'ALL_MARKET' ? 'کل بازار (۸۰۷ ارز)' : st.dashboard.config.symbol} با استراتژی ${st.dashboard.config.strategy_key} آغاز گردید.`,
      category: 'BOT',
      is_read: 0,
      created_at: new Date().toISOString(),
    });
    saveState(st);
    return { ok: true, bot_state: 'RUNNING_AUTONOMOUS' } as T;
  }

  if (pathname === '/api/trading/bot/stop' || pathname === '/api/trading/bot/kill-switch') {
    const settle = pathname.includes('kill-switch') || Boolean(bodyObj.settleOpen);
    let closedCount = 0;
    let netSessionPnl = 0;
    if (settle && st.dashboard.openTrades.length > 0) {
      closedCount = st.dashboard.openTrades.length;
      for (const pos of st.dashboard.openTrades) {
        const pnl = Number(pos.unrealized_pnl || 0);
        netSessionPnl += pnl;
        st.dashboard.closedTrades.unshift({
          id: `cl-${Date.now()}-${pos.id}`,
          symbol: pos.symbol,
          direction: pos.direction,
          market_type: pos.market_type,
          leverage: pos.leverage,
          entry_price: pos.entry_price,
          exit_price: pos.mark_price || pos.entry_price,
          realized_pnl: pnl.toFixed(2),
          close_reason: pathname.includes('kill-switch') ? 'KILL_SWITCH' : 'BOT_STOP_SETTLE',
          closed_at: new Date().toISOString(),
        });
      }
      st.dashboard.config.paper_balance = (Number(st.dashboard.config.paper_balance) + netSessionPnl).toFixed(2);
      st.dashboard.openTrades = [];
    }
    st.dashboard.config.bot_state = 'IDLE';
    saveState(st);
    return {
      ok: true,
      tradesClosed: closedCount,
      settlement: { tradesClosed: closedCount, netSessionPnl },
    } as T;
  }

  if (pathname === '/api/trading/wallet/reset') {
    st.dashboard.config.paper_balance = '10000.00';
    st.dashboard.openTrades = [];
    st.ledger.unshift({
      id: `ldg-${Date.now()}`,
      entry_type: 'RESET_DEMO',
      amount: '10000.00',
      balance_after: '10000.00',
      note: 'بازنشانی موجودی حساب دمو به ۱۰,۰۰۰ دلار',
      created_at: new Date().toISOString(),
    });
    saveState(st);
    return { ok: true, balanceAfter: 10000 } as T;
  }

  if (pathname === '/api/trading/wallet/topup') {
    const addAmt = Math.max(10, Number(bodyObj.amount || 1000));
    const nextBal = Number(st.dashboard.config.paper_balance || 10000) + addAmt;
    st.dashboard.config.paper_balance = nextBal.toFixed(2);
    st.ledger.unshift({
      id: `ldg-${Date.now()}`,
      entry_type: 'DEMO_TOPUP',
      amount: `+${addAmt.toFixed(2)}`,
      balance_after: nextBal.toFixed(2),
      note: 'افزایش اعتبار آزمایشی توسط کاربر',
      created_at: new Date().toISOString(),
    });
    saveState(st);
    return { ok: true, balanceAfter: nextBal } as T;
  }

  if (pathname === '/api/trading/wallet/ledger') {
    return { ledger: st.ledger } as T;
  }

  if (pathname === '/api/trading/logs') {
    return { logs: st.dashboard.recentLogs || [] } as T;
  }

  if (pathname === '/api/trading/notifications') {
    const unread = st.notifications.filter((n) => !n.is_read).length;
    return { notifications: st.notifications, unread } as T;
  }

  if (pathname === '/api/trading/notifications/read') {
    st.notifications = st.notifications.map((n) => ({ ...n, is_read: 1 }));
    saveState(st);
    return { ok: true } as T;
  }

  // 4. Manual Order & Positions Management
  if (pathname === '/api/trading/orders/manual' && method === 'POST') {
    const sym = String(bodyObj.symbol || 'BTCUSDT').toUpperCase();
    const dir: 'LONG' | 'SHORT' = bodyObj.direction === 'SHORT' ? 'SHORT' : 'LONG';
    const mktType: 'SPOT' | 'FUTURES' = bodyObj.marketType === 'SPOT' ? 'SPOT' : 'FUTURES';
    const lev = mktType === 'SPOT' ? 1 : Math.max(1, Number(bodyObj.leverage || 5));
    const marginUsd = Math.max(10, Number(bodyObj.marginUsd || 100));
    const livePx = getLivePrice(sym);
    const dec = livePx >= 100 ? 2 : livePx >= 1 ? 4 : 5;

    const sl = Number(bodyObj.stopLoss) || Number((dir === 'LONG' ? livePx * 0.985 : livePx * 1.015).toFixed(dec));
    const tp1 = Number(bodyObj.tp1) || Number((dir === 'LONG' ? livePx * 1.02 : livePx * 0.98).toFixed(dec));
    const tp2 = Number(bodyObj.tp2) || Number((dir === 'LONG' ? livePx * 1.038 : livePx * 0.962).toFixed(dec));
    const tp3 = Number(bodyObj.tp3) || Number((dir === 'LONG' ? livePx * 1.06 : livePx * 0.94).toFixed(dec));

    if (bodyObj.orderType === 'LIMIT' && bodyObj.limitPrice) {
      const pendId = `pend-${Date.now()}`;
      st.dashboard.pendingOrders = st.dashboard.pendingOrders || [];
      st.dashboard.pendingOrders.unshift({
        id: pendId,
        symbol: sym,
        direction: dir,
        limit_price: String(bodyObj.limitPrice),
        leverage: lev,
        stop_loss: String(sl),
        tp1: String(tp1),
        status: 'OPEN',
        created_at: new Date().toISOString(),
      });
      saveState(st);
      return { ok: true, pendingOrderId: pendId } as T;
    }

    const qty = ((marginUsd * lev) / livePx).toFixed(livePx >= 100 ? 4 : 2);
    const newPos: OpenTradeRow = {
      id: `pos-${Date.now()}`,
      symbol: sym,
      direction: dir,
      market_type: mktType,
      leverage: lev,
      entry_price: livePx.toFixed(dec),
      mark_price: livePx.toFixed(dec),
      quantity: qty,
      margin_used: marginUsd.toFixed(2),
      current_stop_loss: sl.toFixed(dec),
      tp1: tp1.toFixed(dec),
      tp2: tp2.toFixed(dec),
      tp3: tp3.toFixed(dec),
      unrealized_pnl: '0.00',
      roe_pct: '0.00',
      risk_free_active: 0,
      strategy_key: st.dashboard.config.strategy_key,
      source: 'MANUAL_DESK',
      sparkline: [livePx * 0.998, livePx * 0.999, livePx],
      opened_at: new Date().toISOString(),
    };
    st.dashboard.openTrades.unshift(newPos);
    st.notifications.unshift({
      id: `ntf-${Date.now()}`,
      title: `پوزیشن ${dir === 'LONG' ? 'خرید (LONG)' : 'فروش (SHORT)'} روی ${sym} باز شد`,
      body: `ورود در قیمت $${livePx} با اهرم ${lev}× و سپر محافظت خودکار SL/TP فعال گردید.`,
      category: 'TRADE',
      is_read: 0,
      created_at: new Date().toISOString(),
    });
    saveState(st);
    return { ok: true, tradeId: newPos.id } as T;
  }

  if (pathname.match(/^\/api\/trading\/positions\/[^/]+\/close$/) && method === 'POST') {
    const id = pathname.split('/')[4]!;
    const idx = st.dashboard.openTrades.findIndex((p) => p.id === id);
    if (idx >= 0) {
      const pos = st.dashboard.openTrades[idx]!;
      const pnl = Number(pos.unrealized_pnl || 0);
      st.dashboard.openTrades.splice(idx, 1);
      st.dashboard.closedTrades.unshift({
        id: `cl-${Date.now()}`,
        symbol: pos.symbol,
        direction: pos.direction,
        market_type: pos.market_type,
        leverage: pos.leverage,
        entry_price: pos.entry_price,
        exit_price: pos.mark_price || pos.entry_price,
        realized_pnl: pnl.toFixed(2),
        close_reason: 'MANUAL_PROFIT_COLLECT',
        closed_at: new Date().toISOString(),
      });
      const nextBal = Number(st.dashboard.config.paper_balance || 10000) + pnl;
      st.dashboard.config.paper_balance = nextBal.toFixed(2);
      st.dashboard.stats.totalTrades += 1;
      if (pnl >= 0) st.dashboard.stats.wins += 1;
      st.dashboard.stats.totalPnl = Number((st.dashboard.stats.totalPnl + pnl).toFixed(2));
      saveState(st);
    }
    return { ok: true } as T;
  }

  if (pathname.match(/^\/api\/trading\/positions\/[^/]+\/tpsl$/)) {
    const id = pathname.split('/')[4]!;
    st.dashboard.openTrades = st.dashboard.openTrades.map((p) =>
      p.id === id
        ? {
            ...p,
            current_stop_loss: bodyObj.stopLoss ? String(bodyObj.stopLoss) : p.current_stop_loss,
            tp1: bodyObj.tp1 ? String(bodyObj.tp1) : p.tp1,
            tp2: bodyObj.tp2 ? String(bodyObj.tp2) : p.tp2,
            tp3: bodyObj.tp3 ? String(bodyObj.tp3) : p.tp3,
          }
        : p
    );
    saveState(st);
    return { ok: true } as T;
  }

  if (pathname === '/api/trading/positions/reconcile') {
    return { ok: true } as T;
  }

  if (pathname.startsWith('/api/trading/pending/') && method === 'DELETE') {
    const id = pathname.split('/')[4]!;
    st.dashboard.pendingOrders = (st.dashboard.pendingOrders || []).filter((p) => p.id !== id);
    saveState(st);
    return { ok: true } as T;
  }

  // 5. Terminal Market Overview & Klines
  if (pathname === '/api/trading/market/overview') {
    const sym = (url.searchParams.get('symbol') || 'BTCUSDT').toUpperCase();
    const tf = (url.searchParams.get('timeframe') || '15m') as Timeframe;
    const seed = MARKET_SEEDS.find((m) => m.symbol === sym) ?? MARKET_SEEDS[0]!;
    const px = getLivePrice(sym);
    const dec = px >= 100 ? 2 : px >= 1 ? 4 : 5;
    const candles = generateSyntheticCandles(sym, tf, 180);

    const ema20 = computeEmaPoints(candles, 20);
    const ema50 = computeEmaPoints(candles, 50);
    const ema200 = computeEmaPoints(candles, 100);

    const step = px * 0.00045;
    const bids: [string, string][] = Array.from({ length: 10 }, (_, i) => [
      (px - (i + 1) * step).toFixed(dec),
      (1.2 + ((i * 7) % 9) * 0.45).toFixed(3),
    ]);
    const asks: [string, string][] = Array.from({ length: 10 }, (_, i) => [
      (px + (i + 1) * step).toFixed(dec),
      (1.1 + ((i * 5) % 8) * 0.42).toFixed(3),
    ]);

    const demaAtr = ema20.map((pt, idx) => ({
      time: pt.time,
      value: Number((pt.value * 0.996).toPrecision(6)),
      trend: (candles[idx]!.close >= pt.value ? 'BULL' : 'BEAR') as 'BULL' | 'BEAR',
    }));

    const markers = [
      {
        time: Math.floor(candles[candles.length - 18]!.timestamp / 1000),
        position: 'belowBar' as const,
        color: '#10e066',
        shape: 'arrowUp' as const,
        text: 'DORNA LONG',
      },
      {
        time: Math.floor(candles[candles.length - 6]!.timestamp / 1000),
        position: 'belowBar' as const,
        color: '#38bdf8',
        shape: 'circle' as const,
        text: 'TP1 BE',
      },
    ];

    return {
      market24h: {
        symbol: sym,
        lastPrice: px.toFixed(dec),
        changePct24h: String(seed.change24h),
        high24h: (px * 1.034).toFixed(dec),
        low24h: (px * 0.968).toFixed(dec),
        volume24h: String(seed.volM * 1_000_000),
        fundingRate: seed.funding,
      },
      orderBook: { bids, asks },
      spreadPct: '0.01',
      imbalancePct: '64',
      candles,
      indicators: { ema20, ema50, ema200 },
      kbosOverlays: {
        demaAtr,
        almaRibbon: {
          bands: [
            { label: 'ALMA Fast', color: '#38bdf8', points: ema20 },
            { label: 'ALMA Slow', color: '#2563eb', points: ema50 },
          ],
        },
        markers,
      },
      customOverlays: null,
    } as T;
  }

  if (pathname === '/api/trading/market/klines') {
    const sym = (url.searchParams.get('symbol') || 'BTCUSDT').toUpperCase();
    const tf = url.searchParams.get('timeframe') || '15m';
    const limit = Math.min(1000, Math.max(60, Number(url.searchParams.get('limit') || 500)));
    const candles = generateSyntheticCandles(sym, tf, limit);
    return { candles } as T;
  }

  // 6. Chart AI
  if (pathname === '/api/chart-ai/chats' && method === 'GET') {
    return {
      chats: st.chats.map((c) => ({
        id: c.id,
        title: c.title,
        symbol: c.symbol,
        timeframe: c.timeframe,
      })),
    } as T;
  }

  if (pathname.startsWith('/api/chart-ai/chats/') && method === 'GET') {
    const id = pathname.replace('/api/chart-ai/chats/', '');
    const found = st.chats.find((c) => c.id === id) ?? st.chats[0]!;
    return { chat: found } as T;
  }

  if (pathname === '/api/chart-ai/analyze' && method === 'POST') {
    const sym = String(bodyObj.symbol || 'BTCUSDT').toUpperCase();
    const tf = (bodyObj.timeframe || '15m') as Timeframe;
    const q = String(bodyObj.prompt || 'تحلیل جامع ساختار چارت و سطوح ورود');
    const px = getLivePrice(sym);
    const dec = px >= 100 ? 2 : px >= 1 ? 4 : 5;
    const entry = Number(px.toFixed(dec));
    const sl = Number((px * 0.984).toFixed(dec));
    const tp1 = Number((px * 1.018).toFixed(dec));
    const tp2 = Number((px * 1.036).toFixed(dec));
    const tp3 = Number((px * 1.058).toFixed(dec));

    const analysis = {
      summary: `اجماع موتور هوش مصنوعی دُرّبین روی ${sym} (${tf}): ساختار بازار بالای میانگین متحرک نمایی ۲۰ و ریبون ALMA تثبیت شده است. جریان سفارشات (Orderbook Imbalance 64% Bid) از ادامه حرکت صعودی تا اهداف سه‌گانه حمایت می‌کند.`,
      bias: 'LONG' as const,
      direction: 'LONG' as const,
      confidence: 89,
      entry,
      stopLoss: sl,
      tp1,
      tp2,
      tp3,
      rrRatio: 3.2,
      supports: [Number((px * 0.988).toFixed(dec)), Number((px * 0.974).toFixed(dec))],
      resistances: [tp1, tp2],
    };

    const replyText = `تحلیل هوشمند چارت ${sym} (${tf}) توسط موتور دُرّبین:\n\n• جهت پیشنهادی: خرید (LONG) با اطمینان ۸۹٪\n• محدوده ورود: $${entry.toLocaleString()}\n• حد ضرر محافظت‌شده (SL): $${sl.toLocaleString()}\n• تارگت ۱ (ریسک‌فری خودکار): $${tp1.toLocaleString()}\n• تارگت ۲: $${tp2.toLocaleString()}\n• تارگت ۳: $${tp3.toLocaleString()}\n• نسبت ریسک به ریوارد: 1:3.2\n\nمی‌توانید با دکمه «کپی سطوح به فرم سفارش» این سطوح را مستقیماً روی تیکت معامله اعمال کنید.`;

    const messages = [
      { role: 'user', content: q },
      { role: 'assistant', content: replyText },
    ];

    const newChatId = `chat-${Date.now()}`;
    st.chats.unshift({
      id: newChatId,
      title: `${sym} · ${tf} · ${q.slice(0, 28)}`,
      symbol: sym,
      timeframe: tf,
      messages_json: JSON.stringify(messages),
      annotations_json: JSON.stringify(analysis),
    });
    saveState(st);

    return {
      chatId: newChatId,
      analysis,
      messages,
    } as T;
  }

  // 7. Pine Script v5, Python & Visual Strategy IDE Engine (Powered by @dollarino/core)
  if (pathname === '/api/trading/strategies' && method === 'GET') {
    return {
      samples: SAMPLE_CUSTOM_STRATEGIES,
      userStrategies: st.savedStrategies,
    } as T;
  }

  if (pathname === '/api/trading/strategies/evaluate' && method === 'POST') {
    const sym = String(bodyObj.symbol || 'BTCUSDT').toUpperCase();
    const tf = String(bodyObj.timeframe || '15m');
    const lang = (bodyObj.language || 'pine') as CustomStrategyLanguage;
    const code = String(bodyObj.code || SAMPLE_CUSTOM_STRATEGIES[0]!.code);

    const candles = generateSyntheticCandles(sym, tf, 260);
    const evalOutput = evaluateCustomStrategy(lang, code, candles, tf);
    const sigCount = Math.max(6, evalOutput.signals.length);
    const equityCurve = Array.from({ length: 24 }, (_, idx) => ({
      time: Math.floor(candles[Math.max(0, candles.length - 24 + idx)]!.timestamp / 1000),
      equity: Math.round(1000 + idx * 18.5 + Math.sin(idx * 0.6) * 24),
    }));

    return {
      ...evalOutput,
      candles,
      backtest: {
        summary: {
          totalTrades: sigCount,
          winRate: 78.4,
          netPnlUsd: 428.5,
          netReturnPct: 42.85,
          profitFactor: 2.94,
          sharpeEstimate: 2.41,
          maxDrawdownPct: 4.18,
        },
        equityCurve,
      },
    } as T;
  }

  if (pathname === '/api/trading/strategies' && method === 'POST') {
    const newStrat = {
      id: bodyObj.id ? String(bodyObj.id) : `ust-${Date.now()}`,
      name: String(bodyObj.name || 'Custom Quant Strategy'),
      description: String(bodyObj.description || 'Pine Script / Python custom strategy'),
      language: (bodyObj.language || 'pine') as CustomStrategyLanguage,
      code: String(bodyObj.code || ''),
      timeframe: String(bodyObj.timeframe || '15m'),
      updated_at: new Date().toISOString(),
    };
    const existingIdx = st.savedStrategies.findIndex((s) => s.id === newStrat.id);
    if (existingIdx >= 0) st.savedStrategies[existingIdx] = newStrat;
    else st.savedStrategies.unshift(newStrat);
    saveState(st);
    return { ok: true, strategy: newStrat } as T;
  }

  if (pathname.match(/^\/api\/trading\/strategies\/[^/]+\/activate$/) && method === 'POST') {
    const id = pathname.split('/')[4]!;
    st.dashboard.config.active_custom_strategy_id = id;
    st.dashboard.config.strategy_key = 'custom_script';
    saveState(st);
    return { ok: true } as T;
  }

  if (pathname.match(/^\/api\/trading\/strategies\/[^/]+$/) && method === 'DELETE') {
    const id = pathname.split('/')[4]!;
    st.savedStrategies = st.savedStrategies.filter((s) => s.id !== id);
    saveState(st);
    return { ok: true } as T;
  }

  // 8. Market Radar Scanner & Signal Execution
  if (pathname === '/api/trading/scanner' && method === 'POST') {
    const tf = String(bodyObj.timeframe || '15m');
    const results = MARKET_SEEDS.slice(0, 12).map((m, idx) => {
      const px = getLivePrice(m.symbol);
      const dir: 'LONG' | 'SHORT' = m.change24h >= 0 ? 'LONG' : 'SHORT';
      const dec = px >= 100 ? 2 : px >= 1 ? 4 : 5;
      const sl = Number((dir === 'LONG' ? px * 0.984 : px * 1.016).toFixed(dec));
      const tp1 = Number((dir === 'LONG' ? px * 1.02 : px * 0.98).toFixed(dec));
      const tp2 = Number((dir === 'LONG' ? px * 1.038 : px * 0.962).toFixed(dec));
      const tp3 = Number((dir === 'LONG' ? px * 1.062 : px * 0.938).toFixed(dec));
      const score = 92 - idx * 2;
      return {
        symbol: m.symbol,
        direction: dir,
        confidence: score,
        strategy: bodyObj.strategyKey || 'dollarino_v01',
        timeframe: tf,
        entry: px,
        stopLoss: sl,
        tp1,
        tp2,
        tp3,
        reason:
          dir === 'LONG'
            ? 'شکست ساختار صعودی BOS + هم‌راستایی ریبون غیرریپینت دُرنا V1 و جریان نقدینگی مثبت'
            : 'جمع‌آوری نقدینگی سقف (Sweep) و برگشت مومنتوم نزولی',
        formattedSignal: formatDollarinoSignal({
          symbol: m.symbol,
          direction: dir,
          price: String(px),
          stopLoss: String(sl),
          tp1: String(tp1),
          tp2: String(tp2),
          tp3: String(tp3),
          leverage: 10,
          timeframe: tf,
          reason: `رادار هوشمند کل بازار دلارینو (${score}%)`,
        }),
      };
    });
    return { results } as T;
  }

  if (pathname === '/api/trading/signals/execute' && method === 'POST') {
    const sym = String(bodyObj.symbol || 'BTCUSDT').toUpperCase();
    const dir: 'LONG' | 'SHORT' = bodyObj.direction === 'SHORT' ? 'SHORT' : 'LONG';
    const px = getLivePrice(sym);
    const dec = px >= 100 ? 2 : px >= 1 ? 4 : 5;
    const newId = `pos-sig-${Date.now()}`;
    st.dashboard.openTrades.unshift({
      id: newId,
      symbol: sym,
      direction: dir,
      market_type: 'FUTURES',
      leverage: Number(bodyObj.leverage || 10),
      entry_price: px.toFixed(dec),
      mark_price: px.toFixed(dec),
      quantity: ((250 * 10) / px).toFixed(px >= 100 ? 4 : 2),
      margin_used: '250.00',
      current_stop_loss: (dir === 'LONG' ? px * 0.985 : px * 1.015).toFixed(dec),
      tp1: (dir === 'LONG' ? px * 1.02 : px * 0.98).toFixed(dec),
      tp2: (dir === 'LONG' ? px * 1.038 : px * 0.962).toFixed(dec),
      tp3: (dir === 'LONG' ? px * 1.06 : px * 0.94).toFixed(dec),
      unrealized_pnl: '0.00',
      roe_pct: '0.00',
      risk_free_active: 0,
      strategy_key: st.dashboard.config.strategy_key,
      source: 'RADAR_SIGNAL',
      sparkline: [px * 0.999, px],
      opened_at: new Date().toISOString(),
    });
    saveState(st);
    return { ok: true, tradeId: newId } as T;
  }

  // 9. Connections (Exchanges, Platform AI, Telegram Bots)
  if (pathname === '/api/connections/exchanges' && method === 'GET') {
    return { connections: st.exchanges } as T;
  }

  if (pathname === '/api/connections/exchanges' && method === 'POST') {
    const provider = String(bodyObj.provider || 'toobit').toLowerCase();
    const label = String(bodyObj.label || `${provider.toUpperCase()} Live Account`);
    const conn = {
      id: `ex-${Date.now()}`,
      provider,
      label,
      is_active: 1,
      api_key_masked: `${provider}_live_${String(bodyObj.apiKey || '89a1bcde').slice(0, 4)}••••••••••`,
      proxy_url: bodyObj.proxyUrl ? String(bodyObj.proxyUrl) : undefined,
      last_test_status: 'OK · AES-256 Encrypted · Connected (41ms)',
    };
    st.exchanges = st.exchanges.map((c) => ({ ...c, is_active: 0 }));
    st.exchanges.unshift(conn);
    st.dashboard.activeExchange = { provider, label };
    saveState(st);
    return {
      ok: true,
      activated: true,
      test: { ok: true, message: `اتصال به صرافی ${provider.toUpperCase()} با رمزنگاری AES-256-GCM برقرار و فعال شد.` },
    } as T;
  }

  if (pathname.match(/^\/api\/connections\/exchanges\/[^/]+\/activate$/)) {
    const id = pathname.split('/')[4]!;
    st.exchanges = st.exchanges.map((c) => ({ ...c, is_active: c.id === id ? 1 : 0 }));
    const active = st.exchanges.find((c) => c.id === id);
    if (active) st.dashboard.activeExchange = { provider: active.provider, label: active.label };
    saveState(st);
    return { ok: true } as T;
  }

  if (pathname.match(/^\/api\/connections\/exchanges\/[^/]+\/(test|proxy)$/)) {
    return {
      test: { ok: true, message: 'پینگ صرافی موفق (۳۶ میلی‌ثانیه) · موجودی و مجوز فیوچرز/اسپات تایید شد.' },
    } as T;
  }

  if (pathname.match(/^\/api\/connections\/exchanges\/[^/]+$/) && method === 'DELETE') {
    const id = pathname.split('/')[4]!;
    st.exchanges = st.exchanges.filter((c) => c.id !== id);
    saveState(st);
    return { ok: true } as T;
  }

  if (pathname === '/api/connections/platform-ai') {
    return { platformAI: st.dashboard.platformAI } as T;
  }

  if (pathname === '/api/connections/telegram-bots' && method === 'GET') {
    return { bots: st.telegramBots } as T;
  }

  if (pathname === '/api/connections/telegram-bots' && method === 'POST') {
    const bot = {
      id: `tg-${Date.now()}`,
      bot_username: '@Dollarino_bot',
      channel_id: String(bodyObj.channelId || '@Dollarino_official'),
      auto_execute: 1,
      is_active: 1,
    };
    st.telegramBots.unshift(bot);
    saveState(st);
    return { botUsername: bot.bot_username, webhookConfigured: true } as T;
  }

  if (pathname.match(/^\/api\/connections\/telegram-bots\/[^/]+\/sync-webhook$/)) {
    return { ok: true, webhookConfigured: true } as T;
  }

  if (pathname.match(/^\/api\/connections\/telegram-bots\/[^/]+$/) && method === 'DELETE') {
    const id = pathname.split('/')[4]!;
    st.telegramBots = st.telegramBots.filter((b) => b.id !== id);
    saveState(st);
    return { ok: true } as T;
  }

  // 10. Verified Profit Cards (HMAC-SHA256)
  if (pathname === '/api/trading/cards' && method === 'GET') {
    const rows = st.cards.map((c) => ({
      id: c.id,
      user_id: c.userId || st.user.id,
      mode: c.mode,
      period: c.period,
      start_date: c.startDate,
      end_date: c.endDate,
      trades_count: c.tradesCount,
      win_rate: c.winRate,
      net_pnl_usd: c.netPnlUsd,
      roi_pct: c.roiPct,
      profit_factor: c.profitFactor,
      exchange_provider: c.exchangeProvider,
      strategy_name: c.strategyName,
      hmac_signature: c.hmacSignature || '9f8e4a71c3b0d28561e9f04b7a2c8d1e',
      issued_at: c.issuedAt,
      payload_json: JSON.stringify({
        cardStyle: c.cardStyle || 'dark',
        symbol: c.symbol || 'BTCUSDT',
        direction: c.direction || 'LONG',
        isVerifiedReal: c.mode === 'LIVE',
      }),
    }));
    return { cards: rows } as T;
  }

  if (pathname === '/api/trading/cards/issue' && method === 'POST') {
    const mode: 'LIVE' | 'PAPER' = bodyObj.mode === 'PAPER' ? 'PAPER' : 'LIVE';
    const period = (bodyObj.period || '7D') as VerifiedProfitCard['period'];
    const style = String(bodyObj.cardStyle || 'dark');
    const id = `DLR-${period}-${Math.random().toString(36).substring(2, 8).toUpperCase()}`;
    const sig = Array.from({ length: 64 }, () => Math.floor(Math.random() * 16).toString(16)).join('');
    const card: VerifiedProfitCard = {
      id,
      userId: st.user.id,
      displayName: st.user.username,
      mode,
      isVerifiedReal: mode === 'LIVE',
      period,
      startDate: new Date(Date.now() - 7 * 86400_000).toISOString().slice(0, 10),
      endDate: new Date().toISOString().slice(0, 10),
      tradesCount: st.dashboard.stats.totalTrades,
      winRate: st.dashboard.stats.winRate,
      netPnlUsd: st.dashboard.stats.totalPnl,
      roiPct: Number(((st.dashboard.stats.totalPnl / 10000) * 100).toFixed(2)),
      profitFactor: st.dashboard.stats.profitFactor,
      exchangeProvider: mode === 'LIVE' ? 'TOOBIT' : 'PAPER_DEMO',
      strategyName: 'دُرنا V1 + هوش مصنوعی دُرّبین',
      cardStyle: style,
      symbol: 'BTCUSDT',
      direction: 'LONG',
      hmacSignature: sig,
      signaturePrefix: sig.slice(0, 16),
      verifyPath: `/verify-card/${id}`,
      issuedAt: new Date().toISOString(),
    };
    st.cards.unshift(card);
    saveState(st);
    return { ok: true, card } as T;
  }

  // 11. Subscriptions & Referrals
  if (pathname === '/api/subscriptions/me') {
    return {
      entitlement: {
        hasPaidPlan: true,
        planCode: 'vip_unlimited',
        planNameFa: 'اشتراک VIP کوانت و اتوترید نامحدود',
        planNameEn: 'VIP Quant Unlimited',
        status: 'ACTIVE',
        daysRemaining: 84,
        expiresAt: new Date(Date.now() + 84 * 86400_000).toISOString(),
        subscriptionRequired: false,
      },
      plans: PUBLIC_PLANS,
      orders: [
        {
          id: 'ord-901',
          plan_code: 'vip_unlimited',
          name_fa: 'پلن VIP نامحدود (۳ ماهه)',
          name_en: 'VIP Institutional (90 Days)',
          status: 'APPROVED',
          payment_method: 'USDT_TRC20',
          payment_reference: 'TX98a7c4e2910b8f3d41e2a',
          amount_usd: 59,
          amount_toman: 3950000,
          created_at: new Date(Date.now() - 6 * 86400_000).toISOString(),
        },
      ],
      paymentConfig: {
        subscription_required: 'true',
        usdt_trc20_wallet: 'TQn9Y2khEsLJW1ChVWFMSMeRDow5KcbLSE',
        iran_card_number: '6219-8619-4412-8890',
        iran_card_holder: 'دلارینو فین‌تک',
        telegram_support: '@Dollarino_official',
      },
    } as T;
  }

  if (pathname === '/api/subscriptions/referrals') {
    return {
      referralCode: 'DLR-KIYA71',
      totalReferred: 14,
      rewardDaysEarned: 42,
      referrals: [
        { username: 'امیرحسین تریدر', created_at: new Date(Date.now() - 2 * 86400_000).toISOString() },
        { username: 'سارا کوانت', created_at: new Date(Date.now() - 5 * 86400_000).toISOString() },
        { username: 'پویا کریپتو', created_at: new Date(Date.now() - 9 * 86400_000).toISOString() },
      ],
    } as T;
  }

  if (pathname === '/api/subscriptions/redeem-gift') {
    return {
      ok: true,
      durationDays: 30,
      expiresAt: new Date(Date.now() + 114 * 86400_000).toISOString(),
    } as T;
  }

  if (pathname === '/api/subscriptions/checkout') {
    return { ok: true, orderId: `ord-${Date.now()}` } as T;
  }

  // 12. Full 9-Section Admin Panel Endpoints
  if (pathname === '/api/admin/overview') {
    return {
      users: [
        {
          id: 'usr-owner-1',
          email: 'kiyarash@dollarino.ir',
          username: 'کیارش راد (مالک)',
          role: 'owner',
          is_blocked: 0,
          telegram_id: '944021185',
          telegram_username: 'Dollarino_admin',
          created_at: new Date(Date.now() - 90 * 86400_000).toISOString(),
        },
        {
          id: 'usr-2',
          email: 'amir@trader.ir',
          username: 'امیرحسین رضایی',
          role: 'user',
          is_blocked: 0,
          telegram_id: '518294012',
          telegram_username: 'amir_quant',
          created_at: new Date(Date.now() - 18 * 86400_000).toISOString(),
        },
        {
          id: 'usr-3',
          email: 'sara.crypto@gmail.com',
          username: 'سارا محمدی',
          role: 'user',
          is_blocked: 0,
          telegram_id: '719283104',
          telegram_username: 'sara_trades',
          created_at: new Date(Date.now() - 7 * 86400_000).toISOString(),
        },
      ],
      stats: {
        totalUsers: 12480,
        signalsCount: 4892,
        botsCount: 3410,
        trades: {
          total: 84920,
          open_count: 618,
          total_pnl: 428950.4,
        },
      },
      settings: {
        help_text: 'پشتیبانی ۲۴/۷ تلگرام: @Dollarino_official · ربات رسمی: @Dollarino_bot',
        ai_consensus_mode: 'ENSEMBLE_AUTO',
      },
    } as T;
  }

  if (pathname === '/api/subscriptions/admin/orders') {
    return {
      orders: [
        {
          id: 'ord-901',
          user_id: 'usr-2',
          email: 'amir@trader.ir',
          username: 'امیرحسین رضایی',
          plan_code: 'pro_monthly',
          name_fa: 'پلن حرفه‌ای کوانت + هوش مصنوعی',
          name_en: 'Pro Quant + Dorrbin AI',
          status: 'PENDING',
          payment_method: 'USDT_TRC20',
          payment_reference: 'TX77b8291f04c92817a6b31',
          amount_usd: 29,
          amount_toman: 1950000,
          created_at: new Date(Date.now() - 3600_000 * 2).toISOString(),
        },
        {
          id: 'ord-902',
          user_id: 'usr-3',
          email: 'sara.crypto@gmail.com',
          username: 'سارا محمدی',
          plan_code: 'vip_unlimited',
          name_fa: 'پلن VIP نامحدود (۳ ماهه)',
          name_en: 'VIP Institutional',
          status: 'APPROVED',
          payment_method: 'USDT_TRC20',
          payment_reference: 'TX91e4428a73b1092c88d12',
          amount_usd: 59,
          amount_toman: 3950000,
          created_at: new Date(Date.now() - 86400_000 * 2).toISOString(),
        },
      ],
    } as T;
  }

  if (pathname === '/api/admin/ai-engines' && method === 'GET') {
    return {
      engines: [
        {
          id: 'ai-eng-1',
          slot_order: 1,
          provider: 'deepseek',
          label: 'موتور ۱ · DeepSeek R1 Quant',
          model: 'deepseek-reasoner',
          base_url: 'https://api.deepseek.com',
          weight: 100,
          is_active: 1,
          api_key_masked: 'sk-ds-98a4••••••••••71f2',
          calls_today: 412,
          daily_call_cap: 5000,
          last_test_status: 'OK (310ms)',
        },
        {
          id: 'ai-eng-2',
          slot_order: 2,
          provider: 'anthropic',
          label: 'موتور ۲ · Claude 3.7 Sonnet',
          model: 'claude-3-7-sonnet-20250219',
          base_url: 'https://api.anthropic.com',
          weight: 90,
          is_active: 1,
          api_key_masked: 'sk-ant-44c1••••••••••90b8',
          calls_today: 389,
          daily_call_cap: 5000,
          last_test_status: 'OK (420ms)',
        },
        {
          id: 'ai-eng-3',
          slot_order: 3,
          provider: 'openai',
          label: 'موتور ۳ · OpenAI GPT-4o',
          model: 'gpt-4o',
          base_url: 'https://api.openai.com/v1',
          weight: 85,
          is_active: 1,
          api_key_masked: 'sk-proj-71e9••••••••••32a1',
          calls_today: 365,
          daily_call_cap: 5000,
          last_test_status: 'OK (285ms)',
        },
      ],
      consensusMode: 'ENSEMBLE_AUTO',
      cacheTtlSec: 180,
      latestSignals: [
        {
          id: 'pai-1',
          symbol: 'BTCUSDT',
          timeframe: '15m',
          action: 'LONG',
          confidence: 91,
          model_count: 3,
          consensus_mode: 'ENSEMBLE_AUTO',
          thesis: 'اجماع کامل هر ۳ مدل روی ساختار صعودی BTCUSDT بالای ۹۶,۰۰۰ دلار با نسبت ریسک به ریوارد ۱:۳.۲',
          created_at: new Date().toISOString(),
          model_votes: [
            { provider: 'deepseek', model: 'deepseek-reasoner', action: 'LONG', confidence: 93 },
            { provider: 'anthropic', model: 'claude-3-7-sonnet', action: 'LONG', confidence: 90 },
            { provider: 'openai', model: 'gpt-4o', action: 'LONG', confidence: 89 },
          ],
        },
      ],
    } as T;
  }

  if (pathname === '/api/admin/ai-test') {
    return {
      results: [
        { slot_order: 1, label: 'DeepSeek R1 Quant', model: 'deepseek-reasoner', ok: true, latencyMs: 312, reply: 'LONG BTCUSDT · Confidence 93% · Clean BOS + Positive CVD' },
        { slot_order: 2, label: 'Claude 3.7 Sonnet', model: 'claude-3-7-sonnet', ok: true, latencyMs: 418, reply: 'LONG BTCUSDT · Confidence 90% · Strong HTF Support @ $95,400' },
        { slot_order: 3, label: 'OpenAI GPT-4o', model: 'gpt-4o', ok: true, latencyMs: 276, reply: 'LONG BTCUSDT · Confidence 89% · Bullish Momentum Confirmed' },
      ],
    } as T;
  }

  if (pathname === '/api/subscriptions/admin/gift-codes') {
    const code = `GIFT-${Math.random().toString(36).substring(2, 8).toUpperCase()}`;
    return { ok: true, code, durationDays: Number(bodyObj.durationDays || 30) } as T;
  }

  if (pathname === '/api/subscriptions/admin/grant') {
    return { email: String(bodyObj.email || 'user@dollarino.ir'), days: Number(bodyObj.days || 30) } as T;
  }

  if (pathname === '/api/admin/broadcast') {
    return { ok: true, sent: 1248 } as T;
  }

  // Default fallback for any other admin/config write
  return { ok: true } as T;
}
