import { useState } from "react";
import {
  ArrowLeft,
  ArrowUpRight,
  Check,
  Mail,
  MessageCircle,
  Plus,
  Send,
  ShieldCheck,
  Sparkles,
} from "lucide-react";
import { cn } from "../utils/cn";
import { Eyebrow, LiveDot, Logo, LogoMark, Reveal } from "./ui";

/* -------------------------------------------------------------------------- */
/*                                    FAQ                                     */
/* -------------------------------------------------------------------------- */

const faqs = [
  {
    q: "بدون دانش فنی می‌توانم شروع کنم؟",
    a: "بله. کل مسیر سه مرحله ساده است: ساخت حساب، اتصال صرافی و روشن کردن ربات. برای شروع حتی به صرافی هم نیاز ندارید؛ حساب دمو رایگان با قیمت زنده بازار در اختیار شماست.",
  },
  {
    q: "دارایی من در دلارینو نگهداری می‌شود؟",
    a: "خیر. دارایی شما همیشه در حساب صرافی خودتان — مثل Toobit یا KCEX — باقی می‌ماند. دلارینو فقط از طریق یک کلید API محدود به معامله به حساب شما وصل می‌شود و هیچ دسترسی برای برداشت ندارد.",
  },
  {
    q: "آیا سود تضمین می‌شود؟",
    a: "خیر. هیچ ابزاری در بازارهای مالی نمی‌تواند سود را تضمین کند. دلارینو با تحلیل چندلایه و ابزارهای کنترل ریسک تلاش می‌کند تصمیم‌گیری منظم‌تر شود، اما مسئولیت نهایی معامله با شماست.",
  },
  {
    q: "حداقل سرمایه برای شروع چقدر است؟",
    a: "برای حساب دمو هیچ مبلغی لازم نیست. در حساب واقعی، حداقل مبلغ واریز را صرافی طرف قرارداد تعیین می‌کند. پیشنهاد ما این است که ابتدا در دمو با تنظیمات خودتان آشنا شوید.",
  },
  {
    q: "چه صرافی‌هایی پشتیبانی می‌شوند؟",
    a: "در نسخه ۶.۰، Paper Demo، Toobit Futures و KCEX Futures پشتیبانی می‌شوند. اتصال صرافی‌های بیشتر در ادامه توسعه پلتفرم اضافه خواهد شد.",
  },
  {
    q: "هر لحظه می‌توانم ربات را متوقف کنم؟",
    a: "بله. دکمه توقف فوری در پنل و ربات تلگرام همیشه در دسترس است. می‌توانید معاملات جدید را متوقف کنید، اهرم را تغییر دهید یا همه پوزیشن‌ها را با یک لمس ببندید.",
  },
  {
    q: "آیا به کلید API هوش مصنوعی نیاز دارم؟",
    a: "خیر. مدل‌های هوش مصنوعی دلارینو توسط تیم مدیریت پلتفرم انتخاب و مدیریت می‌شوند. شما نیازی به ثبت کلید شخصی برای هیچ‌کدام از مدل‌ها ندارید.",
  },
];

function FaqItem({ item, index, open, onToggle }: {
  item: (typeof faqs)[number];
  index: number;
  open: boolean;
  onToggle: () => void;
}) {
  return (
    <div className="border-b border-line/80 last:border-0">
      <button
        type="button"
        onClick={onToggle}
        aria-expanded={open}
        className="flex w-full items-center gap-3 px-1 py-4 text-right sm:px-2 sm:py-5"
      >
        <span className="font-latin hidden text-[9px] font-bold text-muted/40 sm:block">
          {String(index + 1).padStart(2, "0")}
        </span>
        <span className={cn("flex-1 text-[12px] font-bold leading-relaxed transition-colors sm:text-[13px]", open ? "text-brand" : "text-ink")}>
          {item.q}
        </span>
        <span
          className={cn(
            "grid size-7 shrink-0 place-items-center rounded-full border transition-all duration-300",
            open ? "rotate-45 border-brand bg-brand text-white" : "border-line bg-white text-ink/50"
          )}
        >
          <Plus size={13} />
        </span>
      </button>
      <div
        className={cn(
          "grid transition-all duration-500 ease-[cubic-bezier(0.16,1,0.3,1)]",
          open ? "grid-rows-[1fr] opacity-100" : "grid-rows-[0fr] opacity-0"
        )}
      >
        <div className="overflow-hidden">
          <p className="pb-4 pr-1 text-[10.5px] leading-[2.05] text-muted sm:pr-8 sm:pb-5 sm:text-[11.5px]">
            {item.a}
          </p>
        </div>
      </div>
    </div>
  );
}

function Faq() {
  const [open, setOpen] = useState(0);

  return (
    <section id="faq" className="py-16 sm:py-20 lg:py-28">
      <div className="container-x grid gap-10 lg:grid-cols-[0.72fr_1.28fr] lg:gap-16">
        <div className="lg:sticky lg:top-28 lg:self-start">
          <Reveal>
            <Eyebrow>۰۹ · سوالات پرتکرار</Eyebrow>
          </Reveal>
          <Reveal delay={70}>
            <h2 className="mt-5 text-[1.85rem] font-extrabold leading-[1.45] tracking-[-0.035em] text-ink text-balance sm:text-[2.4rem]">
              قبل از شروع،
              <br className="hidden sm:block" /> هر چیزی که باید بدانید.
            </h2>
          </Reveal>
          <Reveal delay={130}>
            <p className="mt-4 max-w-sm text-[12.5px] leading-[2] text-muted">
              پاسخ سوال‌های رایج را اینجا پیدا کنید. اگر چیز دیگری در ذهن دارید، تیم دلارینو در
              تلگرام در دسترس است.
            </p>
          </Reveal>

          <Reveal delay={180}>
            <div className="relative mt-6 overflow-hidden rounded-[24px] bg-ink p-5 text-white">
              <div className="pointer-events-none absolute -left-10 -top-14 size-36 rounded-full bg-brand/40 blur-3xl" />
              <div className="relative flex items-center gap-2">
                <span className="grid size-9 place-items-center rounded-xl bg-white/10 text-lime">
                  <MessageCircle size={16} />
                </span>
                <div>
                  <p className="text-[11px] font-extrabold">پاسخ سوالتان اینجا نبود؟</p>
                  <p className="mt-0.5 text-[9px] text-white/45">تیم پشتیبانی، هر روز در دسترس</p>
                </div>
              </div>
              <a
                href="https://t.me/Dollarinoofficial"
                target="_blank"
                rel="noreferrer"
                className="relative mt-4 flex items-center justify-between rounded-xl bg-white px-3 py-2.5 text-[10px] font-extrabold text-ink transition-colors hover:bg-lime"
              >
                <span className="flex items-center gap-1.5">
                  <Send size={12} className="text-brand" />
                  گفت‌وگو در تلگرام
                </span>
                <ArrowUpLeftIcon />
              </a>
            </div>
          </Reveal>
        </div>

        <Reveal delay={100}>
          <div className="rounded-[28px] border border-line bg-white p-3 shadow-card sm:p-4">
            {faqs.map((item, index) => (
              <FaqItem
                key={item.q}
                item={item}
                index={index}
                open={open === index}
                onToggle={() => setOpen(open === index ? -1 : index)}
              />
            ))}
          </div>
          <div className="mt-3 flex items-center justify-between rounded-2xl border border-line bg-paper/60 px-4 py-3">
            <span className="flex items-center gap-2 text-[10px] text-muted">
              <ShieldCheck size={13} className="text-up" />
              پاسخ‌های شفاف، بدون وعده غیرواقعی
            </span>
            <a href="#risk" className="flex items-center gap-1 text-[9.5px] font-bold text-ink">
              مدیریت ریسک
              <ArrowLeft size={12} />
            </a>
          </div>
        </Reveal>
      </div>
    </section>
  );
}

function ArrowUpLeftIcon() {
  return <ArrowUpRight size={13} className="text-ink/40" />;
}

/* -------------------------------------------------------------------------- */
/*                                  Final CTA                                 */
/* -------------------------------------------------------------------------- */

function FinalCta() {
  const [email, setEmail] = useState("");
  const [status, setStatus] = useState<"idle" | "error" | "success">("idle");

  const submit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const valid = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email.trim());
    if (!valid) {
      setStatus("error");
      return;
    }
    setStatus("success");
  };

  return (
    <section id="start" className="pb-14 pt-2 sm:pb-20">
      <div className="container-x">
        <Reveal>
          <div className="relative overflow-hidden rounded-[32px] bg-gradient-to-br from-[#3153ff] via-[#2743ea] to-[#14249c] px-5 py-12 text-white sm:rounded-[40px] sm:px-10 sm:py-16 lg:px-16 lg:py-20">
            <div className="stars pointer-events-none absolute inset-0 opacity-80" />
            <div className="pointer-events-none absolute -right-16 -top-20 size-72 rounded-full bg-lime/15 blur-[70px]" />
            <div className="pointer-events-none absolute -bottom-24 left-1/4 size-80 rounded-full border border-white/10" />
            <div className="pointer-events-none absolute -bottom-32 left-1/3 size-96 rounded-full border border-white/[0.07]" />
            <LogoMark className="pointer-events-none absolute -bottom-16 -left-12 size-64 opacity-[0.09] sm:size-80" />

            <div className="relative mx-auto max-w-[720px] text-center">
              <Eyebrow light className="!border-white/20 !bg-white/10 !text-white/80">
                <Sparkles size={11} className="text-lime" />
                شروع بدون ریسک · بدون کارت بانکی
              </Eyebrow>

              <h2 className="mt-5 text-[1.9rem] font-extrabold leading-[1.5] tracking-[-0.035em] text-balance sm:text-[2.7rem] lg:text-[3.2rem]">
                امشب، ربات به جای شما
                <br className="hidden sm:block" /> بیدار می‌ماند.
              </h2>
              <p className="mx-auto mt-4 max-w-lg text-[12.5px] leading-[2] text-white/65 sm:text-[14px]">
                با حساب دمو رایگان شروع کنید؛ بدون سرمایه اولیه، با قیمت زنده بازار. هر وقت آماده
                بودید، با یک کلید امن به صرافی خودتان وصل شوید.
              </p>

              <div className="mx-auto mt-7 max-w-[540px]">
                {status === "success" ? (
                  <div className="animate-rise rounded-2xl border border-white/20 bg-white/10 p-4 backdrop-blur-sm">
                    <div className="flex flex-col items-center gap-2 sm:flex-row sm:text-right">
                      <span className="grid size-9 shrink-0 place-items-center rounded-full bg-lime text-ink">
                        <Check size={18} strokeWidth={3} />
                      </span>
                      <div className="flex-1">
                        <p className="text-[12.5px] font-extrabold">دموی شما آماده است.</p>
                        <p className="mt-1 text-[10.5px] text-white/60">
                          اطلاعات ورود به حساب دمو به <span className="font-latin">{email}</span> ارسال شد.
                        </p>
                      </div>
                      <a
                        href="#panel"
                        className="flex items-center gap-1.5 rounded-full bg-white px-3.5 py-2 text-[10px] font-extrabold text-ink transition-colors hover:bg-lime"
                      >
                        ورود به پنل
                        <ArrowLeft size={12} />
                      </a>
                    </div>
                  </div>
                ) : (
                  <form onSubmit={submit} noValidate>
                    <div className="flex flex-col gap-2 rounded-2xl border border-white/15 bg-white/10 p-1.5 backdrop-blur sm:flex-row sm:items-center sm:rounded-full">
                      <div className="flex flex-1 items-center gap-2 px-3">
                        <Mail size={15} className="shrink-0 text-white/40" />
                        <input
                          type="email"
                          value={email}
                          onChange={(event) => {
                            setEmail(event.target.value);
                            if (status === "error") setStatus("idle");
                          }}
                          dir="ltr"
                          placeholder="ایمیل خود را وارد کنید"
                          aria-label="آدرس ایمیل"
                          className="font-latin w-full bg-transparent py-2.5 text-center text-[12px] font-semibold text-white placeholder:text-white/30 focus:outline-none sm:text-left"
                        />
                      </div>
                      <button
                        type="submit"
                        className="group flex items-center justify-center gap-2 rounded-xl bg-white px-5 py-3 text-[11.5px] font-extrabold text-ink transition-colors hover:bg-lime sm:rounded-full"
                      >
                        شروع رایگان
                        <ArrowLeft size={14} className="transition-transform group-hover:-translate-x-1" />
                      </button>
                    </div>
                    {status === "error" && (
                      <p className="mt-2 text-right text-[9.5px] font-semibold text-[#ffd6d1]">
                        لطفاً یک ایمیل معتبر وارد کنید.
                      </p>
                    )}
                    <p className="mt-2.5 flex items-center justify-center gap-1.5 text-[8.5px] text-white/40">
                      <ShieldCheck size={11} />
                      بدون اسپم؛ فقط دسترسی دمو. هر زمان خواستید لغو کنید.
                    </p>
                  </form>
                )}
              </div>

              <div className="mt-7 flex flex-wrap items-center justify-center gap-x-5 gap-y-2.5 border-t border-white/10 pt-5 text-[9.5px] text-white/55">
                {["راه‌اندازی در ۲ دقیقه", "دموی نامحدود", "پشتیبانی ۲۴/۷"].map((item) => (
                  <span key={item} className="flex items-center gap-1.5">
                    <Check size={11} className="text-lime" strokeWidth={3} />
                    {item}
                  </span>
                ))}
                <a
                  href="https://t.me/Dollarinoofficial"
                  target="_blank"
                  rel="noreferrer"
                  className="flex items-center gap-1.5 rounded-full border border-white/20 px-3 py-1.5 font-bold text-white/80 transition-colors hover:bg-white/10"
                >
                  <Send size={11} />
                  تلگرام
                </a>
              </div>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}

/* -------------------------------------------------------------------------- */
/*                                   Footer                                   */
/* -------------------------------------------------------------------------- */

const footerColumns = [
  {
    title: "محصول",
    links: [
      { label: "هوش مصنوعی دلارینو", href: "#engines" },
      { label: "استراتژی منتخب", href: "#engines" },
      { label: "کپی‌ترید", href: "#engines" },
      { label: "کارت هفتگی", href: "#weekly" },
    ],
  },
  {
    title: "منابع",
    links: [
      { label: "چطور شروع کنیم", href: "#how" },
      { label: "ماشین‌حساب ریسک", href: "#risk" },
      { label: "امنیت", href: "#security" },
      { label: "سوالات پرتکرار", href: "#faq" },
    ],
  },
  {
    title: "دلارینو",
    links: [
      { label: "کانال تلگرام", href: "https://t.me/Dollarinoofficial" },
      { label: "پشتیبانی", href: "https://t.me/Dollarinoofficial" },
      { label: "قوانین استفاده", href: "#faq" },
      { label: "حریم خصوصی", href: "#security" },
    ],
  },
];

function Footer() {
  return (
    <footer className="border-t border-line bg-white">
      <div className="container-x pb-28 pt-12 sm:pb-10 sm:pt-14">
        <div className="grid gap-10 lg:grid-cols-[1.5fr_2fr]">
          <div className="max-w-sm">
            <Logo />
            <p className="mt-4 text-[11px] leading-[2] text-muted">
              دلارینو یک پلتفرم معامله خودکار چندارزی است که تحلیل، استراتژی و اجرا را ساده می‌کند؛
              ساخته‌شده برای اینکه با آرامش بیشتری در بازار بمانید.
            </p>
            <div className="mt-4 flex flex-wrap items-center gap-2">
              <a
                href="https://t.me/Dollarinoofficial"
                target="_blank"
                rel="noreferrer"
                className="flex items-center gap-1.5 rounded-full border border-line bg-paper px-3 py-2 text-[9.5px] font-bold text-ink/70 transition-colors hover:border-ink/20 hover:text-ink"
              >
                <Send size={11} />
                @Dollarinoofficial
              </a>
              <span className="flex items-center gap-1.5 rounded-full bg-mint/60 px-3 py-2 text-[9.5px] font-bold text-mint-deep">
                <LiveDot />
                آنلاین ۲۴/۷
              </span>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-8 sm:grid-cols-3">
            {footerColumns.map((column) => (
              <div key={column.title}>
                <p className="text-[10px] font-extrabold uppercase tracking-[0.1em] text-ink/40">{column.title}</p>
                <ul className="mt-3.5 space-y-2.5">
                  {column.links.map((link) => (
                    <li key={link.label}>
                      <a
                        href={link.href}
                        target={link.href.startsWith("http") ? "_blank" : undefined}
                        rel={link.href.startsWith("http") ? "noreferrer" : undefined}
                        className="group flex items-center gap-1 text-[10.5px] font-medium text-muted transition-colors hover:text-ink"
                      >
                        {link.label}
                        <ArrowUpRight
                          size={9}
                          className="opacity-0 transition-opacity group-hover:opacity-50"
                        />
                      </a>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>

        <div className="mt-10 rounded-2xl border border-line bg-paper/60 p-3.5">
          <p className="text-[8.5px] leading-[1.95] text-muted/80">
            <span className="font-bold text-ink/60">هشدار ریسک:</span> معامله در بازار ارزهای دیجیتال
            و قراردادهای آتی، ریسک بالایی دارد و ممکن است به از دست رفتن بخشی یا تمام سرمایه منجر
            شود. گذشته، تضمینی برای آینده نیست و هیچ سودی تضمین نمی‌شود. پیش از شروع، قوانین صرافی
            خود و سطح تحمل ریسک‌تان را بررسی کنید. دلارینو مشاور سرمایه‌گذاری نیست.
          </p>
        </div>

        <div className="mt-5 flex flex-col items-center justify-between gap-3 border-t border-line pt-5 sm:flex-row">
          <p className="text-[9px] text-muted/70">
            © ۱۴۰۵ دلارینو · تمام حقوق محفوظ است.
          </p>
          <div className="flex items-center gap-3 text-[9px] text-muted/60">
            <span className="flex items-center gap-1">
              <span className="size-1.5 rounded-full bg-mint-deep" />
              همه سیستم‌ها فعال
            </span>
            <span className="h-3 w-px bg-line" />
            <span>ساخته‌شده برای بازارهای واقعی</span>
          </div>
        </div>
      </div>
    </footer>
  );
}

export default function Closing() {
  return (
    <>
      <Faq />
      <FinalCta />
      <Footer />
    </>
  );
}
