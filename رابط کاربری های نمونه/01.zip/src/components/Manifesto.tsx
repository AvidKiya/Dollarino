import { Quote } from "lucide-react";
import { LogoMark, Reveal } from "./ui";

const principles = [
  {
    index: "۰۱",
    title: "ساده، نه ساده‌لوحانه",
    desc: "رابط کاربری آرام و خوانا است، اما منطق معاملاتی پشت آن سخت‌گیرانه طراحی شده.",
  },
  {
    index: "۰۲",
    title: "شفاف، نه وعده‌ی سود",
    desc: "هر معامله با حد ضرر، گزارش روشن و درصد اطمینان ثبت می‌شود؛ بدون ادعا.",
  },
  {
    index: "۰۳",
    title: "خودکار، نه بی‌کنترل",
    desc: "ربات اجرا می‌کند، اما اهرم، ریسک و دکمه توقف همیشه در دستان شماست.",
  },
];

const tickerWords = [
  "رصد ۲۴ ساعته بازار",
  "۳۰+ ارز پرمعامله",
  "۲۰ پوزیشن همزمان",
  "اهرم ۱ تا ۵۰",
  "بدون کلید API شخصی",
  "اجرای بدون احساس",
];

export default function Manifesto() {
  return (
    <section className="relative overflow-hidden bg-ink py-16 text-white sm:py-20 lg:py-24">
      <div className="stars pointer-events-none absolute inset-0 opacity-90" />
      <div className="pointer-events-none absolute -right-24 top-0 size-[420px] rounded-full bg-brand/25 blur-[110px]" />
      <div className="pointer-events-none absolute -left-20 bottom-0 size-[380px] rounded-full bg-lime/10 blur-[100px]" />
      <LogoMark className="pointer-events-none absolute -bottom-20 left-1/2 size-80 -translate-x-1/2 opacity-[0.05]" />

      <div className="container-x relative">
        <Reveal>
          <div className="flex items-start gap-3">
            <span className="mt-1 grid size-9 shrink-0 place-items-center rounded-full border border-white/15 bg-white/5 text-lime">
              <Quote size={15} />
            </span>
            <p className="max-w-3xl text-[1.45rem] font-extrabold leading-[1.65] tracking-[-0.03em] text-balance sm:text-[2.15rem] sm:leading-[1.5] lg:text-[2.55rem]">
              بازار ۲۴ ساعته است؛
              <br />
              <span className="text-lime">آرامش شما</span> نباید ۲۴ ساعته به هم بخورد.
            </p>
          </div>
        </Reveal>

        <div className="mt-10 grid gap-x-8 gap-y-8 border-t border-white/10 pt-8 sm:mt-12 lg:grid-cols-3">
          {principles.map((item, index) => (
            <Reveal key={item.title} delay={index * 90}>
              <div className="group relative h-full">
                <div className="flex items-baseline gap-2.5">
                  <span className="font-latin text-[11px] font-extrabold tracking-[0.16em] text-lime/70">
                    {item.index}
                  </span>
                  <h3 className="text-[15px] font-extrabold tracking-tight text-white sm:text-[17px]">{item.title}</h3>
                </div>
                <p className="mt-2.5 max-w-sm text-[11px] leading-[2.05] text-white/50 sm:text-[12px]">{item.desc}</p>
                <span className="mt-4 block h-px w-10 origin-right bg-white/20 transition-all duration-500 group-hover:w-20 group-hover:bg-lime/50" />
              </div>
            </Reveal>
          ))}
        </div>
      </div>

      {/* running band */}
      <div className="relative mt-12 border-y border-white/10 py-3 sm:mt-14">
        <div className="marquee marquee-mask overflow-hidden" dir="ltr">
          <div className="marquee-track flex items-center gap-8">
            {[...tickerWords, ...tickerWords, ...tickerWords, ...tickerWords].map((word, index) => (
              <span key={index} className="flex shrink-0 items-center gap-8">
                <span className="font-latin text-[11px] font-bold tracking-[0.18em] text-white/35">
                  {String(index + 1).padStart(2, "0")}
                </span>
                <span className="text-[12px] font-bold tracking-tight text-white/70">{word}</span>
                <span className="size-1 rounded-full bg-lime/50" />
              </span>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
