import { useState } from "react";
import { ArrowLeft, Check, Crown, CreditCard, FlaskConical, Rocket, ShieldCheck, Wallet } from "lucide-react";
import { cn } from "../utils/cn";
import { LogoMark, Reveal, SectionHeading } from "./ui";

type Currency = "usd" | "toman";

const plans = [
  {
    id: "demo",
    name: "تست دمو",
    tag: "رایگان برای همیشه",
    desc: "تست استراتژی منتخب دلارینو در حساب دمو با قیمت زنده بازار.",
    usd: 0,
    toman: 0,
    days: null as number | null,
    icon: FlaskConical,
    features: [
      "حساب دمو با قیمت زنده بازار",
      "اجرای استراتژی منتخب (موتور دُرنا V1)",
      "معامله همزمان روی کل بازار",
      "نصب اپلیکیشن روی موبایل و ویندوز",
    ],
    cta: "شروع تست دمو رایگان",
  },
  {
    id: "pro",
    name: "حرفه‌ای ماهانه",
    tag: "محبوب‌ترین",
    desc: "دسترسی کامل به هوش مصنوعی، استراتژی منتخب و کپی‌ترید دلارینو.",
    usd: 29,
    toman: 1950000,
    days: 30,
    icon: Rocket,
    features: [
      "هوش مصنوعی دلارینو، بدون نیاز به API",
      "کپی‌ترید خودکار از تلگرام",
      "اتصال صرافی واقعی (Toobit · KCEX)",
      "کارت هفتگی و حالت Pro تریدرها",
    ],
    cta: "ثبت‌نام و خرید اشتراک",
  },
  {
    id: "quarter",
    name: "ویژه ۳ ماهه",
    tag: "۳۲٪ تخفیف",
    desc: "۹۰ روز همه امکانات حرفه‌ای با بهترین قیمت.",
    usd: 59,
    toman: 3950000,
    days: 90,
    icon: Crown,
    features: [
      "۹۰ روز دسترسی کامل به همه موتورها",
      "سقف بالاتر پردازش هوشمند کل بازار",
      "پشتیبانی و راه‌اندازی اختصاصی",
      "اولویت در دریافت قابلیت‌های جدید",
    ],
    cta: "ثبت‌نام و خرید اشتراک",
  },
];

const faNum = (value: number) => value.toLocaleString("fa-IR");

export default function Pricing() {
  const [currency, setCurrency] = useState<Currency>("usd");

  return (
    <section id="pricing" className="relative overflow-hidden py-16 sm:py-20 lg:py-28">
      <div className="pointer-events-none absolute inset-0 -z-10">
        <div className="absolute left-1/2 top-24 size-[520px] -translate-x-1/2 rounded-full bg-brand/[0.08] blur-[120px]" />
      </div>

      <div className="container-x">
        <SectionHeading
          eyebrow="۰۷ · تعرفه اشتراک‌ها"
          title="رایگان شروع کنید، هر وقت آماده بودید ارتقا دهید."
          desc="پرداخت با تتر (TRC20) یا کارت‌به‌کارت. بدون قرارداد بلندمدت، بدون هزینه‌ی پنهان."
          center
        />

        <Reveal delay={120}>
          <div className="mt-8 flex justify-center">
            <div className="inline-flex rounded-full border border-line bg-white p-1 shadow-card" role="group" aria-label="واحد پول">
              {(
                [
                  { id: "usd", label: "دلار (USDT)" },
                  { id: "toman", label: "تومان" },
                ] as const
              ).map((item) => (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setCurrency(item.id)}
                  aria-pressed={currency === item.id}
                  className={cn(
                    "rounded-full px-5 py-2 text-[11px] font-bold transition-all duration-300",
                    currency === item.id ? "btn-cobalt text-white" : "text-muted hover:text-ink"
                  )}
                >
                  {item.label}
                </button>
              ))}
            </div>
          </div>
        </Reveal>

        <div className="mt-10 grid items-stretch gap-4 lg:grid-cols-3">
          {plans.map((plan, index) => {
            const featured = plan.id === "pro";
            return (
              <Reveal key={plan.id} delay={index * 90} className={cn(featured && "lg:-mt-4")}>
                <article
                  className={cn(
                    "group relative flex h-full flex-col overflow-hidden rounded-[30px] p-6 transition-all duration-500 hover:-translate-y-1 sm:p-7",
                    featured
                      ? "bg-ink text-white shadow-lift ring-1 ring-brand/40 lg:pb-11"
                      : "border border-line bg-white shadow-card hover:border-brand/30 hover:shadow-soft"
                  )}
                >
                  {featured && (
                    <>
                      <div className="stars pointer-events-none absolute inset-0 opacity-60" />
                      <div className="pointer-events-none absolute -right-20 -top-24 size-64 rounded-full bg-brand/45 blur-[70px]" />
                      <div className="pointer-events-none absolute -bottom-24 -left-10 size-56 rounded-full bg-lime/10 blur-[70px]" />
                      <LogoMark className="pointer-events-none absolute -bottom-10 -left-10 size-44 opacity-[0.1]" />
                    </>
                  )}

                  <div className="relative flex items-center justify-between">
                    <span
                      className={cn(
                        "grid size-11 place-items-center rounded-[14px]",
                        featured ? "btn-cobalt text-white" : "bg-brand-soft text-brand"
                      )}
                    >
                      <plan.icon size={19} />
                    </span>
                    <span
                      className={cn(
                        "rounded-full px-3 py-1 text-[10px] font-extrabold",
                        featured
                          ? "bg-lime text-ink shadow-[0_0_20px_rgba(22,230,100,0.45)]"
                          : plan.id === "quarter"
                            ? "bg-sand text-[#b35f00]"
                            : "bg-mint text-mint-deep"
                      )}
                    >
                      {plan.tag}
                    </span>
                  </div>

                  <h3 className={cn("relative mt-6 text-[18px] font-extrabold", featured ? "text-white" : "text-ink")}>
                    {plan.name}
                  </h3>
                  <p className={cn("relative mt-1.5 text-[11.5px] leading-[1.9]", featured ? "text-white/55" : "text-muted")}>
                    {plan.desc}
                  </p>

                  <div className="relative mt-6 flex items-end gap-2">
                    {plan.usd === 0 ? (
                      <p className={cn("text-[38px] font-extrabold leading-none tracking-tight", featured ? "text-white" : "text-ink")}>
                        رایگان
                      </p>
                    ) : currency === "usd" ? (
                      <>
                        <p dir="ltr" className={cn("font-latin text-[44px] font-extrabold leading-none tracking-tight", featured ? "text-white" : "text-ink")}>
                          ${plan.usd}
                        </p>
                        <span className={cn("mb-1 text-[11px]", featured ? "text-white/45" : "text-muted")}>
                          / {faNum(plan.days ?? 0)} روز
                        </span>
                      </>
                    ) : (
                      <>
                        <p className={cn("text-[32px] font-extrabold leading-none tracking-tight", featured ? "text-white" : "text-ink")}>
                          {faNum(plan.toman)}
                        </p>
                        <span className={cn("mb-1 text-[11px]", featured ? "text-white/45" : "text-muted")}>
                          تومان / {faNum(plan.days ?? 0)} روز
                        </span>
                      </>
                    )}
                  </div>

                  <ul className={cn("relative mt-6 space-y-2.5 border-t pt-5", featured ? "border-white/10" : "border-line")}>
                    {plan.features.map((feature) => (
                      <li
                        key={feature}
                        className={cn("flex items-start gap-2 text-[11.5px] font-medium leading-relaxed", featured ? "text-white/75" : "text-ink/70")}
                      >
                        <span
                          className={cn(
                            "mt-0.5 grid size-4 shrink-0 place-items-center rounded-full",
                            featured ? "bg-lime/20 text-lime" : "bg-mint text-mint-deep"
                          )}
                        >
                          <Check size={9} strokeWidth={4} />
                        </span>
                        {feature}
                      </li>
                    ))}
                  </ul>

                  <a
                    href="#start"
                    className={cn(
                      "group/btn relative mt-auto flex items-center justify-center gap-2 rounded-2xl px-4 py-3.5 text-[12px] font-extrabold transition-all",
                      "mt-7",
                      featured
                        ? "bg-lime text-ink hover:bg-white"
                        : plan.usd === 0
                          ? "border border-line bg-paper text-ink hover:border-brand/30 hover:bg-white"
                          : "btn-cobalt text-white hover:-translate-y-px"
                    )}
                  >
                    {plan.cta}
                    <ArrowLeft size={14} className="transition-transform group-hover/btn:-translate-x-1" />
                  </a>
                </article>
              </Reveal>
            );
          })}
        </div>

        <Reveal delay={200}>
          <div className="mt-6 flex flex-wrap items-center justify-center gap-x-6 gap-y-3 text-[10.5px] font-semibold text-muted">
            <span className="flex items-center gap-1.5">
              <Wallet size={14} className="text-brand" /> پرداخت تتر TRC20
            </span>
            <span className="flex items-center gap-1.5">
              <CreditCard size={14} className="text-brand" /> کارت‌به‌کارت
            </span>
            <span className="flex items-center gap-1.5">
              <ShieldCheck size={14} className="text-up" /> لغو در هر زمان
            </span>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
