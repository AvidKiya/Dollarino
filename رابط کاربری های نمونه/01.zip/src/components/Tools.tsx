import { useState } from "react";
import {
  ArrowLeft,
  ArrowUpRight,
  Bot,
  Calculator,
  Check,
  Cloud,
  Info,
  KeyRound,
  Lock,
  ShieldCheck,
  SlidersHorizontal,
  Target,
} from "lucide-react";
import { cn } from "../utils/cn";
import { Eyebrow, Reveal, SectionHeading } from "./ui";

/* -------------------------------------------------------------------------- */
/*                               Risk calculator                              */
/* -------------------------------------------------------------------------- */

const format = (value: number) =>
  value.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });

function RangeField({
  label,
  hint,
  value,
  min,
  max,
  step,
  suffix,
  onChange,
}: {
  label: string;
  hint: string;
  value: number;
  min: number;
  max: number;
  step: number;
  suffix: string;
  onChange: (value: number) => void;
}) {
  const fill = ((value - min) / (max - min)) * 100;
  return (
    <div>
      <div className="flex items-center justify-between gap-3">
        <div>
          <p className="text-[11px] font-bold text-ink">{label}</p>
          <p className="mt-0.5 text-[9px] text-muted">{hint}</p>
        </div>
        <span className="font-latin rounded-full border border-line bg-paper px-2.5 py-1 text-[10px] font-extrabold text-ink">
          {value}
          {suffix}
        </span>
      </div>
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(event) => onChange(Number(event.target.value))}
        className="range mt-3"
        style={{ "--fill": `${fill}%` } as React.CSSProperties}
        dir="ltr"
        aria-label={label}
      />
    </div>
  );
}

function RiskCalculator() {
  const [balanceText, setBalanceText] = useState("1000");
  const [risk, setRisk] = useState(1);
  const [stop, setStop] = useState(2);
  const [leverage, setLeverage] = useState(5);

  const balance = Math.max(0, Number(balanceText) || 0);
  const riskAmount = balance * (risk / 100);
  const position = stop > 0 ? riskAmount / (stop / 100) : 0;
  const margin = leverage > 0 ? position / leverage : 0;
  const liquidation = (100 / leverage) * 0.9;

  return (
    <section id="risk" className="relative py-16 sm:py-20 lg:py-28">
      <div className="pointer-events-none absolute inset-0 -z-10">
        <div className="absolute -left-24 top-20 size-80 rounded-full bg-brand/[0.06] blur-[100px]" />
        <div className="dot-grid absolute bottom-10 right-10 hidden h-36 w-52 opacity-30 lg:block" />
      </div>

      <div className="container-x grid items-start gap-10 lg:grid-cols-[0.82fr_1.18fr] lg:gap-14">
        <div className="lg:sticky lg:top-28">
          <Reveal>
            <Eyebrow>۰۵ · قبل از هر معامله</Eyebrow>
          </Reveal>
          <Reveal delay={70}>
            <h2 className="mt-5 text-[1.85rem] font-extrabold leading-[1.45] tracking-[-0.035em] text-ink text-balance sm:text-[2.4rem] lg:text-[2.7rem]">
              ریسک را قبل از معامله
              <br className="hidden sm:block" /> بشناسید.
            </h2>
          </Reveal>
          <Reveal delay={130}>
            <p className="mt-4 max-w-md text-[13px] leading-[2.05] text-muted sm:text-[14px]">
              موفقیت در بازار، بیشتر از انتخاب سیگنال، به اندازه‌ی پوزیشن و مدیریت ضرر وابسته است.
              با این ماشین‌حساب، قاعده‌ی خودتان را پیدا کنید.
            </p>
          </Reveal>

          <div className="mt-7 space-y-2.5">
            {[
              {
                icon: Target,
                title: "سقف ضرر مشخص",
                desc: "قبل از ورود بدانید در بدترین حالت چقدر از سرمایه‌تان در خطر است.",
              },
              {
                icon: SlidersHorizontal,
                title: "اهرم با آگاهی",
                desc: "رابطه اهرم، مارجین و فاصله لیکویید را همین‌جا ببینید.",
              },
              {
                icon: Bot,
                title: "اجرای بدون احساس",
                desc: "ربات به قواعد شما وفادار می‌ماند؛ حتی وقتی بازار هیجانی است.",
              },
            ].map((item) => (
              <Reveal key={item.title} delay={160}>
                <div className="group flex items-start gap-3 rounded-2xl border border-transparent p-2.5 transition-colors hover:border-line hover:bg-white/60">
                  <span className="grid size-9 shrink-0 place-items-center rounded-xl bg-white text-ink shadow-sm ring-1 ring-line">
                    <item.icon size={15} />
                  </span>
                  <div>
                    <p className="text-[12px] font-extrabold text-ink">{item.title}</p>
                    <p className="mt-1 text-[10.5px] leading-[1.9] text-muted">{item.desc}</p>
                  </div>
                </div>
              </Reveal>
            ))}
          </div>

          <Reveal delay={200}>
            <div className="mt-5 flex items-start gap-2.5 rounded-2xl border border-line bg-white/70 p-3.5">
              <ShieldCheck size={16} className="mt-0.5 shrink-0 text-up" />
              <p className="text-[10px] leading-[1.9] text-muted">
                <span className="font-bold text-ink">قاعده طلایی دلارینو:</span> هیچ معامله‌ای بدون حد
                ضرر و بدون سقف ریسک باز نمی‌شود.
              </p>
            </div>
          </Reveal>
        </div>

        <Reveal delay={100}>
          <div className="overflow-hidden rounded-[30px] border border-line bg-white shadow-soft">
            <div className="flex items-center justify-between border-b border-line bg-paper/60 px-5 py-4 sm:px-6">
              <div className="flex items-center gap-2.5">
                <span className="grid size-9 place-items-center rounded-xl bg-ink text-lime">
                  <Calculator size={16} />
                </span>
                <div>
                  <p className="text-[12px] font-extrabold text-ink">ماشین‌حساب اندازه پوزیشن</p>
                  <p className="mt-0.5 text-[9px] text-muted">تنظیمات را لمس کنید و نتیجه را ببینید</p>
                </div>
              </div>
              <span className="hidden items-center gap-1.5 rounded-full border border-line bg-white px-2 py-1 text-[8px] font-bold text-muted sm:flex">
                <span className="size-1.5 rounded-full bg-mint-deep" />
                بدون ذخیره‌سازی
              </span>
            </div>

            <div className="grid gap-5 p-5 sm:p-6 md:grid-cols-2">
              <div>
                <div className="flex items-center justify-between">
                  <p className="text-[11px] font-bold text-ink">موجودی حساب</p>
                  <span className="font-latin text-[9px] font-bold text-muted">USDT</span>
                </div>
                <div className="mt-2 flex items-center gap-2 rounded-xl border border-line bg-paper/60 px-3 py-2.5 transition-colors focus-within:border-ink/30 focus-within:bg-white">
                  <span className="font-latin text-[15px] font-extrabold text-ink/35">$</span>
                  <input
                    value={balanceText}
                    onChange={(event) => {
                      const next = event.target.value.replace(/[^\d.]/g, "");
                      setBalanceText(next);
                    }}
                    inputMode="decimal"
                    dir="ltr"
                    aria-label="موجودی حساب به دلار"
                    className="font-latin w-full bg-transparent text-[17px] font-extrabold text-ink outline-none"
                  />
                </div>
                <div className="mt-2 flex gap-1.5">
                  {[500, 1000, 5000].map((amount) => (
                    <button
                      key={amount}
                      type="button"
                      onClick={() => setBalanceText(String(amount))}
                      className={cn(
                        "font-latin flex-1 rounded-lg border px-2 py-1.5 text-[9px] font-bold transition-colors",
                        balance === amount
                          ? "border-ink bg-ink text-white"
                          : "border-line bg-white text-muted hover:border-ink/20 hover:text-ink"
                      )}
                    >
                      ${amount.toLocaleString("en-US")}
                    </button>
                  ))}
                </div>
              </div>

              <div className="rounded-2xl border border-line bg-paper/60 p-3.5">
                <div className="flex items-center justify-between">
                  <p className="text-[10px] font-semibold text-ink/70">ریسک این معامله</p>
                  <span className="font-latin rounded-full bg-mint px-2 py-0.5 text-[8.5px] font-extrabold text-mint-deep">
                    SAFE
                  </span>
                </div>
                <p className="font-latin mt-2 text-[23px] font-extrabold leading-none tracking-tight text-ink">
                  ${format(riskAmount)}
                </p>
                <div className="mt-2.5 h-1.5 overflow-hidden rounded-full bg-line">
                  <div
                    className="h-full rounded-full bg-gradient-to-l from-mint-deep to-brand transition-all duration-500"
                    style={{ width: `${Math.min(100, risk * 20 + 20)}%` }}
                  />
                </div>
                <p className="mt-1.5 text-[8px] text-muted">
                  {risk}٪ از موجودی، بیشترین ضرر قابل تحمل در این معامله
                </p>
              </div>

              <div className="space-y-5 md:col-span-2 md:grid md:grid-cols-2 md:space-y-0 md:gap-5">
                <RangeField
                  label="درصد ریسک"
                  hint="چند درصد از موجودی در خطر باشد؟"
                  value={risk}
                  min={0.5}
                  max={3}
                  step={0.25}
                  suffix="%"
                  onChange={setRisk}
                />
                <RangeField
                  label="فاصله حد ضرر"
                  hint="فاصله درصدی نقطه ورود و حد ضرر"
                  value={stop}
                  min={0.5}
                  max={5}
                  step={0.25}
                  suffix="%"
                  onChange={setStop}
                />
              </div>

              <div className="md:col-span-2">
                <div className="flex items-center justify-between">
                  <p className="text-[11px] font-bold text-ink">اهرم</p>
                  <p className="text-[9px] text-muted">فاصله لیکویید تقریبی: {liquidation.toFixed(1)}٪</p>
                </div>
                <div className="mt-2 grid grid-cols-6 gap-1.5">
                  {[1, 3, 5, 10, 20, 50].map((item) => (
                    <button
                      key={item}
                      type="button"
                      onClick={() => setLeverage(item)}
                      aria-pressed={leverage === item}
                      className={cn(
                        "font-latin rounded-lg border py-2 text-[10px] font-extrabold transition-all",
                        leverage === item
                          ? "border-ink bg-ink text-lime"
                          : "border-line bg-white text-muted hover:border-ink/25 hover:text-ink"
                      )}
                    >
                      {item}x
                    </button>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-3 gap-2 md:col-span-2">
                {[
                  { label: "اندازه پوزیشن", value: position, tone: "text-ink" },
                  { label: "مارجین لازم", value: margin, tone: "text-brand" },
                  { label: "ریسک هر معامله", value: riskAmount, tone: "text-ink" },
                ].map((item) => (
                  <div key={item.label} className="rounded-xl border border-line bg-paper/60 px-2 py-2.5 sm:px-3">
                    <p className="text-[8px] text-muted sm:text-[8.5px]">{item.label}</p>
                    <p className={cn("font-latin mt-1 truncate text-[12px] font-extrabold sm:text-[14px]", item.tone)}>
                      ${format(item.value)}
                    </p>
                  </div>
                ))}
              </div>

              <div className="md:col-span-2">
                <a
                  href="#start"
                  className="group flex items-center justify-between gap-3 rounded-xl bg-ink px-4 py-3.5 text-white transition-colors hover:bg-brand"
                >
                  <span className="flex items-center gap-2 text-[12px] font-extrabold">
                    <Bot size={15} />
                    شروع با همین تنظیمات در حساب دمو
                  </span>
                  <span className="grid size-6 place-items-center rounded-full bg-white/10 transition-transform group-hover:-translate-x-1">
                    <ArrowLeft size={13} />
                  </span>
                </a>
                <p className="mt-2 flex items-start gap-1.5 text-[8.5px] leading-relaxed text-muted/80">
                  <Info size={11} className="mt-px shrink-0" />
                  این محاسبات تخمینی است و تضمین سود نیست. کارمزد صرافی و شرایط بازار را در نظر بگیرید.
                </p>
              </div>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}

/* -------------------------------------------------------------------------- */
/*                                  Security                                  */
/* -------------------------------------------------------------------------- */

const security = [
  {
    icon: Lock,
    title: "رمزنگاری AES-256",
    desc: "کلیدهای صرافی به‌صورت رمزنگاری‌شده نگهداری می‌شوند و هرگز در دسترس عمومی نیستند.",
    tag: "DATA",
  },
  {
    icon: KeyRound,
    title: "دسترسی محدود",
    desc: "کلید API فقط برای معامله ساخته می‌شود؛ بدون اجازه برداشت یا انتقال دارایی.",
    tag: "API",
  },
  {
    icon: Cloud,
    title: "زیرساخت Cloudflare",
    desc: "ربات روی Cloudflare Workers و Durable Objects با پایداری بالا اجرا می‌شود.",
    tag: "INFRA",
  },
  {
    icon: ShieldCheck,
    title: "کنترل کامل",
    desc: "هر لحظه می‌توانید ربات را متوقف کنید، اهرم را تغییر دهید یا پوزیشن‌ها را ببندید.",
    tag: "YOU",
  },
];

function Security() {
  return (
    <section id="security" className="border-y border-line bg-white py-16 sm:py-20 lg:py-24">
      <div className="container-x">
        <SectionHeading
          eyebrow="۰۶ · امنیت و شفافیت"
          title="آرامش، از زیرساخت شروع می‌شود."
          desc="دلارینو کلید خصوصی یا دارایی شما را نگه نمی‌دارد. فقط به آنچه برای اجرای معاملات لازم است دسترسی دارد."
          center
        />

        <div className="mt-10 grid gap-3 sm:grid-cols-2 lg:mt-12 lg:grid-cols-4">
          {security.map((item, index) => (
            <Reveal key={item.title} delay={index * 70}>
              <article className="group flex h-full flex-col rounded-[24px] border border-line bg-paper/50 p-5 transition-all duration-500 hover:-translate-y-1 hover:border-ink/15 hover:bg-white hover:shadow-soft">
                <div className="flex items-center justify-between">
                  <span className="grid size-10 place-items-center rounded-[13px] bg-white text-ink shadow-sm ring-1 ring-line transition-colors group-hover:bg-ink group-hover:text-lime">
                    <item.icon size={17} />
                  </span>
                  <span className="font-latin text-[8px] font-bold tracking-[0.18em] text-muted/50">{item.tag}</span>
                </div>
                <h3 className="mt-5 text-[13.5px] font-extrabold text-ink">{item.title}</h3>
                <p className="mt-2 text-[10.5px] leading-[1.95] text-muted">{item.desc}</p>
                <span className="mt-auto flex items-center gap-1.5 pt-4 text-[9px] font-bold text-up">
                  <Check size={10} strokeWidth={3} /> فعال و پیوسته
                </span>
              </article>
            </Reveal>
          ))}
        </div>

        <Reveal delay={150}>
          <div className="mt-3 flex flex-col items-center justify-between gap-4 overflow-hidden rounded-[24px] border border-line bg-ink px-5 py-5 text-white sm:flex-row sm:px-7">
            <div className="flex items-center gap-3">
              <span className="grid size-10 shrink-0 place-items-center rounded-full bg-white/10 text-lime">
                <ShieldCheck size={18} />
              </span>
              <div>
                <p className="text-[12px] font-extrabold">دارایی شما، در حساب خودتان می‌ماند.</p>
                <p className="mt-1 text-[10px] text-white/45">
                  دلارینو هیچ‌وقت درخواست واریز، کلید خصوصی یا دسترسی برداشت نمی‌کند.
                </p>
              </div>
            </div>
            <a
              href="#faq"
              className="group flex shrink-0 items-center gap-2 rounded-full border border-white/15 bg-white/5 px-4 py-2.5 text-[10px] font-bold text-white/75 transition-colors hover:bg-white/10 hover:text-white"
            >
              سوالات امنیتی
              <ArrowUpRight size={13} className="transition-transform group-hover:-translate-y-0.5" />
            </a>
          </div>
        </Reveal>
      </div>
    </section>
  );
}

export default function Tools() {
  return (
    <>
      <RiskCalculator />
      <Security />
    </>
  );
}
