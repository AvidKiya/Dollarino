import { useEffect, useId, useRef, useState, type ReactNode } from "react";
import { ArrowLeft } from "lucide-react";
import { cn } from "../utils/cn";
import logoSrc from "../assets/logo.webp";

/* -------------------------------------------------------------------------- */
/*                                    Logo                                    */
/* -------------------------------------------------------------------------- */

export { logoSrc };

export function LogoMark({ className = "size-10", glow = false }: { className?: string; glow?: boolean }) {
  return (
    <img
      src={logoSrc}
      alt=""
      aria-hidden="true"
      draggable={false}
      className={cn("shrink-0 select-none object-contain", className)}
      style={glow ? { filter: "drop-shadow(0 10px 26px rgba(31, 99, 255, 0.55))" } : undefined}
    />
  );
}

export function Logo({ className, light = false }: { className?: string; light?: boolean }) {
  return (
    <div className={cn("flex items-center gap-2.5", className)}>
      <LogoMark glow className="size-10 shrink-0 sm:size-11" />
      <div className="flex flex-col justify-center leading-none">
        <span
          className={cn(
            "text-[20px] font-extrabold tracking-[-0.045em] sm:text-[22px]",
            light ? "text-white" : "text-ink"
          )}
        >
          دلارینو
        </span>
        <span
          className={cn(
            "font-latin mt-1 text-[7px] font-bold tracking-[0.26em]",
            light ? "text-white/45" : "text-muted/70"
          )}
        >
          DOLLARINO
        </span>
      </div>
    </div>
  );
}

/* -------------------------------------------------------------------------- */
/*                                  Animation                                 */
/* -------------------------------------------------------------------------- */

export function Reveal({
  children,
  className,
  delay = 0,
}: {
  children: ReactNode;
  className?: string;
  delay?: number;
}) {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const node = ref.current;
    if (!node) return;
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          node.classList.add("is-visible");
          observer.disconnect();
        }
      },
      { threshold: 0.12, rootMargin: "0px 0px -6% 0px" }
    );
    observer.observe(node);
    return () => observer.disconnect();
  }, []);

  return (
    <div ref={ref} className={cn("reveal", className)} style={{ transitionDelay: `${delay}ms` }}>
      {children}
    </div>
  );
}

export function LiveDot({ className, dark = false }: { className?: string; dark?: boolean }) {
  return (
    <span className={cn("relative flex size-2 shrink-0", className)}>
      <span
        className={cn(
          "animate-pulse-ring absolute inline-flex size-full rounded-full",
          dark ? "bg-lime" : "bg-mint-deep"
        )}
      />
      <span className={cn("relative inline-flex size-2 rounded-full", dark ? "bg-lime" : "bg-mint-deep")} />
    </span>
  );
}

/* -------------------------------------------------------------------------- */
/*                                  Typography                                */
/* -------------------------------------------------------------------------- */

export function Eyebrow({
  children,
  light = false,
  className,
}: {
  children: ReactNode;
  light?: boolean;
  className?: string;
}) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-2 rounded-full border px-3 py-1.5 text-[11px] font-semibold tracking-tight",
        light ? "border-white/15 bg-white/5 text-white/80" : "border-line bg-white/70 text-ink/70",
        className
      )}
    >
      <LiveDot dark={light} />
      {children}
    </span>
  );
}

export function SectionHeading({
  eyebrow,
  title,
  desc,
  light = false,
  center = false,
  className,
  action,
}: {
  eyebrow: string;
  title: ReactNode;
  desc?: ReactNode;
  light?: boolean;
  center?: boolean;
  className?: string;
  action?: ReactNode;
}) {
  return (
    <div
      className={cn(
        "flex flex-col gap-5",
        center ? "items-center text-center" : "items-start",
        action && !center && "lg:flex-row lg:items-end lg:justify-between",
        className
      )}
    >
      <div className={cn("max-w-2xl", center && "flex flex-col items-center")}>
        <Reveal>
          <Eyebrow light={light}>{eyebrow}</Eyebrow>
        </Reveal>
        <Reveal delay={70}>
          <h2
            className={cn(
              "mt-5 text-[1.85rem] font-extrabold leading-[1.45] tracking-[-0.035em] text-balance sm:text-[2.45rem] lg:text-[2.85rem]",
              light ? "text-white" : "text-ink"
            )}
          >
            {title}
          </h2>
        </Reveal>
        {desc && (
          <Reveal delay={140}>
            <p
              className={cn(
                "mt-4 max-w-xl text-[14px] leading-[2.05] sm:text-[15px]",
                light ? "text-white/60" : "text-muted"
              )}
            >
              {desc}
            </p>
          </Reveal>
        )}
      </div>
      {action && <Reveal delay={180}>{action}</Reveal>}
    </div>
  );
}

/* -------------------------------------------------------------------------- */
/*                                   Buttons                                  */
/* -------------------------------------------------------------------------- */

type CTAProps = {
  children: ReactNode;
  href?: string;
  variant?: "dark" | "light" | "brand" | "outlineLight" | "soft";
  className?: string;
  arrow?: boolean;
  onClick?: () => void;
  icon?: ReactNode;
};

export function CTA({
  children,
  href = "#start",
  variant = "dark",
  className,
  arrow = true,
  onClick,
  icon,
}: CTAProps) {
  const variants = {
    dark: "btn-cobalt text-white border-transparent hover:-translate-y-px hover:shadow-[0_20px_50px_-15px_rgba(31,99,255,0.8)]",
    light: "bg-white text-ink border-line hover:border-ink/30 hover:bg-white",
    brand: "btn-cobalt text-white border-transparent hover:-translate-y-px hover:shadow-[0_20px_50px_-15px_rgba(31,99,255,0.8)]",
    outlineLight: "bg-transparent text-white border-white/25 hover:bg-white/10 hover:border-white/50",
    soft: "bg-brand-soft text-brand-dark border-transparent hover:bg-[#dfe4ff]",
  };

  return (
    <a
      href={href}
      onClick={onClick}
      className={cn(
        "group inline-flex items-center justify-center gap-2.5 rounded-full border px-5 py-3.5 text-[13px] font-bold transition-all duration-300 sm:px-6 sm:text-sm",
        variants[variant],
        className
      )}
    >
      {icon}
      <span>{children}</span>
      {arrow && (
        <ArrowLeft
          size={17}
          strokeWidth={2.2}
          className="transition-transform duration-300 group-hover:-translate-x-1"
        />
      )}
    </a>
  );
}

/* -------------------------------------------------------------------------- */
/*                                   Charts                                   */
/* -------------------------------------------------------------------------- */

function buildPoints(values: number[], width: number, height: number, pad: number) {
  const min = Math.min(...values);
  const max = Math.max(...values);
  const range = max - min || 1;
  return values.map((value, index) => {
    const x = pad + (index / (values.length - 1)) * (width - pad * 2);
    const y = height - pad - ((value - min) / range) * (height - pad * 2);
    return [x, y] as [number, number];
  });
}

function smoothPath(points: [number, number][]) {
  if (!points.length) return "";
  let d = `M ${points[0][0]},${points[0][1]}`;
  for (let i = 0; i < points.length - 1; i++) {
    const p0 = points[i - 1] ?? points[i];
    const p1 = points[i];
    const p2 = points[i + 1];
    const p3 = points[i + 2] ?? p2;
    const c1x = p1[0] + (p2[0] - p0[0]) / 6;
    const c1y = p1[1] + (p2[1] - p0[1]) / 6;
    const c2x = p2[0] - (p3[0] - p1[0]) / 6;
    const c2y = p2[1] - (p3[1] - p1[1]) / 6;
    d += ` C ${c1x},${c1y} ${c2x},${c2y} ${p2[0]},${p2[1]}`;
  }
  return d;
}

export function AreaChart({
  values,
  stroke = "#2b4bf2",
  fill = "#2b4bf2",
  className,
  height = 150,
  showDot = false,
  grid = false,
}: {
  values: number[];
  stroke?: string;
  fill?: string;
  className?: string;
  height?: number;
  showDot?: boolean;
  grid?: boolean;
}) {
  const uid = useId().replace(/:/g, "");
  const width = 340;
  const pad = 8;
  const points = buildPoints(values, width, height, pad);
  const line = smoothPath(points);
  const last = points[points.length - 1];
  const area = `${line} L ${width - pad},${height - pad} L ${pad},${height - pad} Z`;
  const lastXPct = (last[0] / width) * 100;
  const lastYPct = (last[1] / height) * 100;

  return (
    <div className={cn("relative w-full", className)} dir="ltr">
      <svg viewBox={`0 0 ${width} ${height}`} className="h-auto w-full overflow-visible" fill="none">
        <defs>
          <linearGradient id={`area-${uid}`} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={fill} stopOpacity="0.28" />
            <stop offset="70%" stopColor={fill} stopOpacity="0.04" />
            <stop offset="100%" stopColor={fill} stopOpacity="0" />
          </linearGradient>
        </defs>
        {grid &&
          [0.25, 0.5, 0.75].map((ratio) => (
            <line
              key={ratio}
              x1={pad}
              x2={width - pad}
              y1={height * ratio}
              y2={height * ratio}
              stroke="currentColor"
              strokeOpacity="0.09"
              strokeDasharray="3 6"
            />
          ))}
        <path d={area} fill={`url(#area-${uid})`} />
        <path
          d={line}
          stroke={stroke}
          strokeWidth="2.4"
          strokeLinecap="round"
          vectorEffect="non-scaling-stroke"
        />
        {showDot && (
          <>
            <line
              x1={last[0]}
              x2={last[0]}
              y1={pad}
              y2={height - pad}
              stroke={stroke}
              strokeOpacity="0.25"
              strokeDasharray="3 4"
              vectorEffect="non-scaling-stroke"
            />
            <circle cx={last[0]} cy={last[1]} r="7" fill={stroke} fillOpacity="0.16" />
            <circle cx={last[0]} cy={last[1]} r="3.5" fill={stroke} stroke="#0e1714" strokeWidth="1.5" />
          </>
        )}
      </svg>
      {showDot && (
        <span
          className="pointer-events-none absolute size-2.5 rounded-full"
          style={{ left: `${lastXPct}%`, top: `${lastYPct}%`, display: "none" }}
          aria-hidden="true"
        />
      )}
    </div>
  );
}

export function Sparkline({
  values,
  stroke = "#0e8f64",
  className,
}: {
  values: number[];
  stroke?: string;
  className?: string;
}) {
  const points = buildPoints(values, 100, 34, 3);
  return (
    <span dir="ltr" className="inline-flex">
      <svg viewBox="0 0 100 34" className={cn("h-8 w-20", className)} fill="none">
        <path
          d={smoothPath(points)}
          stroke={stroke}
          strokeWidth="2"
          strokeLinecap="round"
          vectorEffect="non-scaling-stroke"
        />
      </svg>
    </span>
  );
}

/* -------------------------------------------------------------------------- */
/*                                    Data                                    */
/* -------------------------------------------------------------------------- */

export type Coin = {
  symbol: string;
  name: string;
  price: number;
  change: number;
  color: string;
  text?: string;
  spark: number[];
};

export const coins: Coin[] = [
  {
    symbol: "BTC",
    name: "بیت‌کوین",
    price: 67420.5,
    change: 2.41,
    color: "#F7931A",
    spark: [22, 26, 24, 31, 29, 36, 34, 41, 45, 43, 50, 54],
  },
  {
    symbol: "ETH",
    name: "اتریوم",
    price: 3512.84,
    change: 1.28,
    color: "#627EEA",
    spark: [30, 28, 33, 31, 37, 36, 42, 40, 46, 44, 49, 52],
  },
  {
    symbol: "SOL",
    name: "سولانا",
    price: 178.42,
    change: 4.62,
    color: "#0f1b17",
    text: "#16E664",
    spark: [18, 23, 21, 29, 27, 34, 40, 37, 46, 44, 53, 58],
  },
  {
    symbol: "BNB",
    name: "بایننس",
    price: 602.17,
    change: -0.34,
    color: "#F0B90B",
    text: "#1b1b1b",
    spark: [44, 42, 46, 43, 41, 44, 39, 42, 40, 38, 41, 39],
  },
  {
    symbol: "XRP",
    name: "ریپل",
    price: 0.6124,
    change: 0.92,
    color: "#23292F",
    spark: [30, 33, 31, 35, 34, 38, 36, 40, 39, 43, 45, 44],
  },
  {
    symbol: "ADA",
    name: "کاردانو",
    price: 0.4481,
    change: -1.12,
    color: "#0033AD",
    spark: [48, 45, 47, 43, 44, 41, 42, 39, 40, 37, 38, 35],
  },
  {
    symbol: "AVAX",
    name: "آوالانچ",
    price: 38.21,
    change: 3.11,
    color: "#E84142",
    spark: [22, 27, 25, 30, 34, 32, 38, 42, 40, 46, 44, 50],
  },
  {
    symbol: "LINK",
    name: "چین‌لینک",
    price: 17.84,
    change: 1.77,
    color: "#2A5ADA",
    spark: [28, 31, 29, 35, 33, 38, 36, 41, 39, 45, 43, 48],
  },
];

export function CoinBadge({ coin, className }: { coin: Coin; className?: string }) {
  return (
    <span
      className={cn("font-latin grid size-9 shrink-0 place-items-center rounded-full text-[10px] font-extrabold", className)}
      style={{ background: coin.color, color: coin.text ?? "#fff" }}
    >
      {coin.symbol === "BTC" ? "₿" : coin.symbol.slice(0, 1)}
    </span>
  );
}

export function usd(value: number, digits?: number) {
  const decimals = digits ?? (value > 0 && value < 1 ? 4 : 2);
  return value.toLocaleString("en-US", {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  });
}

export function countUpTarget(target: number, active: boolean) {
  const [value, setValue] = useState(0);
  useEffect(() => {
    if (!active) return;
    let frame = 0;
    const start = performance.now();
    const duration = 1300;
    const tick = (now: number) => {
      const progress = Math.min((now - start) / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      setValue(target * eased);
      if (progress < 1) frame = requestAnimationFrame(tick);
    };
    frame = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(frame);
  }, [active, target]);
  return value;
}
