import { useEffect, useMemo, useRef, useState } from "react";
import { ArrowRight, Check, Crown, RotateCcw, ShieldCheck, X, Zap } from "lucide-react";
import { Coin, Engine, INITIAL_COINS, Lang, Position, Signal, T, Theme, Trader, View, fmtMoney } from "./lib/data";
import { Dock, Footer, Palette, QuickTrade, SidebarContent, TickerTape, Toast, Toasts, Topbar } from "./components/shell";
import Appearance from "./components/Appearance";
import Overview from "./views/Overview";
import Radar, { Stats } from "./views/Radar";
import Markets from "./views/Markets";
import CopyView from "./views/Copy";
import Portfolio from "./views/Portfolio";
import Terminal from "./views/Terminal";
import WeeklyCard from "./views/WeeklyCard";
import { Faq, Pricing } from "./views/PricingFaq";
import Site from "./views/Site";

const VIEWS: View[] = ["overview", "terminal", "markets", "radar", "copy", "portfolio", "card", "pricing", "faq"];
let signalId = 100;
const ENGINE_POOL: Engine[] = ["ai", "ai", "strategy", "strategy", "copy"];
function makeSignal(coins: Coin[], bornAgo = 0, engine?: Engine): Signal {
  const c = coins[Math.floor(Math.random() * coins.length)];
  const side = Math.random() > .42 ? "long" : "short";
  const conf = 62 + Math.floor(Math.random() * 36);
  const tp = .012 + Math.random() * .028, sl = .008 + Math.random() * .015;
  const born = Date.now() - bornAgo;
  return { id: signalId++, sym: c.sym, side, entry: c.price, tp: side === "long" ? c.price * (1 + tp) : c.price * (1 - tp), sl: side === "long" ? c.price * (1 - sl) : c.price * (1 + sl), conf, engine: engine ?? ENGINE_POOL[Math.floor(Math.random() * ENGINE_POOL.length)], born, resolveAt: born + 35000 + Math.random() * 45000, status: "active", pnl: 0, dec: c.dec };
}
function seedSignals(coins: Coin[]) {
  const out: Signal[] = [];
  for (let i = 0; i < 18; i++) { const s = makeSignal(coins, (i + 2) * 95000); const win = i < 13; s.status = win ? "tp" : "sl"; s.pnl = win ? .8 + Math.random() * 3 : -.6 - Math.random() * 1.4; out.push(s); }
  for (let i = 0; i < 5; i++) out.push(makeSignal(coins, i * 40000 + 8000));
  return out.sort((a, b) => b.born - a.born);
}
const INITIAL_POSITIONS: Position[] = [
  { id: 1, sym: "BTC", side: "long", entry: 95000, margin: 1200, lev: 10, dec: 0 },
  { id: 2, sym: "ETH", side: "long", entry: 3300, margin: 800, lev: 5, dec: 0, mirror: "@aurum_ai" },
];
function readPref<T>(key: string, fallback: T): T { try { const v = localStorage.getItem(key); return v ? JSON.parse(v) as T : fallback; } catch { return fallback; } }
function savePref(key: string, value: unknown) { try { localStorage.setItem(key, JSON.stringify(value)); } catch { /* private browsing */ } }
const pnlOf = (p: Position, coins: Coin[]) => { const cur = coins.find((c) => c.sym === p.sym)?.price ?? p.entry; return p.margin * p.lev * (p.side === "long" ? (cur - p.entry) / p.entry : (p.entry - cur) / p.entry); };

export default function App() {
  const [lang, setLang] = useState<Lang>(() => readPref<Lang>("dollarino-lang", "fa") === "en" ? "en" : "fa");
  const [theme, setTheme] = useState<Theme>(() => {
    const v = readPref<string>("dollarino-theme", "paper");
    if (v === "light") return "paper";
    if (v === "cobalt") return "midnight";
    return ["obsidian", "paper", "cosmic", "midnight"].includes(v) ? v as Theme : "paper";
  });
  const [mode, setMode] = useState<"site" | "app">(() => { const h = window.location.hash.slice(1); return h && VIEWS.includes(h as View) ? "app" : "site"; });
  const [view, setView] = useState<View>(() => { const h = window.location.hash.slice(1) as View; return VIEWS.includes(h) ? h : "overview"; });
  const [coins, setCoins] = useState<Coin[]>(INITIAL_COINS);
  const [signals, setSignals] = useState<Signal[]>(() => seedSignals(INITIAL_COINS));
  const [stats, setStats] = useState<Stats>({ total: 23, wins: 13, pnl: 1840, avgConf: 78, closed: 18 });
  const [positions, setPositions] = useState<Position[]>(INITIAL_POSITIONS);
  const [cash, setCash] = useState(10000);
  const [realized, setRealized] = useState(640);
  const [followed, setFollowed] = useState<string[]>(["aurum"]);
  const [engine, setEngine] = useState<Engine>("ai");
  const [selected, setSelected] = useState("BTC");
  const [plan, setPlan] = useState(0);
  const [equity, setEquity] = useState<number[]>(() => Array.from({ length: 48 }, (_, i) => 11200 + i * 26 + Math.random() * 80 - 40));
  const [palette, setPalette] = useState(false);
  const [themeOpen, setThemeOpen] = useState(false);
  const [drawer, setDrawer] = useState(false);
  const [qt, setQt] = useState<{ sym: string; side: "long" | "short" } | null>(null);
  const [resetOpen, setResetOpen] = useState(false);
  const [planOpen, setPlanOpen] = useState<number | null>(null);
  const [toasts, setToasts] = useState<Toast[]>([]);
  const nextId = useRef(10);
  const coinsRef = useRef(coins); coinsRef.current = coins;
  const signalsRef = useRef(signals); signalsRef.current = signals;
  const positionsRef = useRef(positions); positionsRef.current = positions;
  const engineRef = useRef(engine); engineRef.current = engine;
  const t = T[lang];

  const toast = (text: string, kind: Toast["kind"] = "info") => { const id = Date.now() + Math.random(); setToasts((p) => [...p.slice(-2), { id, text, kind }]); setTimeout(() => setToasts((p) => p.filter((x) => x.id !== id)), 3600); };
  const go = (v: View) => { setMode("app"); setView(v); setDrawer(false); if (window.location.hash !== `#${v}`) window.location.hash = v; };
  const launch = (v: View) => { go(v); window.scrollTo({ top: 0, behavior: "instant" }); };
  const site = () => { setMode("site"); setDrawer(false); window.history.replaceState(null, "", "#site"); window.scrollTo({ top: 0, behavior: "instant" }); };
  const openTrade = (sym: string, side: "long" | "short" = "long") => setQt({ sym, side });
  const openTheme = () => { setDrawer(false); setThemeOpen(true); };

  useEffect(() => { document.documentElement.dataset.theme = theme; document.documentElement.style.colorScheme = theme === "paper" ? "light" : "dark"; document.querySelector('meta[name="theme-color"]')?.setAttribute("content", { paper: "#f4f1ea", obsidian: "#070906", cosmic: "#050a1a", midnight: "#070a12" }[theme]); savePref("dollarino-theme", theme); }, [theme]);
  useEffect(() => { document.documentElement.lang = lang; document.documentElement.dir = t.dir; document.title = `Dollarino OS — ${view === "overview" ? "Every Market. One Engine." : view === "terminal" ? t.terminal.title : view === "card" ? t.card.title : view === "radar" ? t.radar.title : view === "copy" ? t.cp.title : view === "portfolio" ? t.pf.title : view === "markets" ? t.mk.title : view === "pricing" ? t.pr.title : t.fq.title}`; savePref("dollarino-lang", lang); }, [lang, view, mode]);
  useEffect(() => { const h = () => { const v = window.location.hash.slice(1) as View; if (VIEWS.includes(v)) { setMode("app"); setView(v); setDrawer(false); } else { setMode("site"); } }; window.addEventListener("hashchange", h); return () => window.removeEventListener("hashchange", h); }, []);
  useEffect(() => { window.scrollTo({ top: 0, behavior: "instant" }); const els = document.querySelectorAll(".reveal:not(.in)"); const obs = new IntersectionObserver((es) => es.forEach((e) => e.isIntersecting && e.target.classList.add("in")), { threshold: .06 }); els.forEach((el) => obs.observe(el)); const fallback = setTimeout(() => els.forEach((el) => el.classList.add("in")), 1000); return () => { obs.disconnect(); clearTimeout(fallback); }; }, [view, mode]);
  useEffect(() => { const h = (e: KeyboardEvent) => { if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "k") { e.preventDefault(); setPalette((p) => !p); } }; window.addEventListener("keydown", h); return () => window.removeEventListener("keydown", h); }, []);

  /* live market + signal resolution against actual simulated marks */
  useEffect(() => {
    const iv = setInterval(() => {
      if (document.hidden) return;
      const cs = coinsRef.current.map((c) => {
        const drift = (Math.random() - .485) * c.price * .0016;
        const price = Math.max(c.price * .5, c.price + drift);
        return { ...c, price, open: c.open + drift * .02, spark: [...c.spark.slice(1), price] };
      });
      coinsRef.current = cs;
      setCoins(cs);
      const now = Date.now();
      const resolved = signalsRef.current.filter((s) => s.status === "active" && now >= s.resolveAt);
      if (resolved.length) {
        const outcomes = resolved.map((s) => {
          const mark = cs.find((c) => c.sym === s.sym)?.price ?? s.entry;
          const hitTp = s.side === "long" ? mark >= s.tp : mark <= s.tp;
          const hitSl = s.side === "long" ? mark <= s.sl : mark >= s.sl;
          const exit = hitTp ? s.tp : hitSl ? s.sl : mark;
          const pnl = (exit - s.entry) / s.entry * 100 * 10 * (s.side === "long" ? 1 : -1);
          return { id: s.id, sym: s.sym, status: hitTp ? "tp" : hitSl ? "sl" : "closed", pnl };
        });
        const byId = new Map(outcomes.map((o) => [o.id, o]));
        setSignals((prev) => prev.map((s) => { const o = byId.get(s.id); return o ? { ...s, status: o.status, pnl: o.pnl } as Signal : s; }));
        setStats((st) => ({ ...st, closed: st.closed + outcomes.length, wins: st.wins + outcomes.filter((x) => x.pnl >= 0).length, pnl: st.pnl + outcomes.reduce((sum, x) => sum + x.pnl * 10, 0) }));
        outcomes.forEach((o) => toast(`${o.status === "tp" ? t.toast.tp : o.status === "sl" ? t.toast.sl : t.common.exit} · ${o.sym} ${o.pnl >= 0 ? "+" : ""}${o.pnl.toFixed(1)}%`, o.pnl >= 0 ? "win" : "lose"));
      }
      setEquity((prev) => [...prev.slice(1), equityRef.current]);
    }, 1600);
    return () => clearInterval(iv);
  }, []);
  useEffect(() => { const iv = setInterval(() => { if (document.hidden) return; const e = engineRef.current; const s = makeSignal(coinsRef.current, 0, e); setSignals((prev) => [s, ...prev].slice(0, 30)); setStats((st) => ({ ...st, total: st.total + 1, avgConf: (st.avgConf * st.total + s.conf) / (st.total + 1) })); }, 9000); return () => clearInterval(iv); }, []);

  const unreal = useMemo(() => positions.reduce((sum, p) => sum + pnlOf(p, coins), 0), [positions, coins]);
  const equityVal = cash + positions.reduce((s, p) => s + p.margin, 0) + unreal;
  const equityRef = useRef(equityVal); equityRef.current = equityVal;
  const consensus = useMemo(() => { const active = signals.filter((s) => s.status === "active"); return active.length ? active.reduce((sum, s) => sum + (s.side === "long" ? s.conf : -s.conf), 0) / active.length : 0; }, [signals]);
  const activeCount = signals.filter((s) => s.status === "active").length;
  const qtCoin = coins.find((c) => c.sym === qt?.sym) ?? coins[0];

  const addPosition = (sym: string, side: "long" | "short", lev: number, margin: number, mirror?: string) => {
    if (positions.length >= 20) { toast(lang === "fa" ? "حداکثر ۲۰ پوزیشن همزمان." : "Maximum 20 paper positions reached."); return false; }
    if (margin <= 0 || margin > cash) { toast(lang === "fa" ? "موجودی کافی نیست." : "Insufficient paper balance."); return false; }
    const c = coins.find((x) => x.sym === sym) ?? coins[0];
    setCash((b) => b - margin);
    setPositions((p) => [{ id: nextId.current++, sym, side, entry: c.price, margin, lev, dec: c.dec, mirror }, ...p]);
    toast(`${t.common.opened} · ${sym} ${side.toUpperCase()} ${lev}×`);
    return true;
  };
  const closePosition = (p: Position) => { const pnl = pnlOf(p, coins); setCash((b) => b + p.margin + pnl); setRealized((r) => r + pnl); setPositions((ps) => ps.filter((x) => x.id !== p.id)); toast(`${t.common.closed} · ${p.sym} ${pnl >= 0 ? "+" : ""}${fmtMoney(pnl)}`, pnl >= 0 ? "win" : "lose"); };
  const closeAll = () => { const pnl = positions.reduce((s, p) => s + pnlOf(p, coins), 0); const margin = positions.reduce((s, p) => s + p.margin, 0); setCash((b) => b + margin + pnl); setRealized((r) => r + pnl); setPositions([]); toast(`${t.common.closedAll} ${pnl >= 0 ? "+" : ""}${fmtMoney(pnl)}`, pnl >= 0 ? "win" : "lose"); };
  const toggleFollow = (tr: Trader) => {
    if (followed.includes(tr.id)) {
      const mirrored = positions.filter((p) => p.mirror === tr.tag); const pnl = mirrored.reduce((s, p) => s + pnlOf(p, coins), 0);
      setCash((b) => b + mirrored.reduce((s, p) => s + p.margin, 0) + pnl); setRealized((r) => r + pnl);
      setPositions((ps) => ps.filter((p) => p.mirror !== tr.tag)); setFollowed((f) => f.filter((x) => x !== tr.id)); toast(`${t.common.unfollowed} ${tr.tag}`);
    } else if (addPosition(tr.focus, tr.bias, 8, 600, tr.tag)) { setFollowed((f) => [...f, tr.id]); toast(`${t.common.followed} ${tr.tag}`, "win"); }
  };
  const reset = () => { setCash(10000); setRealized(0); setPositions([]); setFollowed([]); setSignals([]); signalsRef.current = []; setStats({ total: 0, wins: 0, pnl: 0, avgConf: 0, closed: 0 }); setEquity(Array(48).fill(10000)); setEngine("ai"); setSelected("BTC"); setPlan(0); setResetOpen(false); go("overview"); toast(t.common.resetDone); };

  const modalOpen = palette || themeOpen || !!qt || resetOpen || planOpen !== null;
  useEffect(() => {
    if (!modalOpen) return;
    const old = document.body.style.overflow; document.body.style.overflow = "hidden";
    const prev = document.activeElement as HTMLElement | null;
    const frame = requestAnimationFrame(() => { const d = document.querySelector('[role="dialog"]'); const first = d?.querySelector<HTMLElement>('input,button,select,[tabindex="0"]'); first?.focus(); });
    const h = (e: KeyboardEvent) => {
      if (e.key === "Escape") { setPalette(false); setThemeOpen(false); setQt(null); setResetOpen(false); setPlanOpen(null); }
      if (e.key === "Tab") { const d = document.querySelector('[role="dialog"]'); if (!d) return; const els = Array.from(d.querySelectorAll<HTMLElement>('button:not([disabled]),input,select,a[href],[tabindex="0"]')); const first = els[0], last = els[els.length - 1]; if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last?.focus(); } else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first?.focus(); } }
    };
    window.addEventListener("keydown", h); return () => { cancelAnimationFrame(frame); document.body.style.overflow = old; window.removeEventListener("keydown", h); prev?.focus(); };
  }, [modalOpen, palette, themeOpen, qt?.sym, resetOpen, planOpen]);

  return <div dir={t.dir} className="noise min-h-screen">
    {mode === "site" && <Site lang={lang} setLang={setLang} onTheme={openTheme} coins={coins} signals={signals} equity={equity} onLaunch={launch} onEngine={setEngine} />}
    {mode === "app" && <>
    <div className="ambient fixed inset-0 -z-10 overflow-hidden"><div className="absolute inset-0 bg-[var(--bg)]" /><div className="absolute inset-0 grid-bg" /><div className="absolute -top-48 start-1/3 h-[480px] w-[520px] rounded-full bg-gold/10 blur-[150px] glow-pulse" /><div className="absolute top-1/3 -end-48 h-[420px] w-[420px] rounded-full bg-jade/5 blur-[150px]" /><div className="absolute bottom-0 -start-40 h-[380px] w-[380px] rounded-full bg-gold/5 blur-[150px]" /></div>
    <div className="lg:flex lg:items-start">
      <aside className="hidden lg:block sticky top-0 h-screen w-[236px] xl:w-[248px] shrink-0 border-e hairline bg-black/25 backdrop-blur-xl p-4"><SidebarContent view={view} setView={go} lang={lang} activeCount={activeCount} onTheme={openTheme} onReset={() => setResetOpen(true)} /></aside>
      <div className="flex-1 min-w-0"><Topbar lang={lang} setLang={setLang} equity={equityVal} onPalette={() => setPalette(true)} onMenu={() => setDrawer(true)} onTheme={openTheme} onSite={site} onStart={() => go("terminal")} view={view} /><TickerTape coins={coins} lang={lang} onTrade={openTrade} />
        <main key={view} className="mx-auto max-w-6xl px-3 sm:px-6 min-h-[70vh]">
          {view === "overview" && <Overview lang={lang} coins={coins} equity={equity} signals={signals} stats={stats} consensus={consensus} onGo={go} onTrade={openTrade} onEngine={(e) => { setEngine(e); go(e === "copy" ? "copy" : "terminal"); }} />}
          {view === "terminal" && <Terminal lang={lang} coins={coins} selected={selected} onSelect={setSelected} engine={engine} onEngine={setEngine} positions={positions} cash={cash} equity={equityVal} plan={plan} onClose={closePosition} onOpen={(side, lev, margin) => addPosition(selected, side, lev, margin)} />}
          {view === "markets" && <Markets lang={lang} coins={coins} onTrade={openTrade} />}
          {view === "radar" && <Radar lang={lang} coins={coins} signals={signals} stats={stats} consensus={consensus} onTrade={openTrade} />}
          {view === "copy" && <CopyView lang={lang} followed={followed} onToggle={toggleFollow} />}
          {view === "portfolio" && <Portfolio lang={lang} coins={coins} positions={positions} cash={cash} realized={realized} stats={stats} unreal={unreal} equity={equityVal} curve={equity} onClose={closePosition} onCloseAll={closeAll} onTrade={() => openTrade("BTC")} onToast={toast} />}
          {view === "card" && <WeeklyCard lang={lang} stats={{ pnl: realized / 100, trades: stats.closed, win: stats.closed ? stats.wins / stats.closed * 100 : 0 }} onToast={toast} />}
          {view === "pricing" && <Pricing lang={lang} onChoose={setPlanOpen} />}
          {view === "faq" && <Faq lang={lang} />}
        </main><Footer lang={lang} onGo={go} />
      </div>
    </div>
    </>
    }
    {drawer && <div className="lg:hidden fixed inset-0 z-[70] bg-black/70 backdrop-blur-sm" onClick={() => setDrawer(false)}><div className="absolute top-0 bottom-0 start-0 w-[280px] max-w-[85vw] bg-[var(--panel)] border-e hairline p-4 pop-in overflow-y-auto" onClick={(e) => e.stopPropagation()}><SidebarContent view={view} setView={go} lang={lang} activeCount={activeCount} onTheme={openTheme} onReset={() => { setDrawer(false); setResetOpen(true); }} onClose={() => setDrawer(false)} /></div></div>}
    {mode === "app" && <Dock view={view} setView={go} lang={lang} onTrade={() => openTrade("BTC")} />}
    <Palette open={palette} onClose={() => setPalette(false)} lang={lang} setLang={setLang} coins={coins} onGo={go} onTrade={openTrade} onTheme={openTheme} onReset={() => setResetOpen(true)} />
    {themeOpen && <Appearance theme={theme} onTheme={setTheme} lang={lang} onClose={() => setThemeOpen(false)} />}
    {qt && <QuickTrade coin={qtCoin} lang={lang} cash={cash} initialSide={qt.side} onClose={() => setQt(null)} onOpen={(side, lev, margin) => { if (addPosition(qt.sym, side, lev, margin)) setQt(null); }} />}
    {resetOpen && <div className="fixed inset-0 z-[80] bg-black/70 backdrop-blur-sm p-4 grid place-items-center" onClick={() => setResetOpen(false)}><div role="dialog" aria-modal="true" aria-label={t.common.reset} className="pop-in panel !bg-[var(--panel)] rounded-3xl p-7 max-w-sm w-full" onClick={(e) => e.stopPropagation()}><div className="flex items-center justify-between mb-5"><span className="h-12 w-12 rounded-2xl bg-gold/15 grid place-items-center"><RotateCcw className="h-6 w-6 text-gold" /></span><button onClick={() => setResetOpen(false)} className="h-9 w-9 grid place-items-center rounded-full btn-ghost"><X className="h-4 w-4" /></button></div><h3 className="font-display font-bold text-2xl">{t.common.reset}</h3><p className="text-sm text-white/50 mt-3">{lang === "fa" ? "پوزیشن‌ها، کپی‌ها و آمار دمو پاک می‌شوند و حساب با ۱۰٬۰۰۰ USDT تازه شروع می‌شود. ظاهر و زبان انتخابی تو حفظ می‌شوند." : "Paper positions, mirrors and stats will be cleared. Your account restarts with 10,000 USDT. Your theme and language stay exactly as you like them."}</p><div className="flex gap-3 mt-6"><button onClick={() => setResetOpen(false)} className="btn-ghost flex-1 py-3 rounded-xl font-bold text-sm">{t.common.cancel}</button><button onClick={reset} className="btn-gold flex-1 py-3 rounded-xl font-black text-sm">{t.common.reset}</button></div></div></div>}
    {planOpen !== null && <div className="fixed inset-0 z-[80] bg-black/70 backdrop-blur-sm p-4 grid place-items-center overflow-y-auto" onClick={() => setPlanOpen(null)}><div role="dialog" aria-modal="true" aria-label={t.plans[planOpen].name} className="pop-in panel !bg-[var(--panel)] rounded-3xl p-7 max-w-md w-full" onClick={(e) => e.stopPropagation()}><div className="flex items-center justify-between mb-5"><span className="h-12 w-12 rounded-2xl bg-gold/15 grid place-items-center"><Crown className="h-6 w-6 text-gold" /></span><button onClick={() => setPlanOpen(null)} className="h-9 w-9 grid place-items-center rounded-full btn-ghost"><X className="h-4 w-4" /></button></div><h3 className="font-display font-bold text-3xl">{t.plans[planOpen].name}<span className="text-gold">.</span></h3><p className="text-sm text-white/50 mt-1">{t.plans[planOpen].desc}</p><p className="font-display font-bold text-5xl mt-5 tabular">{t.plans[planOpen].price}<span className="text-sm text-white/40 font-medium">{planOpen > 0 ? t.pr.mo : ""}</span></p><ul className="mt-5 space-y-2.5">{t.plans[planOpen].feats.map((f) => <li key={f} className="flex items-center gap-2 text-sm text-white/65"><Check className="h-4 w-4 text-gold" />{f}</li>)}</ul><div className="panel rounded-2xl p-3.5 mt-5 flex items-start gap-2"><ShieldCheck className="h-4 w-4 text-jade shrink-0" /><p className="text-xs text-white/50">{lang === "fa" ? "این پیش‌نمایش تعاملی است. هیچ پرداختی انجام نمی‌شود و پلن انتخابی فقط در دموی کاغذی فعال می‌شود." : "This is an interactive preview. No payment is collected. Your selected plan is simulated with paper funds only."}</p></div><button onClick={() => { setPlan(planOpen); setPlanOpen(null); go("terminal"); toast(`${t.plans[planOpen].name} · ${t.nav.paper}`); }} className="btn-gold w-full py-3.5 rounded-2xl font-black mt-5 flex items-center justify-center gap-2"><Zap className="h-4 w-4" />{lang === "fa" ? "امتحان در دموی کاغذی" : "Try in Paper Demo"}<ArrowRight className="h-4 w-4 rtl:rotate-180" /></button></div></div>}
    {mode === "app" && <Toasts items={toasts} />}
  </div>;
}
