import { Check, Moon, Palette, Sun, X, Zap, Sparkles } from "lucide-react";
import { Lang, T, Theme } from "../lib/data";

const LOOKS: { id: Theme; icon: typeof Moon; bg: string; panel: string; accent: string; ink: string; lime: string }[] = [
  { id: "obsidian", icon: Moon, bg: "#090b07", panel: "#171a11", accent: "#e8c15a", ink: "#f5edd7", lime: "#d7f83c" },
  { id: "paper", icon: Sun, bg: "#f4f1ea", panel: "#fffdf7", accent: "#2f5bff", ink: "#10131a", lime: "#d9f73c" },
  { id: "cosmic", icon: Sparkles, bg: "#050a1a", panel: "#0a1328", accent: "#1f63ff", ink: "#f3f7fd", lime: "#16e664" },
  { id: "midnight", icon: Zap, bg: "#070a12", panel: "#0d1220", accent: "#6d8bff", ink: "#eef2ff", lime: "#c9f24e" },
];

export default function Appearance({ theme, onTheme, lang, onClose }: { theme: Theme; onTheme: (t: Theme) => void; lang: Lang; onClose: () => void }) {
  const t = T[lang].design;
  return <div className="fixed inset-0 z-[80] bg-black/70 backdrop-blur-sm p-4 grid place-items-center overflow-y-auto" onClick={onClose}>
    <div role="dialog" aria-modal="true" aria-label={t.title} className="pop-in w-full max-w-3xl panel !bg-[var(--panel)] rounded-[30px] p-6 sm:p-8 shadow-2xl" onClick={(e) => e.stopPropagation()}>
      <div className="flex items-start justify-between gap-4">
        <div>
          <p className="text-[9px] font-black tracking-[.2em] text-gold uppercase mb-2.5 flex items-center gap-2"><Palette className="h-3.5 w-3.5" />FOUR SIGNATURE LOOKS</p>
          <h2 className="font-display font-semibold text-3xl sm:text-4xl">{t.title}</h2>
          <p className="text-sm text-white/50 mt-3 max-w-xl">{t.sub}</p>
        </div>
        <button onClick={onClose} className="h-9 w-9 shrink-0 grid place-items-center rounded-full btn-ghost" aria-label={T[lang].common.close}><X className="h-4 w-4" /></button>
      </div>
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mt-7">
        {LOOKS.map((l) => {
          const on = theme === l.id;
          return <button key={l.id} onClick={() => onTheme(l.id)} aria-pressed={on} className={`text-start rounded-2xl p-2.5 transition hover:-translate-y-1 ${on ? "ring-2 ring-gold" : ""}`} style={{ background: l.bg, border: `1px solid ${l.accent}33` }}>
            <div className="rounded-xl overflow-hidden" style={{ background: l.bg, border: `1px solid ${l.accent}22` }}>
              <div className="flex items-center gap-1.5 px-2 py-1.5 border-b" style={{ borderColor: l.accent + "22" }}>
                <span className="h-4 w-4 rounded-full grid place-items-center text-[6px] font-black" style={{ background: l.accent, color: l.bg }}>D$</span>
                <span className="text-[7px] font-bold" style={{ color: l.ink }}>Dollarino.</span>
                <span className="ms-auto h-1 w-6 rounded-full" style={{ background: l.accent }} />
              </div>
              <div className="p-2">
                <p className="font-display font-semibold text-[12px] leading-tight" style={{ color: l.ink }}>سه موتور.<br /><span style={{ background: l.lime, color: "#0b1405", borderRadius: 4, padding: "0 3px" }}>یک میز.</span></p>
                <div className="mt-2 rounded-lg p-2" style={{ background: l.panel, border: `1px solid ${l.accent}22` }}>
                  <p className="text-[5px]" style={{ color: l.ink, opacity: .5 }}>TOTAL EQUITY</p>
                  <p className="font-display font-bold text-[12px] tabular" style={{ color: l.ink }}>$12,480</p>
                  <svg viewBox="0 0 120 30" className="w-full mt-1"><path d="M0 26L12 21L22 24L35 17L45 19L55 12L65 16L75 8L85 11L98 5L110 7L120 1" stroke={l.accent} strokeWidth="1.6" fill="none" /></svg>
                </div>
              </div>
            </div>
            <div className="flex items-center gap-1.5 mt-2.5 px-1">
              <l.icon className="h-3.5 w-3.5" style={{ color: l.accent }} />
              <p className="font-bold text-[11px]" style={{ color: l.ink }}>{t[l.id]}</p>
              {on && <Check className="h-3.5 w-3.5 ms-auto" style={{ color: l.accent }} />}
            </div>
            <p className="text-[9px] mt-1 px-1" style={{ color: l.ink, opacity: .55 }}>{t[`${l.id}D`]}</p>
          </button>;
        })}
      </div>
      <div className="flex flex-wrap items-center justify-between gap-3 mt-7">
        <p className="text-[11px] text-white/40 flex items-center gap-1.5"><Check className="h-3.5 w-3.5 text-jade" />{t.saved}</p>
        <button onClick={onClose} className="btn-gold font-black text-sm px-6 py-3 rounded-xl">{lang === "fa" ? "عالیه، ادامه بده" : "Looks good. Let's go."}</button>
      </div>
    </div>
  </div>;
}
