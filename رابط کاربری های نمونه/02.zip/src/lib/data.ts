import { EXTRA } from "./content";

export type Lang = "en" | "fa";
export type View = "overview" | "terminal" | "markets" | "radar" | "copy" | "portfolio" | "card" | "pricing" | "faq";
export type Theme = "obsidian" | "paper" | "cosmic" | "midnight";
export type Engine = "ai" | "strategy" | "copy";

/* ---------------- coins ---------------- */
export interface Coin {
  sym: string; name: string; price: number; open: number;
  vol: string; spark: number[]; color: string; dec: number;
}
const seed = (base: number, vol: number, n = 30) => {
  const arr: number[] = [];
  let v = base;
  for (let i = 0; i < n; i++) { v += (Math.random() - 0.46) * vol; arr.push(v); }
  return arr;
};
const RAW = [
  { sym: "BTC", name: "Bitcoin", price: 97420, chg: 2.84, vol: "$38.2B", color: "#f7931a", dec: 0, sv: 900 },
  { sym: "ETH", name: "Ethereum", price: 3412, chg: 3.61, vol: "$19.4B", color: "#8a9cff", dec: 0, sv: 55 },
  { sym: "SOL", name: "Solana", price: 214.6, chg: -1.24, vol: "$4.8B", color: "#9945ff", dec: 1, sv: 4 },
  { sym: "BNB", name: "BNB Chain", price: 692.4, chg: 1.12, vol: "$2.1B", color: "#f0b90b", dec: 1, sv: 9 },
  { sym: "XRP", name: "Ripple", price: 2.41, chg: 5.37, vol: "$5.6B", color: "#25a4e8", dec: 2, sv: 0.05 },
  { sym: "DOGE", name: "Dogecoin", price: 0.382, chg: -2.18, vol: "$2.9B", color: "#c2a633", dec: 3, sv: 0.008 },
  { sym: "SUI", name: "Sui", price: 4.82, chg: 6.21, vol: "$1.8B", color: "#4da2ff", dec: 2, sv: 0.12 },
  { sym: "LINK", name: "Chainlink", price: 22.4, chg: 4.12, vol: "$540M", color: "#5b8cff", dec: 1, sv: 0.5 },
  { sym: "AVAX", name: "Avalanche", price: 38.7, chg: -0.84, vol: "$620M", color: "#ff6b6b", dec: 1, sv: 0.7 },
  { sym: "TON", name: "Toncoin", price: 5.62, chg: 0.94, vol: "$310M", color: "#0098ea", dec: 2, sv: 0.1 },
  { sym: "ADA", name: "Cardano", price: 0.98, chg: 1.87, vol: "$1.2B", color: "#6b8afd", dec: 2, sv: 0.02 },
  { sym: "TRX", name: "Tron", price: 0.264, chg: -1.62, vol: "$480M", color: "#ff5c5c", dec: 3, sv: 0.005 },
];
export const INITIAL_COINS: Coin[] = RAW.map((c) => ({
  sym: c.sym, name: c.name, price: c.price, open: c.price / (1 + c.chg / 100),
  vol: c.vol, spark: seed(c.price, c.sv), color: c.color, dec: c.dec,
}));
export const changeOf = (c: Coin) => ((c.price - c.open) / c.open) * 100;
export const fmtPrice = (p: number, d = 2) =>
  p.toLocaleString("en-US", { minimumFractionDigits: d, maximumFractionDigits: d });
export const fmtMoney = (n: number) =>
  (n < 0 ? "-$" : "$") + Math.abs(n).toLocaleString("en-US", { maximumFractionDigits: 0 });
export const fmtSign = (n: number, d = 1) => `${n >= 0 ? "+" : ""}${n.toFixed(d)}%`;
export const timeAgo = (ts: number, lang: Lang) => {
  const s = Math.max(1, Math.floor((Date.now() - ts) / 1000));
  if (lang === "fa") {
    if (s < 60) return `${s} ثانیه پیش`;
    const m = Math.floor(s / 60);
    if (m < 60) return `${m} دقیقه پیش`;
    return `${Math.floor(m / 60)} ساعت پیش`;
  }
  if (s < 60) return `${s}s ago`;
  const m = Math.floor(s / 60);
  if (m < 60) return `${m}m ago`;
  return `${Math.floor(m / 60)}h ago`;
};

/* ---------------- signals / positions / traders ---------------- */
export interface Signal {
  id: number; sym: string; side: "long" | "short"; entry: number;
  tp: number; sl: number; conf: number; engine: Engine;
  born: number; resolveAt: number; status: "active" | "tp" | "sl" | "closed"; pnl: number; dec: number;
}
export interface Position {
  id: number; sym: string; side: "long" | "short"; entry: number;
  margin: number; lev: number; dec: number; mirror?: string;
}
export interface Trader {
  id: string; name: string; tag: string; win: number; roi: number;
  copiers: number; risk: "Low" | "Medium" | "High";
  focus: string; bias: "long" | "short"; color: string; spark: number[];
}
export const TRADERS: Trader[] = [
  { id: "aurum", name: "Aurum", tag: "@aurum_ai", win: 78, roi: 42.6, copiers: 12840, risk: "Low", focus: "BTC", bias: "long", color: "#e8c15a", spark: seed(100, 3) },
  { id: "orion", name: "Orion", tag: "@orion_swings", win: 73, roi: 35.9, copiers: 9870, risk: "Low", focus: "ETH", bias: "long", color: "#10d9a3", spark: seed(100, 3.4) },
  { id: "falcon", name: "Falcon", tag: "@falcon_futures", win: 71, roi: 31.2, copiers: 8930, risk: "Medium", focus: "SOL", bias: "long", color: "#38e1ff", spark: seed(100, 4) },
  { id: "midnight", name: "Midnight Quant", tag: "@midnight_quant", win: 69, roi: 27.8, copiers: 6210, risk: "Medium", focus: "BNB", bias: "short", color: "#9945ff", spark: seed(100, 4.4) },
  { id: "velvet", name: "Velvet Bull", tag: "@velvet_bull", win: 64, roi: 19.4, copiers: 4102, risk: "High", focus: "DOGE", bias: "long", color: "#f0b90b", spark: seed(100, 5.4) },
  { id: "saffron", name: "Saffron", tag: "@saffron_signals", win: 66, roi: 22.3, copiers: 3540, risk: "High", focus: "XRP", bias: "short", color: "#ff4d6d", spark: seed(100, 5) },
];
export const ENGINE_META: Record<Engine, { en: string; fa: string; color: string }> = {
  ai: { en: "Dorr-Bin AI", fa: "هوش مصنوعی دُرّبین", color: "#e8c15a" },
  strategy: { en: "Dorna V1", fa: "استراتژی دُرنا", color: "#10d9a3" },
  copy: { en: "Mirror Copy", fa: "کپی آینه‌ای", color: "#38e1ff" },
};

/* ---------------- i18n ---------------- */
const BASE = {
  en: {
    dir: "ltr" as const,
    shell: {
      overview: "Overview", markets: "Markets", radar: "AI Radar", copy: "Copy Trade",
      portfolio: "Portfolio", pricing: "Pricing", faq: "FAQ", menu: "Menu",
      searchPh: "Search coins, views, actions…  (Ctrl+K)", start: "Start Free",
      enginesOn: "All engines online", trade: "Trade", equity: "Equity",
      views: "Views", account: "Account",
    },
    ov: {
      badge: "Dollarino OS v6 · The Wealth Engine",
      t1: "Wealth,", t2: "engineered.",
      sub: "An AI trading house in your pocket — Dollarino scans 30+ markets day and night, fires precision signals and mirrors elite traders while you live your life.",
      cta1: "Start Trading Free", cta2: "Watch AI Radar",
      s1: "Markets scanned", s2: "Signals today", s3: "Radar win rate", s4: "Max leverage",
      equity: "Equity Curve", live: "LIVE", consensus: "Market Consensus", long: "LONG", short: "SHORT",
      showdown: "Engine Showdown", win: "Win rate", roi: "30-day ROI",
      latest: "Latest Radar Signals", viewAll: "Open full radar",
      stepsT: "Zero to autopilot in three steps",
      steps: [
        ["Connect in seconds", "Paper demo is instant. Going live takes one API key — encrypted, never stored in plain text."],
        ["Pick your engine", "Dorr-Bin AI, Dorna V1 strategy, or mirror the elite. Or run all three at once."],
        ["Watch it compound", "Signals fire, positions manage themselves. You check the equity curve and smile."],
      ] as [string, string][],
      exT: "Connected venues", more: "more soon",
      ctaT: "Your money should work while you sleep.",
      ctaS: "Free paper account with live prices. No card. No risk. Just the machine.",
      ctaB: "Activate Dollarino",
    },
    radar: {
      title: "AI Radar", sub: "Every signal the engines fire — live, timestamped, resolved in public.",
      st1: "Signals today", st2: "Win rate", st3: "Avg confidence", st4: "Signal PnL",
      all: "All engines", feed: "Live Signal Feed", mom: "Momentum Now", board: "Engine Leaderboard",
      tp: "TP HIT", sl: "SL HIT", active: "ACTIVE", conf: "confidence",
      entry: "Entry", tpL: "Target", slL: "Stop",
    },
    mk: {
      title: "Markets", sub: "The full Dollarino universe — live simulated feed across every tracked venue.",
      search: "Search coins…", asset: "Asset", price: "Price", chg: "24h", trend: "Trend", range: "24h Range", trade: "Trade",
      empty: "No coins match your search.",
    },
    cp: {
      title: "Copy Trade", sub: "Mirror elite traders tick-for-tick. One tap to follow — Dollarino handles entries, exits and risk.",
      copiers: "Total copiers", avgRoi: "Avg 30d ROI", elite: "Elite traders", auto: "Auto-mirror",
      follow: "Follow", following: "Following", win: "Win", roi: "30d ROI", risk: "Risk", focus: "Focus",
      how: "How mirroring works",
      howSteps: ["Pick a trader whose risk fits you", "Dollarino copies every entry & exit instantly", "Pause or unfollow anytime — you stay in control"],
    },
    pf: {
      title: "Portfolio", sub: "Your paper fund — live marks, mirrored traders and full position control.",
      equity: "Total Equity", unrl: "Unrealized PnL", real: "Realized PnL", winr: "Closed win rate",
      alloc: "Allocation", pos: "Positions", empty: "No positions yet — fire your first trade and watch the machine work.",
      emptyCta: "Open Quick Trade", close: "Close", mirror: "MIRRORED", manual: "MANUAL",
      entry: "Entry", mark: "Mark", margin: "Margin", pnl: "PnL",
    },
    qt: {
      title: "Quick Trade", balance: "Available", long: "LONG", short: "SHORT",
      lev: "Leverage", amount: "Margin (USDT)", size: "Position size", liq: "Est. liquidation",
      confirm: "Confirm", cancel: "Cancel", opened: "Position opened",
    },
    pr: {
      title: "Pricing", sub: "Start free on paper. Upgrade when the machine earns its keep.",
      mo: "/mo", cta: "Get Started", pop: "Most Popular",
      plans: [
        { name: "Paper", price: "$0", desc: "Learn with live prices", feats: ["Paper demo account", "Dorna V1 strategy", "5 coins · 3 positions", "Weekly results card"] },
        { name: "Gold", price: "$19", desc: "For serious traders", feats: ["All 30+ coins", "20 simultaneous trades", "AI + Strategy + Copy", "Leverage up to 50×", "Priority execution"] },
        { name: "Black", price: "$49", desc: "For funds & pros", feats: ["Everything in Gold", "Multi-model AI consensus", "Custom webhooks", "Dedicated manager", "API access"] },
      ],
    },
    fq: {
      title: "Questions", sub: "Everything you need to know before handing your market to the machine.",
      items: [
        ["Do I need trading experience?", "No. Dollarino handles analysis, entries and exits. You pick an engine and set risk — the machine does the rest."],
        ["Which exchanges are supported?", "Paper Demo (free, live prices), Toobit Futures and KCEX Futures — with more venues on the way."],
        ["How does the AI work without my API key?", "Models are managed centrally by Dollarino. You simply switch the engine on — no keys, no setup."],
        ["Can I stop everything anytime?", "Instantly. Pause, close all, or pull the plug in one tap. You are always the boss."],
      ] as [string, string][],
    },
    pal: {
      title: "Command", views: "Go to view", coins: "Quick trade", actions: "Actions",
      toFa: "Switch to فارسی", toEn: "Switch to English",
    },
    foot: { tag: "Wealth, engineered.", rights: "© 2026 Dollarino OS. All rights reserved.", risk: "Trading involves risk. Paper mode is simulated. Past performance never guarantees future results." },
    toast: { tp: "Target hit", sl: "Stopped out", followed: "Now mirroring", unfollowed: "Stopped mirroring", closed: "Position closed" },
  },
  fa: {
    dir: "rtl" as const,
    shell: {
      overview: "نمای کلی", markets: "بازارها", radar: "رادار هوش مصنوعی", copy: "کپی‌ترید",
      portfolio: "پورتفوی", pricing: "تعرفه‌ها", faq: "سوالات", menu: "منو",
      searchPh: "جستجوی ارز، صفحه، دستور… (Ctrl+K)", start: "شروع رایگان",
      enginesOn: "همه موتورها آنلاین‌اند", trade: "معامله", equity: "ارزش دارایی",
      views: "صفحات", account: "حساب",
    },
    ov: {
      badge: "دلارینو OS نسخه ۶ · موتور ثروت",
      t1: "ثروت،", t2: "مهندسی‌شده.",
      sub: "یه خونه‌ی ترید هوشمند توی جیبت — دلارینو ۳۰+ بازار رو شب و روز رصد می‌کنه، سیگنال‌های دقیق شلیک می‌کنه و تریدرهای نخبه رو کپی می‌کنه، در حالی که تو به زندگیت می‌رسی.",
      cta1: "شروع رایگان ترید", cta2: "تماشای رادار هوش مصنوعی",
      s1: "بازار تحت رصد", s2: "سیگنال امروز", s3: "وین‌ریت رادار", s4: "حداکثر اهرم",
      equity: "منحنی رشد سرمایه", live: "زنده", consensus: "اجماع بازار", long: "لانگ", short: "شورت",
      showdown: "نبرد موتورها", win: "وین‌ریت", roi: "سود ۳۰ روزه",
      latest: "آخرین سیگنال‌های رادار", viewAll: "مشاهده رادار کامل",
      stepsT: "در سه قدم تا خلبان خودکار",
      steps: [
        ["اتصال در چند ثانیه", "دمو فوری فعال می‌شود. برای لایو فقط یک کلید API کافی است — رمزنگاری‌شده و امن."],
        ["انتخاب موتور", "هوش مصنوعی دُرّبین، استراتژی دُرنا یا کپی نخبگان. یا هر سه را همزمان اجرا کن."],
        ["تماشای رشد مرکب", "سیگنال‌ها شلیک می‌شوند و پوزیشن‌ها خودشان مدیریت می‌شوند. تو فقط منحنی رشد را ببین و لبخند بزن."],
      ] as [string, string][],
      exT: "صرافی‌های متصل", more: "به‌زودی بیشتر",
      ctaT: "پولت باید وقتی خوابی کار کند.",
      ctaS: "حساب دمو رایگان با قیمت زنده. بدون کارت، بدون ریسک. فقط ماشین.",
      ctaB: "فعال‌سازی دلارینو",
    },
    radar: {
      title: "رادار هوش مصنوعی", sub: "هر سیگنالی که موتورها شلیک می‌کنند — زنده، با ساعت دقیق و نتیجه شفاف.",
      st1: "سیگنال امروز", st2: "وین‌ریت", st3: "میانگین اطمینان", st4: "سود سیگنال‌ها",
      all: "همه موتورها", feed: "فید زنده سیگنال", mom: "مومنتوم فعلی", board: "جدول موتورها",
      tp: "تارگت خورد", sl: "استاپ خورد", active: "فعال", conf: "اطمینان",
      entry: "ورود", tpL: "تارگت", slL: "استاپ",
    },
    mk: {
      title: "بازارها", sub: "دنیای کامل دلارینو — فید زنده شبیه‌سازی‌شده از همه بازارهای تحت رصد.",
      search: "جستجوی ارز…", asset: "ارز", price: "قیمت", chg: "۲۴ ساعته", trend: "روند", range: "بازه ۲۴ ساعته", trade: "معامله",
      empty: "ارزی با این جستجو پیدا نشد.",
    },
    cp: {
      title: "کپی‌ترید", sub: "تریدرهای نخبه را تیک‌به‌تیک کپی کن. با یک لمس دنبال کن — دلارینو ورود، خروج و ریسک را مدیریت می‌کند.",
      copiers: "کل کپی‌کننده‌ها", avgRoi: "میانگین سود ۳۰ روزه", elite: "تریدر نخبه", auto: "کپی خودکار",
      follow: "دنبال کن", following: "دنبال می‌کنی", win: "وین", roi: "سود ۳۰ روزه", risk: "ریسک", focus: "تمرکز",
      how: "کپی کردن چطور کار می‌کند",
      howSteps: ["تریدری انتخاب کن که ریسکش به تو می‌خورد", "دلارینو هر ورود و خروجی را لحظه‌ای کپی می‌کند", "هر وقت خواستی توقف کن — کنترل همیشه با توست"],
    },
    pf: {
      title: "پورتفوی", sub: "صندوق دمای تو — قیمت لحظه‌ای، تریدرهای کپی‌شده و کنترل کامل پوزیشن‌ها.",
      equity: "ارزش کل", unrl: "سود/زیان شناور", real: "سود/زیان محقق‌شده", winr: "وین‌ریت بسته‌شده‌ها",
      alloc: "تخصیص دارایی", pos: "پوزیشن‌ها", empty: "هنوز پوزیشنی نداری — اولین معامله‌ات را باز کن و ماشین را تماشا کن.",
      emptyCta: "باز کردن معامله سریع", close: "بستن", mirror: "کپی‌شده", manual: "دستی",
      entry: "ورود", mark: "لحظه‌ای", margin: "مارجین", pnl: "سود/زیان",
    },
    qt: {
      title: "معامله سریع", balance: "موجودی", long: "لانگ", short: "شورت",
      lev: "اهرم", amount: "مارجین (USDT)", size: "حجم پوزیشن", liq: "لیکوییدیشن تقریبی",
      confirm: "تأیید معامله", cancel: "انصراف", opened: "پوزیشن باز شد",
    },
    pr: {
      title: "تعرفه‌ها", sub: "در دمو رایگان شروع کن. وقتی ماشین خودش را ثابت کرد، ارتقا بده.",
      mo: "/ماه", cta: "شروع کن", pop: "محبوب‌ترین",
      plans: [
        { name: "کاغذی", price: "$0", desc: "یادگیری با قیمت زنده", feats: ["حساب دمو", "استراتژی دُرنا V1", "۵ ارز · ۳ پوزیشن", "کارت نتایج هفتگی"] },
        { name: "طلایی", price: "$19", desc: "برای تریدرهای جدی", feats: ["هر ۳۰+ ارز", "۲۰ معامله همزمان", "هوش مصنوعی + استراتژی + کپی", "اهرم تا ۵۰ برابر", "اجرای اولویت‌دار"] },
        { name: "مشکی", price: "$49", desc: "برای حرفه‌ای‌ها و صندوق‌ها", feats: ["همه امکانات طلایی", "اجماع چندمدلی هوش مصنوعی", "وب‌هوک اختصاصی", "مدیر اختصاصی", "دسترسی API"] },
      ],
    },
    fq: {
      title: "سوالات", sub: "هرچه باید بدانی قبل از اینکه بازارت را به ماشین بسپاری.",
      items: [
        ["به تجربه ترید نیاز دارم؟", "نه. دلارینو تحلیل، ورود و خروج را انجام می‌دهد. تو فقط موتور را انتخاب و ریسک را تنظیم می‌کنی — بقیه با ماشین است."],
        ["کدام صرافی‌ها پشتیبانی می‌شوند؟", "دموی Paper (رایگان با قیمت زنده)، فیوچرز Toobit و KCEX — و صرافی‌های بیشتری در راه‌اند."],
        ["هوش مصنوعی بدون کلید API من چطور کار می‌کند؟", "مدل‌ها به‌صورت مرکزی توسط دلارینو مدیریت می‌شوند. تو فقط موتور را روشن می‌کنی — بدون کلید و بدون تنظیمات."],
        ["هر وقت بخواهم می‌توانم همه‌چیز را متوقف کنم؟", "فوری. با یک لمس توقف کن، همه را ببند یا خاموش کن. رئیس همیشه تویی."],
      ] as [string, string][],
    },
    pal: {
      title: "فرمان", views: "رفتن به صفحه", coins: "معامله سریع", actions: "دستورات",
      toFa: "تغییر به فارسی", toEn: "Switch to English",
    },
    foot: { tag: "ثروت، مهندسی‌شده.", rights: "© ۲۰۲۶ دلارینو OS. تمامی حقوق محفوظ است.", risk: "ترید همراه با ریسک است. حالت دمو شبیه‌سازی‌شده است. عملکرد گذشته هرگز تضمین آینده نیست." },
    toast: { tp: "تارگت خورد", sl: "استاپ خورد", followed: "کپی شروع شد", unfollowed: "کپی متوقف شد", closed: "پوزیشن بسته شد" },
  },
} as const;

export const T = {
  en: { ...BASE.en, ...EXTRA.en },
  fa: { ...BASE.fa, ...EXTRA.fa },
} as const;
