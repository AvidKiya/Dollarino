import { useState } from "react";
import { ArrowRight, ArrowUpRight, BadgeCheck, BrainCircuit, Crosshair, Copy, Eye, EyeOff, Layers, Zap, Trophy, ShieldCheck, Sparkles } from "lucide-react";
import { Coin, ENGINE_META, Engine, Lang, Signal, T, View, fmtMoney, fmtPrice, fmtSign } from "../lib/data";
import { Counter, EquityCurve, Gauge } from "../components/Charts";
import { SignalCard } from "./Radar";

interface Props {
  lang: Lang; coins: Coin[]; equity: number[]; signals: Signal[];
  stats: { total: number; wins: number; pnl: number }; consensus: number;
  onGo: (v: View) => void; onTrade: (sym: string, side?: "long" | "short") => void;
  onEngine: (e: Engine) => void;
}
const ENGINES = [
  { e: "ai" as Engine, icon: BrainCircuit, win: 71, roi: "+34.2%", code: "DORR-BIN" },
  { e: "strategy" as Engine, icon: Crosshair, win: 64, roi: "+22.8%", code: "DORNA V1" },
  { e: "copy" as Engine, icon: Copy, win: 58, roi: "+18.1%", code: "MIRROR" },
];

export default function Overview({ lang, coins, equity, signals, stats, consensus, onGo, onTrade, onEngine }: Props) {
  const t = T[lang]; const h = t.hero; const [hidden, setHidden] = useState(false);
  const btc = coins[0]; const cur = equity[equity.length - 1] ?? 0; const chg = ((cur - (equity[0] ?? 1)) / (equity[0] ?? 1)) * 100;
  const winRate = stats.total ? stats.wins / stats.total * 100 : 0;
  return <div className="pb-4">
    {/* signature hero */}
    <section className="pt-8 sm:pt-10 pb-8">
      <div className="grid lg:grid-cols-[1.05fr_1fr] gap-8 xl:gap-12 items-center">
        <div className="reveal in">
          <div className="inline-flex items-center gap-2 panel rounded-full px-4 py-2 text-[10px] font-black tracking-[.12em] text-goldsoft mb-6"><span className="live-gold h-2 w-2 rounded-full bg-gold" />{h.badge}</div>
          <h1 className="font-display font-semibold tracking-tight leading-[1.04] text-[clamp(38px,11.8vw,48px)] sm:text-[60px] lg:text-[48px] xl:text-[68px]">
            {h.title1}<br />{h.title2}<br /><em className="text-gold-grad font-display italic">{h.title3}</em>
          </h1>
          <p className="mt-5 text-white/55 text-[14px] sm:text-[15px] leading-[1.8] max-w-lg">{h.sub}</p>
          <div className="mt-6 flex flex-wrap gap-3">
            <button onClick={() => onGo("terminal")} className="btn-gold inline-flex items-center gap-2 font-black px-6 py-3.5 rounded-2xl text-[13px]"><Zap className="h-[18px] w-[18px]" />{h.cta1}</button>
            <button onClick={() => onGo("radar")} className="btn-ghost inline-flex items-center gap-2 font-bold px-6 py-3.5 rounded-2xl text-[13px]">{h.cta2}<ArrowRight className="h-4 w-4 rtl:rotate-180" /></button>
          </div>
          <div className="mt-7 grid grid-cols-4 gap-2 max-w-lg">
            {[
              { v: <Counter to={30} suffix="+" />, l: h.s1 }, { v: <Counter to={20} />, l: h.s2 },
              { v: <Counter to={winRate} suffix="%" decimals={1} />, l: h.s3 }, { v: <Counter to={50} suffix="×" />, l: h.s4 },
            ].map((s, i) => <div key={i} className="panel rounded-2xl px-2 py-3.5 text-center"><p className="font-display font-bold text-xl sm:text-2xl text-goldsoft tabular">{s.v}</p><p className="text-[9px] sm:text-[10px] text-white/40 font-semibold mt-1 leading-tight">{s.l}</p></div>)}
          </div>
        </div>

        {/* live portfolio hero card */}
        <div className="reveal in relative lg:mt-4">
          <div className="absolute -inset-1 rounded-[40px] bg-gold/10 blur-3xl pointer-events-none" />
          <div className="relative panel rounded-[28px] p-5 sm:p-6 shadow-2xl">
            <div className="flex items-center justify-between mb-1"><div className="flex items-center gap-2 text-[10px] font-black tracking-widest text-white/50"><span className="live-dot h-2 w-2 rounded-full bg-jade" />{t.common.live} MARKET FEED</div><span className="text-[9px] font-black tracking-widest bg-gold/15 text-gold px-2.5 py-1 rounded-full">DORR-BIN AI</span></div>
            <div className="flex items-end justify-between mt-4"><div><p className="text-xs text-white/45 font-semibold">{h.wallet}</p><div className="flex items-center gap-2"><p className="font-display font-bold text-3xl sm:text-4xl tabular">{hidden ? "••••••" : fmtMoney(cur)}</p><button onClick={() => setHidden(!hidden)} className="text-white/40 hover:text-white transition">{hidden ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}</button></div></div><span className="inline-flex items-center gap-1 bg-jade/15 text-jade text-xs font-black px-2.5 py-1.5 rounded-full mb-1"><ArrowUpRight className="h-3.5 w-3.5" />{fmtSign(chg)}</span></div>
            <div className="h-44 sm:h-48 mt-4 rounded-2xl bg-black/20 border border-white/6 p-2"><EquityCurve data={equity} /></div>
            <div className="grid grid-cols-3 gap-2.5 mt-4">{[
              { icon: BrainCircuit, label: h.signal, val: "LONG BTC", cls: "text-jade" },
              { icon: Trophy, label: h.win, val: `${winRate.toFixed(0)}%`, cls: "text-goldsoft" },
              { icon: ShieldCheck, label: h.risk, val: "Low", cls: "text-[#38e1ff]" },
            ].map((c, i) => <div key={i} className="rounded-2xl bg-white/4 border border-white/8 p-3"><c.icon className={`h-4 w-4 mb-1.5 ${c.cls}`} /><p className="font-display font-bold text-sm tabular">{c.val}</p><p className="text-[9px] text-white/40 font-semibold mt-0.5">{c.label}</p></div>)}</div>
          </div>
          <div className="absolute -top-5 -end-2 sm:-end-5 glass panel rounded-2xl px-4 py-3 shadow-2xl animate-floaty hidden sm:flex items-center gap-3"><span className="h-9 w-9 rounded-xl bg-jade/15 grid place-items-center"><ArrowUpRight className="h-5 w-5 text-jade" /></span><div><p className="text-[10px] text-white/45 font-bold">BTC/USDT</p><p className="font-display font-bold text-sm tabular">${fmtPrice(btc.price, 0)}</p></div></div>
          <div className="absolute -bottom-6 -start-2 sm:-start-5 panel rounded-2xl px-4 py-3 shadow-2xl animate-floaty-slow hidden sm:flex items-center gap-3"><span className="h-9 w-9 rounded-xl bg-gold/15 grid place-items-center"><BrainCircuit className="h-5 w-5 text-gold" /></span><div><p className="text-[10px] text-white/45 font-bold">{h.opened}</p><p className="font-display font-bold text-sm">SOL · LONG 10×</p></div></div>
        </div>
      </div>
      <div className="reveal flex flex-wrap items-center justify-center gap-2.5 mt-10"><span className="text-[9px] font-black tracking-widest text-white/30 uppercase w-full text-center mb-1">{t.ov.exT}</span>{["Paper Demo", "Toobit Futures", "KCEX Futures"].map((x) => <span key={x} className="inline-flex items-center gap-1.5 panel rounded-full px-5 py-2 text-xs font-bold"><BadgeCheck className="h-3.5 w-3.5 text-jade" />{x}</span>)}<span className="panel rounded-full px-5 py-2 text-xs font-bold text-white/35">+ {t.ov.more}</span></div>
    </section>

    {/* engines */}
    <section className="reveal pt-6 pb-12 border-t hairline">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-6"><div><p className="text-[9px] font-black tracking-[.2em] text-gold uppercase mb-2.5">INTELLIGENCE, IN SYNC</p><h2 className="font-display font-semibold text-3xl sm:text-[38px] tracking-tight">{t.sections.enginesT}</h2><p className="text-sm text-white/45 mt-2">{t.sections.enginesS}</p></div><span className="hidden sm:inline-flex items-center gap-1.5 text-[10px] font-black text-jade border border-jade/25 bg-jade/8 rounded-full px-3 py-1.5"><span className="live-dot h-1.5 w-1.5 rounded-full bg-jade" />ALL SYSTEMS ONLINE</span></div>
      <div className="grid sm:grid-cols-3 gap-3.5">{ENGINES.map((en) => { const meta = ENGINE_META[en.e]; return <div key={en.e} className="panel panel-hover rounded-[26px] p-5 sm:p-6 relative overflow-hidden"><div className="absolute -top-10 -end-10 h-28 w-28 rounded-full blur-2xl opacity-30" style={{ background: meta.color }} /><div className="relative flex items-center justify-between mb-4"><span className="h-12 w-12 rounded-2xl grid place-items-center" style={{ background: `${meta.color}18`, color: meta.color, border: `1px solid ${meta.color}33` }}><en.icon className="h-6 w-6" /></span><span className="text-[9px] font-black tracking-widest px-2.5 py-1 rounded-full" style={{ background: `${meta.color}18`, color: meta.color }}>{en.code}</span></div><h3 className="relative font-display font-bold text-xl mb-2">{meta[lang]}</h3><p className="relative text-[12px] text-white/45 leading-relaxed min-h-[60px]">{en.e === "ai" ? t.sections.aiDesc : en.e === "strategy" ? t.sections.strategyDesc : t.sections.copyDesc}</p><div className="flex items-center justify-between text-xs font-bold mt-5 mb-1.5"><span className="text-white/40">{t.ov.win}</span><span className="tabular" style={{ color: meta.color }}>{en.win}%</span></div><div className="h-1.5 rounded-full bg-white/8 overflow-hidden"><div className="h-full rounded-full" style={{ width: `${en.win}%`, background: `linear-gradient(90deg,${meta.color}55,${meta.color})` }} /></div><button onClick={() => onEngine(en.e)} className="mt-5 w-full flex items-center justify-between text-xs font-black py-2.5 rounded-xl transition hover:bg-white/5" style={{ color: meta.color }}>{t.sections.try}<ArrowUpRight className="h-4 w-4 rtl:rotate-180" /></button></div>; })}</div>
    </section>

    {/* live radar */}
    <section className="reveal pb-14">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-6"><div><p className="text-[9px] font-black tracking-[.2em] text-gold uppercase mb-2.5 flex items-center gap-2"><span className="live-gold h-1.5 w-1.5 rounded-full bg-gold" />LIVE INTELLIGENCE</p><h2 className="font-display font-semibold text-3xl sm:text-[38px] tracking-tight">{t.sections.radarT}</h2><p className="text-sm text-white/45 mt-2">{t.sections.radarS}</p></div><button onClick={() => onGo("radar")} className="inline-flex items-center gap-1.5 text-xs font-bold text-gold hover:text-goldsoft transition shrink-0">{t.sections.allRadar}<ArrowRight className="h-4 w-4 rtl:rotate-180" /></button></div>
      <div className="grid lg:grid-cols-[1fr_300px] gap-4"><div className="space-y-3">{signals.slice(0, 3).map((s) => <SignalCard key={s.id} s={s} lang={lang} coins={coins} onTrade={onTrade} />)}</div><div className="flex flex-col gap-4"><div className="panel rounded-[26px] p-5 flex-1"><h3 className="font-display font-bold text-lg mb-3">{t.ov.consensus}</h3><Gauge value={consensus} longL={t.ov.long} shortL={t.ov.short} /></div><div className="panel rounded-[26px] p-5"><h3 className="font-display font-bold text-lg mb-4">{t.radar.board}</h3>{ENGINES.map((en, i) => { const m = ENGINE_META[en.e]; return <div key={en.e} className="flex items-center gap-3 mb-3 last:mb-0"><span className="font-display italic font-bold text-lg w-5" style={{ color: i === 0 ? "var(--gold)" : "var(--faint)" }}>{i + 1}</span><div className="flex-1"><p className="text-xs font-bold" style={{ color: m.color }}>{m[lang]}</p><p className="text-[10px] text-white/40 tabular mt-0.5">{en.win}% {t.ov.win.toLowerCase()}</p></div><span className="text-xs font-bold text-jade tabular">{en.roi}</span></div>; })}</div></div></div>
    </section>

    {/* portfolio preview */}
    <section className="reveal pb-14">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-6"><div><p className="text-[9px] font-black tracking-[.2em] text-gold uppercase mb-2.5">TOTAL CONTROL</p><h2 className="font-display font-semibold text-3xl sm:text-[38px] tracking-tight">{t.sections.pfT}</h2><p className="text-sm text-white/45 mt-2">{t.sections.pfS}</p></div><button onClick={() => onGo("portfolio")} className="inline-flex items-center gap-1.5 text-xs font-bold text-gold hover:text-goldsoft transition shrink-0">{t.sections.allPortfolio}<ArrowRight className="h-4 w-4 rtl:rotate-180" /></button></div>
      <div className="panel rounded-[28px] p-5 sm:p-7 grid lg:grid-cols-[1.5fr_1fr] gap-6 items-center"><div><div className="flex items-center justify-between"><h3 className="font-display font-bold text-xl">{t.ov.equity}</h3><span className="text-[10px] font-black text-jade flex items-center gap-1.5"><span className="live-dot h-1.5 w-1.5 rounded-full bg-jade" />{t.common.live}</span></div><p className="font-display font-bold text-4xl mt-3 tabular">{fmtMoney(cur)}</p><div className="h-48 mt-4"><EquityCurve data={equity} /></div></div><div><h3 className="font-display font-bold text-xl mb-4">{t.common.allocation}</h3><div className="space-y-3">{[{ label: "Bitcoin", sym: "BTC", color: coins[0].color }, { label: "Ethereum", sym: "ETH", color: coins[1].color }, { label: "Solana", sym: "SOL", color: coins[2].color }].map((c, i) => <div key={c.sym} className="flex items-center gap-2.5 text-sm"><span className="h-2.5 w-2.5 rounded-full" style={{ background: c.color }} /><span className="font-bold">{c.label}</span><span className="ms-auto text-white/40 tabular">{[42, 28, 18][i]}%</span></div>)}</div><button onClick={() => onGo("portfolio")} className="btn-ghost w-full mt-6 py-3 rounded-2xl font-bold text-sm flex items-center justify-center gap-2"><Layers className="h-4 w-4 text-gold" />{t.sections.allPortfolio}</button></div></div>
    </section>

    {/* weekly card teaser */}
    <section className="reveal panel rounded-[28px] p-7 sm:p-9 flex flex-col sm:flex-row items-center gap-7 relative overflow-hidden">
      <div className="relative w-40 shrink-0 animate-floaty-slow"><div className="aspect-[4/5] rounded-2xl p-4 border border-gold/30 bg-gradient-to-br from-[#302508] via-[#171305] to-[#0b0d07] shadow-xl shadow-black/40"><p className="text-[7px] font-black tracking-[.2em] text-gold">DOLLARINO · WEEKLY</p><p className="font-display font-bold text-4xl text-jade mt-6">+18.4%</p><div className="flex gap-2 mt-5">{[1,2,3].map((i) => <span key={i} className="flex-1 h-9 rounded-lg bg-gold/10 border border-gold/20" />)}</div><p className="text-[7px] text-white/40 mt-4">Trade Every Market. Automatically.</p></div></div>
      <div className="flex-1"><p className="text-[9px] font-black tracking-[.2em] text-gold uppercase mb-2.5">THE WEEKLY CARD STUDIO</p><h3 className="font-display font-semibold text-2xl sm:text-4xl tracking-tight">{t.sections.cardT}</h3><p className="text-sm text-white/45 mt-3 max-w-md">{t.sections.cardS}</p><button onClick={() => onGo("card")} className="btn-gold inline-flex items-center gap-2 mt-6 px-6 py-3.5 rounded-2xl font-black text-sm"><Sparkles className="h-4 w-4" />{t.nav.card}<ArrowUpRight className="h-4 w-4" /></button></div><span className="hidden sm:grid absolute -end-10 -bottom-10 place-items-center font-display font-bold text-[180px] text-gold/5 select-none">D$</span>
    </section>

    {/* final cta */}
    <section className="reveal relative overflow-hidden rounded-[30px] mt-10 p-8 sm:p-12 text-center border border-gold/25" style={{ background: "linear-gradient(150deg,color-mix(in srgb,var(--gold) 12%,var(--bg)),var(--bg) 60%)" }}><div className="absolute inset-0 grid-bg opacity-70" /><div className="absolute left-1/2 top-0 -translate-x-1/2 h-48 w-[90%] max-w-[420px] rounded-full bg-gold/15 blur-[100px]" /><span className="absolute inset-0 grid place-items-center font-display font-bold text-[190px] text-gold/5 select-none">D$</span><div className="relative"><h3 className="font-display font-semibold text-3xl sm:text-5xl leading-tight">{t.common.ctaT}</h3><p className="mt-3 text-white/55">{t.common.ctaS}</p><button onClick={() => onGo("terminal")} className="btn-gold mt-8 inline-flex items-center gap-2 font-black px-9 py-4 rounded-2xl"><Zap className="h-5 w-5" />{t.common.ctaB}</button></div></section>
  </div>;
}
