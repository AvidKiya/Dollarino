import { useMemo, useState } from "react";
import {
  ArrowLeft, ArrowUpRight, BrainCircuit, Check, ChevronDown, Copy, Crosshair,
  Download, Eye, EyeOff, Globe2, Menu, Palette, Play, Radar as RadarIcon,
  Rocket, Sparkles, Star, TrendingUp, Trophy, Wallet, X, Zap,
} from "lucide-react";
import { Coin, Engine, Lang, Signal, T, View, changeOf, fmtPrice } from "../lib/data";
import { Sparkline } from "../components/Charts";

const S = {
  fa: {
    dir: "rtl" as const,
    announce: "نسخه ۶٫۰ منتشر شد — سه موتور، ۳۰+ ارز و اهرم آزاد تا 50×",
    announceLink: "مشاهده تعرفه",
    nav: ["امکانات", "موتورها", "آزمایشگاه", "پنل", "تعرفه\u200cها", "سوالات"],
    launch: "ورود به میز", start: "شروع رایگان", site: "سایت",
    badge1: "نسخه ۶٫۰", badge2: "Paper · Toobit · KCEX", badge3: "PWA قابل نصب",
    eyebrow: "سه موتور · یک میز · صفر حدس",
    h1: "شما بخوابید،", h2: "دلارینو", h3: "بیدار", h4: "می\u200cماند.",
    heroSub: "ادیتوریال آرام بیرون، دستگاه شیشه\u200cای درون. هوش مصنوعی دُرّبین، استراتژی دُرنا و کپی\u200cترید را ترکیب کن، رادار را زنده ببین و نتیجه هفته را با لوگوی دلارینو بیرون ببر.",
    cta1: "شروع رایگان در دمو", cta2: "ببین چطور کار می\u200cکند",
    trust: ["بدون کلید API", "اهرم در اختیار تو", "بدون محدودیت ارز"],
    rating: "رضایت کاربران", traders: "تریدر فعال",
    stats: [["30+", "ارز تحت رصد"], ["20", "معامله همزمان"], ["24/7", "ربات بیدار"], ["50×", "حداکثر اهرم"]],
    instrument: "LIVE DESK", acct: "موجودی دمو", signals: "سیگنال فعال", daily: "سود امروز",
    enginesT: "سه موتور. یک مغز.", enginesS: "هر کدام را جداگانه روشن کن، یا بگذار هر سه با هم فکر کنند.",
    engines: [
      ["هوش مصنوعی دُرّبین", "ترکیب ۱ تا ۳ مدل پیشرفته — DeepSeek، Claude، GPT و Gemini. بدون کلید API، فقط نتیجه.", "DORR-BIN"],
      ["استراتژی دُرنا V1", "روند، مومنتوم، شکار نقدینگی و ریبون غیرریپینت در یک پلی\u200cبوک اثبات\u200cشده.", "DORNA V1"],
      ["کپی\u200cترید آینه", "سیگنال\u200cهای نخبگان را از تلگرام و TradingView لحظه\u200cای کپی کن.", "MIRROR"],
    ],
    labT: "مدل ترکیبی\u200cات را بساز.", labS: "وزن هر موتور را تغییر بده و همان لحظه اثرش را روی وین\u200cریت، بازده و ریسک ببین.",
    presets: [["متوازن", [55, 30, 15]], ["هوش\u200cمحور", [75, 15, 10]], ["استراتژی\u200cمحور", [20, 65, 15]], ["کپی\u200cمحور", [15, 20, 65]]],
    enginesShort: ["دُرّبین AI", "دُرنا V1", "کپی آینه"],
    score: "امتیاز ترکیب", win: "وین\u200cریت تخمینی", roi: "بازده ۳۰ روزه", riskL: "سطح ریسک", apply: "اجرا در میز معاملاتی",
    showcaseT: "همه\u200cچیز، یک جا.", showcaseS: "از سیگنال تا کارت هفتگی — چهار ابزار که کنار هم کار می\u200cکنند.",
    tools: [
      ["رادار زنده", "هر سیگنال، با ورود و تارگت و استاپ، شفاف و لحظه\u200cای.", "رادار"],
      ["کپی\u200cترید", "تریدرهای نخبه را دنبال کن؛ پوزیشن\u200cها خودکار کپی می\u200cشوند.", "کپی\u200cترید"],
      ["پورتفوی", "دارایی، سود شناور و تخصیص ارزها در یک نمای روشن.", "پورتفوی"],
      ["کارت هفتگی", "نتایجت را قاب بگیر و با کیفیت بالا PNG خروجی بگیر.", "کارت هفته"],
    ],
    pricingT: "ساده شروع کن. جدی ادامه بده.", pricingS: "دمو همیشه رایگان است. این پیش\u200cنمایش هیچ پرداختی دریافت نمی\u200cکند.",
    faqT: "سوال\u200cها، جواب\u200cهای روشن.",
    installT: "همراهت، همیشه.", installS: "PWA قابل نصب روی موبایل و دسکتاپ + ربات تلگرام ۲۴/۷. لازم نیست میز را مدام باز نگه داری.",
    closingT: "بازار حرکت می\u200cکند.", closingT2: "دلارینو تصمیم می\u200cگیرد.", closingB: "فعال\u200cسازی دلارینو",
    foot: "هر بازار. یک موتور.", rights: "© ۲۰۲۶ دلارینو. تمامی حقوق محفوظ است.", risk: "این پیش\u200cنمایش تعاملی است؛ همه قیمت\u200cها، سیگنال\u200cها و معاملات شبیه\u200cسازی شده\u200cاند و هیچ سفارش واقعی ارسال نمی\u200cشود.",
  },
  en: {
    dir: "ltr" as const,
    announce: "v6.0 is live — three engines, 30+ markets, free leverage up to 50×",
    announceLink: "See pricing",
    nav: ["Features", "Engines", "Lab", "Workspace", "Pricing", "FAQ"],
    launch: "Launch App", start: "Start Free", site: "Site",
    badge1: "VERSION 6.0", badge2: "Paper · Toobit · KCEX", badge3: "Installable PWA",
    eyebrow: "Three engines · One desk · Zero guesswork",
    h1: "You sleep.", h2: "Dollarino", h3: "stays", h4: "awake.",
    heroSub: "Editorial calm outside, a glass machine within. Blend Dorr-Bin AI, the Dorna V1 strategy and copy trading, watch the live radar, and take your weekly results out into the world.",
    cta1: "Start Free in Demo", cta2: "See how it works",
    trust: ["No API keys", "Leverage stays yours", "No coin limits"],
    rating: "user rating", traders: "active traders",
    stats: [["30+", "markets scanned"], ["20", "parallel trades"], ["24/7", "bot awake"], ["50×", "max leverage"]],
    instrument: "LIVE DESK", acct: "Demo balance", signals: "active signals", daily: "today's PnL",
    enginesT: "Three engines. One brain.", enginesS: "Switch each on individually — or let all three think together.",
    engines: [
      ["Dorr-Bin AI", "A smart blend of 1–3 frontier models — DeepSeek, Claude, GPT and Gemini. No API keys. Just intelligence.", "DORR-BIN"],
      ["Dorna V1 Strategy", "Trend, momentum, liquidity hunts and a non-repainting ribbon in one proven playbook.", "DORNA V1"],
      ["Mirror Copy Trading", "Mirror elite signals from Telegram and TradingView instantly, tick for tick.", "MIRROR"],
    ],
    labT: "Build your blend.", labS: "Change each engine's weight and watch win rate, return and risk respond instantly.",
    presets: [["Balanced", [55, 30, 15]], ["AI-first", [75, 15, 10]], ["Strategy-first", [20, 65, 15]], ["Copy-first", [15, 20, 65]]],
    enginesShort: ["Dorr-Bin AI", "Dorna V1", "Mirror Copy"],
    score: "Blend score", win: "Estimated win rate", roi: "30-day return", riskL: "Risk level", apply: "Run on the desk",
    showcaseT: "Everything, in one place.", showcaseS: "From signal to weekly card — four tools that work as one.",
    tools: [
      ["Live Radar", "Every signal with entry, target and stop — open and timestamped.", "Radar"],
      ["Copy Trading", "Follow elite traders; positions mirror automatically.", "Copy Trade"],
      ["Portfolio", "Equity, unrealized PnL and allocation in one clear view.", "Portfolio"],
      ["Weekly Card", "Frame your results and export a high-quality PNG.", "Weekly Card"],
    ],
    pricingT: "Start simple. Stay serious.", pricingS: "Demo is always free. This interactive preview collects no payment.",
    faqT: "Good questions. Clear answers.",
    installT: "With you, always.", installS: "An installable PWA for mobile and desktop plus a 24/7 Telegram bot. You don't need to keep the desk open.",
    closingT: "The market moves.", closingT2: "Dollarino decides.", closingB: "Activate Dollarino",
    foot: "Every market. One engine.", rights: "© 2026 Dollarino. All rights reserved.", risk: "This is an interactive preview. All prices, signals and trades are simulated — no real orders are sent.",
  },
} as const;

const ENGINE_ICONS = [BrainCircuit, Crosshair, Copy];
const TOOL_ICONS = [RadarIcon, Copy, Wallet, Trophy];
const TOOL_VIEWS: View[] = ["radar", "copy", "portfolio", "card"];

export default function Site({ lang, setLang, onTheme, coins, signals, equity, onLaunch, onEngine }: {
  lang: Lang; setLang: (l: Lang) => void; onTheme: () => void;
  coins: Coin[]; signals: Signal[]; equity: number[];
  onLaunch: (v: View) => void; onEngine: (e: Engine) => void;
}) {
  const s = S[lang]; const t = T[lang]; const [menu, setMenu] = useState(false); const [hidden, setHidden] = useState(false);
  const [weights, setWeights] = useState<number[]>([55, 30, 15]); const [preset, setPreset] = useState(0); const [faq, setFaq] = useState(0);
  const active = signals.filter((x) => x.status === "active").length;
  const bal = equity[equity.length - 1] ?? 12480;
  const scroll = (id: string) => { setMenu(false); document.getElementById(id)?.scrollIntoView({ behavior: "smooth", block: "start" }); };
  const lab = useMemo(() => {
    const [a, b, c] = weights, sum = a + b + c || 1;
    const win = 52 + (a * .17 + b * .13 + c * .09) / sum * 100 * .32;
    const roi = 7 + (a * .24 + b * .19 + c * .13) / sum * 100 * .38;
    const risk = Math.max(1, 9 - (a * .035 + b * .028 + c * .012) / sum * 100);
    return { win: Math.min(92, win), roi: Math.min(58, roi), risk: Math.min(9, risk), score: Math.round((win * .45 + roi * .4 + (10 - risk) * 3.2)) };
  }, [weights]);

  return <div dir={s.dir} className="min-h-screen relative bg-[var(--bg)] text-[var(--text)]">
    {/* ambient */}
    <div className="pointer-events-none absolute inset-x-0 top-0 h-[980px] overflow-hidden">
      <div className="absolute inset-0 site-dots opacity-60" style={{ maskImage: "radial-gradient(ellipse 80% 65% at 72% 20%, #000, transparent 75%)" }} />
      <div className="absolute -top-32 end-[12%] h-[420px] w-[420px] rounded-full blur-[120px] opacity-30 glow-pulse" style={{ background: "var(--gold)" }} />
      <div className="absolute top-[420px] start-[5%] h-[300px] w-[300px] rounded-full blur-[110px] opacity-20" style={{ background: "var(--lime)" }} />
    </div>

    {/* announcement */}
    <div className="relative z-20 text-center py-2.5 text-[11px] font-bold border-b hairline" style={{ background: "var(--gold)", color: "#fff" }}>
      <span className="inline-flex items-center gap-2"><Sparkles className="h-3.5 w-3.5" />{s.announce}<button onClick={() => scroll("pricing")} className="underline underline-offset-2 font-black">{s.announceLink} →</button></span>
    </div>

    {/* header */}
    <header className="sticky top-0 z-40 px-3 sm:px-6 pt-3">
      <div className="mx-auto max-w-6xl panel rounded-full px-3 sm:px-4 py-2 flex items-center gap-2 shadow-lg" style={{ background: "color-mix(in srgb,var(--panel) 88%,transparent)" }}>
        <button onClick={() => scroll("top")} className="flex items-center gap-2.5 shrink-0">
          <span className="h-9 w-9 rounded-xl grid place-items-center font-display font-bold text-sm shadow-md" style={{ background: "linear-gradient(135deg,var(--gold-a),var(--gold-b),var(--gold-c))", color: "#fff" }}>D$</span>
          <span className="leading-none"><span dir="ltr" className="block font-[var(--font-num)] font-bold text-[15px]">dollarino<span style={{ color: "var(--gold)" }}>.</span></span><span className="text-[9px] font-bold opacity-50">OS · v6</span></span>
        </button>
        <nav className="hidden lg:flex items-center gap-0.5 mx-auto">{s.nav.map((n, i) => <button key={n} onClick={() => scroll(["features", "engines", "lab", "showcase", "pricing", "faq"][i])} className="px-3.5 py-2 rounded-full text-[12px] font-bold opacity-65 hover:opacity-100 hover:bg-[var(--soft)] transition">{n}</button>)}</nav>
        <div className="ms-auto flex items-center gap-1.5">
          <button onClick={() => setLang(lang === "fa" ? "en" : "fa")} className="inline-flex items-center gap-1 text-[11px] font-bold px-2.5 py-2 rounded-full btn-ghost"><Globe2 className="h-3.5 w-3.5" />{lang === "fa" ? "EN" : "فارسی"}</button>
          <button onClick={onTheme} aria-label={t.nav.appearance} title={t.nav.appearance} className="h-9 w-9 grid place-items-center rounded-full btn-ghost"><Palette className="h-4 w-4" /></button>
          <button onClick={() => onLaunch("overview")} className="hidden sm:inline-flex btn-gold items-center gap-1.5 text-[11px] font-black px-4 py-2.5 rounded-full">{s.launch}<ArrowLeft className="h-3.5 w-3.5 rtl:rotate-0" /></button>
          <button onClick={() => setMenu(!menu)} aria-label="Menu" className="lg:hidden h-9 w-9 grid place-items-center rounded-full btn-ghost">{menu ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}</button>
        </div>
      </div>
      {menu && <div className="panel rounded-3xl mt-2 p-2 lg:hidden max-w-6xl mx-auto">{s.nav.map((n, i) => <button key={n} onClick={() => scroll(["features", "engines", "lab", "showcase", "pricing", "faq"][i])} className="block w-full text-start px-4 py-3 rounded-2xl text-sm font-bold hover:bg-[var(--soft)]">{n}</button>)}<button onClick={() => onLaunch("overview")} className="btn-gold w-full py-3 rounded-2xl font-black text-sm mt-1">{s.launch}</button></div>}
    </header>

    {/* hero */}
    <main id="top" className="relative">
      <section className="mx-auto max-w-6xl px-4 sm:px-6 pt-10 sm:pt-16 pb-8">
        <div className="grid grid-cols-[minmax(0,1fr)] lg:grid-cols-[minmax(0,1.02fr)_minmax(0,.98fr)] gap-10 xl:gap-16 items-center">
          {/* copy */}
          <div className="relative z-10 text-center lg:text-start min-w-0">
            <div className="flex flex-wrap justify-center lg:justify-start gap-2 mb-7">{[s.badge1, s.badge2, s.badge3].map((b, i) => <span key={b} className="inline-flex items-center gap-1.5 panel rounded-full px-3.5 py-2 text-[10px] font-black">{i === 0 ? <Rocket className="h-3.5 w-3.5" style={{ color: "var(--gold)" }} /> : i === 2 ? <Download className="h-3.5 w-3.5" /> : null}{b}</span>)}</div>
            <p className="text-[11px] font-black tracking-[.18em] opacity-55 mb-4">{s.eyebrow}</p>
            <h1 className="font-display font-bold tracking-tight leading-[1.16] text-[clamp(36px,9vw,68px)]">
              {s.h1}<br /><span style={{ color: "var(--gold)" }}>{s.h2} </span><span className="mark-lime">{s.h3}</span><br />{s.h4}
            </h1>
            <p className="mt-6 text-[14px] sm:text-[15px] leading-[1.9] opacity-65 max-w-xl mx-auto lg:mx-0">{s.heroSub}</p>
            <div className="mt-7 flex flex-wrap justify-center lg:justify-start gap-3">
              <button onClick={() => onLaunch("terminal")} className="btn-lime inline-flex items-center gap-2 font-black px-7 py-4 rounded-2xl text-sm"><Zap className="h-[18px] w-[18px]" />{s.cta1}</button>
              <button onClick={() => scroll("showcase")} className="btn-ghost inline-flex items-center gap-2 font-bold px-6 py-4 rounded-2xl text-sm"><Play className="h-4 w-4" />{s.cta2}</button>
            </div>
            <div className="mt-7 flex flex-wrap justify-center lg:justify-start gap-x-5 gap-y-2 text-[12px] font-bold opacity-65">{s.trust.map((x) => <span key={x} className="inline-flex items-center gap-1.5"><Check className="h-4 w-4" style={{ color: "var(--jade)" }} />{x}</span>)}</div>
            <div className="mt-8 flex flex-wrap justify-center lg:justify-start items-center gap-4 text-[11px] font-bold opacity-60">
              <span className="flex text-[13px]" style={{ color: "var(--gold)" }}>{[0,1,2,3,4].map((i) => <Star key={i} className="h-4 w-4 fill-current" />)}</span>
              <span>4.9 · {s.rating}</span><span className="opacity-30">|</span>
              <span className="flex -space-x-2 space-x-reverse">{["#2f5bff","#16e664","#ff8a00","#9945ff"].map((c, i) => <span key={i} className="h-7 w-7 rounded-full border-2 border-[var(--bg)] grid place-items-center text-[9px] text-white font-black" style={{ background: c }}>{["K","A","M","S"][i]}</span>)}</span>
              <span>+12K {s.traders}</span>
            </div>
          </div>

          {/* instrument card */}
          <div className="relative animate-floaty-slow mx-auto w-full max-w-[430px] min-w-0">
            <div className="absolute inset-0 rounded-[40px] blur-3xl opacity-30" style={{ background: "var(--gold)" }} />
            <div className="site-dark relative rounded-[30px] p-4 sm:p-5 shadow-2xl border border-white/10" style={{ background: "var(--ink-card)" }}>
              <div className="flex items-center justify-between px-1 pb-3 text-white/45 text-[9px] font-black tracking-widest"><span className="flex items-center gap-1.5"><span className="live-dot h-1.5 w-1.5 rounded-full" style={{ background: "var(--jade)" }} />{s.instrument}</span><span dir="ltr">DOLLARINO OS · V6</span></div>
              {/* wallet */}
              <div className="relative overflow-hidden rounded-[22px] p-5" style={{ background: "linear-gradient(135deg,var(--gold-b),var(--gold-c))" }}>
                <span className="absolute -top-10 -start-10 h-36 w-36 rounded-full bg-white/15" /><span className="absolute -bottom-16 end-4 h-44 w-44 rounded-full border-[24px] border-white/10" />
                <div className="relative flex items-start justify-between">
                  <button onClick={() => setHidden(!hidden)} aria-label="toggle balance" className="h-9 w-9 rounded-xl bg-white/15 grid place-items-center text-white"><EyeOff className="h-4 w-4" style={{ display: hidden ? "block" : "none" }} /><Eye className="h-4 w-4" style={{ display: hidden ? "none" : "block" }} /></button>
                  <div className="text-end text-white"><p className="text-[10px] font-bold opacity-75">{s.acct} · USD</p><p dir="ltr" className="font-num font-bold text-[29px] sm:text-[33px] tabular">{hidden ? "$•••••" : "$" + fmtPrice(bal, 2)}</p></div>
                </div>
                <div className="relative flex items-center justify-between mt-6"><span className="text-[10px] font-bold text-white/80">{s.daily}</span><span className="font-num font-black text-xs rounded-full px-3 py-1.5" style={{ background: "var(--lime)", color: "#0b1405" }}>+12.4% · +$741.28</span></div>
              </div>
              {/* markets */}
              <div className="mt-3 space-y-2">{coins.slice(0, 4).map((c) => { const ch = changeOf(c); return <div key={c.sym} className="rounded-xl bg-white/[0.045] border border-white/8 px-3 py-2.5 flex items-center gap-2 min-w-0"><span className="h-7 w-7 rounded-lg grid place-items-center text-[10px] font-black" style={{ background: c.color + "28", color: c.color }}>{c.sym[0]}</span><span className="font-num font-bold text-[11px] text-white/85">{c.sym}</span><Sparkline data={c.spark} up={ch >= 0} w={72} h={22} /><span dir="ltr" className="font-num font-bold text-[11px] text-white/70 tabular ms-auto">${fmtPrice(c.price, c.dec)}</span><span dir="ltr" className="font-num font-black text-[10px] tabular w-14 text-end" style={{ color: ch >= 0 ? "var(--jade)" : "var(--rose)" }}>{ch >= 0 ? "+" : ""}{ch.toFixed(2)}%</span></div>; })}</div>
              <div className="flex items-center justify-between mt-3 px-1"><span className="text-[9px] font-bold text-white/40">{s.instrument} · 30+ MARKETS</span><span className="rounded-full px-3 py-1.5 text-[10px] font-black" style={{ background: "var(--lime)", color: "#0b1405" }}>{active} {s.signals}</span></div>
              {/* floating signal toast */}
              <div className="absolute -top-4 -end-3 sm:-end-8 panel rounded-2xl px-3.5 py-2.5 shadow-xl animate-floaty border border-white/15 !bg-[var(--panel)] hidden sm:flex items-center gap-2.5">
                <span className="h-8 w-8 rounded-xl grid place-items-center" style={{ background: "color-mix(in srgb,var(--jade) 20%,transparent)" }}><TrendingUp className="h-4 w-4" style={{ color: "var(--jade)" }} /></span>
                <div><p className="text-[9px] font-bold opacity-50">LONG BTC · 94%</p><p className="font-num font-bold text-xs" style={{ color: "var(--jade)" }}>+$125.40</p></div>
              </div>
              <div className="absolute -bottom-4 -start-3 sm:-start-8 panel rounded-full px-4 py-2.5 shadow-xl animate-floaty-slow border border-white/15 !bg-[var(--panel)] hidden sm:flex items-center gap-2 text-[10px] font-black"><span className="live-dot h-2 w-2 rounded-full" style={{ background: "var(--jade)" }} />LONG BTC · {lang === "fa" ? "سیگنال جدید" : "NEW SIGNAL"}</div>
            </div>
          </div>
        </div>

        {/* stats strip */}
        <div id="features" className="reveal in mt-14 grid grid-cols-2 lg:grid-cols-4 gap-px overflow-hidden rounded-[26px] border hairline" style={{ background: "var(--line)" }}>
          {s.stats.map(([v, l]) => <div key={l} className="bg-[var(--panel)] px-5 py-6 text-center"><p className="font-num font-bold text-3xl sm:text-4xl tabular" style={{ color: "var(--gold)" }}>{v}</p><p className="mt-1 text-[11px] font-bold opacity-55">{l}</p></div>)}
        </div>
      </section>

      {/* ticker */}
      <div className="relative border-y hairline overflow-hidden" style={{ background: "var(--ink-card)" }}>
        <div className="flex w-max gap-8 px-4 py-2.5 animate-ticker" style={lang === "fa" ? { animationName: "ticker-rtl" } : undefined}>
          {[...coins, ...coins].map((c, i) => { const ch = changeOf(c); return <span key={i} dir="ltr" className="flex items-center gap-2 text-[11px] font-bold whitespace-nowrap text-white/70"><span style={{ color: c.color }}>{c.sym}</span>${fmtPrice(c.price, c.dec)}<span style={{ color: ch >= 0 ? "var(--jade)" : "var(--rose)" }}>{ch >= 0 ? "▲" : "▼"} {Math.abs(ch).toFixed(2)}%</span></span>; })}
        </div>
      </div>

      {/* engines */}
      <section id="engines" className="mx-auto max-w-6xl px-4 sm:px-6 py-16 sm:py-24">
        <div className="reveal max-w-2xl"><p className="text-[10px] font-black tracking-[.2em] opacity-50 mb-3">01 · INTELLIGENCE, IN SYNC</p><h2 className="font-display font-bold text-[clamp(30px,6vw,52px)] leading-tight">{s.enginesT}</h2><p className="mt-3 text-sm opacity-60">{s.enginesS}</p></div>
        <div className="reveal grid sm:grid-cols-3 gap-3.5 mt-8">{s.engines.map((e, i) => { const Icon = ENGINE_ICONS[i]; const color = [ "var(--gold)", "var(--jade)", "var(--blue)" ][i]; return <div key={e[0]} className="panel panel-hover rounded-[26px] p-6 relative overflow-hidden"><span className="absolute -top-10 -end-10 h-28 w-28 rounded-full blur-2xl opacity-25" style={{ background: color }} /><div className="flex items-center justify-between mb-5"><span className="h-12 w-12 rounded-2xl grid place-items-center" style={{ background: `color-mix(in srgb,${color} 14%,transparent)`, color }}><Icon className="h-6 w-6" /></span><span className="text-[9px] font-black tracking-widest px-2.5 py-1 rounded-full" style={{ background: `color-mix(in srgb,${color} 14%,transparent)`, color }}>{e[2]}</span></div><h3 className="font-bold text-lg">{e[0]}</h3><p className="text-[12px] leading-relaxed opacity-60 mt-2 min-h-[62px]">{e[1]}</p><button onClick={() => { onEngine((["ai", "strategy", "copy"] as Engine[])[i]); onLaunch(i === 2 ? "copy" : "terminal"); }} className="mt-4 w-full flex items-center justify-between text-xs font-black py-2.5 transition hover:opacity-70" style={{ color }}>{s.apply}<ArrowUpRight className="h-4 w-4 rtl:rotate-180" /></button></div>; })}</div>
      </section>

      {/* strategy lab */}
      <section id="lab" className="mx-auto max-w-6xl px-4 sm:px-6 pb-16 sm:pb-24">
        <div className="reveal grid lg:grid-cols-[.85fr_1.15fr] gap-8 panel rounded-[32px] p-6 sm:p-9 relative overflow-hidden">
          <div className="absolute inset-0 grid-bg opacity-70 pointer-events-none" />
          <div className="relative"><p className="text-[10px] font-black tracking-[.2em] opacity-50 mb-3">02 · THE STRATEGY LAB</p><h2 className="font-display font-bold text-[clamp(28px,5vw,46px)] leading-tight">{s.labT}</h2><p className="mt-4 text-sm leading-relaxed opacity-60">{s.labS}</p>
            <div className="flex flex-wrap gap-2 mt-6">{s.presets.map((p, i) => <button key={p[0]} onClick={() => { setPreset(i); setWeights(p[1] as unknown as number[]); }} className={`px-4 py-2.5 rounded-full text-xs font-black transition ${preset === i ? "btn-lime" : "btn-ghost"}`}>{p[0]}</button>)}</div>
            <div className="mt-8 grid grid-cols-3 gap-2">{[
              { l: s.score, v: String(lab.score), c: "var(--gold)" },
              { l: s.win, v: `${lab.win.toFixed(1)}%`, c: "var(--jade)" },
              { l: s.roi, v: `+${lab.roi.toFixed(1)}%`, c: "var(--lime)" },
            ].map((x) => <div key={x.l} className="rounded-2xl p-3 panel text-center"><p className="font-num font-bold text-xl tabular" style={{ color: x.c }}>{x.v}</p><p className="text-[9px] font-bold opacity-50 mt-1 leading-tight">{x.l}</p></div>)}</div>
            <button onClick={() => { const best = (["ai", "strategy", "copy"] as Engine[])[weights.indexOf(Math.max(...weights))]; onEngine(best); onLaunch("terminal"); }} className="btn-gold mt-6 w-full py-3.5 rounded-2xl font-black text-sm flex items-center justify-center gap-2"><Zap className="h-4 w-4" />{s.apply}</button>
          </div>
          <div className="relative space-y-6">{s.enginesShort.map((name, i) => <div key={name}><div className="flex items-center justify-between text-sm font-bold mb-2"><span className="flex items-center gap-2"><span className="h-2.5 w-2.5 rounded-full" style={{ background: ["var(--gold)","var(--jade)","var(--blue)"][i] }} />{name}</span><span className="font-num tabular">{weights[i]}%</span></div><input type="range" min={0} max={100} value={weights[i]} onChange={(e) => { const w = [...weights]; w[i] = +e.target.value; setWeights(w); setPreset(-1); }} className="w-full" style={{ "--fill": `${weights[i]}%` } as React.CSSProperties} /></div>)}
            <div className="panel rounded-2xl p-4"><div className="flex items-center justify-between text-xs font-bold mb-3"><span>{s.riskL}</span><span className="font-num tabular" style={{ color: "var(--gold)" }}>{lab.risk.toFixed(1)} / 10</span></div><div className="h-2 rounded-full overflow-hidden" style={{ background: "var(--line)" }}><div className="h-full rounded-full transition-all duration-500" style={{ width: `${lab.risk * 10}%`, background: "linear-gradient(90deg,var(--jade),var(--gold),var(--rose))" }} /></div><p className="text-[10px] opacity-50 mt-3 leading-relaxed">{lang === "fa" ? "خروجی آزمایشگاه تخمینی و آموزشی است و وعده سود نیست." : "Lab outputs are illustrative estimates, not a promise of profit."}</p></div>
            <div className="grid grid-cols-3 gap-2">{(["ai","strategy","copy"] as Engine[]).map((e, i) => <div key={e} className="rounded-xl p-3 text-center panel"><div className="h-10 flex items-end justify-center gap-0.5">{Array.from({length: 5},(_,j) => <span key={j} className="w-2 rounded-t" style={{ height: `${8 + ((weights[i] + j*17) % 30)}px`, background: ["var(--gold)","var(--jade)","var(--blue)"][i], opacity: .35 + j*.13 }} />)}</div><p className="text-[9px] font-bold opacity-50 mt-2">{s.enginesShort[i]}</p></div>)}</div>
          </div>
        </div>
      </section>

      {/* showcase bento */}
      <section id="showcase" className="mx-auto max-w-6xl px-4 sm:px-6 pb-16 sm:pb-24">
        <div className="reveal text-center max-w-2xl mx-auto"><p className="text-[10px] font-black tracking-[.2em] opacity-50 mb-3">03 · THE WORKSPACE</p><h2 className="font-display font-bold text-[clamp(30px,6vw,52px)] leading-tight">{s.showcaseT}</h2><p className="mt-3 text-sm opacity-60">{s.showcaseS}</p></div>
        <div className="reveal grid sm:grid-cols-2 lg:grid-cols-4 gap-3.5 mt-8">{s.tools.map((x, i) => { const Icon = TOOL_ICONS[i]; return <button key={x[0]} onClick={() => onLaunch(TOOL_VIEWS[i])} className="panel panel-hover rounded-[26px] p-5 text-start group"><span className="h-11 w-11 rounded-2xl grid place-items-center mb-4" style={{ background: "color-mix(in srgb,var(--gold) 12%,transparent)", color: "var(--gold)" }}><Icon className="h-5 w-5" /></span><h3 className="font-bold">{x[0]}</h3><p className="text-[12px] leading-relaxed opacity-60 mt-2 min-h-[54px]">{x[1]}</p><span className="mt-3 inline-flex items-center gap-1 text-[11px] font-black" style={{ color: "var(--gold)" }}>{x[2]}<ArrowUpRight className="h-3.5 w-3.5 rtl:rotate-180 transition group-hover:translate-x-1" /></span></button>; })}</div>
      </section>

      {/* pricing */}
      <section id="pricing" className="mx-auto max-w-6xl px-4 sm:px-6 pb-16 sm:pb-24">
        <div className="reveal text-center max-w-2xl mx-auto"><p className="text-[10px] font-black tracking-[.2em] opacity-50 mb-3">04 · SIMPLE PRICING</p><h2 className="font-display font-bold text-[clamp(30px,6vw,52px)] leading-tight">{s.pricingT}</h2><p className="mt-3 text-sm opacity-60">{s.pricingS}</p></div>
        <div className="reveal grid md:grid-cols-3 gap-3.5 mt-8">{t.plans.map((p, i) => <div key={p.name} className={`panel rounded-[26px] p-6 flex flex-col ${i === 1 ? "!border-[var(--gold)]" : ""}`}>{i === 1 && <span className="text-[9px] font-black tracking-widest mb-3" style={{ color: "var(--gold)" }}>{t.common.popular}</span>}<h3 className="font-bold text-lg">{p.name}</h3><p className="text-xs opacity-55 mt-1">{p.desc}</p><p className="font-num font-bold text-4xl mt-5 tabular">{p.price}<span className="text-xs font-medium opacity-50">{i ? t.pr.mo : ""}</span></p><ul className="mt-5 space-y-2 flex-1">{p.feats.map((f) => <li key={f} className="flex items-center gap-2 text-[12px] opacity-70"><Check className="h-4 w-4 shrink-0" style={{ color: "var(--jade)" }} />{f}</li>)}</ul><button onClick={() => onLaunch("terminal")} className={`mt-6 w-full py-3 rounded-2xl font-black text-sm ${i === 1 ? "btn-lime" : "btn-ghost"}`}>{t.common.getStarted}</button></div>)}</div>
      </section>

      {/* faq */}
      <section id="faq" className="mx-auto max-w-3xl px-4 sm:px-6 pb-16 sm:pb-24">
        <h2 className="reveal font-display font-bold text-[clamp(28px,5vw,44px)] text-center">{s.faqT}</h2>
        <div className="reveal space-y-2.5 mt-8">{t.faq.slice(0, 5).map((it, i) => <div key={it[0]} className="panel rounded-2xl overflow-hidden"><button onClick={() => setFaq(faq === i ? -1 : i)} className="w-full flex items-center justify-between gap-4 px-5 py-4 text-start font-bold text-sm">{it[0]}<ChevronDown className={`h-4 w-4 shrink-0 transition-transform ${faq === i ? "rotate-180" : ""}`} style={{ color: "var(--gold)" }} /></button><div className={`grid transition-all duration-300 ${faq === i ? "grid-rows-[1fr] opacity-100" : "grid-rows-[0fr] opacity-0"}`}><div className="overflow-hidden"><p className="px-5 pb-5 text-[13px] leading-relaxed opacity-60">{it[1]}</p></div></div></div>)}</div>
      </section>

      {/* install + closing */}
      <section className="mx-auto max-w-6xl px-4 sm:px-6 pb-20">
        <div className="site-dark reveal relative overflow-hidden rounded-[32px] p-8 sm:p-12 border border-white/10 text-white" style={{ background: "linear-gradient(140deg,var(--hero-b),var(--ink-card))" }}>
          <div className="absolute inset-0 site-starfield opacity-70 pointer-events-none" /><div className="absolute -top-24 end-0 h-72 w-72 rounded-full blur-[100px] opacity-30" style={{ background: "var(--gold)" }} />
          <div className="relative grid lg:grid-cols-[1fr_auto] gap-8 items-center">
            <div><span className="inline-flex items-center gap-2 rounded-full px-3.5 py-2 text-[10px] font-black" style={{ background: "var(--lime)", color: "#0b1405" }}><Download className="h-3.5 w-3.5" />PWA · TELEGRAM BOT 24/7</span><h2 className="font-display font-bold text-[clamp(28px,5vw,46px)] mt-5 leading-tight">{s.installT}<br /><span style={{ color: "var(--lime)" }}>{s.closingT2}</span></h2><p className="mt-4 text-sm text-white/60 max-w-lg leading-relaxed">{s.installS}</p></div>
            <div className="flex flex-col gap-3"><button onClick={() => onLaunch("terminal")} className="btn-lime inline-flex items-center justify-center gap-2 font-black px-8 py-4 rounded-2xl whitespace-nowrap"><Zap className="h-5 w-5" />{s.closingB}</button><button onClick={() => scroll("top")} className="btn-ghost text-white/70 inline-flex items-center justify-center gap-2 font-bold px-8 py-4 rounded-2xl whitespace-nowrap"><ArrowUpRight className="h-4 w-4" />{lang === "fa" ? "برگشت به بالا" : "Back to top"}</button></div>
          </div>
        </div>
      </section>
    </main>

    <footer className="border-t hairline"><div className="mx-auto max-w-6xl px-4 sm:px-6 py-9 flex flex-col md:flex-row items-center justify-between gap-4 text-[11px] font-bold opacity-55"><span className="font-display text-lg opacity-100">dollarino<span style={{ color: "var(--gold)" }}>.</span> · {s.foot}</span><div className="flex flex-wrap justify-center gap-x-5 gap-y-1">{s.nav.map((n, i) => <button key={n} onClick={() => scroll(["features","engines","lab","showcase","pricing","faq"][i])}>{n}</button>)}</div><span>{s.rights}</span></div><p className="text-center text-[10px] opacity-40 px-6 pb-8 max-w-3xl mx-auto">{s.risk}</p></footer>
  </div>;
}
