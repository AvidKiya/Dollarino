import { chromium } from '@playwright/test';

const browser = await chromium.launch({ headless: true, args: ['--no-sandbox'] });
const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
const errors = [];
page.on('pageerror', (e) => errors.push(e.message));
page.on('console', (m) => { if (m.type() === 'error') errors.push(m.text()); });
const base = 'http://127.0.0.1:5173';
const assert = (v, msg) => { if (!v) throw new Error(msg); console.log('PASS:', msg); };
const layout = async (label) => {
  const r = await page.evaluate(() => {
    const w = innerWidth, out = [];
    document.querySelectorAll('body *').forEach((e) => {
      const b = e.getBoundingClientRect();
      if (b.width && b.right > w + 1) out.push({ cls: (e.getAttribute('class') || '').slice(0, 110), right: Math.round(b.right), left: Math.round(b.left) });
    });
    return { w, sw: document.documentElement.scrollWidth, hash: location.hash, out: out.slice(0, 12) };
  });
  if (r.sw > r.w + 2) console.log('OVERFLOW DEBUG', label, JSON.stringify(r));
  assert(r.sw <= r.w + 2, `${label}: no horizontal overflow (${r.sw}/${r.w})`);
};

try {
  // ---------- combined landing ----------
  await page.goto(base, { waitUntil: 'networkidle' });
  await page.waitForTimeout(1600);
  assert((await page.locator('h1').innerText()).includes('شما بخوابید'), 'Persian combined hero renders');
  assert(await page.getByText('آزمایشگاه').first().isVisible(), 'Strategy Lab section present');
  assert(await page.locator('nav.fixed').count() === 0, 'App dock hidden on site');
  await layout('Site desktop 1440');
  await page.screenshot({ path: '/home/user/sandbox/shots/final-site.png' });

  // language
  await page.getByRole('button', { name: 'EN', exact: true }).click();
  assert((await page.locator('h1').innerText()).includes('You sleep'), 'English site translation');
  assert(await page.locator('html').getAttribute('dir') === 'ltr', 'English switches to LTR');

  // four looks
  await page.getByRole('button', { name: 'Appearance', exact: true }).click();
  for (const [name, key] of [['Obsidian Gold', 'obsidian'], ['Editorial Paper', 'paper'], ['Cosmic Cobalt', 'cosmic'], ['Midnight Signal', 'midnight']]) {
    await page.getByRole('button', { name: new RegExp(name) }).click();
    assert(await page.locator('html').getAttribute('data-theme') === key, `Theme ${name} applies`);
  }
  await page.getByRole('button', { name: "Looks good. Let's go." }).click();

  // strategy lab is interactive
  await page.getByRole('button', { name: 'AI-first' }).click();
  const slider = page.locator('#lab input[type="range"]').first();
  await slider.fill('90');
  assert((await slider.inputValue()) === '90', 'Lab weight slider moves');
  assert((await page.locator('#lab').innerText()).includes('90%'), 'Lab score reacts to weights');

  // ---------- launch app ----------
  await page.getByRole('button', { name: 'Launch App', exact: true }).click();
  await page.waitForTimeout(900);
  assert(await page.locator('aside').isVisible(), 'App workspace opens with sidebar');
  assert(!(await page.locator('body').innerText()).includes('You sleep.'), 'Landing replaced by workspace');
  await layout('App desktop 1440');
  await page.screenshot({ path: '/home/user/sandbox/shots/final-app.png' });

  // command palette + quick trade
  await page.keyboard.press('Control+k');
  await page.getByPlaceholder('Search views, coins, actions…').fill('SOL');
  await page.locator('[role="dialog"]').getByRole('button', { name: /SOL/ }).first().click();
  assert(await page.getByRole('dialog').getByText('SOL/USDT', { exact: true }).isVisible(), 'Command palette opens quick trade');
  await page.getByRole('button', { name: /Confirm · SOL/ }).click();
  await page.locator('aside').getByRole('button', { name: 'Portfolio', exact: true }).click();
  assert(await page.locator('main').getByText('SOL', { exact: true }).count() > 0, 'New position appears in portfolio');
  await page.locator('main').getByRole('button', { name: 'Close', exact: true }).first().click();
  assert(await page.locator('main').getByText('SOL', { exact: true }).count() === 0, 'Position closes correctly');

  // copy trading
  await page.locator('aside').getByRole('button', { name: 'Copy Trade', exact: true }).click();
  const orion = page.locator('main .panel-hover').filter({ hasText: '@orion_swings' });
  await orion.getByRole('button', { name: /Follow · @orion_swings/ }).click();
  await orion.getByRole('button', { name: 'Following', exact: true }).waitFor({ state: 'visible' });
  assert(true, 'Follow mirrors an elite trader');
  await orion.getByRole('button', { name: 'Following', exact: true }).click();

  // terminal
  await page.locator('aside').getByRole('button', { name: 'Terminal', exact: true }).click();
  await page.locator('main select').selectOption('strategy');
  await page.locator('main').getByRole('button', { name: 'SHORT', exact: true }).click();
  await page.locator('main input[type="range"]').fill('20');
  await page.locator('main').getByRole('button', { name: 'Open Position · BTC', exact: true }).click();
  assert(await page.locator('main').getByText('SHORT 20×', { exact: true }).isVisible(), 'Terminal executes leveraged short');

  // weekly PNG
  await page.locator('aside').getByRole('button', { name: 'Weekly Card', exact: true }).click();
  await page.locator('main input').first().fill('Kiya');
  const dl = page.waitForEvent('download');
  await page.getByRole('button', { name: 'Download PNG', exact: true }).click();
  assert((await dl).suggestedFilename() === 'dollarino-weekly-Kiya.png', 'Weekly card exports real PNG');

  // pricing + faq
  await page.locator('aside').getByRole('button', { name: 'Pricing', exact: true }).click();
  await page.getByRole('button', { name: /Yearly/ }).click();
  assert((await page.locator('main').innerText()).includes('$15'), 'Yearly pricing updates');
  await page.locator('aside').getByRole('button', { name: 'FAQ', exact: true }).click();
  await page.getByRole('button', { name: 'Is this connected to my real money?' }).click();
  assert(await page.getByText(/No real orders are sent/).isVisible(), 'FAQ accordion reveals simulation notice');

  // back to site
  await page.getByRole('button', { name: 'Site', exact: true }).click();
  await page.waitForTimeout(600);
  assert((await page.locator('h1').innerText()).includes('You sleep'), 'Site mode returns from workspace');

  // ---------- responsive, all views, RTL ----------
  for (const w of [390, 320]) {
    await page.setViewportSize({ width: w, height: 844 });
    await page.goto(base, { waitUntil: 'networkidle' });
    await page.waitForTimeout(1200);
    await layout(`Site mobile ${w}`);
    assert(await page.locator('nav.fixed').count() === 0, `No app dock on site at ${w}px`);
    for (const v of ['overview', 'terminal', 'markets', 'radar', 'copy', 'portfolio', 'card', 'pricing', 'faq']) {
      await page.goto(`${base}/#${v}`, { waitUntil: 'networkidle' });
      await page.waitForTimeout(1000);
      await layout(`App ${w}px ${v}`);
    }
  }
  await page.setViewportSize({ width: 1024, height: 768 });
  await page.goto(base, { waitUntil: 'networkidle' });
  await page.waitForTimeout(1000);
  await layout('Tablet 1024 site');

  // Persian RTL across all four looks
  await page.setViewportSize({ width: 390, height: 844 });
  await page.getByRole('button', { name: 'فارسی', exact: true }).click();
  assert(await page.locator('html').getAttribute('dir') === 'rtl', 'Persian RTL active');
  for (const key of ['paper', 'obsidian', 'cosmic', 'midnight']) {
    await page.evaluate((k) => localStorage.setItem('dollarino-theme', JSON.stringify(k)), key);
    await page.reload({ waitUntil: 'networkidle' });
    await page.waitForTimeout(900);
    assert(await page.locator('html').getAttribute('data-theme') === key, `RTL layout with ${key}`);
    await layout(`RTL ${key} mobile`);
  }

  assert(errors.length === 0, `No browser errors (${errors.join('; ')})`);
  console.log('ALL SMOKE TESTS PASSED');
} finally {
  console.log('BROWSER ERRORS:', JSON.stringify(errors));
  await browser.close();
}
