import { useEffect, useMemo, useState } from "react";
import {
  ArrowLeft, Bot, ChevronDown, Layers3, Menu, Moon, Radio, ShieldCheck,
  Sparkles, Sun, Target, Wallet, X, Zap,
} from "lucide-react";
import Lab, { LAB_PRESETS, type LabPreset } from "./components/Lab";
import Desk, { WalletCard } from "./components/Desk";
import Radar from "./components/Radar";
import CopyBoard from "./components/CopyBoard";
import Weekly from "./components/Weekly";
import { Spark } from "./components/Viz";
import {
  ENGINE_META, INITIAL_COINS, INITIAL_POSITIONS, TRADERS, changeOf, fmtPrice,
  makeSignal, positionPnl, seedSignals, tickCoin, type Coin, type Engine, type Position, type Side, type Signal,
} from "./lib/market";

type Tab = "desk" | "lab" | "radar" | "copy" | "card";

const TABS: { id: Tab; label: string }[] = [
  { id: "desk", label: "میز کار" },
  { id: "lab", label: "آزمایشگاه" },
  { id: "radar", label: "رادار" },
  { id: "copy", label: "کپی ترید" },
  { id: "card", label: "کارت هفته" },
];

const FAQS: [string, string][] = [
  ["مدل ترکیبی یعنی چه؟", "به جای انتخاب فقط یک موتور، دُرّبین، دُرنا و کپی ترید همزمان روشن می‌شوند. آزمایشگاه از روی همین ترکیب امتیاز، نرخ برد و بازده تخمینی می‌سازد و میز کار همان منطق را اجرا می‌کند."],
  ["برای شروع کلید API لازم است؟", "نه. حساب Paper Demo رایگان است و قیمت زنده می‌گیرد. اگر به Toobit یا KCEX وصل شوید، کلید با AES-256 رمز می‌شود و داخل Git نمی‌رود."],
  ["چند ارز و چند معامله؟", "حالت ALL_MARKET بیش از ۳۰ ارز پرنقدینگی را می‌بیند و تا ۲۰ معامله همزمان را با چرخش خودکار روند و اهرم ۱ تا ۵۰ برابر مدیریت می‌کند."],
  ["رادار واقعاً زنده است؟", "در این نسخه، قیمت‌ها، سیگنال‌ها و بستن هدف یا حد ضرر شبیه‌سازی زنده هستند تا حس محصول را قبل از اتصال صرافی ببینید."],
  ["ربات تلگرام چه می‌کند؟", "۲۴ ساعته وضعیت معامله، سیگنال کانال @Dollarinoofficial و نتیجه هفته را می‌فرستد. لازم نیست میز را مدام باز نگه دارید."],
];

function Logo() {
  return (
    <a href="#top" className="flex items-center gap-2.5">
      <img src="/logo.png" alt="دلارینو" className="h-10 w-10 rounded-xl object-cover" />
      <span className="leading-none">
        <span dir="ltr" className="latin block text-[16px] font-bold tracking-tight">dollarino<span style={{ color: "var(--cobalt)" }}>.</span></span>
        <span className="latin text-[9px] font-semibold muted">OS · v6</span>
      </span>
    </a>
  );
}

export default function App() {
  const [theme, setTheme] = useState<"light" | "dark">("light");
  const [menu, setMenu] = useState(false);
  const [tab, setTab] = useState<Tab>("desk");
  const [focus, setFocus] = useState(false);
  const [coins, setCoins] = useState<Coin[]>(INITIAL_COINS);
  const [signals, setSignals] = useState<Signal[]>(() => seedSignals(INITIAL_COINS));
  const [positions, setPositions] = useState<Position[]>(INITIAL_POSITIONS);
  const [cash, setCash] = useState(8000);
  const [hist, setHist] = useState<number[]>(() => Array.from({ length: 28 }, (_, i) => 9600 + i * 18 + Math.sin(i) * 40));
  const [hidden, setHidden] = useState(false);
  const [pro, setPro] = useState(false);
  const [followed, setFollowed] = useState<string[]>(["aurum"]);
  const [filter, setFilter] = useState<Engine | "all">("all");
  const [now, setNow] = useState(Date.now());
  const [faq, setFaq] = useState<number | null>(0);
  const [toast, setToast] = useState("");
  const [seed, setSeed] = useState<LabPreset>(LAB_PRESETS.blend);
  const [nonce, setNonce] = useState(0);
  const [nextId, setNextId] = useState(20);

  useEffect(() => { document.documentElement.dataset.theme = theme; }, [theme]);

  useEffect(() => {
    const id = window.setInterval(() => {
      setNow(Date.now());
      setCoins((prev) => prev.map(tickCoin));
    }, 1800);
    return () => window.clearInterval(id);
  }, []);

  const coinsRef = useMemo(() => ({ current: coins }), []);
  coinsRef.current = coins;

  useEffect(() => {
    const id = window.setInterval(() => {
      setSignals((prev) => {
        const t = Date.now();
        let next = prev.map((s) => {
          if (s.status !== "active" || t < s.resolveAt) return s;
          const win = Math.random() < s.conf / 125;
          return { ...s, status: win ? "tp" as const : "sl" as const, pnl: win ? +(0.7 + Math.random() * 2.6).toFixed(2) : +(-(0.4 + Math.random() * 1.2)).toFixed(2) };
        });
        if (next.filter((s) => s.status === "active").length < 4) next = [makeSignal(coinsRef.current), ...next];
        return next.slice(0, 16);
      });
    }, 4000);
    return () => window.clearInterval(id);
  }, [coinsRef]);

  const unrealized = useMemo(() => positions.reduce((s, p) => {
    const price = coins.find((c) => c.sym === p.sym)?.price ?? p.entry;
    return s + positionPnl(p, price);
  }, 0), [positions, coins]);
  const locked = positions.reduce((s, p) => s + p.margin, 0);
  const equity = cash + locked + unrealized;

  useEffect(() => {
    setHist((h) => [...h.slice(-36), equity]);
  }, [Math.round(equity)]);

  useEffect(() => {
    if (!toast) return;
    const t = window.setTimeout(() => setToast(""), 2600);
    return () => window.clearTimeout(t);
  }, [toast]);

  const closed = signals.filter((s) => s.status !== "active");
  const winRate = closed.length ? Math.round((closed.filter((s) => s.status === "tp").length / closed.length) * 100) : 86;
  const weekPct = 8.6 + (unrealized / 10000) * 100;

  const openTrade = (p: { sym: string; side: Side; lev: number; margin: number }) => {
    if (p.margin > cash) { setToast("نقد آزاد کافی نیست"); return; }
    if (positions.length >= 20) { setToast("سقف ۲۰ معامله همزمان پر است"); return; }
    const coin = coins.find((c) => c.sym === p.sym);
    if (!coin) return;
    setCash((c) => c - p.margin);
    setPositions((prev) => [...prev, { id: nextId, sym: p.sym, side: p.side, entry: coin.price, margin: p.margin, lev: p.lev, dec: coin.dec }]);
    setNextId((n) => n + 1);
    setToast(`${p.sym} ${p.side === "long" ? "خرید" : "فروش"} باز شد`);
  };

  const closeTrade = (id: number) => {
    const p = positions.find((x) => x.id === id);
    if (!p) return;
    const price = coins.find((c) => c.sym === p.sym)?.price ?? p.entry;
    const pnl = positionPnl(p, price);
    setCash((c) => c + p.margin + pnl);
    setPositions((prev) => prev.filter((x) => x.id !== id));
    setToast(`${p.sym} بسته شد · ${pnl >= 0 ? "+" : ""}${pnl.toFixed(1)}$`);
  };

  const go = (next: Tab, enter = true) => {
    setTab(next);
    if (enter) setFocus(true);
    setMenu(false);
    window.setTimeout(() => document.getElementById("instrument")?.scrollIntoView({ behavior: "smooth", block: "start" }), 30);
  };

  const applyPreset = (key: keyof typeof LAB_PRESETS) => {
    setSeed(LAB_PRESETS[key]);
    setNonce((n) => n + 1);
    go("lab");
  };

  return (
    <div id="top" dir="rtl" className="min-h-screen">
      <div className="grain" />
      <header className="sticky top-0 z-40 border-b hair" style={{ background: "color-mix(in srgb, var(--paper) 88%, transparent)", backdropFilter: "blur(16px)" }}>
        <div className="wrap flex h-[72px] items-center justify-between gap-3">
          <Logo />
          <nav className="hidden items-center gap-1 lg:flex">
            <a href="#engines" className="rounded-lg px-3 py-2 text-[12px] font-bold muted">موتورها</a>
            {TABS.map((t) => (
              <button key={t.id} onClick={() => go(t.id, false)} className="rounded-lg px-3 py-2 text-[12px] font-bold muted hover:text-[var(--ink)]">{t.label}</button>
            ))}
          </nav>
          <div className="flex items-center gap-2">
            <button onClick={() => setTheme(theme === "light" ? "dark" : "light")} className="grid h-10 w-10 place-items-center rounded-xl border hair" aria-label="تم">{theme === "light" ? <Moon size={16} /> : <Sun size={16} />}</button>
            <button onClick={() => go("desk")} className="btn btn-cobalt !hidden !px-4 !py-2.5 !text-[12px] sm:!inline-flex">ورود به میز <ArrowLeft size={14} /></button>
            <button onClick={() => setMenu(!menu)} className="grid h-10 w-10 place-items-center rounded-xl border hair lg:hidden" aria-label="منو">{menu ? <X size={16} /> : <Menu size={16} />}</button>
          </div>
        </div>
        {menu && (
          <div className="wrap pb-4 lg:hidden">
            <div className="card p-2">
              {TABS.map((t) => <button key={t.id} onClick={() => go(t.id)} className="block w-full rounded-xl px-3 py-3 text-right text-[13px] font-bold">{t.label}</button>)}
            </div>
          </div>
        )}
      </header>

      {!focus && (
        <section className="wrap relative grid items-center gap-10 pb-14 pt-12 lg:grid-cols-[1.05fr_.95fr] lg:pt-16">
          <div className="pointer-events-none absolute -top-10 right-0 h-72 w-72 rounded-full opacity-70 blur-3xl" style={{ background: "color-mix(in srgb, var(--cobalt) 28%, transparent)" }} />
          <div className="pointer-events-none absolute bottom-0 left-10 h-56 w-56 rounded-full opacity-60 blur-3xl" style={{ background: "color-mix(in srgb, var(--gold) 30%, transparent)" }} />
          <div className="dots pointer-events-none absolute inset-0 opacity-50" style={{ maskImage: "radial-gradient(circle at 70% 30%, #000, transparent 70%)" }} />
          <div className="relative reveal">
            <div className="mb-5 flex flex-wrap gap-2">
              <span className="tag"><img src="/logo.png" alt="" className="h-4 w-4 rounded" /> نسخه ۶٫۰</span>
              <span className="tag">Paper · Toobit · KCEX</span>
              <span className="tag">PWA</span>
            </div>
            <h1 className="h1">سه موتور.<br />یک میز. <span className="mark">صفر حدس.</span></h1>
            <p className="muted mt-5 max-w-xl text-[15px] leading-8">
              ادیتوریال آرام بیرون، دستگاه شیشه‌ای درون. هوش مصنوعی دُرّبین، استراتژی دُرنا و کپی ترید را ترکیب کن، رادار را زنده ببین، و نتیجه هفته را با لوگوی خود دلارینو بیرون ببر.
            </p>
            <div className="mt-7 flex flex-wrap gap-3">
              <button onClick={() => go("desk")} className="btn btn-cobalt">باز کردن میز <ArrowLeft size={16} /></button>
              <button onClick={() => applyPreset("full")} className="btn btn-lime">ساخت مدل ترکیبی</button>
            </div>
            <div className="mt-8 grid max-w-lg grid-cols-3 gap-4 border-t hair pt-5">
              {[["30+", "ارز زنده"], ["20", "معامله همزمان"], ["1–50x", "اهرم"]].map(([v, l]) => (
                <div key={l}><div dir="ltr" className="latin text-[26px] font-bold">{v}</div><div className="mt-1 text-[10px] muted">{l}</div></div>
              ))}
            </div>
          </div>

          <div className="relative reveal d2">
            <div className="night floaty rounded-[28px] p-4 shadow-[0_30px_80px_-30px_rgba(18,20,26,.55)] md:p-5">
              <div className="mb-3 flex items-center justify-between px-1">
                <span className="latin text-[10px] tracking-[.16em] text-[#e4b84a]">LIVE DESK</span>
                <span className="inline-flex items-center gap-1 text-[10px] text-[#3ddc97]"><i className="pulse h-1.5 w-1.5 rounded-full bg-[#3ddc97]" />زنده</span>
              </div>
              <WalletCard equity={equity} pnl={weekPct} hidden={hidden} onToggle={() => setHidden(!hidden)} compact />
              <div className="mt-3 space-y-1.5">
                {coins.slice(0, 4).map((c) => {
                  const ch = changeOf(c);
                  return (
                    <div key={c.sym} className="flex items-center gap-3 rounded-xl bg-white/[.04] px-3 py-2">
                      <span className="latin text-[11px] font-bold" style={{ color: c.color }}>{c.sym}</span>
                      <Spark data={c.spark} color={ch >= 0 ? "#3ddc97" : "#ff8b92"} width={64} />
                      <span dir="ltr" className="latin mr-auto text-[11px]">${fmtPrice(c.price, c.dec)}</span>
                      <span dir="ltr" className="latin text-[10px] font-bold" style={{ color: ch >= 0 ? "#3ddc97" : "#ff8b92" }}>{ch >= 0 ? "+" : ""}{ch.toFixed(2)}%</span>
                    </div>
                  );
                })}
              </div>
            </div>
            <div className="absolute -bottom-3 right-4 rounded-2xl border border-black/10 bg-[#dff25a] px-3 py-2 text-[11px] font-extrabold text-[#14160f] shadow-lg">سیگنال فعال: {signals.filter((s) => s.status === "active").length}</div>
          </div>
        </section>
      )}

      <div className="overflow-hidden border-y hair bg-[#10131a] py-3 text-white">
        <div className="marquee" dir="ltr">
          {[0, 1].map((k) => (
            <div key={k} className="flex shrink-0 items-center gap-8 px-4">
              {coins.map((c) => {
                const ch = changeOf(c);
                return (
                  <span key={`${k}-${c.sym}`} className="latin inline-flex items-center gap-2 text-[11px] text-white/75">
                    <b className="text-white">{c.sym}</b>
                    <span className="text-white/40">{fmtPrice(c.price, c.dec)}</span>
                    <span style={{ color: ch >= 0 ? "#dff25a" : "#ff8b92" }}>{ch >= 0 ? "+" : ""}{ch.toFixed(2)}%</span>
                    <Spark data={c.spark} color={ch >= 0 ? "#dff25a" : "#ff8b92"} width={48} height={22} />
                  </span>
                );
              })}
            </div>
          ))}
        </div>
      </div>

      <section id="instrument" className="wrap scroll-mt-24 py-10 md:py-14">
        <div className="mb-4 flex flex-wrap items-end justify-between gap-3">
          <div>
            <div className="eyebrow">THE INSTRUMENT</div>
            <h2 className="mt-2 text-[28px] font-black">{focus ? "میز دلارینو" : "همین‌جا امتحانش کن."}</h2>
          </div>
          {focus && <button onClick={() => setFocus(false)} className="btn btn-ghost !py-2 !text-[12px]">بازگشت به معرفی</button>}
        </div>
        <div className={`night overflow-hidden rounded-[28px] ${focus ? "min-h-[78vh]" : ""}`}>
          <div className="flex gap-1 overflow-x-auto border-b border-white/10 px-3 py-3 md:px-5">
            {TABS.map((t) => (
              <button key={t.id} onClick={() => setTab(t.id)} className={`tab ${tab === t.id ? "on" : ""}`}>{t.label}</button>
            ))}
          </div>
          <div className="p-4 pb-8 md:p-6" key={tab}>
            {tab === "desk" && (
              <Desk coins={coins} positions={positions} equity={equity} unrealized={unrealized} hist={hist} cash={cash} hidden={hidden} pro={pro} onToggleHidden={() => setHidden(!hidden)} onTogglePro={() => setPro(!pro)} onOpen={openTrade} onClose={closeTrade} />
            )}
            {tab === "lab" && <Lab seed={seed} nonce={nonce} />}
            {tab === "radar" && <Radar signals={signals} now={now} filter={filter} onFilter={setFilter} />}
            {tab === "copy" && (
              <CopyBoard traders={TRADERS} followed={followed} onToggle={(id) => {
                setFollowed((f) => f.includes(id) ? f.filter((x) => x !== id) : [...f, id]);
                const tr = TRADERS.find((t) => t.id === id);
                setToast(followed.includes(id) ? "دنبال‌کردن قطع شد" : `${tr?.name} به آینه اضافه شد`);
              }} />
            )}
            {tab === "card" && <Weekly pct={weekPct} profit={unrealized} win={winRate} trades={`${positions.length}/20`} />}
          </div>
        </div>
      </section>

      {!focus && (
        <>
          <section id="engines" className="wrap grid gap-4 py-6 md:grid-cols-3">
            {[
              { k: "full" as const, icon: Sparkles, t: "دُرّبین", d: "ترکیب DeepSeek، Claude، GPT و Gemini. کلید API با خودتان نیست؛ مدل را پلتفرم اداره می‌کند.", c: "#e4b84a" },
              { k: "calm" as const, icon: Target, t: "دُرنا V1", d: "روند، مومنتوم، شکار نقدینگی و ریبون غیرریپینت. در دمو برای همه رایگان است.", c: "#0f9f6e" },
              { k: "mirror" as const, icon: Radio, t: "کپی ترید", d: "کانال @Dollarinoofficial، کانال اختصاصی، یا وب‌هوک TradingView. اجرا همان لحظه.", c: "#2f4bff" },
            ].map((e) => {
              const Icon = e.icon;
              return (
                <button key={e.t} onClick={() => applyPreset(e.k)} className="card p-6 text-right transition hover:-translate-y-1">
                  <div className="mb-5 flex items-center justify-between">
                    <span className="grid h-11 w-11 place-items-center rounded-2xl" style={{ background: `${e.c}22`, color: e.c }}><Icon size={20} /></span>
                    <span className="latin text-[10px] font-bold muted">{ENGINE_META[e.k === "full" ? "ai" : e.k === "calm" ? "strategy" : "copy"].en}</span>
                  </div>
                  <h3 className="text-[20px] font-black">{e.t}</h3>
                  <p className="muted mt-2 text-[12px] leading-7">{e.d}</p>
                  <div className="mt-4 text-[11px] font-extrabold" style={{ color: "var(--cobalt)" }}>بردن به آزمایشگاه ←</div>
                </button>
              );
            })}
          </section>

          <section className="wrap py-12">
            <div className="card overflow-hidden md:grid md:grid-cols-[.9fr_1.1fr]">
              <div className="bg-[#10131a] p-7 text-white md:p-10">
                <div className="latin text-[10px] tracking-[.18em] text-[#e4b84a]">HOW IT SITS TOGETHER</div>
                <h2 className="mt-3 text-[30px] font-black leading-snug">کاغذ بیرون.<br />ابسیدین درون.</h2>
                <p className="mt-4 text-[12px] leading-7 text-white/60">صفحه معرفی از نمونه‌های ادیتوریال آمده؛ میز، رادار و کپی از سیستم معاملاتی شبانه؛ کارت کبالت و حالت حرفه‌ای از خود محصول. آزمایشگاه جایی است که این‌ها یکی می‌شوند.</p>
              </div>
              <div className="grid sm:grid-cols-2">
                {[
                  ["۰۱", "دمو را باز کن", "بدون کارت و بدون کلید. قیمت، قیمت بازار است."],
                  ["۰۲", "مدل را بچین", "یک موتور یا هر سه. ریسک و اهرم مال توست."],
                  ["۰۳", "رادار را نگاه کن", "سیگنال می‌آید، هدف یا حد ضرر را عمومی ثبت می‌کند."],
                  ["۰۴", "هفته را سهم کن", "PNG شیشه‌ای با لوگوی دلارینو، از اعداد همین میز."],
                ].map(([n, t, d]) => (
                  <div key={n} className="border-b hair p-6 sm:odd:border-l">
                    <div className="latin text-[12px] font-bold" style={{ color: "var(--cobalt)" }}>{n}</div>
                    <div className="mt-2 text-[15px] font-extrabold">{t}</div>
                    <p className="muted mt-1 text-[11px] leading-6">{d}</p>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section className="wrap py-8">
            <div className="mb-8 flex flex-wrap items-end justify-between gap-4">
              <h2 className="h2">تعرفه، بعد از اینکه ماشین خودش را ثابت کرد.</h2>
              <p className="max-w-sm text-[12px] leading-7 muted">شروع روی کاغذ رایگان است. طلایی و مشکی وقتی معنی دارند که دمو را دوست داشته باشی.</p>
            </div>
            <div className="grid gap-4 md:grid-cols-3">
              {[
                { name: "کاغذ", price: "۰", note: "یادگیری با قیمت زنده", feats: ["حساب دمو", "دُرنا V1", "کارت هفتگی", "رادار عمومی"], hot: false },
                { name: "طلایی", price: "۱۹$", note: "برای ترید جدی", feats: ["۳۰+ ارز", "۲۰ معامله همزمان", "هر سه موتور", "اهرم تا ۵۰ برابر"], hot: true },
                { name: "مشکی", price: "۴۹$", note: "برای میزهای حرفه‌ای", feats: ["همه امکانات طلایی", "اجماع چندمدلی", "وب‌هوک اختصاصی", "API"], hot: false },
              ].map((p) => (
                <article key={p.name} className="card relative p-6" style={p.hot ? { outline: "2px solid var(--cobalt)" } : undefined}>
                  {p.hot && <span className="absolute left-4 top-4 rounded-full bg-[#dff25a] px-2 py-1 text-[9px] font-extrabold text-[#14160f]">پرطرفدار</span>}
                  <div className="text-[13px] font-extrabold">{p.name}</div>
                  <div className="latin mt-3 text-[36px] font-bold">{p.price}</div>
                  <div className="muted text-[11px]">{p.note}</div>
                  <ul className="mt-5 space-y-2 text-[12px]">{p.feats.map((f) => <li key={f} className="flex items-center gap-2"><i className="h-1.5 w-1.5 rounded-full" style={{ background: "var(--cobalt)" }} />{f}</li>)}</ul>
                  <button onClick={() => go("desk")} className={`btn mt-6 w-full ${p.hot ? "btn-cobalt" : "btn-ghost"}`}>شروع با دمو</button>
                </article>
              ))}
            </div>
          </section>

          <section className="wrap grid gap-8 py-12 md:grid-cols-[.8fr_1.2fr]">
            <div>
              <div className="eyebrow">FAQ</div>
              <h2 className="h2 mt-3">شفاف، مثل خود میز.</h2>
              <p className="muted mt-3 text-[13px] leading-7">اگر این‌جا نبود، ربات تلگرام ۲۴ ساعته جواب می‌دهد.</p>
              <div className="mt-5 flex flex-wrap gap-2">
                {["AES-256", "JWT", "Workers", "D1"].map((x) => <span key={x} className="tag latin"><ShieldCheck size={12} />{x}</span>)}
              </div>
            </div>
            <div>
              {FAQS.map(([q, a], i) => (
                <div key={q} className="border-t hair last:border-b">
                  <button onClick={() => setFaq(faq === i ? null : i)} className="flex w-full items-center justify-between gap-4 py-4 text-right">
                    <span className="text-[13px] font-extrabold">{q}</span>
                    <ChevronDown size={16} className={`shrink-0 transition ${faq === i ? "rotate-180" : ""}`} />
                  </button>
                  {faq === i && <p className="muted pb-4 text-[12px] leading-7">{a}</p>}
                </div>
              ))}
            </div>
          </section>

          <section className="wrap pb-16">
            <div className="relative overflow-hidden rounded-[28px] bg-[#2f4bff] px-6 py-14 text-center text-white md:px-12">
              <div className="pointer-events-none absolute -left-16 -top-16 h-56 w-56 rounded-full border-[28px] border-white/10" />
              <div className="pointer-events-none absolute -bottom-20 right-8 h-64 w-64 rounded-full border-[28px] border-[#dff25a]/30" />
              <div className="relative">
                <div className="mx-auto mb-4 inline-flex items-center gap-2 rounded-full bg-[#dff25a] px-3 py-1 text-[11px] font-extrabold text-[#14160f]"><Zap size={13} /> همین حالا</div>
                <h2 className="text-[34px] font-black leading-snug md:text-[48px]">بازار منتظر نمی‌ماند.<br />میز تو چراغ است.</h2>
                <div className="mt-7 flex flex-wrap justify-center gap-3">
                  <button onClick={() => go("desk")} className="btn btn-lime">ورود رایگان به میز</button>
                  <button onClick={() => applyPreset("blend")} className="btn !border-white/40 !text-white">مدل متعادل</button>
                </div>
              </div>
            </div>
          </section>

          <footer className="wrap pb-28 md:pb-10">
            <div className="grid gap-8 border-t hair pt-8 md:grid-cols-4">
              <div className="md:col-span-1">
                <Logo />
                <p className="muted mt-3 max-w-[240px] text-[11px] leading-6">ترکیب معرفی ادیتوریال، میز شبانه و آزمایشگاه مدل. یک دلارینو، نه سه نمونه جدا.</p>
              </div>
              {[
                ["میز", ["میز کار", "رادار", "کپی ترید", "کارت هفته"]],
                ["موتورها", ["دُرّبین", "دُرنا V1", "کپی ترید", "ALL_MARKET"]],
                ["صرافی", ["Paper Demo", "Toobit Futures", "KCEX Futures", "@Dollarinoofficial"]],
              ].map(([t, items]) => (
                <div key={t as string}>
                  <div className="mb-3 text-[12px] font-extrabold">{t as string}</div>
                  <div className="space-y-2">{(items as string[]).map((x) => <button key={x} onClick={() => go("desk", false)} className="block text-[11px] muted">{x}</button>)}</div>
                </div>
              ))}
            </div>
            <div className="latin mt-10 select-none text-center font-bold leading-none tracking-[-.06em] text-transparent" style={{ WebkitTextStroke: "1px var(--line)", fontSize: "clamp(2.4rem, 10vw, 8rem)" }}>DOLLARINO</div>
            <div className="mt-4 flex flex-wrap justify-between gap-2 border-t hair pt-4 text-[10px] muted">
              <span>© ۲۰۲۵ دلارینو</span>
              <span className="inline-flex items-center gap-3"><Bot size={12} /> تلگرام ۲۴/۷ <Layers3 size={12} /> Workers + D1</span>
            </div>
          </footer>
        </>
      )}

      <div className="fixed bottom-4 left-1/2 z-50 flex -translate-x-1/2 gap-1 rounded-2xl border border-white/10 bg-[#10131a]/95 px-2 py-2 shadow-2xl backdrop-blur md:hidden">
        {[
          { id: "desk" as Tab, icon: Wallet, t: "میز" },
          { id: "lab" as Tab, icon: Sparkles, t: "آزمایش" },
          { id: "radar" as Tab, icon: Radio, t: "رادار" },
          { id: "copy" as Tab, icon: Target, t: "کپی" },
          { id: "card" as Tab, icon: Layers3, t: "کارت" },
        ].map(({ id, icon: Icon, t }) => (
          <button key={id} onClick={() => go(id, false)} className="flex w-14 flex-col items-center gap-1 rounded-xl py-1.5 text-[9px]" style={{ color: tab === id ? "#dff25a" : "rgba(255,255,255,.55)", background: tab === id ? "rgba(223,242,90,.1)" : "transparent" }}>
            <Icon size={15} />{t}
          </button>
        ))}
      </div>

      {toast && <div className="fixed bottom-24 left-1/2 z-[70] -translate-x-1/2 rounded-xl bg-[#12141a] px-4 py-3 text-[12px] font-bold text-[#f6f3ea] shadow-xl md:bottom-8">{toast}</div>}
    </div>
  );
}
