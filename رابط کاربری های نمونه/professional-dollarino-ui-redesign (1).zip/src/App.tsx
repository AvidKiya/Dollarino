import { useEffect, useState } from 'react';
import {
  ArrowLeft, ArrowUpRight, Bot, BrainCircuit, Check, ChevronDown, Download, Gauge,
  Globe2, Layers3, LockKeyhole, Menu, MessageSquare, Moon, Radio, Repeat2,
  ShieldCheck, Sparkles, Sun, Target, TrendingUp, Wallet, X, Zap,
} from 'lucide-react';
import HybridLab from './components/HybridLab';
import { BarColumns, Spark } from './components/Viz';

const nav = [
  { label: 'مدل ترکیبی', href: '#lab' },
  { label: 'قابلیت‌ها', href: '#features' },
  { label: 'روند کار', href: '#how' },
  { label: 'عملکرد', href: '#numbers' },
  { label: 'سوالات', href: '#faq' },
];

const engineStack = [
  { code: 'AI / DORRBIN', name: 'هوش مصنوعی', icon: Sparkles, color: '#d9f75c', pos: 'top-0 right-2 md:right-8 w-[78%]' },
  { code: 'DRN / V1', name: 'استراتژی منتخب', icon: Target, color: '#7e95ff', pos: 'top-[33%] left-0 md:left-2 w-[78%]' },
  { code: 'CPY / SIGNAL', name: 'کپی ترید', icon: Radio, color: '#ff9c7a', pos: 'bottom-0 right-2 md:right-8 w-[78%]' },
];

const faqs: [string, string][] = [
  ['«مدل ترکیبی» دقیقاً یعنی چه؟', 'یعنی به جای انتخاب فقط یک موتور، می‌توانید هوش مصنوعی دُرّبین، استراتژی دُرنا V1 و کپی ترید را همزمان فعال کنید. دلارینو خروجی آن‌ها را با هم تلفیق کرده و یک مدل واحد با امتیاز، نرخ موفقیت و کنترل ریسک مشخص میسازد.'],
  ['برای شروع به کلید API یا واریز نیاز دارم؟', 'خیر. حساب Paper Demo رایگان است و با قیمت زنده بازار کار می‌کند. برای اتصال صرافی، کلیدها بهصورت رمزگذاریشده AES-256 ذخیره می‌شوند.'],
  ['چه صرافیهایی پشتیبانی می‌شوند؟', 'Paper Demo، Toobit Futures و KCEX Futures. بستر اصلی پلتفرم Cloudflare Workers به همراه D1 و Durable Objects است.'],
  ['محدودیت تعداد ارز و معاملات چقدر است؟', 'موتور آزاد ALL_MARKET بیش از ۳۰ ارز پرنقدینگی را رصد می‌کند، تا ۲۰ معامله همزمان را مدیریت می‌کند و اهرم ۱x تا ۵۰x در اختیار شماست.'],
  ['ربات تلگرام چه کاری انجام میدهد؟', 'بهصورت ۲۴/۷ وضعیت معاملات، سیگنالهای جدید و نتایج هفتگی را به شما اطلاع میدهد؛ بدون اینکه نیاز باشد پنل را مدام چک کنید.'],
];

function Mark({ light = false }: { light?: boolean }) {
  return (
    <div className="w-9 h-9 rounded-[10px] flex items-center justify-center shrink-0 relative overflow-hidden" style={{ background: light ? '#d9f75c' : 'var(--ink)', border: '1.5px solid var(--edge)' }}>
      <span dir="ltr" className="latin text-[18px] font-bold leading-none" style={{ color: light ? '#111318' : 'var(--paper)' }}>$</span>
      <span className="absolute -bottom-3 -left-3 w-7 h-7 rounded-full border-2" style={{ borderColor: 'var(--cobalt)' }} />
    </div>
  );
}

function Logo() {
  return (
    <a href="#top" className="flex items-center gap-2.5 shrink-0">
      <Mark />
      <span dir="ltr" className="latin text-[17px] font-bold tracking-[-.055em]">dollarino<span className="cobalt">.</span><span className="latin text-[9px] font-medium muted tracking-normal mr-1.5">V6</span></span>
    </a>
  );
}

function SectionIntro({ index, label, title, desc, center = false }: { index: string; label: string; title: string; desc?: string; center?: boolean }) {
  return (
    <div className={`${center ? 'text-center mx-auto' : ''} max-w-2xl mb-10 md:mb-14 reveal`}>
      <div className={`flex items-center gap-3 mb-4 ${center ? 'justify-center' : ''}`}>
        <span dir="ltr" className="latin text-[10px] font-bold cobalt">/{index}</span>
        <span className="h-px w-8" style={{ background: 'var(--line)' }} />
        <span className="eyebrow">{label}</span>
      </div>
      <h2 className="h2">{title}</h2>
      {desc && <p className="body mt-4 max-w-xl">{desc}</p>}
    </div>
  );
}

function WeeklyDownload({ onDone }: { onDone: (msg: string) => void }) {
  const download = () => {
    const c = document.createElement('canvas'); c.width = 800; c.height = 1000;
    const x = c.getContext('2d'); if (!x) return;
    x.fillStyle = '#f3f2ec'; x.fillRect(0, 0, 800, 1000);
    x.fillStyle = '#e4e3db';
    for (let i = 0; i <= 800; i += 40) for (let j = 0; j <= 1000; j += 40) { x.beginPath(); x.arc(i, j, 1.2, 0, 7); x.fill(); }
    x.fillStyle = '#2d4bf4'; x.fillRect(0, 0, 800, 14);
    x.fillStyle = '#d9f75c'; x.fillRect(60, 90, 210, 210);
    x.fillStyle = '#111318'; x.font = '700 150px "Space Grotesk", sans-serif'; x.textAlign = 'center'; x.fillText('$', 165, 250);
    x.textAlign = 'right'; x.direction = 'rtl';
    x.fillStyle = '#70747d'; x.font = '600 22px Vazirmatn, sans-serif'; x.fillText('نتایج هفتگی · دلارینو v6.0', 740, 140);
    x.fillStyle = '#111318'; x.font = '900 68px Vazirmatn, sans-serif'; x.fillText('هفته خوبی بود.', 740, 235);
    x.fillStyle = '#111318'; x.font = '900 68px Vazirmatn, sans-serif'; x.fillText('اعداد هم میگویند.', 740, 320);
    x.fillStyle = '#2d4bf4'; x.textAlign = 'left'; x.direction = 'ltr'; x.font = '700 132px "Space Grotesk", sans-serif'; x.fillText('+12.8%', 60, 540);
    x.fillStyle = '#70747d'; x.direction = 'rtl'; x.textAlign = 'right'; x.font = '500 24px Vazirmatn, sans-serif'; x.fillText('بازده کیف پول در ۷ روز', 740, 520);
    x.strokeStyle = '#cfcec6'; x.lineWidth = 1;
    const rows: [string, string][] = [['سود خالص', '+$3,248'], ['معاملات موفق', '38 / 42'], ['نرخ موفقیت', '90.4%']];
    rows.forEach(([l, v], i) => {
      const y = 630 + i * 95;
      x.beginPath(); x.moveTo(60, y + 28); x.lineTo(740, y + 28); x.stroke();
      x.fillStyle = '#70747d'; x.font = '500 24px Vazirmatn, sans-serif'; x.textAlign = 'right'; x.direction = 'rtl'; x.fillText(l, 740, y + 5);
      x.fillStyle = '#111318'; x.font = '700 34px "Space Grotesk", sans-serif'; x.textAlign = 'left'; x.direction = 'ltr'; x.fillText(v, 60, y + 5);
    });
    x.beginPath(); x.moveTo(60, 920); x.lineTo(740, 920); x.stroke();
    x.fillStyle = '#111318'; x.font = '700 24px "Space Grotesk", sans-serif'; x.textAlign = 'left'; x.direction = 'ltr'; x.fillText('dollarino.', 60, 970);
    x.fillStyle = '#70747d'; x.font = '500 18px Vazirmatn, sans-serif'; x.textAlign = 'right'; x.direction = 'rtl'; x.fillText('ترید هوشمند، بدون پیچیدگی', 740, 970);
    const a = document.createElement('a'); a.download = 'dollarino-weekly.png'; a.href = c.toDataURL('image/png'); a.click();
    onDone('کارت هفتگی دانلود شد');
  };
  return (
    <div className="relative max-w-[340px] w-full mx-auto lg:mx-0">
      <div className="absolute -inset-5 rounded-[36px] -rotate-3" style={{ background: 'var(--lime)' }} />
      <div className="relative brut bg-[var(--panel)] aspect-[4/5] rounded-[18px] p-6 flex flex-col justify-between overflow-hidden dots">
        <div className="flex items-start justify-between relative z-10">
          <div className="w-[74px] h-[74px] rounded-xl flex items-center justify-center bg-lime" style={{ border: '1.5px solid var(--edge)' }}><span dir="ltr" className="latin text-[44px] font-bold">$</span></div>
          <span className="tag !bg-transparent">WEEK 43</span>
        </div>
        <div className="relative z-10">
          <div className="text-[10px] muted mb-2">نتایج هفتگی · دلارینو v6.0</div>
          <div className="text-[23px] font-black leading-[1.5]">هفته خوبی بود.<br />اعداد هم میگویند.</div>
          <div dir="ltr" className="latin text-[58px] font-bold cobalt leading-none mt-5">+12.8%</div>
          <div className="text-[10px] muted mt-2">بازده کیف پول در ۷ روز</div>
        </div>
        <div className="relative z-10 grid grid-cols-3 gap-2 pt-4 border-t line">
          {[['+$3,248', 'سود خالص'], ['38/42', 'موفق'], ['90.4%', 'دقت']].map(([v, l]) => (
            <div key={l}><div dir="ltr" className="latin text-[12px] font-bold">{v}</div><div className="text-[9px] muted mt-1">{l}</div></div>
          ))}
        </div>
      </div>
      <button onClick={download} className="btn btn-ink w-full mt-8"><Download size={16} /> دانلود کارت هفتگی PNG</button>
    </div>
  );
}

export default function App() {
  const [theme, setTheme] = useState<'light' | 'dark'>('light');
  const [menu, setMenu] = useState(false);
  const [faq, setFaq] = useState<number | null>(0);
  const [toast, setToast] = useState('');

  useEffect(() => { document.documentElement.dataset.theme = theme; }, [theme]);
  useEffect(() => {
    const obs = new IntersectionObserver((entries) => entries.forEach((e) => { if (e.isIntersecting) { e.target.classList.add('in'); obs.unobserve(e.target); } }), { threshold: .08 });
    document.querySelectorAll('.reveal').forEach((el) => obs.observe(el));
    return () => obs.disconnect();
  }, []);
  useEffect(() => { if (!toast) return; const t = window.setTimeout(() => setToast(''), 2800); return () => window.clearTimeout(t); }, [toast]);

  return (
    <div id="top" dir="rtl" className="min-h-screen relative overflow-hidden">
      {/* NAV */}
      <header className="sticky top-0 z-50" style={{ background: 'color-mix(in srgb, var(--paper) 88%, transparent)', backdropFilter: 'blur(18px)', borderBottom: '1px solid var(--line)' }}>
        <div className="wrap h-16 md:h-[74px] flex items-center justify-between gap-4">
          <Logo />
          <nav className="hidden lg:flex items-center gap-1">
            {nav.map((n) => <a key={n.href} href={n.href} className="text-[12px] font-semibold muted hover:text-[var(--ink)] transition px-3 py-2 rounded-lg">{n.label}</a>)}
          </nav>
          <div className="flex items-center gap-2">
            <button onClick={() => setTheme(theme === 'light' ? 'dark' : 'light')} className="w-9 h-9 rounded-lg flex items-center justify-center border line hover:border-[var(--ink)] transition" aria-label="تغییر تم">{theme === 'light' ? <Moon size={16} /> : <Sun size={16} />}</button>
            <a href="#lab" className="btn btn-ink !px-4 !py-2.5 !text-[11px] hidden sm:inline-flex">بسازش <ArrowLeft size={14} /></a>
            <button onClick={() => setMenu(!menu)} className="w-9 h-9 rounded-lg flex items-center justify-center border line lg:hidden" aria-label="منو">{menu ? <X size={17} /> : <Menu size={17} />}</button>
          </div>
        </div>
        {menu && (
          <div className="wrap lg:hidden pb-4">
            <div className="card p-3">{nav.map((n) => <a key={n.href} href={n.href} onClick={() => setMenu(false)} className="block text-[12px] muted hover:text-[var(--ink)] px-3 py-3 rounded-lg">{n.label}</a>)}</div>
          </div>
        )}
      </header>

      <main>
        {/* HERO */}
        <section className="wrap relative pt-14 md:pt-20 pb-16 md:pb-24">
          <div className="absolute inset-0 dots opacity-60 pointer-events-none" style={{ maskImage: 'radial-gradient(ellipse at 30% 20%, #000, transparent 75%)' }} />
          <div className="relative grid lg:grid-cols-[1.05fr_.95fr] gap-12 lg:gap-16 items-center">
            <div className="reveal in">
              <div className="flex flex-wrap items-center gap-2 mb-7">
                <span className="tag tag-solid"><span className="w-1.5 h-1.5 rounded-full bg-lime blink" /> نسخه ۶٫۰</span>
                <span className="tag">Cloudflare Workers + AI</span>
                <span className="tag">PWA قابل نصب</span>
              </div>
              <h1 className="h1">
                به جای حدس،<br />
                <span className="underline-mark">سیستم</span> داشته باش.
              </h1>
              <p className="body !text-[14px] md:!text-[16px] max-w-[520px] mt-7">
                دلارینو هوش مصنوعی، استراتژی اختصاصی و کپی ترید را در یک <strong className="font-bold" style={{ color: 'var(--ink)' }}>مدل ترکیبی واحد</strong> کنار هم میگذارد؛ تا بیش از ۳۰ ارز را همزمان، ساده و دقیق معامله کند.
              </p>
              <div className="flex flex-wrap items-center gap-3 mt-9">
                <a href="#lab" className="btn btn-ink">مدل خودت را بساز <ArrowLeft size={16} /></a>
                <a href="#features" className="btn btn-ghost">اول قابلیت‌ها را ببین <ArrowUpRight size={15} /></a>
              </div>
              <div className="grid grid-cols-3 gap-4 mt-12 pt-7 border-t line max-w-[500px]">
                {[['30+', 'ارز زنده'], ['20', 'معامله همزمان'], ['24/7', 'ربات تلگرام']].map(([v, l]) => (
                  <div key={l}><div dir="ltr" className="latin text-[22px] md:text-[27px] font-bold leading-none">{v}</div><div className="text-[10px] muted mt-2">{l}</div></div>
                ))}
              </div>
            </div>

            {/* composition */}
            <div className="relative h-[400px] md:h-[470px] reveal in" aria-label="ترکیب سه موتور در هسته دلارینو">
              <div className="absolute inset-0 rounded-[36px] dots opacity-70" />
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[250px] h-[250px] md:w-[300px] md:h-[300px] rounded-full border border-dashed" style={{ borderColor: 'var(--line)' }} />
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[190px] h-[190px] md:w-[225px] md:h-[225px] rounded-full border border-dashed spin-slow" style={{ borderColor: 'var(--cobalt)', opacity: .45 }} />
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[150px] h-[150px] md:w-[175px] md:h-[175px] rounded-2xl flex flex-col items-center justify-center z-10 brut" style={{ background: '#101318', borderColor: '#101318', boxShadow: '6px 6px 0 var(--cobalt)' }}>
                <span dir="ltr" className="latin text-[54px] font-bold leading-none text-[#d9f75c]">$</span>
                <span dir="ltr" className="latin text-[8px] tracking-[.2em] text-white/60 mt-2">HYBRID CORE</span>
                <div className="mt-3 px-2.5 py-1 rounded-full bg-[#d9f75c] text-[9px] font-bold text-[#101318]">امتیاز ۹۲</div>
              </div>
              {engineStack.map((e, i) => {
                const Icon = e.icon;
                return (
                  <div key={e.code} className={`absolute ${e.pos} ${i === 1 ? 'float-b' : 'float-a'} card !rounded-xl p-3.5 flex items-center gap-3 shadow-[0_16px_40px_rgba(17,19,24,.1)]`}>
                    <div className="w-9 h-9 rounded-lg flex items-center justify-center shrink-0" style={{ background: `color-mix(in srgb, ${e.color} 28%, transparent)`, color: e.color }}><Icon size={17} /></div>
                    <div className="min-w-0"><div dir="ltr" className="latin text-[9px] font-bold muted tracking-wider">{e.code}</div><div className="text-[11px] font-bold mt-0.5">{e.name}</div></div>
                    <span className="mr-auto w-1.5 h-1.5 rounded-full shrink-0" style={{ background: e.color }} />
                  </div>
                );
              })}
              <div className="absolute -bottom-1 left-0 md:-left-4 tag tag-lime !text-[10px]"><Zap size={12} /> خروجی واحد، سه برابر دقت</div>
            </div>
          </div>
        </section>

        {/* TICKER */}
        <div className="overflow-hidden py-3.5" style={{ background: '#101318', borderTop: '1px solid #2d3340', borderBottom: '1px solid #2d3340' }}>
          <div className="track">
            {[0, 1].map((k) => (
              <div key={k} className="flex items-center gap-9 px-6 shrink-0">
                {[['BTC', '67,420.50', '+2.84%', true], ['ETH', '3,486.12', '+1.62%', true], ['SOL', '178.34', '+5.21%', true], ['XRP', '0.6241', '−0.86%', false], ['DOGE', '0.1842', '+3.41%', true], ['AVAX', '42.18', '−1.24%', false], ['BNB', '594.20', '+0.92%', true]].map(([s, p, ch, up]) => (
                  <div key={`${k}-${s}`} dir="ltr" className="latin flex items-center gap-2.5 text-[11px] whitespace-nowrap text-white/80">
                    <span className="font-bold text-white">{s as string}</span>
                    <span className="text-white/45">{p as string}</span>
                    <span style={{ color: up ? '#d9f75c' : '#ff8a6b' }}>{ch as string}</span>
                    <Spark data={up ? [20, 24, 22, 28, 26, 33, 31, 37, 36, 42] : [42, 38, 40, 34, 36, 30, 32, 27, 28, 24]} color={up ? '#d9f75c' : '#ff8a6b'} width={54} />
                    <span className="text-white/20">/</span>
                  </div>
                ))}
              </div>
            ))}
          </div>
        </div>

        {/* LAB */}
        <section className="wrap py-16 md:py-24">
          <div className="flex flex-wrap items-end justify-between gap-6 mb-9 reveal">
            <div>
              <div className="flex items-center gap-3 mb-4"><span dir="ltr" className="latin text-[10px] font-bold cobalt">/01</span><span className="h-px w-8" style={{ background: 'var(--line)' }} /><span className="eyebrow">THE HYBRID MODEL</span></div>
              <h2 className="h2">به جای تماشا، امتحانش کن.</h2>
            </div>
            <p className="body max-w-md !text-[12.5px]">این یک دموی واقعی از منطق ترکیب موتورهاست. ترکیبها را عوض کن، ریسک و اهرم را جابهجا کن و ببین مدل چطور تغییر شخصیت میدهد.</p>
          </div>
          <div className="reveal"><HybridLab /></div>
        </section>

        {/* BENTO FEATURES */}
        <section id="features" className="wrap py-14 md:py-24">
          <SectionIntro index="02" label="WHY IT WORKS" title="همه چیز سر جای خودش." desc="پیچیدگی زیر سطح است؛ چیزی که میبینی، سریع، تمیز و قابل اعتماد است." />
          <div className="grid md:grid-cols-3 gap-4">
            <div className="card md:col-span-2 p-6 md:p-9 reveal relative overflow-hidden">
              <div className="flex flex-wrap items-start justify-between gap-4">
                <div><span className="tag tag-lime mb-5">ALL MARKET ENGINE</span><h3 className="h3 !text-[20px] md:!text-[26px] mt-2">یک موتور آزاد،<br />بیش از ۳۰ ارز پرنقدینگی.</h3></div>
                <Globe2 size={30} className="cobalt" strokeWidth={1.5} />
              </div>
              <p className="body !text-[12px] max-w-md mt-3">محدود به یک یا سه ارز نیست. رصد همزمان کل بازار، تا ۲۰ معامله موازی و چرخش خودکار روند هنگام برگشت بازار.</p>
              <div className="grid grid-cols-4 sm:grid-cols-7 gap-2 mt-7">
                {['BTC', 'ETH', 'SOL', 'XRP', 'DOGE', 'AVAX', 'BNB', 'LINK', 'ADA', 'TON', 'DOT', 'LTC', 'TRX', 'NEAR'].map((s, i) => (
                  <div key={s} dir="ltr" className="latin rounded-lg py-2 text-center text-[9px] font-bold border line" style={{ background: i < 5 ? 'var(--lime)' : 'var(--soft)', color: 'var(--ink)' }}>{s}</div>
                ))}
              </div>
            </div>

            <div className="card p-6 md:p-7 reveal flex flex-col justify-between">
              <div><span className="tag mb-5">TELEGRAM BOT</span><div className="flex items-center gap-2 mt-3"><MessageSquare size={22} className="cobalt" /><h3 className="h3">همیشه خبر دار.</h3></div><p className="body !text-[11.5px] mt-2">ربات ۲۴/۷ وضعیت معاملات و سیگنالها را همان لحظه به شما میرساند.</p></div>
              <div className="mt-6 space-y-2">
                <div className="rounded-xl p-3 text-[10px] max-w-[85%]" style={{ background: 'var(--soft)' }}>🚀 سیگنال جدید: SOL / LONG<br /><span className="muted">اطمینان ۹۴٪ · اجرا شد</span></div>
                <div className="rounded-xl p-3 text-[10px] max-w-[75%] mr-auto bg-cobalt text-white">سود امروز: +$842.16 ✨</div>
              </div>
            </div>

            <div className="card p-6 md:p-7 reveal">
              <span className="tag mb-5">SECURITY FIRST</span>
              <div className="w-12 h-12 rounded-xl flex items-center justify-center mb-4" style={{ background: 'var(--soft)' }}><LockKeyhole size={21} className="cobalt" /></div>
              <h3 className="h3">کلیدها، فقط پیش خودت.</h3>
              <p className="body !text-[11.5px] mt-2">رمزنگاری AES-256، نشست JWT و ذخیره امن در Cloudflare Secrets. هیچ کلیدی وارد Git نمی‌شود.</p>
              <div className="flex flex-wrap gap-2 mt-5">{[['AES-256', ShieldCheck], ['JWT', Check], ['D1 DB', Layers3]].map(([t, I]) => { const Icon = I as typeof Check; return <span key={t as string} className="tag !text-[9px]"><Icon size={11} /> {t as string}</span>; })}</div>
            </div>

            <div className="card md:col-span-2 p-6 md:p-9 reveal relative overflow-hidden">
              <div className="absolute -left-16 -bottom-16 w-64 h-64 rounded-full opacity-20 blur-3xl" style={{ background: 'var(--cobalt)' }} />
              <div className="relative flex flex-col md:flex-row gap-8 items-center">
                <div className="flex-1">
                  <span className="tag tag-lime mb-5">PRO MODE / SIMPLE UI</span>
                  <h3 className="h3 !text-[20px] md:!text-[26px]">ساده برای شروع،<br />عمیق برای حرفهایها.</h3>
                  <p className="body !text-[12px] mt-3">رابط الهامگرفته از اپلیکیشنهای فینتک، داک موبایل iOS، تم روشن و تیره، حالت حرفهای تریدرها و کارت اشتراک هفتگی.</p>
                  <div className="flex flex-wrap gap-2 mt-5">{['نمایش/پنهان موجودی', 'Pro Mode', 'کارت هفتگی', 'PWA'].map((x) => <span key={x} className="tag !text-[9px]"><Check size={11} className="cobalt" />{x}</span>)}</div>
                </div>
                <div className="w-full max-w-[210px] brut rounded-2xl p-3 shrink-0" style={{ background: 'var(--panel)' }}>
                  <div className="flex items-center justify-between mb-3"><span className="text-[9px] muted">کیف پول</span><span className="w-2 h-2 rounded-full bg-lime" /></div>
                  <div dir="ltr" className="latin text-[19px] font-bold">$24,856<span className="text-[11px] muted">.42</span></div>
                  <div dir="ltr" className="latin text-[10px] cobalt font-bold mt-1">+12.84%</div>
                  <div className="mt-3 h-12 flex items-end gap-1">{[30, 45, 38, 60, 52, 72, 64, 84, 76, 96].map((h, i) => <div key={i} className="flex-1 rounded-t-sm" style={{ height: `${h}%`, background: i > 6 ? 'var(--cobalt)' : 'var(--line)' }} />)}</div>
                  <div className="flex justify-around mt-3 pt-2 border-t line">{[Wallet, TrendingUp, Bot, Gauge].map((I, i) => { const Icon = I; return <Icon key={i} size={13} className={i === 0 ? 'cobalt' : 'muted'} />; })}</div>
                </div>
              </div>
            </div>

            <div className="card p-6 md:p-7 reveal flex flex-col justify-between">
              <span className="tag mb-5">AUTO FLIP</span>
              <div className="w-12 h-12 rounded-xl flex items-center justify-center cobalt mb-4" style={{ background: 'var(--soft)' }}><Repeat2 size={22} /></div>
              <h3 className="h3">وقتی بازار برمیگردد،<br />مدل هم برمیگردد.</h3>
              <p className="body !text-[11.5px] mt-2">چرخش خودکار روند و اهرم آزاد ۱x تا ۵۰x، بدون دخالت دست.</p>
              <div className="flex items-center gap-3 mt-6 pt-4 border-t line"><span dir="ltr" className="latin text-[10px] font-bold muted">LONG</span><ArrowLeft size={16} className="cobalt" /><span dir="ltr" className="latin text-[10px] font-bold cobalt">SHORT</span></div>
            </div>
          </div>
        </section>

        {/* HOW */}
        <section id="how" className="wrap py-14 md:py-24">
          <SectionIntro index="03" label="THREE STEPS" title="از صفر تا اجرا، سه خط." center />
          <div className="reveal">
            {[
              { n: '01', icon: Wallet, t: 'حساب دمو بساز', d: 'رایگان، بدون کلید API، با قیمت زنده بازار.' },
              { n: '02', icon: BrainCircuit, t: 'مدل ترکیبیات را بچین', d: 'موتورها، دامنه بازار، ریسک و اهرم را انتخاب کن.' },
              { n: '03', icon: TrendingUp, t: 'بگذار سیستم کار کند', d: 'اجرای ۲۴/۷، گزارش لحظه‌ای و کنترل کامل از پنل یا تلگرام.' },
            ].map((s) => {
              const Icon = s.icon;
              return (
                <div key={s.n} className="group grid grid-cols-[auto_1fr_auto] md:grid-cols-[90px_1fr_1.1fr_auto] gap-4 md:gap-8 items-center py-6 md:py-8 border-t line last:border-b hover:bg-[var(--soft)] transition px-2 md:px-4 rounded-lg">
                  <span dir="ltr" className="latin text-[26px] md:text-[38px] font-bold muted group-hover:text-[var(--cobalt)] transition">{s.n}</span>
                  <div className="flex items-center gap-3"><Icon size={20} className="cobalt shrink-0" /><h3 className="h3">{s.t}</h3></div>
                  <p className="body !text-[12px] col-span-3 md:col-span-1">{s.d}</p>
                  <ArrowUpRight size={19} className="cobalt hidden md:block group-hover:-translate-y-1 group-hover:translate-x-1 transition" />
                </div>
              );
            })}
          </div>
        </section>

        {/* NUMBERS */}
        <section id="numbers" className="py-16 md:py-24 mt-6" style={{ background: '#101318', color: '#f4f3ed' }}>
          <div className="wrap">
            <div className="grid lg:grid-cols-[.9fr_1.1fr] gap-12 items-end">
              <div className="reveal">
                <div className="flex items-center gap-3 mb-5"><span dir="ltr" className="latin text-[10px] font-bold text-[#d9f75c]">/04</span><span className="h-px w-8 bg-white/20" /><span className="latin text-[10px] tracking-[.2em] text-white/50">BY THE NUMBERS</span></div>
                <h2 className="h2 !text-white">اعداد،<br />حرف آخر را میزنند.</h2>
                <p className="text-[12px] leading-8 text-white/50 mt-5 max-w-sm">معماری سبک، اجرای سریع و پوشش گسترده؛ چیزی که یک سیستم معاملاتی را از یک ربات ساده جدا می‌کند.</p>
                <div className="grid grid-cols-2 gap-6 mt-9">
                  {[['+12.8%', 'میانگین بازده هفتگی'], ['90.4%', 'نرخ موفقیت سیگنالها'], ['<80ms', 'تأخیر اجرای سیگنال'], ['0', 'کلید API لازم برای شروع']].map(([v, l]) => (
                    <div key={l}><div dir="ltr" className="latin text-[26px] md:text-[31px] font-bold text-[#d9f75c]">{v}</div><div className="text-[10px] text-white/50 mt-1.5">{l}</div></div>
                  ))}
                </div>
              </div>
              <div className="reveal rounded-2xl border border-white/12 p-5 md:p-7" style={{ background: 'rgba(255,255,255,.035)' }}>
                <div className="flex items-center justify-between mb-6"><span className="text-[11px] text-white/60">روند حجم معاملات · ۲۶ دوره</span><span className="latin text-[9px] text-[#d9f75c]">LIVE FEED</span></div>
                <BarColumns data={Array.from({ length: 26 }, (_, i) => 25 + Math.abs(Math.sin(i * .62) * 55) + i * 1.1)} height={190} />
                <div className="grid grid-cols-3 gap-3 mt-6 pt-5 border-t border-white/12">
                  {[['ALL_MARKET', '30+', Globe2], ['TOP_COINS', '10', Layers3], ['SINGLE', '01', Target]].map(([k, v, I]) => { const Icon = I as typeof Globe2; return <div key={k as string}><Icon size={14} className="text-[#7e95ff] mb-2" /><div dir="ltr" className="latin text-[10px] font-bold text-white/70">{k as string}</div><div dir="ltr" className="latin text-[18px] font-bold text-white mt-1">{v as string}</div></div>; })}
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* WEEKLY */}
        <section id="weekly" className="wrap py-16 md:py-24">
          <div className="grid lg:grid-cols-2 gap-14 items-center">
            <div className="order-2 lg:order-1 reveal">
              <SectionIntro index="05" label="SHARE YOUR WINS" title="نتیجهای که دیدنی است." desc="کارت هفتگی ۴:۵ با طراحی اختصاصی دلارینو؛ بازده، سود و نرخ موفقیت در یک قاب که ارسالش لذت دارد." />
              <div className="space-y-3 mb-8">
                {['خروجی PNG با کیفیت بالا و یک کلیک', 'طراحی هماهنگ با برند و تایپوگرافی دلارینو', 'آمار واقعی پنل، مستقیم از حساب کاربری'].map((x) => <div key={x} className="flex items-center gap-3 text-[12px]"><span className="w-6 h-6 rounded-lg flex items-center justify-center cobalt" style={{ background: 'var(--soft)' }}><Check size={13} /></span>{x}</div>)}
              </div>
              <a href="#lab" className="btn btn-ghost"><ArrowUpRight size={15} /> برگرد و مدل بساز</a>
            </div>
            <div className="order-1 lg:order-2 flex justify-center lg:justify-end reveal"><WeeklyDownload onDone={setToast} /></div>
          </div>
        </section>

        {/* FAQ */}
        <section id="faq" className="wrap py-14 md:py-24">
          <div className="grid md:grid-cols-[.85fr_1.15fr] gap-10 md:gap-16">
            <SectionIntro index="06" label="FAQ" title="شفاف، مثل خود محصول." desc="اگر جوابت اینجا نیست، ربات تلگرام ۲۴/۷ پاسخگوست." />
            <div className="reveal">
              {faqs.map(([q, a], i) => (
                <div key={q} className="accordion-item">
                  <button onClick={() => setFaq(faq === i ? null : i)} className="w-full flex items-center justify-between gap-4 py-5 text-right">
                    <span className="text-[13px] md:text-[14px] font-bold">{q}</span>
                    <ChevronDown size={17} className={`cobalt shrink-0 transition-transform duration-300 ${faq === i ? 'rotate-180' : ''}`} />
                  </button>
                  {faq === i && <p className="body !text-[12px] pb-6 max-w-xl">{a}</p>}
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA */}
        <section className="wrap pb-16 md:pb-24 pt-4">
          <div className="reveal relative overflow-hidden rounded-[24px] px-7 py-14 md:px-14 md:py-20 text-center bg-cobalt" style={{ color: '#fff' }}>
            <div className="absolute -top-24 -right-24 w-72 h-72 rounded-full border-[40px] border-white/10" />
            <div className="absolute -bottom-32 -left-20 w-80 h-80 rounded-full border-[40px] border-white/10" />
            <div className="relative">
              <span className="tag !bg-[#d9f75c] !text-[#111318] !border-[#d9f75c] mb-6"><Sparkles size={12} /> شروع، همین حالا</span>
              <h2 className="h2 !text-white max-w-2xl mx-auto">بازار منتظر نمیماند.<br />شما هم لازم نیست.</h2>
              <p className="text-[12.5px] text-white/70 mt-5 max-w-lg mx-auto leading-8">حساب دمو رایگان بساز و همان لحظه ببین مدل ترکیبی دلارینو چطور به جای تو تصمیم میگیرد.</p>
              <div className="flex flex-wrap justify-center gap-3 mt-8">
                <a href="#lab" className="btn btn-lime !border-[#111318] !shadow-[4px_4px_0_#111318]">ساخت مدل رایگان <ArrowLeft size={16} /></a>
                <a href="#features" className="btn !border-white/40 !text-white hover:!bg-white/10">قابلیت‌ها <ArrowUpRight size={15} /></a>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* FOOTER */}
      <footer className="wrap pb-28 md:pb-10">
        <div className="border-t line pt-10 grid grid-cols-2 md:grid-cols-4 gap-9">
          <div className="col-span-2 md:col-span-1">
            <Logo />
            <p className="body !text-[11px] mt-4 max-w-[250px]">سیستم ترید خودکار چندارزی؛ هوش مصنوعی، استراتژی اختصاصی و کپی ترید در یک پلتفرم.</p>
            <div className="flex flex-wrap gap-2 mt-5">{[['Paper Demo', Check], ['Toobit', Check], ['KCEX', Check]].map(([n, I]) => { const Icon = I as typeof Check; return <span key={n as string} className="tag !text-[9px]"><Icon size={10} className="cobalt" />{n as string}</span>; })}</div>
          </div>
          {[
            ['محصول', ['مدل ترکیبی', 'قابلیت‌ها', 'کارت هفتگی', 'پنل کاربری']],
            ['موتورها', ['دُرّبین AI', 'دُرنا V1', 'کپی ترید', 'ALL_MARKET']],
            ['پلتفرم', ['امنیت', 'سوالات متداول', 'ربات تلگرام', '@Dollarinoofficial']],
          ].map(([t, items]) => (
            <div key={t as string}><div className="text-[12px] font-bold mb-4">{t as string}</div><div className="space-y-2.5">{(items as string[]).map((x) => <a key={x} href="#top" className="block text-[11px] muted hover:text-[var(--cobalt)] transition">{x}</a>)}</div></div>
          ))}
        </div>
        <div dir="ltr" className="latin outline-word text-center font-bold leading-none mt-14 select-none" style={{ fontSize: 'clamp(2.5rem, 10vw, 9rem)', letterSpacing: '-.06em' }}>DOLLARINO</div>
        <div className="flex flex-wrap justify-between gap-3 mt-8 pt-6 border-t line text-[10px] muted"><span>© ۲۰۲۵ دلارینو — ساخته شده برای تصمیمهای بهتر.</span><span>v6.0 / Cloudflare Workers · D1 · Durable Objects</span></div>
      </footer>

      {/* mobile dock */}
      <div className="fixed bottom-4 left-1/2 -translate-x-1/2 z-50 md:hidden">
        <div className="flex items-center gap-1 rounded-2xl px-2 py-2 border border-white/10" style={{ background: 'rgba(16,19,24,.94)', backdropFilter: 'blur(18px)', boxShadow: '0 14px 40px rgba(0,0,0,.3)' }}>
          {[
            { i: BrainCircuit, t: 'آزمایشگاه', h: '#lab' },
            { i: Layers3, t: 'قابلیت‌ها', h: '#features' },
            { i: Download, t: 'کارت', h: '#weekly' },
            { i: theme === 'light' ? Moon : Sun, t: 'تم', h: '', act: () => setTheme(theme === 'light' ? 'dark' : 'light') },
          ].map(({ i: Icon, t, h, act }) => (
            <a key={t} href={h || undefined} onClick={act} className="w-[66px] py-2 rounded-xl flex flex-col items-center gap-1 text-[9px] text-white/55 hover:text-[#d9f75c] transition"><Icon size={17} />{t}</a>
          ))}
        </div>
      </div>

      {toast && <div className="fixed bottom-24 md:bottom-8 left-1/2 -translate-x-1/2 z-[70] px-5 py-3 rounded-xl text-[11px] font-bold shadow-xl" style={{ background: 'var(--ink)', color: 'var(--paper)' }}>{toast}</div>}
    </div>
  );
}
