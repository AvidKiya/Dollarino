import { useId } from 'react';

type LineChartProps = {
  data: number[];
  height?: number;
  color?: string;
  showGrid?: boolean;
  className?: string;
};

export function LineChart({ data, height = 240, color = 'var(--accent)', showGrid = true, className = '' }: LineChartProps) {
  const id = useId().replace(/:/g, '');
  const w = 600, h = 220, pad = 12;
  const min = Math.min(...data), max = Math.max(...data);
  const span = max - min || 1;
  const points = data.map((v, i) => ({
    x: pad + (i / (data.length - 1)) * (w - pad * 2),
    y: pad + (1 - (v - min) / span) * (h - pad * 2 - 18),
  }));
  const line = points.map((p, i) => `${i === 0 ? 'M' : 'L'} ${p.x.toFixed(1)} ${p.y.toFixed(1)}`).join(' ');
  const area = `${line} L ${points[points.length - 1].x} ${h} L ${points[0].x} ${h} Z`;
  const last = points[points.length - 1];

  return (
    <svg viewBox={`0 0 ${w} ${h}`} preserveAspectRatio="none" className={className} style={{ width: '100%', height }} aria-hidden="true">
      <defs>
        <linearGradient id={`area-${id}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity="0.28" />
          <stop offset="65%" stopColor={color} stopOpacity="0.06" />
          <stop offset="100%" stopColor={color} stopOpacity="0" />
        </linearGradient>
        <filter id={`glow-${id}`} x="-20%" y="-60%" width="140%" height="220%">
          <feGaussianBlur stdDeviation="5" result="b" />
          <feMerge><feMergeNode in="b" /><feMergeNode in="SourceGraphic" /></feMerge>
        </filter>
      </defs>
      {showGrid && [0, 1, 2, 3, 4].map((i) => (
        <line key={i} x1="0" x2={w} y1={28 + i * 44} y2={28 + i * 44} stroke="var(--line)" strokeWidth="1" strokeDasharray="3 6" />
      ))}
      <path d={area} fill={`url(#area-${id})`} />
      <path d={line} fill="none" stroke={color} strokeWidth="2.6" strokeLinejoin="round" strokeLinecap="round" className="draw-line" filter={`url(#glow-${id})`} />
      <circle cx={last.x} cy={last.y} r="9" fill={color} opacity="0.16" />
      <circle cx={last.x} cy={last.y} r="3.6" fill={color} stroke="var(--bg)" strokeWidth="1.5" />
    </svg>
  );
}

export function Sparkline({ data, color = 'var(--accent)', className = '' }: { data: number[]; color?: string; className?: string }) {
  const min = Math.min(...data), max = Math.max(...data), span = max - min || 1;
  const pts = data.map((v, i) => `${(i / (data.length - 1)) * 100},${26 - ((v - min) / span) * 22}`).join(' ');
  return (
    <svg viewBox="0 0 100 30" preserveAspectRatio="none" className={className} style={{ width: '100%', height: 30 }} aria-hidden="true">
      <polyline points={pts} fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" vectorEffect="non-scaling-stroke" />
    </svg>
  );
}

export const heroSeries = [22, 26, 24, 31, 28, 34, 32, 39, 36, 45, 42, 48, 44, 53, 50, 58, 55, 63, 60, 69, 66, 74, 70, 79, 76, 85, 82, 92, 88, 98];
export const weekSeries = [30, 34, 32, 38, 36, 44, 41, 47, 45, 52, 49, 55, 60, 57, 64, 68, 65, 72, 78, 75, 82, 88, 85, 94, 91, 99];
