import { Check, Radio } from "lucide-react";
import { Spark } from "./Viz";
import type { Trader } from "../lib/market";

export default function CopyBoard({ traders, followed, onToggle }: { traders: Trader[]; followed: string[]; onToggle: (id: string) => void }) {
  const avg = traders.reduce((s, t) => s + t.roi, 0) / traders.length;
  return (
    <div>
      <div className="mb-4 flex flex-wrap items-end justify-between gap-3">
        <div>
          <div className="latin text-[10px] tracking-[.18em] text-[#8ea2ff]">MIRROR</div>
          <h3 className="mt-1 text-[20px] font-black">کپی ترید</h3>
          <p className="dim mt-1 max-w-lg text-[11px] leading-6">سیگنال کانال <span className="latin text-white">@Dollarinoofficial</span> یا تریدرهای منتخب، همان لحظه روی حساب شما می‌نشیند. وب‌هوک TradingView هم همین‌جا وصل می‌شود.</p>
        </div>
        <div className="rounded-xl border border-white/10 px-3 py-2 text-[11px]"><span className="dim">میانگین بازده ۳۰روز </span><b className="latin text-[#3ddc97]">+{avg.toFixed(1)}%</b></div>
      </div>
      <div className="grid gap-3 md:grid-cols-2">
        {traders.map((t) => {
          const on = followed.includes(t.id);
          return (
            <article key={t.id} className="rounded-2xl border border-white/10 bg-white/[.03] p-4">
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="grid h-11 w-11 place-items-center rounded-2xl text-[13px] font-black text-[#12141a]" style={{ background: t.color }}>{t.name.slice(0, 1)}</div>
                  <div>
                    <div className="text-[14px] font-extrabold">{t.name}</div>
                    <div dir="ltr" className="latin text-left text-[10px] faint">{t.tag}</div>
                  </div>
                </div>
                <Spark data={t.spark} color={t.color} width={72} />
              </div>
              <div className="mt-4 grid grid-cols-4 gap-2 text-[10px]">
                {[[`${t.win}%`, "برد"], [`+${t.roi}%`, "بازده"], [t.risk, "ریسک"], [t.focus, "تمرکز"]].map(([v, l]) => (
                  <div key={l}><div className="latin font-bold text-white">{v}</div><div className="faint mt-0.5">{l}</div></div>
                ))}
              </div>
              <div className="mt-4 flex items-center justify-between">
                <span className="faint text-[10px]">{t.copiers.toLocaleString("en-US")} دنبال‌کننده · {t.bias === "long" ? "تمایل خرید" : "تمایل فروش"}</span>
                <button onClick={() => onToggle(t.id)} className="inline-flex items-center gap-1 rounded-xl px-3 py-2 text-[11px] font-extrabold" style={{ background: on ? "#dff25a" : "rgba(255,255,255,.06)", color: on ? "#14160f" : "white" }}>
                  {on ? <Check size={13} /> : <Radio size={13} />} {on ? "دنبال می‌کنی" : "دنبال کن"}
                </button>
              </div>
            </article>
          );
        })}
      </div>
    </div>
  );
}
