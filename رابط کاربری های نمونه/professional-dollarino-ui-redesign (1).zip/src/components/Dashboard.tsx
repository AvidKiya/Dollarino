import { useEffect, useMemo, useState } from 'react';
import {
  Activity, ArrowDownLeft, ArrowUpRight, Bot, ChevronDown, Eye, EyeOff,
  Radio, Search, Settings2, ShieldCheck, Sparkles, TrendingUp, Zap,
} from 'lucide-react';
import { LineChart, Sparkline, heroSeries, weekSeries } from './Chart';

type Coin = {
  sym: string; name: string; price: number; change: number; spark: number[];
  mark: string; tint: string;
};

const initialCoins: Coin[] = [
  { sym: 'BTC', name: 'Bitcoin', price: 67420.5, change: 2.84, spark: [20, 24, 22, 29, 28, 35, 33, 40, 38, 48], mark: '₿', tint: '#f7931a' },
  { sym: 'ETH', name: 'Ethereum', price: 3486.12, change: 1.62, spark: [26, 22, 28, 25, 32, 30, 36, 34, 42, 45], mark: 'Ξ', tint: '#8a92f7' },
  { sym: 'SOL', name: 'Solana', price: 178.34, change: 5.21, spark: [18, 25, 22, 34, 31, 39, 36, 47, 45, 56], mark: '◎', tint: '#14f195' },
  { sym: 'XRP', name: 'XRP', price: 0.6241, change: -0.86, spark: [46, 42, 44, 38, 40, 35, 37, 31, 33, 29], mark: '✕', tint: '#a8b6cc' },
  { sym: 'DOGE', name: 'Dogecoin', price: 0.1842, change: 3.41, spark: [22, 27, 25, 30, 28, 36, 34, 43, 40, 49], mark: 'Ð', tint: '#c3a634' },
  { sym: 'AVAX', name: 'Avalanche', price: 42.18, change: -1.24, spark: [44, 40, 42, 36, 38, 33, 35, 30, 32, 28], mark: '▲', tint: '#e84142' },
];

const positions = [
  { pair: 'BTC/USDT', side: 'LONG', lev: '10x', entry: '66,940.20', pnl: '+342.80', pct: '+4.12%', up: true },
  { pair: 'SOL/USDT', side: 'LONG', lev: '5x', entry: '172.60', pnl: '+186.40', pct: '+7.84%', up: true },
  { pair: 'ETH/USDT', side: 'SHORT', lev: '8x', entry: '3,512.00', pnl: '+74.20', pct: '+1.96%', up: true },
  { pair: 'AVAX/USDT', side: 'SHORT', lev: '3x', entry: '41.20', pnl: '−28.60', pct: '−1.44%', up: false },
];

const signals = [
  { src: 'دُرّبین · AI', pair: 'SOL/USDT', action: 'LONG', conf: 94, detail: 'شکست مقاومت + جریان ورودی قوی', time: '۲ دقیقه پیش' },
  { src: 'دُرنا V1', pair: 'BTC/USDT', action: 'LONG', conf: 88, detail: 'ریبون non-repaint تأییدشده روی t4h', time: '۱۲ دقیقه پیش' },
  { src: 'کپی ترید', pair: 'ETH/USDT', action: 'SHORT', conf: 81, detail: 'سیگنال کانال رسمی @Dollarinoofficial', time: '۳۴ دقیقه پیش' },
];

const fmt = (n: number, sym: string) =>
  n.toLocaleString('en-US', { minimumFractionDigits: sym === 'BTC' || sym === 'ETH' ? 2 : 4, maximumFractionDigits: sym === 'BTC' || sym === 'ETH' ? 2 : 4 });

export default function Dashboard() {
  const [tab, setTab] = useState<'overview' | 'market' | 'signals'>('overview');
  const [range, setRange] = useState('1D');
  const [hidden, setHidden] = useState(false);
  const [pro, setPro] = useState(false);
  const [query, setQuery] = useState('');
  const [coins, setCoins] = useState(initialCoins);

  useEffect(() => {
    const id = window.setInterval(() => {
      setCoins((prev) => prev.map((c) => {
        const drift = (Math.random() - 0.48) * 0.0035;
        const change = Math.max(-9, Math.min(9, c.change + drift * 100));
        return { ...c, price: c.price * (1 + drift), change };
      }));
    }, 2400);
    return () => window.clearInterval(id);
  }, []);

  const filtered = useMemo(() => coins.filter((c) => (c.sym + c.name).toLowerCase().includes(query.toLowerCase())), [coins, query]);
  const chartData = range === '1D' ? heroSeries : range === '1W' ? weekSeries : [...heroSeries].reverse();

  return (
    <div className="glass rounded-[28px] overflow-hidden shadow-[var(--shadow)]" id="dashboard-panel">
      {/* panel header */}
      <div className="flex flex-wrap items-center justify-between gap-4 px-5 py-4 md:px-7 md:py-5 hairline border-b">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl flex items-center justify-center" style={{ background: 'var(--accent-soft)', color: 'var(--accent)' }}>
            <Activity size={18} strokeWidth={2.2} />
          </div>
          <div>
            <div className="text-sm font-bold">پنل معاملاتی</div>
            <div className="text-[11px] muted flex items-center gap-1.5 mt-0.5"><span className="dot" />اتصال زنده به بازار</div>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={() => setHidden(!hidden)} className="w-9 h-9 rounded-xl surface flex items-center justify-center muted hover:text-[var(--text)] transition" aria-label="نمایش یا پنهان موجودی">
            {hidden ? <EyeOff size={16} /> : <Eye size={16} />}
          </button>
          <button onClick={() => setPro(!pro)} className={`h-9 px-3 rounded-xl border flex items-center gap-2 text-[11px] font-bold transition ${pro ? 'text-[var(--accent)] border-[var(--accent)]' : 'muted hairline'}`} style={pro ? { background: 'var(--accent-soft)' } : {}}>
            <Settings2 size={15} /> حالت حرفه‌ای
          </button>
        </div>
      </div>

      {/* tabs */}
      <div className="flex gap-1 px-4 md:px-6 pt-4 pb-2 overflow-x-auto">
        {[
          { id: 'overview', label: 'نمای کلی', icon: TrendingUp },
          { id: 'market', label: 'بازار', icon: Activity },
          { id: 'signals', label: 'سیگنال‌های هوش مصنوعی', icon: Sparkles },
        ].map(({ id, label, icon: Icon }) => (
          <button key={id} onClick={() => setTab(id as typeof tab)} className={`tab-btn flex items-center gap-2 px-4 py-2.5 rounded-xl text-[12px] md:text-[13px] font-bold ${tab === id ? 'active' : 'muted hover:text-[var(--text)]'}`}>
            <Icon size={15} /> {label}
          </button>
        ))}
      </div>

      <div className="p-4 md:p-7" key={tab}>
        {tab === 'overview' && (
          <div className="animate-rise">
            <div className="grid lg:grid-cols-[1.5fr_1fr] gap-4">
              <div className="rounded-2xl border hairline p-5 md:p-6" style={{ background: 'var(--surface)' }}>
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div>
                    <div className="text-[11px] muted mb-2">ارزش کل کیف پول · USD</div>
                    <div dir="ltr" className="latin text-3xl md:text-[38px] font-bold tracking-tight inline-block">
                      {hidden ? '••••••••' : '$ 24,856.42'}
                    </div>
                    <div className="flex items-center gap-2 mt-2 text-[12px]">
                      <span className="accent font-bold flex items-center gap-1" dir="ltr"><ArrowUpRight size={14} /> +12.84%</span>
                      <span className="muted">در ۳۰ روز گذشته</span>
                    </div>
                  </div>
                  <div className="flex gap-1 p-1 rounded-xl surface border hairline">
                    {['1D', '1W', '1M'].map((r) => (
                      <button key={r} onClick={() => setRange(r)} dir="ltr" className={`latin px-3 py-1.5 rounded-lg text-[10px] font-bold transition ${range === r ? 'text-[var(--accent)]' : 'muted'}`} style={range === r ? { background: 'var(--accent-soft)' } : {}}>{r}</button>
                    ))}
                  </div>
                </div>
                <div className="mt-3 -mx-2"><LineChart data={chartData} height={210} /></div>
                <div className="grid grid-cols-3 gap-3 mt-3 pt-4 border-t hairline">
                  {[
                    { label: 'سود امروز', value: '+$ 842.16', color: 'var(--accent)' },
                    { label: 'معاملات باز', value: '12 / 20', color: 'var(--text)' },
                    { label: 'نرخ موفقیت', value: '87.4%', color: 'var(--blue)' },
                  ].map((s) => (
                    <div key={s.label}>
                      <div className="text-[10px] muted mb-1">{s.label}</div>
                      <div dir="ltr" className="latin text-[13px] md:text-[15px] font-bold" style={{ color: s.color }}>{s.value}</div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="rounded-2xl border hairline p-5" style={{ background: 'var(--surface)' }}>
                <div className="flex items-center justify-between mb-4">
                  <div className="text-[13px] font-bold">معاملات باز</div>
                  <span className="pill text-[10px]">12 فعال</span>
                </div>
                <div className="space-y-1">
                  {positions.map((p) => (
                    <div key={p.pair} className="flex items-center justify-between gap-2 py-3 border-b hairline last:border-0">
                      <div className="min-w-0">
                        <div dir="ltr" className="latin text-[12px] font-bold text-left">{p.pair}</div>
                        <div dir="ltr" className="latin text-[9px] muted mt-1 text-left">{p.side} · {p.lev}</div>
                      </div>
                      <div className="text-left">
                        <div dir="ltr" className={`latin text-[12px] font-bold ${p.up ? 'accent' : ''}`} style={!p.up ? { color: 'var(--red)' } : {}}>{p.pnl}</div>
                        <div dir="ltr" className={`latin text-[9px] mt-1 ${p.up ? 'accent' : ''}`} style={!p.up ? { color: 'var(--red)' } : {}}>{p.pct}</div>
                      </div>
                    </div>
                  ))}
                </div>
                <div className="mt-3 flex items-center justify-between rounded-xl px-3 py-2.5" style={{ background: 'var(--accent-soft)' }}>
                  <span className="text-[10px] muted">سود شناور کل</span>
                  <span dir="ltr" className="latin text-[13px] font-bold accent">+ $574.80</span>
                </div>
              </div>
            </div>
            {pro && (
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mt-4 animate-rise">
                {[
                  ['Score ریسک', '72 / 100'], ['تغییرات ۲۴س', '+3.42%'], ['حجم معاملات', '$1.24M'], ['Funding', '+0.010%'],
                ].map(([l, v]) => (
                  <div key={l} className="rounded-xl border hairline p-3.5" style={{ background: 'var(--surface)' }}>
                    <div className="text-[10px] muted mb-1.5">{l}</div>
                    <div dir="ltr" className="latin text-[13px] font-bold">{v}</div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {tab === 'market' && (
          <div className="animate-rise">
            <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
              <div className="relative flex-1 min-w-[200px] max-w-sm">
                <Search size={15} className="absolute right-3 top-1/2 -translate-y-1/2 muted" />
                <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="جستجوی ارز..." className="w-full rounded-xl border hairline bg-transparent py-2.5 pr-9 pl-3 text-[12px] outline-none focus:border-[var(--accent)] transition placeholder:text-[var(--faint)]" />
              </div>
              <div className="text-[11px] muted flex items-center gap-2"><ShieldCheck size={14} className="accent" /> قیمت لحظه‌ای · به‌روزرسانی خودکار</div>
            </div>
            <div className="rounded-2xl border hairline overflow-hidden" style={{ background: 'var(--surface)' }}>
              <div className="hidden md:grid grid-cols-[1.4fr_1fr_1fr_1fr] gap-3 px-5 py-3 text-[10px] muted border-b hairline">
                <span>ارز</span><span className="text-left">قیمت</span><span className="text-left">۲۴ ساعت</span><span className="text-left">روند ۷ روزه</span>
              </div>
              {filtered.map((c) => (
                <div key={c.sym} className="grid grid-cols-[1fr_auto] md:grid-cols-[1.4fr_1fr_1fr_1fr] items-center gap-3 px-4 md:px-5 py-3.5 border-b hairline last:border-0 hover:bg-[var(--surface-strong)] transition">
                  <div className="flex items-center gap-3 min-w-0">
                    <div dir="ltr" className="latin w-9 h-9 rounded-full flex items-center justify-center text-[15px] font-bold shrink-0" style={{ color: c.tint, background: `${c.tint}1c`, border: `1px solid ${c.tint}33` }}>{c.mark}</div>
                    <div className="min-w-0">
                      <div dir="ltr" className="latin text-[12px] font-bold text-left">{c.sym}</div>
                      <div className="text-[10px] muted text-left truncate">{c.name}</div>
                    </div>
                  </div>
                  <div dir="ltr" className="latin text-[12px] font-semibold text-left hidden md:block ticker-pulse">${fmt(c.price, c.sym)}</div>
                  <div dir="ltr" className={`latin text-[11px] font-bold text-left hidden md:block ${c.change >= 0 ? 'accent' : ''}`} style={c.change < 0 ? { color: 'var(--red)' } : {}}>{c.change >= 0 ? '+' : ''}{c.change.toFixed(2)}%</div>
                  <div className="hidden md:block"><Sparkline data={c.spark} color={c.change >= 0 ? 'var(--accent)' : 'var(--red)'} /></div>
                  <div className="md:hidden text-left">
                    <div dir="ltr" className="latin text-[12px] font-bold">${fmt(c.price, c.sym)}</div>
                    <div dir="ltr" className={`latin text-[10px] ${c.change >= 0 ? 'accent' : ''}`} style={c.change < 0 ? { color: 'var(--red)' } : {}}>{c.change >= 0 ? '+' : ''}{c.change.toFixed(2)}%</div>
                  </div>
                </div>
              ))}
              {filtered.length === 0 && <div className="py-10 text-center text-[12px] muted">نتیجه‌ای یافت نشد</div>}
            </div>
            {pro && <div className="mt-3 text-[10px] muted">نمایش حجم، عمق بازار و funding به صورت لحظه‌ای · حالت حرفه‌ای فعال است</div>}
          </div>
        )}

        {tab === 'signals' && (
          <div className="animate-rise grid md:grid-cols-[1.5fr_1fr] gap-4">
            <div className="space-y-3">
              {signals.map((s, idx) => (
                <div key={s.pair} className="rounded-2xl border hairline p-4 md:p-5 flex gap-4 items-start hover:border-[var(--line-strong)] transition" style={{ background: 'var(--surface)' }}>
                  <div className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0" style={{ background: idx === 2 ? 'var(--blue-soft)' : 'var(--accent-soft)', color: idx === 2 ? 'var(--blue)' : 'var(--accent)' }}>
                    {idx === 2 ? <Radio size={18} /> : idx === 1 ? <Zap size={18} /> : <Bot size={18} />}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex flex-wrap items-center gap-2 mb-1.5">
                      <span dir="ltr" className="latin text-[13px] font-bold">{s.pair}</span>
                      <span className="pill text-[9px]">{s.src}</span>
                      <span dir="ltr" className="latin text-[9px] font-bold accent">{s.action}</span>
                    </div>
                    <div className="text-[11px] muted mb-3">{s.detail}</div>
                    <div className="flex items-center gap-3">
                      <div className="h-1.5 rounded-full flex-1 max-w-[200px]" style={{ background: 'var(--surface-strong)' }}>
                        <div className="h-full rounded-full" style={{ width: `${s.conf}%`, background: 'linear-gradient(90deg,var(--blue),var(--accent))' }} />
                      </div>
                      <span dir="ltr" className="latin text-[10px] font-bold muted">{s.conf}% اطمینان</span>
                    </div>
                  </div>
                  <div className="text-[9px] muted whitespace-nowrap hidden sm:block">{s.time}</div>
                </div>
              ))}
            </div>
            <div className="rounded-2xl border hairline p-5 flex flex-col justify-between" style={{ background: 'linear-gradient(150deg, var(--accent-soft), transparent 70%)' }}>
              <div>
                <div className="w-10 h-10 rounded-xl flex items-center justify-center mb-4" style={{ background: 'var(--accent-soft)', color: 'var(--accent)' }}><Sparkles size={19} /></div>
                <h4 className="text-[15px] font-bold mb-2">دُرّبین تصمیم می‌گیرد</h4>
                <p className="text-[11px] muted leading-7">ترکیب هوشمند مدل‌های DeepSeek، Claude، GPT و Gemini با تحلیل تکنیکال لحظه‌ای — بدون نیاز به کلید API.</p>
              </div>
              <div className="mt-5 space-y-2.5">
                {['تحلیل ۳ تایم فریم به صورت همزمان', 'فیلتر نقدینگی و ریبون non-repaint', 'اجرای خودکار تا ۲۰ معامله'].map((x) => (
                  <div key={x} className="flex items-center gap-2 text-[11px]"><span className="dot shrink-0" /> {x}</div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* footer strip */}
      <div className="flex flex-wrap items-center justify-between gap-3 px-5 md:px-7 py-3.5 border-t hairline text-[10px] muted">
        <div className="flex items-center gap-4">
          <span className="flex items-center gap-1.5"><ArrowUpRight size={12} className="accent" /> Paper Demo</span>
          <span className="flex items-center gap-1.5"><ArrowDownLeft size={12} className="accent" /> Toobit Futures</span>
          <span className="flex items-center gap-1.5 hidden sm:flex"><ArrowUpRight size={12} className="accent" /> KCEX Futures</span>
        </div>
        <div className="flex items-center gap-1.5"><ChevronDown size={12} /> آخرین بروزرسانی: لحظاتی پیش</div>
      </div>
    </div>
  );
}
