import { useMemo, useState } from "react";
import { ArrowDownLeft, ArrowUpRight, Eye, EyeOff, Search, Settings2, X } from "lucide-react";
import { Area, Spark } from "./Viz";
import { changeOf, fmtMoney, fmtPrice, positionPnl, type Coin, type Position, type Side } from "../lib/market";

export function WalletCard({
  equity, pnl, hidden, onToggle, compact = false,
}: { equity: number; pnl: number; hidden: boolean; onToggle: () => void; compact?: boolean }) {
  const up = pnl >= 0;
  return (
    <div className="relative overflow-hidden rounded-[22px] p-5 text-white" style={{ background: "linear-gradient(145deg,#1a2dff 0%,#2a45e6 42%,#1630b8 100%)", boxShadow: "inset 0 1px 0 rgba(255,255,255,.28), 0 18px 40px -24px rgba(26,45,255,.8)" }}>
      <div className="pointer-events-none absolute -left-8 -top-10 h-32 w-32 rounded-full bg-white/10" />
      <div className="pointer-events-none absolute -bottom-16 left-10 h-36 w-36 rounded-full border border-white/15" />
      <div className="relative flex items-start justify-between">
        <div>
          <div className="text-[10px] font-bold text-white/70">کیف‌پول کبالت · USD</div>
          <div dir="ltr" className="latin mt-2 text-[30px] font-bold leading-none tracking-tight">{hidden ? "••••••" : fmtMoney(equity, 2)}</div>
        </div>
        <button onClick={onToggle} className="grid h-9 w-9 place-items-center rounded-xl bg-white/10" aria-label="نمایش موجودی">{hidden ? <EyeOff size={16} /> : <Eye size={16} />}</button>
      </div>
      <div className="relative mt-4 flex items-center justify-between">
        <span className="rounded-full px-2.5 py-1 text-[10px] font-extrabold" style={{ background: up ? "#dff25a" : "#ffd0d4", color: "#14160f" }} dir="ltr">{up ? "+" : ""}{pnl.toFixed(2)}%</span>
        {!compact && <span className="text-[10px] text-white/65">Paper Demo · قیمت زنده</span>}
      </div>
    </div>
  );
}

export default function Desk({
  coins, positions, equity, unrealized, hist, cash, hidden, pro, onToggleHidden, onTogglePro, onOpen, onClose,
}: {
  coins: Coin[];
  positions: Position[];
  equity: number;
  unrealized: number;
  hist: number[];
  cash: number;
  hidden: boolean;
  pro: boolean;
  onToggleHidden: () => void;
  onTogglePro: () => void;
  onOpen: (p: { sym: string; side: Side; lev: number; margin: number }) => void;
  onClose: (id: number) => void;
}) {
  const [q, setQ] = useState("");
  const [trade, setTrade] = useState<string | null>(null);
  const [side, setSide] = useState<Side>("long");
  const [lev, setLev] = useState(5);
  const [margin, setMargin] = useState(500);
  const list = coins.filter((c) => (c.sym + c.name).toLowerCase().includes(q.toLowerCase()));
  const upCount = coins.filter((c) => changeOf(c) >= 0).length;
  const consensus = Math.round((upCount / coins.length) * 100);
  const base = 10000;
  const pnlPct = ((equity - base) / base) * 100;
  const active = coins.find((c) => c.sym === trade);

  const rows = useMemo(() => positions.map((p) => {
    const coin = coins.find((c) => c.sym === p.sym);
    const price = coin?.price ?? p.entry;
    return { ...p, price, pnl: positionPnl(p, price) };
  }), [positions, coins]);

  return (
    <div>
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <div>
          <div className="latin text-[10px] tracking-[.18em] text-[#e4b84a]">DESK · PAPER</div>
          <h3 className="mt-1 text-[20px] font-black">میز کار</h3>
        </div>
        <button onClick={onTogglePro} className="inline-flex items-center gap-2 rounded-xl border px-3 py-2 text-[11px] font-extrabold" style={{ borderColor: pro ? "#e4b84a" : "rgba(255,255,255,.14)", color: pro ? "#e4b84a" : "rgba(255,255,255,.7)", background: pro ? "rgba(228,184,74,.1)" : "transparent" }}>
          <Settings2 size={14} /> حالت حرفه‌ای
        </button>
      </div>

      <div className="grid gap-4 lg:grid-cols-[1.15fr_.85fr]">
        <div className="space-y-4">
          <WalletCard equity={equity} pnl={pnlPct} hidden={hidden} onToggle={onToggleHidden} />
          <div className="rounded-2xl border border-white/10 bg-white/[.03] p-4">
            <div className="mb-2 flex items-center justify-between text-[11px]">
              <span className="dim">منحنی سرمایه</span>
              <span className="latin font-bold" style={{ color: unrealized >= 0 ? "#3ddc97" : "#ff8b92" }}>{fmtMoney(unrealized, 0)} شناور</span>
            </div>
            <Area data={hist} color="#8ea2ff" height={150} />
            {pro && (
              <div className="mt-3 grid grid-cols-4 gap-2 border-t border-white/10 pt-3">
                {[[`$${Math.round(cash).toLocaleString("en-US")}`, "نقد آزاد"], [`${consensus}%`, "اجماع صعود"], ["1–50x", "اهرم"], ["20", "سقف پوزیشن"]].map(([v, l]) => (
                  <div key={l}><div className="latin text-[12px] font-bold">{v}</div><div className="faint mt-1 text-[9px]">{l}</div></div>
                ))}
              </div>
            )}
          </div>
        </div>

        <div className="rounded-2xl border border-white/10 bg-white/[.03] p-4">
          <div className="mb-2 flex items-center justify-between"><span className="text-[13px] font-extrabold">پوزیشن‌های باز</span><span className="latin text-[10px] faint">{rows.length}/20</span></div>
          <div className="space-y-2">
            {rows.map((p) => (
              <div key={p.id} className="flex items-center gap-3 rounded-xl border border-white/8 bg-black/20 px-3 py-2.5">
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <span dir="ltr" className="latin text-[12px] font-bold">{p.sym}</span>
                    <span className="rounded-md px-1.5 py-0.5 text-[9px] font-extrabold" style={{ color: p.side === "long" ? "#3ddc97" : "#ff8b92", background: p.side === "long" ? "rgba(61,220,151,.12)" : "rgba(255,139,146,.12)" }}>{p.side === "long" ? "LONG" : "SHORT"} · {p.lev}x</span>
                  </div>
                  <div className="faint mt-1 text-[9px]">{p.mirror ? `کپی از ${p.mirror}` : "دستی"} · ورود {fmtPrice(p.entry, p.dec)}</div>
                </div>
                <div className="text-left">
                  <div dir="ltr" className="latin text-[12px] font-bold" style={{ color: p.pnl >= 0 ? "#3ddc97" : "#ff8b92" }}>{p.pnl >= 0 ? "+" : ""}{p.pnl.toFixed(1)}</div>
                  <button onClick={() => onClose(p.id)} className="faint mt-1 text-[9px] underline-offset-2 hover:text-white">بستن</button>
                </div>
              </div>
            ))}
            {rows.length === 0 && <div className="dim py-8 text-center text-[12px]">پوزیشنی باز نیست. از بازار یکی بساز.</div>}
          </div>
          <div className="mt-3">
            <div className="mb-1 flex justify-between text-[9px] faint"><span>اجماع بازار</span><span className="latin">{consensus}% LONG</span></div>
            <div className="flex h-1.5 overflow-hidden rounded-full bg-white/10"><div style={{ width: `${consensus}%`, background: "#3ddc97" }} /><div className="flex-1" style={{ background: "#ff8b92" }} /></div>
          </div>
        </div>
      </div>

      <div className="mt-4 rounded-2xl border border-white/10 bg-white/[.03] p-4">
        <div className="mb-3 flex flex-wrap items-center justify-between gap-3">
          <div className="text-[13px] font-extrabold">بازار تحت نظر</div>
          <div className="relative w-full max-w-[220px]">
            <Search size={13} className="absolute right-3 top-1/2 -translate-y-1/2 text-white/40" />
            <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="جستجوی ارز" className="field pr-8" />
          </div>
        </div>
        <div className="grid gap-2 sm:grid-cols-2">
          {list.map((c) => {
            const ch = changeOf(c);
            return (
              <button key={c.sym} onClick={() => { setTrade(c.sym); setSide(ch >= 0 ? "long" : "short"); }} className="flex items-center gap-3 rounded-xl border border-white/8 px-3 py-2.5 text-right transition hover:border-white/25">
                <span className="latin grid h-8 w-8 place-items-center rounded-full text-[11px] font-bold" style={{ color: c.color, background: `${c.color}22` }}>{c.sym.slice(0, 1)}</span>
                <span className="min-w-0 flex-1">
                  <span dir="ltr" className="latin block text-left text-[12px] font-bold">{c.sym}</span>
                  <span className="faint block truncate text-[9px]">{c.name}</span>
                </span>
                <Spark data={c.spark} color={ch >= 0 ? "#3ddc97" : "#ff8b92"} width={54} />
                <span className="text-left">
                  <span dir="ltr" className="latin block text-[11px] font-semibold">${fmtPrice(c.price, c.dec)}</span>
                  <span dir="ltr" className="latin block text-[10px] font-bold" style={{ color: ch >= 0 ? "#3ddc97" : "#ff8b92" }}>{ch >= 0 ? "+" : ""}{ch.toFixed(2)}%</span>
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {trade && active && (
        <div className="fixed inset-0 z-[60] grid place-items-end bg-black/55 p-3 sm:place-items-center" onClick={() => setTrade(null)}>
          <div className="night w-full max-w-md rounded-3xl p-5" onClick={(e) => e.stopPropagation()}>
            <div className="mb-4 flex items-start justify-between">
              <div>
                <div className="latin text-[10px] text-[#e4b84a]">QUICK TRADE</div>
                <div dir="ltr" className="latin mt-1 text-[22px] font-bold">{active.sym}<span className="dim text-[12px]"> /USDT</span></div>
                <div dir="ltr" className="latin text-[12px] text-[#3ddc97]">${fmtPrice(active.price, active.dec)}</div>
              </div>
              <button onClick={() => setTrade(null)} className="grid h-8 w-8 place-items-center rounded-lg bg-white/5" aria-label="بستن"><X size={16} /></button>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <button onClick={() => setSide("long")} className="flex h-11 items-center justify-center gap-1 rounded-xl text-[12px] font-extrabold" style={{ background: side === "long" ? "rgba(61,220,151,.16)" : "rgba(255,255,255,.04)", color: side === "long" ? "#3ddc97" : "rgba(255,255,255,.55)" }}><ArrowUpRight size={15} /> خرید</button>
              <button onClick={() => setSide("short")} className="flex h-11 items-center justify-center gap-1 rounded-xl text-[12px] font-extrabold" style={{ background: side === "short" ? "rgba(255,139,146,.16)" : "rgba(255,255,255,.04)", color: side === "short" ? "#ff8b92" : "rgba(255,255,255,.55)" }}><ArrowDownLeft size={15} /> فروش</button>
            </div>
            <div className="mt-4">
              <div className="mb-1 flex justify-between text-[11px]"><span className="dim">اهرم</span><span className="latin font-bold text-[#e4b84a]">{lev}x</span></div>
              <input dir="ltr" type="range" min={1} max={50} value={lev} onChange={(e) => setLev(+e.target.value)} />
            </div>
            <div className="mt-3 flex gap-1.5">
              {[200, 500, 1000, 2000].map((n) => (
                <button key={n} onClick={() => setMargin(n)} className="latin flex-1 rounded-lg border py-2 text-[10px] font-bold" style={{ borderColor: margin === n ? "#dff25a" : "rgba(255,255,255,.12)", color: margin === n ? "#dff25a" : "rgba(255,255,255,.65)" }}>{n}</button>
              ))}
            </div>
            <div className="dim mt-3 flex justify-between text-[10px]"><span>نقد آزاد</span><span className="latin">{fmtMoney(cash, 0)}</span></div>
            <div className="dim flex justify-between text-[10px]"><span>اندازه موقعیت</span><span className="latin">{fmtMoney(margin * lev, 0)}</span></div>
            <button
              onClick={() => { onOpen({ sym: active.sym, side, lev, margin }); setTrade(null); }}
              className="btn mt-4 w-full !border-[#14160f] !bg-[#dff25a] !text-[#14160f]"
            >تأیید معامله دمو</button>
          </div>
        </div>
      )}
    </div>
  );
}
