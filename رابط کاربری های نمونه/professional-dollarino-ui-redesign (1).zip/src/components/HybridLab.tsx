import { useEffect, useMemo, useRef, useState, type CSSProperties } from 'react';
import { Check, Copy, Cpu, Play, Radio, RotateCcw, SlidersHorizontal, Sparkles, Zap } from 'lucide-react';
import { AreaChart, GaugeRing } from './Viz';

type EngineId = 'ai' | 'dorna' | 'copy';
type Scope = 'ALL' | 'TOP' | 'SINGLE';

const ENGINES: { id: EngineId; code: string; name: string; sub: string; color: string; icon: typeof Cpu; w: [number, number, number, number] }[] = [
  { id: 'ai', code: 'AI', name: 'هوش مصنوعی دُرّبین', sub: 'تحلیل چندمدلی', color: '#d9f75c', icon: Sparkles, w: [9, 7, 8, 6] },
  { id: 'dorna', code: 'DRN', name: 'استراتژی دُرنا V1', sub: 'روند و مومنتوم', color: '#7e95ff', icon: Zap, w: [8, 9, 7, 9] },
  { id: 'copy', code: 'CPY', name: 'کپی ترید', sub: 'سیگنال لحظه‌ای', color: '#ff9c7a', icon: Radio, w: [6, 10, 9, 5] },
];

const PRESETS: { name: string; engines: EngineId[]; risk: number; leverage: number; scope: Scope }[] = [
  { name: 'محافظهکار', engines: ['dorna'], risk: 3, leverage: 3, scope: 'TOP' },
  { name: 'متعادل', engines: ['ai', 'dorna'], risk: 6, leverage: 10, scope: 'ALL' },
  { name: 'تهاجمی', engines: ['ai', 'dorna', 'copy'], risk: 9, leverage: 25, scope: 'ALL' },
];

const clamp = (v: number, a: number, b: number) => Math.min(b, Math.max(a, v));

export default function HybridLab() {
  const [active, setActive] = useState<EngineId[]>(['ai', 'dorna']);
  const [risk, setRisk] = useState(6);
  const [leverage, setLeverage] = useState(10);
  const [scope, setScope] = useState<Scope>('ALL');
  const [capital, setCapital] = useState(10000);
  const [phase, setPhase] = useState<'idle' | 'running' | 'done'>('idle');
  const [progress, setProgress] = useState(0);
  const [toast, setToast] = useState('');
  const timer = useRef<number | null>(null);

  useEffect(() => () => { if (timer.current) window.clearInterval(timer.current); }, []);
  useEffect(() => { if (!toast) return; const t = window.setTimeout(() => setToast(''), 2600); return () => window.clearTimeout(t); }, [toast]);

  const model = useMemo(() => {
    const n = active.length || 1;
    const axes = [0, 1, 2, 3].map((i) => clamp(Math.round((ENGINES.filter((e) => active.includes(e.id)).reduce((s, e) => s + e.w[i], 0) / n) * 9.1 + (n - 1) * 2.4 - (i === 3 ? (risk - 5) * 1.4 : 0)), 35, 99));
    const coverage = scope === 'ALL' ? 30 : scope === 'TOP' ? 10 : 1;
    const winRate = clamp(Math.round(60 + n * 4 + axes[0] * 0.16 - (risk - 5) * 1.3 - leverage * 0.12), 42, 96);
    const monthly = clamp((winRate - 50) * 0.34 * (risk / 6) + n * 0.75, 1.5, 26);
    const profit = Math.round(capital * monthly / 100);
    const trades = scope === 'SINGLE' ? 8 : Math.round(coverage * (2.2 + risk * 0.18));
    const score = Math.round((axes[0] + axes[1] + axes[2] + axes[3]) / 4);
    const code = `DLR/${active.map((a) => a.toUpperCase()).sort().join('+') || 'NONE'} · ${scope} · L${leverage} · R${risk}`;
    const seed = risk * 3.1 + leverage * 0.7 + n * 5 + coverage;
    const curve = Array.from({ length: 30 }, (_, i) => {
      const wave = Math.sin(i * 0.85 + seed) * (risk * 0.8) + Math.cos(i * 0.37 + seed * 0.4) * 1.6;
      return 100 + (monthly / 30) * i * 3.2 + wave + (i / 30) * monthly;
    });
    const bars = Array.from({ length: 26 }, (_, i) => 25 + Math.abs(Math.sin(i * 0.62 + seed) * 55) + (i / 26) * 30);
    return { axes, coverage, winRate, monthly, profit, trades, score, code, curve, bars };
  }, [active, risk, leverage, scope, capital]);

  const toggle = (id: EngineId) => {
    setActive((prev) => prev.includes(id) ? (prev.length === 1 ? prev : prev.filter((x) => x !== id)) : [...prev, id]);
    setPhase('idle'); setProgress(0);
  };

  const applyPreset = (p: typeof PRESETS[number]) => {
    setActive(p.engines); setRisk(p.risk); setLeverage(p.leverage); setScope(p.scope);
    setPhase('idle'); setProgress(0);
    setToast(`پیشتنظیم «${p.name}» اعمال شد`);
  };

  const run = () => {
    if (phase === 'running') return;
    setPhase('running'); setProgress(0);
    let p = 0;
    if (timer.current) window.clearInterval(timer.current);
    timer.current = window.setInterval(() => {
      p += 7;
      setProgress(Math.min(100, p));
      if (p >= 100) { if (timer.current) window.clearInterval(timer.current); setPhase('done'); setToast('شبیهسازی ۳۰ روزه کامل شد'); }
    }, 65);
  };

  const copyCode = async () => {
    try { await navigator.clipboard.writeText(model.code); setToast('شناسه مدل کپی شد'); }
    catch { setToast(model.code); }
  };

  const chartColor = active.includes('ai') ? '#d9f75c' : '#7e95ff';

  return (
    <div className="console shadow-[0_30px_90px_rgba(0,0,0,.28)]" id="lab">
      <div className="absolute inset-0 console-grid pointer-events-none" />
      <div className="relative">
        {/* console top bar */}
        <div className="flex flex-wrap items-center justify-between gap-3 px-5 md:px-8 py-4 border-b c-line">
          <div className="flex items-center gap-3">
            <div dir="ltr" className="flex gap-1.5"><i className="w-2.5 h-2.5 rounded-full bg-[#ff6242]" /><i className="w-2.5 h-2.5 rounded-full bg-[#d9f75c]" /><i className="w-2.5 h-2.5 rounded-full bg-[#7e95ff]" /></div>
            <span dir="ltr" className="latin text-[10px] tracking-[.2em] font-bold c-muted">HYBRID ENGINE LAB / V6.0</span>
          </div>
          <div className="flex items-center gap-2 text-[10px]"><span className="w-1.5 h-1.5 rounded-full bg-[#d9f75c] blink" /><span className="c-muted">محاسبه زنده</span></div>
        </div>

        <div className="p-5 md:p-8">
          <div className="flex flex-wrap items-end justify-between gap-4 mb-7">
            <div>
              <div className="latin text-[10px] tracking-[.2em] text-[#d9f75c] mb-2">BUILD YOUR OWN MODEL</div>
              <h3 className="text-[22px] md:text-[30px] font-extrabold text-white leading-tight">موتورها را ترکیب کن. نتیجه را ببین.</h3>
              <p className="c-muted text-[11.5px] mt-2 max-w-md leading-7">هر ترکیب، شخصیت معاملاتی متفاوتی میسازد. پارامترها را تغییر بده — همهچیز همان لحظه محاسبه می‌شود.</p>
            </div>
            <div className="flex flex-wrap gap-2">
              {PRESETS.map((p) => (
                <button key={p.name} onClick={() => applyPreset(p)} className="latin px-3 py-2 rounded-lg text-[10px] font-bold border border-white/15 c-muted hover:border-[#d9f75c] hover:text-[#d9f75c] transition">{p.name}</button>
              ))}
            </div>
          </div>

          <div className="grid lg:grid-cols-2 gap-5">
            {/* CONTROLS */}
            <div className="rounded-2xl c-surface border c-line p-4 md:p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2 text-[12px] font-bold text-white"><SlidersHorizontal size={15} color="#d9f75c" /> ۰۱ · انتخاب موتورها</div>
                <span className="latin text-[10px] c-muted">{active.length}/3 ACTIVE</span>
              </div>
              <div className="space-y-2.5">
                {ENGINES.map((e) => {
                  const Icon = e.icon;
                  const on = active.includes(e.id);
                  return (
                    <button key={e.id} onClick={() => toggle(e.id)} className={`engine-chip w-full flex items-center gap-3 text-right p-3 rounded-xl ${on ? 'on' : ''}`} style={{ ['--chip' as string]: e.color } as CSSProperties}>
                      <span className="latin w-10 h-10 rounded-lg flex items-center justify-center text-[10px] font-bold shrink-0" style={{ background: on ? e.color : 'rgba(255,255,255,.08)', color: on ? '#101318' : 'rgba(255,255,255,.5)' }}>{e.code}</span>
                      <span className="flex-1 min-w-0">
                        <span className="block text-[12px] font-bold text-white">{e.name}</span>
                        <span className="block text-[10px] c-muted mt-0.5">{e.sub}</span>
                      </span>
                      <Icon size={16} color={on ? e.color : 'rgba(255,255,255,.35)'} />
                      <span className="w-8 h-[18px] rounded-full flex items-center px-[3px] shrink-0 transition" style={{ background: on ? e.color : 'rgba(255,255,255,.15)' }}>
                        <span className="w-3 h-3 rounded-full bg-[#101318] transition-transform" style={{ transform: on ? 'translateX(-14px)' : 'none' }} />
                      </span>
                    </button>
                  );
                })}
              </div>

              <div className="divider c-line my-5" />
              <div className="text-[12px] font-bold text-white mb-3">۰۲ · دامنه بازار</div>
              <div className="grid grid-cols-3 gap-2">
                {([['ALL', 'همه ارزها', '30+'], ['TOP', 'برترها', '10'], ['SINGLE', 'تک ارز', '01']] as [Scope, string, string][]).map(([id, label, count]) => (
                  <button key={id} onClick={() => { setScope(id); setPhase('idle'); }} className="rounded-xl border p-2.5 text-center transition" style={{ borderColor: scope === id ? '#d9f75c' : 'rgba(255,255,255,.13)', background: scope === id ? 'rgba(217,247,92,.1)' : 'rgba(255,255,255,.03)' }}>
                    <div dir="ltr" className="latin text-[11px] font-bold" style={{ color: scope === id ? '#d9f75c' : 'rgba(255,255,255,.65)' }}>{id}</div>
                    <div className="text-[9px] c-muted mt-1">{label}</div>
                    <div dir="ltr" className="latin text-[9px] mt-1 text-white">{count}</div>
                  </button>
                ))}
              </div>

              <div className="divider c-line my-5" />
              <div className="space-y-5">
                <div>
                  <div className="flex items-center justify-between mb-2"><span className="text-[11px] c-muted">سطح ریسک</span><span dir="ltr" className="latin text-[13px] font-bold" style={{ color: risk > 7 ? '#ff8a6b' : '#d9f75c' }}>{risk} / 10</span></div>
                  <div dir="ltr"><input type="range" min="1" max="10" value={risk} onChange={(e) => { setRisk(+e.target.value); setPhase('idle'); }} /></div>
                  <div dir="rtl" className="flex justify-between text-[9px] c-muted mt-1.5"><span>محافظهکار</span><span>تهاجمی</span></div>
                </div>
                <div>
                  <div className="flex items-center justify-between mb-2"><span className="text-[11px] c-muted">اهرم معاملاتی</span><span dir="ltr" className="latin text-[13px] font-bold text-[#7e95ff]">{leverage}x</span></div>
                  <div dir="ltr"><input type="range" min="1" max="50" value={leverage} onChange={(e) => { setLeverage(+e.target.value); setPhase('idle'); }} /></div>
                  <div dir="rtl" className="flex justify-between text-[9px] c-muted mt-1.5"><span>1x</span><span>50x</span></div>
                </div>
              </div>

              <div className="divider c-line my-5" />
              <div className="flex flex-wrap items-center justify-between gap-3">
                <span className="text-[11px] c-muted">سرمایه شبیهسازی</span>
                <div className="flex gap-1.5">
                  {[1000, 5000, 10000, 50000].map((c) => (
                    <button key={c} onClick={() => { setCapital(c); setPhase('idle'); }} dir="ltr" className="latin px-2.5 py-1.5 rounded-lg text-[10px] font-bold border transition" style={{ borderColor: capital === c ? '#7e95ff' : 'rgba(255,255,255,.13)', color: capital === c ? '#7e95ff' : 'rgba(255,255,255,.55)', background: capital === c ? 'rgba(126,149,255,.12)' : 'transparent' }}>{c >= 1000 ? `${c / 1000}k` : c}</button>
                  ))}
                </div>
              </div>
            </div>

            {/* LIVE OUTPUT */}
            <div className="rounded-2xl c-surface border c-line p-4 md:p-6 flex flex-col">
              <div className="flex items-center justify-between mb-5">
                <div className="flex items-center gap-2 text-[12px] font-bold text-white"><Cpu size={15} color="#7e95ff" /> ۰۳ · خروجی زنده مدل</div>
                <span className="latin text-[9px] c-muted">REAL-TIME</span>
              </div>

              <div className="flex items-center gap-5 pb-5 border-b c-line">
                <GaugeRing value={model.score} color={chartColor} />
                <div className="flex-1 min-w-0">
                  <div className="latin text-[9px] tracking-[.18em] c-muted mb-1">MODEL ID</div>
                  <div dir="ltr" className="latin text-[11px] font-bold text-white break-all leading-5">{model.code}</div>
                  <button onClick={copyCode} className="mt-2 inline-flex items-center gap-1.5 text-[10px] c-muted hover:text-[#d9f75c] transition"><Copy size={11} /> کپی شناسه</button>
                </div>
              </div>

              <div className="space-y-3 py-5 border-b c-line">
                {[['دقت تحلیل', model.axes[0], '#d9f75c'], ['سرعت اجرا', model.axes[1], '#7e95ff'], ['پوشش بازار', model.axes[2], '#ff9c7a'], ['کنترل ریسک', model.axes[3], '#ffffff']].map(([label, val, color]) => (
                  <div key={label as string}>
                    <div className="flex justify-between text-[10px] mb-1.5"><span className="c-muted">{label as string}</span><span dir="ltr" className="latin font-bold text-white">{val as number}%</span></div>
                    <div className="h-[5px] rounded-full bg-white/10 overflow-hidden">
                      <div className="h-full rounded-full transition-all duration-500" style={{ width: `${val as number}%`, background: color as string }} />
                    </div>
                  </div>
                ))}
              </div>

              <div className="grid grid-cols-3 gap-2 py-5 border-b c-line">
                {[
                  ['نرخ موفقیت', `${model.winRate}%`, '#d9f75c'],
                  ['بازده ۳۰ روزه', `+${model.monthly.toFixed(1)}%`, '#d9f75c'],
                  ['معاملات پیشبینی', String(model.trades), '#ffffff'],
                ].map(([l, v, c]) => (
                  <div key={l}>
                    <div className="text-[9px] c-muted mb-1.5">{l}</div>
                    <div dir="ltr" className="latin text-[14px] md:text-[17px] font-bold" style={{ color: c }}>{v}</div>
                  </div>
                ))}
              </div>

              <div className="pt-5 flex-1">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[10px] c-muted">پیشبینی رشد سرمایه · ۳۰ روز</span>
                  <span dir="ltr" className="latin text-[12px] font-bold" style={{ color: chartColor }}>+${model.profit.toLocaleString('en-US')}</span>
                </div>
                <div className="-mx-2"><AreaChart data={model.curve} color={chartColor} height={110} /></div>
                <div dir="ltr" className="latin flex justify-between text-[9px] c-muted mt-1"><span>DAY 01</span><span>DAY 30</span></div>
              </div>
            </div>
          </div>

          {/* run bar */}
          <div className="mt-5 rounded-2xl border c-line c-surface p-4 md:p-5 flex flex-col md:flex-row items-stretch md:items-center gap-4">
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between gap-3 mb-2">
                <span className="text-[11px] font-bold text-white flex items-center gap-2">
                  {phase === 'done' ? <Check size={14} color="#d9f75c" /> : <Play size={13} color="#d9f75c" />}
                  {phase === 'running' ? 'در حال پردازش بازارها...' : phase === 'done' ? 'شبیهسازی کامل شد' : 'آماده اجرای شبیهسازی'}
                </span>
                <span dir="ltr" className="latin text-[10px] c-muted">{phase === 'idle' ? 'READY' : `${Math.round(progress)}%`}</span>
              </div>
              <div className="h-1.5 rounded-full bg-white/10 overflow-hidden">
                <div className="h-full rounded-full transition-all duration-100" style={{ width: `${phase === 'idle' ? 0 : progress}%`, background: 'linear-gradient(90deg,#7e95ff,#d9f75c)' }} />
              </div>
              {phase === 'done' && (
                <div className="text-[10px] c-muted mt-2">نتیجه: {model.trades} معامله · {model.winRate}% موفق · سود تخمینی <span dir="ltr" className="latin font-bold" style={{ color: chartColor }}>+${model.profit.toLocaleString('en-US')}</span></div>
              )}
            </div>
            <div className="flex gap-2 shrink-0">
              <button onClick={() => { setPhase('idle'); setProgress(0); }} className="btn !px-3.5 !py-3 !text-[11px] !border-white/20 !text-white/70 !bg-white/5 hover:!text-white"><RotateCcw size={14} /></button>
              <button onClick={run} className="btn !bg-[#d9f75c] !text-[#101318] !border-[#d9f75c] !px-6 !shadow-none hover:!shadow-none" style={{ boxShadow: '3px 3px 0 rgba(255,255,255,.25)' }}>
                <Play size={15} fill="currentColor" /> اجرای مدل ترکیبی
              </button>
            </div>
          </div>
          <div className="mt-4 text-[9px] c-muted leading-6">* تمام اعداد نمایشی، خروجی شبیهساز تعاملی هستند و توصیه سرمایهگذاری محسوب نمی‌شوند.</div>
        </div>
      </div>
      {toast && <div className="absolute bottom-4 left-1/2 -translate-x-1/2 z-20 bg-[#d9f75c] text-[#101318] text-[11px] font-bold px-4 py-2.5 rounded-xl shadow-xl whitespace-nowrap">{toast}</div>}
    </div>
  );
}
