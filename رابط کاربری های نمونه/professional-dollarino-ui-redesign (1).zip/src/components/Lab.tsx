import { useEffect, useMemo, useState } from "react";
import { Check, Copy, Play, Radio, RotateCcw, SlidersHorizontal, Sparkles, Zap } from "lucide-react";
import { Area, Gauge } from "./Viz";

export type LabEngine = "ai" | "strategy" | "copy";
export type Scope = "ALL" | "TOP" | "SINGLE";
export type LabPreset = { engines: LabEngine[]; risk: number; leverage: number; scope: Scope };

const META: { id: LabEngine; code: string; name: string; sub: string; color: string; icon: typeof Sparkles; w: number[] }[] = [
  { id: "ai", code: "AI", name: "دُرّبین", sub: "DeepSeek · Claude · GPT · Gemini", color: "#e4b84a", icon: Sparkles, w: [9, 7, 8, 6] },
  { id: "strategy", code: "DRN", name: "دُرنا V1", sub: "روند، مومنتوم، ریبون غیرریپینت", color: "#3ddc97", icon: Zap, w: [8, 8, 7, 9] },
  { id: "copy", code: "CPY", name: "کپی ترید", sub: "کانال رسمی + TradingView", color: "#8ea2ff", icon: Radio, w: [6, 10, 9, 5] },
];

export const LAB_PRESETS: Record<string, LabPreset> = {
  calm: { engines: ["strategy"], risk: 3, leverage: 3, scope: "TOP" },
  blend: { engines: ["ai", "strategy"], risk: 6, leverage: 10, scope: "ALL" },
  mirror: { engines: ["copy", "ai"], risk: 5, leverage: 8, scope: "TOP" },
  full: { engines: ["ai", "strategy", "copy"], risk: 8, leverage: 20, scope: "ALL" },
};

const clamp = (v: number, a: number, b: number) => Math.min(b, Math.max(a, v));

export default function Lab({ seed, nonce }: { seed?: LabPreset; nonce?: number }) {
  const [active, setActive] = useState<LabEngine[]>(seed?.engines ?? ["ai", "strategy"]);
  const [risk, setRisk] = useState(seed?.risk ?? 6);
  const [leverage, setLeverage] = useState(seed?.leverage ?? 10);
  const [scope, setScope] = useState<Scope>(seed?.scope ?? "ALL");
  const [capital, setCapital] = useState(10000);
  const [phase, setPhase] = useState<"idle" | "run" | "done">("idle");
  const [progress, setProgress] = useState(0);
  const [note, setNote] = useState("");

  useEffect(() => {
    if (!seed || !nonce) return;
    setActive(seed.engines);
    setRisk(seed.risk);
    setLeverage(seed.leverage);
    setScope(seed.scope);
    setPhase("idle");
    setProgress(0);
    setNote("پیش‌تنظیم روی آزمایشگاه نشست");
  }, [nonce]);

  useEffect(() => {
    if (phase !== "run") return;
    const id = window.setInterval(() => {
      setProgress((p) => {
        if (p >= 100) {
          window.clearInterval(id);
          setPhase("done");
          setNote("شبیه‌سازی ۳۰ روزه تمام شد");
          return 100;
        }
        return p + 8;
      });
    }, 70);
    return () => window.clearInterval(id);
  }, [phase]);

  useEffect(() => {
    if (!note) return;
    const t = window.setTimeout(() => setNote(""), 2400);
    return () => window.clearTimeout(t);
  }, [note]);

  const model = useMemo(() => {
    const picked = META.filter((e) => active.includes(e.id));
    const n = picked.length || 1;
    const axes = [0, 1, 2, 3].map((i) =>
      clamp(Math.round(picked.reduce((s, e) => s + e.w[i], 0) / n * 9 + (n - 1) * 3 - (i === 3 ? (risk - 5) * 1.5 : 0)), 38, 98),
    );
    const coverage = scope === "ALL" ? 30 : scope === "TOP" ? 10 : 1;
    const win = clamp(Math.round(61 + n * 4.2 + axes[0] * 0.12 - (risk - 5) * 1.2 - leverage * 0.1), 46, 94);
    const monthly = clamp((win - 50) * 0.32 * (risk / 6) + n * 0.7, 1.4, 24);
    const profit = Math.round((capital * monthly) / 100);
    const trades = Math.round(coverage * (1.6 + risk * 0.22));
    const score = Math.round(axes.reduce((s, v) => s + v, 0) / 4);
    const curve = Array.from({ length: 32 }, (_, i) => 100 + (monthly / 30) * i * 3 + Math.sin(i * 0.7 + risk) * risk * 0.45);
    const code = `DLR/${[...active].sort().join("+").toUpperCase()}·${scope}·L${leverage}·R${risk}`;
    return { axes, win, monthly, profit, trades, score, curve, code, coverage };
  }, [active, risk, leverage, scope, capital]);

  const toggle = (id: LabEngine) => {
    setActive((prev) => (prev.includes(id) ? (prev.length === 1 ? prev : prev.filter((x) => x !== id)) : [...prev, id]));
    setPhase("idle");
    setProgress(0);
  };

  const color = active.includes("ai") ? "#e4b84a" : active.includes("strategy") ? "#3ddc97" : "#8ea2ff";

  return (
    <div className="relative">
      <div className="grid gap-4 lg:grid-cols-2">
        <div className="rounded-2xl border border-white/10 bg-white/[.03] p-4 md:p-5">
          <div className="mb-4 flex items-center justify-between">
            <div className="flex items-center gap-2 text-[12px] font-extrabold"><SlidersHorizontal size={15} color="#dff25a" /> ترکیب موتورها</div>
            <span className="latin text-[10px] faint">{active.length}/3</span>
          </div>
          <div className="space-y-2">
            {META.map((e) => {
              const on = active.includes(e.id);
              const Icon = e.icon;
              return (
                <button key={e.id} onClick={() => toggle(e.id)} className="flex w-full items-center gap-3 rounded-xl border p-3 text-right transition" style={{ borderColor: on ? e.color : "rgba(255,255,255,.1)", background: on ? `${e.color}18` : "transparent" }}>
                  <span className="latin grid h-10 w-10 shrink-0 place-items-center rounded-lg text-[10px] font-bold" style={{ background: on ? e.color : "rgba(255,255,255,.06)", color: on ? "#12141a" : "rgba(255,255,255,.7)" }}>{e.code}</span>
                  <span className="min-w-0 flex-1">
                    <span className="block text-[13px] font-extrabold">{e.name}</span>
                    <span className="dim mt-0.5 block text-[10px]">{e.sub}</span>
                  </span>
                  <Icon size={16} color={on ? e.color : "rgba(255,255,255,.35)"} />
                </button>
              );
            })}
          </div>

          <div className="my-5 h-px bg-white/10" />
          <div className="mb-2 text-[12px] font-extrabold">دامنه بازار</div>
          <div className="grid grid-cols-3 gap-2">
            {(["ALL", "TOP", "SINGLE"] as Scope[]).map((id) => (
              <button key={id} onClick={() => { setScope(id); setPhase("idle"); }} className="rounded-xl border px-2 py-3 text-center" style={{ borderColor: scope === id ? "#dff25a" : "rgba(255,255,255,.1)", background: scope === id ? "rgba(223,242,90,.1)" : "transparent" }}>
                <div className="latin text-[11px] font-bold" style={{ color: scope === id ? "#dff25a" : "white" }}>{id}</div>
                <div className="faint mt-1 text-[9px]">{id === "ALL" ? "۳۰+ ارز" : id === "TOP" ? "۱۰ برتر" : "تک‌ارز"}</div>
              </button>
            ))}
          </div>

          <div className="mt-5 space-y-4">
            <label className="block">
              <div className="mb-1.5 flex justify-between text-[11px]"><span className="dim">ریسک</span><span className="latin font-bold" style={{ color: risk > 7 ? "#ff8b92" : "#dff25a" }}>{risk}/10</span></div>
              <input dir="ltr" type="range" min={1} max={10} value={risk} onChange={(e) => { setRisk(+e.target.value); setPhase("idle"); }} />
            </label>
            <label className="block">
              <div className="mb-1.5 flex justify-between text-[11px]"><span className="dim">اهرم</span><span className="latin font-bold text-[#8ea2ff]">{leverage}x</span></div>
              <input dir="ltr" type="range" min={1} max={50} value={leverage} onChange={(e) => { setLeverage(+e.target.value); setPhase("idle"); }} />
            </label>
          </div>
          <div className="mt-5 flex flex-wrap gap-1.5">
            {[1000, 5000, 10000, 25000].map((c) => (
              <button key={c} onClick={() => setCapital(c)} className="latin rounded-lg border px-2.5 py-1.5 text-[10px] font-bold" style={{ borderColor: capital === c ? "#e4b84a" : "rgba(255,255,255,.12)", color: capital === c ? "#e4b84a" : "rgba(255,255,255,.6)" }}>${c / 1000}k</button>
            ))}
          </div>
        </div>

        <div className="flex flex-col rounded-2xl border border-white/10 bg-white/[.03] p-4 md:p-5">
          <div className="mb-4 flex items-center gap-4">
            <Gauge value={model.score} color={color} />
            <div className="min-w-0">
              <div className="latin text-[9px] tracking-[.18em] faint">MODEL ID</div>
              <div dir="ltr" className="latin mt-1 break-all text-left text-[12px] font-bold">{model.code}</div>
              <button onClick={() => { navigator.clipboard?.writeText(model.code); setNote("شناسه مدل کپی شد"); }} className="dim mt-2 inline-flex items-center gap-1 text-[10px] hover:text-[#dff25a]"><Copy size={12} /> کپی شناسه</button>
            </div>
          </div>
          <div className="space-y-2.5 border-y border-white/10 py-4">
            {[["دقت", model.axes[0], "#e4b84a"], ["سرعت", model.axes[1], "#8ea2ff"], ["پوشش", model.axes[2], "#3ddc97"], ["کنترل ریسک", model.axes[3], "#f6f3ea"]].map(([l, v, c]) => (
              <div key={l as string}>
                <div className="mb-1 flex justify-between text-[10px]"><span className="dim">{l as string}</span><span className="latin">{v as number}</span></div>
                <div className="h-1.5 overflow-hidden rounded-full bg-white/10"><div className="h-full rounded-full transition-all" style={{ width: `${v as number}%`, background: c as string }} /></div>
              </div>
            ))}
          </div>
          <div className="grid grid-cols-3 gap-2 py-4">
            {[[`${model.win}%`, "نرخ برد"], [`+${model.monthly.toFixed(1)}%`, "بازده ۳۰روز"], [String(model.trades), "معامله"]].map(([v, l]) => (
              <div key={l}><div className="latin text-[16px] font-bold" style={{ color }}>{v}</div><div className="faint mt-1 text-[9px]">{l}</div></div>
            ))}
          </div>
          <div className="mt-auto">
            <div className="mb-1 flex justify-between text-[10px]"><span className="dim">رشد سرمایه</span><span className="latin font-bold" style={{ color }}>+${model.profit.toLocaleString("en-US")}</span></div>
            <Area data={model.curve} color={color} height={96} />
          </div>
        </div>
      </div>

      <div className="mt-4 flex flex-col gap-3 rounded-2xl border border-white/10 bg-white/[.03] p-4 md:flex-row md:items-center">
        <div className="min-w-0 flex-1">
          <div className="mb-2 flex justify-between text-[11px]">
            <span className="font-bold">{phase === "done" ? "شبیه‌سازی آماده است" : phase === "run" ? "در حال خواندن بازار..." : "مدل ترکیبی آماده اجراست"}</span>
            <span className="latin faint">{phase === "idle" ? "READY" : `${Math.min(100, progress)}%`}</span>
          </div>
          <div className="h-1.5 overflow-hidden rounded-full bg-white/10">
            <div className="h-full rounded-full" style={{ width: `${phase === "idle" ? 0 : Math.min(100, progress)}%`, background: "linear-gradient(90deg,#8ea2ff,#e4b84a,#dff25a)" }} />
          </div>
          {phase === "done" && <div className="dim mt-2 text-[10px]">{model.trades} معامله · برد {model.win}% · سود تخمینی <b className="latin" style={{ color }}>+${model.profit.toLocaleString("en-US")}</b></div>}
        </div>
        <div className="flex gap-2">
          <button onClick={() => { setPhase("idle"); setProgress(0); }} className="btn !border-white/15 !bg-white/5 !text-white/70"><RotateCcw size={14} /></button>
          <button onClick={() => { setProgress(0); setPhase("run"); }} className="btn !border-[#14160f] !bg-[#dff25a] !text-[#14160f]"><Play size={14} fill="currentColor" /> اجرای مدل</button>
        </div>
      </div>
      <p className="faint mt-3 text-[9px] leading-5">اعداد خروجی شبیه‌ساز تعاملی هستند و توصیه سرمایه‌گذاری نیستند. پوشش فعلی: {model.coverage} بازار.</p>
      {note && <div className="absolute bottom-8 left-1/2 z-10 -translate-x-1/2 rounded-xl bg-[#dff25a] px-4 py-2 text-[11px] font-extrabold text-[#14160f]"><Check size={12} className="ml-1 inline" />{note}</div>}
    </div>
  );
}
