import { ENGINE_META, fmtPrice, timeAgo, type Engine, type Signal } from "../lib/market";

export default function Radar({ signals, now, filter, onFilter }: { signals: Signal[]; now: number; filter: Engine | "all"; onFilter: (f: Engine | "all") => void }) {
  const shown = signals.filter((s) => filter === "all" || s.engine === filter);
  const closed = signals.filter((s) => s.status !== "active");
  const wins = closed.filter((s) => s.status === "tp").length;
  const rate = closed.length ? Math.round((wins / closed.length) * 100) : 0;
  const active = signals.filter((s) => s.status === "active");

  return (
    <div>
      <div className="mb-4 flex flex-wrap items-end justify-between gap-3">
        <div>
          <div className="latin text-[10px] tracking-[.18em] text-[#3ddc97]">RADAR · LIVE</div>
          <h3 className="mt-1 text-[20px] font-black">رادار سیگنال</h3>
          <p className="dim mt-1 max-w-md text-[11px] leading-6">هر سه موتور اینجا شلیک می‌کنند. سیگنال فعال می‌ماند، بعد عمومی به هدف یا حد ضرر می‌رسد.</p>
        </div>
        <div className="grid grid-cols-3 gap-2">
          {[[String(signals.length), "کل"], [`${rate}%`, "برد بسته‌شده"], [String(active.length), "فعال"]].map(([v, l]) => (
            <div key={l} className="rounded-xl border border-white/10 px-3 py-2 text-center"><div className="latin text-[14px] font-bold">{v}</div><div className="faint text-[9px]">{l}</div></div>
          ))}
        </div>
      </div>
      <div className="mb-3 flex gap-1.5 overflow-x-auto">
        {(["all", "ai", "strategy", "copy"] as const).map((id) => (
          <button key={id} onClick={() => onFilter(id)} className="rounded-full border px-3 py-1.5 text-[10px] font-extrabold" style={{ borderColor: filter === id ? "#dff25a" : "rgba(255,255,255,.12)", color: filter === id ? "#14160f" : "rgba(255,255,255,.7)", background: filter === id ? "#dff25a" : "transparent" }}>
            {id === "all" ? "همه موتورها" : ENGINE_META[id].fa}
          </button>
        ))}
      </div>
      <div className="grid gap-2">
        {shown.slice(0, 8).map((s) => {
          const meta = ENGINE_META[s.engine];
          const life = Math.max(0.08, Math.min(1, (s.resolveAt - now) / Math.max(1, s.resolveAt - s.born)));
          const tone = s.status === "tp" ? "#3ddc97" : s.status === "sl" ? "#ff8b92" : meta.color;
          return (
            <article key={s.id} className="grid gap-3 rounded-2xl border border-white/10 bg-white/[.03] p-3 sm:grid-cols-[1fr_auto] sm:items-center">
              <div className="min-w-0">
                <div className="flex flex-wrap items-center gap-2">
                  <span dir="ltr" className="latin text-[13px] font-bold">{s.sym}/USDT</span>
                  <span className="rounded-md px-1.5 py-0.5 text-[9px] font-extrabold" style={{ color: s.side === "long" ? "#3ddc97" : "#ff8b92", background: "rgba(255,255,255,.04)" }}>{s.side.toUpperCase()}</span>
                  <span className="text-[10px] font-bold" style={{ color: meta.color }}>{meta.fa}</span>
                  <span className="faint text-[9px]">{timeAgo(s.born)}</span>
                </div>
                <div dir="ltr" className="latin faint mt-2 flex flex-wrap gap-3 text-left text-[10px]">
                  <span>ENTRY {fmtPrice(s.entry, s.dec)}</span>
                  <span style={{ color: "#3ddc97" }}>TP {fmtPrice(s.tp, s.dec)}</span>
                  <span style={{ color: "#ff8b92" }}>SL {fmtPrice(s.sl, s.dec)}</span>
                </div>
                {s.status === "active" ? (
                  <div className="mt-2 h-1 overflow-hidden rounded-full bg-white/10"><div className="h-full rounded-full" style={{ width: `${life * 100}%`, background: meta.color }} /></div>
                ) : (
                  <div className="mt-2 text-[10px] font-extrabold" style={{ color: tone }}>{s.status === "tp" ? "هدف خورد" : "حد ضرر"} · {s.pnl > 0 ? "+" : ""}{s.pnl.toFixed(2)}%</div>
                )}
              </div>
              <div className="text-left">
                <div className="latin text-[18px] font-bold" style={{ color: tone }}>{s.conf}</div>
                <div className="faint text-[9px]">اطمینان</div>
              </div>
            </article>
          );
        })}
      </div>
    </div>
  );
}
