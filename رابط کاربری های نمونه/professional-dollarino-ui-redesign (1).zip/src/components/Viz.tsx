import { useId } from 'react';

export function AreaChart({ data, color = '#d9f75c', height = 200, grid = true, className = '' }: { data: number[]; color?: string; height?: number; grid?: boolean; className?: string }) {
  const uid = useId().replace(/:/g, '');
  const w = 600, h = 200, pad = 10;
  const min = Math.min(...data), max = Math.max(...data), span = max - min || 1;
  const pts = data.map((v, i) => ({ x: pad + (i / (data.length - 1)) * (w - pad * 2), y: h - 14 - ((v - min) / span) * (h - 38) }));
  const line = pts.map((p, i) => `${i ? 'L' : 'M'} ${p.x.toFixed(1)} ${p.y.toFixed(1)}`).join(' ');
  const area = `${line} L ${pts[pts.length - 1].x} ${h} L ${pts[0].x} ${h} Z`;
  const last = pts[pts.length - 1];
  return (
    <svg viewBox={`0 0 ${w} ${h}`} preserveAspectRatio="none" className={className} style={{ width: '100%', height, display: 'block' }} aria-hidden="true">
      <defs>
        <linearGradient id={`g-${uid}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity=".32" />
          <stop offset="100%" stopColor={color} stopOpacity="0" />
        </linearGradient>
      </defs>
      {grid && [0, 1, 2, 3].map((i) => <line key={i} x1="0" x2={w} y1={25 + i * 48} y2={25 + i * 48} stroke="rgba(255,255,255,.1)" strokeDasharray="2 7" />)}
      <path d={area} fill={`url(#g-${uid})`} />
      <path d={line} fill="none" stroke={color} strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" className="draw" vectorEffect="non-scaling-stroke" />
      <line x1={last.x} x2={last.x} y1={last.y} y2={h} stroke={color} strokeDasharray="3 5" opacity=".45" />
      <circle cx={last.x} cy={last.y} r="4.5" fill={color} />
    </svg>
  );
}

export function BarColumns({ data, color = '#d9f75c', height = 130 }: { data: number[]; color?: string; height?: number }) {
  const max = Math.max(...data, 1);
  return (
    <div className="flex items-end gap-[3px]" style={{ height }} aria-hidden="true">
      {data.map((v, i) => (
        <div key={i} className="flex-1 rounded-t-[2px] origin-bottom" style={{ height: `${Math.max(6, (v / max) * 100)}%`, background: i > data.length - 6 ? color : 'rgba(255,255,255,.2)', animation: `grow .5s ${i * 18}ms both ease-out` }} />
      ))}
    </div>
  );
}

export function GaugeRing({ value, size = 116, color = '#d9f75c' }: { value: number; size?: number; color?: string }) {
  const r = 44, c = 2 * Math.PI * r;
  return (
    <svg width={size} height={size} viewBox="0 0 110 110" aria-hidden="true">
      <circle cx="55" cy="55" r={r} fill="none" stroke="rgba(255,255,255,.12)" strokeWidth="7" />
      <circle cx="55" cy="55" r={r} fill="none" stroke={color} strokeWidth="7" strokeLinecap="round"
        strokeDasharray={c} strokeDashoffset={c - (Math.min(100, Math.max(0, value)) / 100) * c}
        transform="rotate(-90 55 55)" style={{ transition: 'stroke-dashoffset .6s ease' }} />
      <text x="55" y="60" textAnchor="middle" fill="#f4f3ed" fontSize="21" fontWeight="700" fontFamily="Space Grotesk, sans-serif">{Math.round(value)}</text>
      <text x="55" y="74" textAnchor="middle" fill="rgba(244,243,237,.45)" fontSize="8" fontFamily="Vazirmatn, sans-serif">SCORE</text>
    </svg>
  );
}

export function Spark({ data, color = '#2d4bf4', width = 90 }: { data: number[]; color?: string; width?: number }) {
  const min = Math.min(...data), max = Math.max(...data), span = max - min || 1;
  const pts = data.map((v, i) => `${(i / (data.length - 1)) * 100},${28 - ((v - min) / span) * 24}`).join(' ');
  return (
    <svg viewBox="0 0 100 30" preserveAspectRatio="none" style={{ width, height: 30 }} aria-hidden="true">
      <polyline points={pts} fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" vectorEffect="non-scaling-stroke" />
    </svg>
  );
}
