export function Spark({ data, color = "#3ddc97", width = 72, height = 28 }: { data: number[]; color?: string; width?: number; height?: number }) {
  if (data.length < 2) return null;
  const min = Math.min(...data);
  const max = Math.max(...data);
  const span = max - min || 1;
  const pts = data.map((v, i) => `${(i / (data.length - 1)) * 100},${height - 2 - ((v - min) / span) * (height - 4)}`).join(" ");
  return (
    <svg viewBox={`0 0 100 ${height}`} width={width} height={height} preserveAspectRatio="none" aria-hidden="true">
      <polyline points={pts} fill="none" stroke={color} strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" vectorEffect="non-scaling-stroke" />
    </svg>
  );
}

export function Area({ data, color = "#dff25a", height = 180 }: { data: number[]; color?: string; height?: number }) {
  const w = 640;
  const h = 200;
  const min = Math.min(...data);
  const max = Math.max(...data);
  const span = max - min || 1;
  const pts = data.map((v, i) => ({
    x: (i / (data.length - 1)) * w,
    y: 16 + (1 - (v - min) / span) * (h - 36),
  }));
  const line = pts.map((p, i) => `${i ? "L" : "M"}${p.x.toFixed(1)} ${p.y.toFixed(1)}`).join(" ");
  const last = pts[pts.length - 1];
  return (
    <svg viewBox={`0 0 ${w} ${h}`} preserveAspectRatio="none" style={{ width: "100%", height, display: "block" }} aria-hidden="true">
      <defs>
        <linearGradient id="ag" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity="0.35" />
          <stop offset="100%" stopColor={color} stopOpacity="0" />
        </linearGradient>
      </defs>
      {[0, 1, 2, 3].map((i) => (
        <line key={i} x1="0" x2={w} y1={24 + i * 44} y2={24 + i * 44} stroke="rgba(255,255,255,.08)" strokeDasharray="3 7" />
      ))}
      <path d={`${line} L${w} ${h} L0 ${h} Z`} fill="url(#ag)" />
      <path d={line} fill="none" stroke={color} strokeWidth="2.6" strokeLinejoin="round" strokeLinecap="round" />
      <circle cx={last.x} cy={last.y} r="4.5" fill={color} />
    </svg>
  );
}

export function Gauge({ value, color = "#dff25a" }: { value: number; color?: string }) {
  const r = 42;
  const c = 2 * Math.PI * r;
  const v = Math.max(0, Math.min(100, value));
  return (
    <svg width="118" height="118" viewBox="0 0 118 118" aria-hidden="true">
      <circle cx="59" cy="59" r={r} fill="none" stroke="rgba(255,255,255,.1)" strokeWidth="8" />
      <circle cx="59" cy="59" r={r} fill="none" stroke={color} strokeWidth="8" strokeLinecap="round" strokeDasharray={c} strokeDashoffset={c - (v / 100) * c} transform="rotate(-90 59 59)" />
      <text x="59" y="56" textAnchor="middle" fill="#f6f3ea" fontSize="22" fontWeight="700" fontFamily="Space Grotesk, sans-serif">{Math.round(v)}</text>
      <text x="59" y="72" textAnchor="middle" fill="rgba(246,243,234,.45)" fontSize="8" fontFamily="Vazirmatn, sans-serif">امتیاز مدل</text>
    </svg>
  );
}
