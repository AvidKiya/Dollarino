import { Download } from "lucide-react";

export default function Weekly({ pct, profit, win, trades }: { pct: number; profit: number; win: number; trades: string }) {
  const download = () => {
    const canvas = document.createElement("canvas");
    canvas.width = 800;
    canvas.height = 1000;
    const x = canvas.getContext("2d");
    if (!x) return;
    const paint = (logo?: HTMLImageElement) => {
      const g = x.createLinearGradient(0, 0, 800, 1000);
      g.addColorStop(0, "#14206a");
      g.addColorStop(0.45, "#0d1430");
      g.addColorStop(1, "#10160f");
      x.fillStyle = g;
      x.fillRect(0, 0, 800, 1000);
      x.globalAlpha = 0.08;
      x.fillStyle = "#ffffff";
      x.font = "900 340px Space Grotesk, sans-serif";
      x.textAlign = "center";
      x.fillText("D", 400, 620);
      x.globalAlpha = 1;
      x.fillStyle = "#dff25a";
      x.fillRect(0, 0, 800, 14);
      if (logo) {
        x.save();
        x.beginPath();
        x.roundRect(56, 70, 108, 108, 26);
        x.clip();
        x.drawImage(logo, 56, 70, 108, 108);
        x.restore();
      }
      x.textAlign = "right";
      x.direction = "rtl";
      x.fillStyle = "#dff25a";
      x.font = "700 24px Vazirmatn, sans-serif";
      x.fillText("کارت هفتگی دلارینو", 740, 118);
      x.fillStyle = "rgba(255,255,255,.62)";
      x.font = "500 20px Vazirmatn, sans-serif";
      x.fillText("شیشه ۴:۵ · آماده اشتراک", 740, 156);
      x.fillStyle = "#ffffff";
      x.font = "900 64px Vazirmatn, sans-serif";
      x.fillText("این هفته،", 740, 300);
      x.fillText("عدد حرف زد.", 740, 380);
      x.textAlign = "left";
      x.direction = "ltr";
      x.fillStyle = "#dff25a";
      x.font = "700 120px Space Grotesk, sans-serif";
      x.fillText(`${pct >= 0 ? "+" : ""}${pct.toFixed(1)}%`, 56, 560);
      x.fillStyle = "rgba(255,255,255,.55)";
      x.font = "500 22px Vazirmatn, sans-serif";
      x.textAlign = "right";
      x.direction = "rtl";
      x.fillText("بازده ترکیبی میز + آزمایشگاه", 740, 530);
      const rows: [string, string][] = [
        ["سود شناور", `${profit >= 0 ? "+" : "-"}$${Math.abs(Math.round(profit)).toLocaleString("en-US")}`],
        ["نرخ برد رادار", `${win}%`],
        ["معاملات نمونه", trades],
      ];
      rows.forEach(([l, v], i) => {
        const y = 660 + i * 78;
        x.strokeStyle = "rgba(255,255,255,.12)";
        x.beginPath();
        x.moveTo(56, y + 24);
        x.lineTo(744, y + 24);
        x.stroke();
        x.fillStyle = "rgba(255,255,255,.55)";
        x.font = "500 22px Vazirmatn, sans-serif";
        x.textAlign = "right";
        x.direction = "rtl";
        x.fillText(l, 744, y);
        x.fillStyle = "#ffffff";
        x.font = "700 28px Space Grotesk, sans-serif";
        x.textAlign = "left";
        x.direction = "ltr";
        x.fillText(v, 56, y);
      });
      x.fillStyle = "#e4b84a";
      x.font = "700 22px Space Grotesk, sans-serif";
      x.textAlign = "left";
      x.fillText("dollarino.", 56, 948);
      x.fillStyle = "rgba(255,255,255,.4)";
      x.font = "500 16px Vazirmatn, sans-serif";
      x.textAlign = "right";
      x.direction = "rtl";
      x.fillText("Paper · Toobit · KCEX", 744, 948);
      const a = document.createElement("a");
      a.download = "dollarino-weekly.png";
      a.href = canvas.toDataURL("image/png");
      a.click();
    };
    const logo = new Image();
    logo.onload = () => paint(logo);
    logo.onerror = () => paint();
    logo.src = "/logo.png";
  };

  return (
    <div className="grid items-center gap-8 lg:grid-cols-2">
      <div>
        <div className="latin text-[10px] tracking-[.18em] text-[#e4b84a]">WEEKLY CARD</div>
        <h3 className="mt-2 text-[26px] font-black leading-snug">کارت شیشه‌ای هفته، با اعداد همین میز.</h3>
        <p className="dim mt-3 text-[12px] leading-7">طراحی ۴:۵ محصول، هایلایت لیمویی نسخه ادیتوریال، و لوگوی خود دلارینو. خروجی PNG واقعی است و با سود شناور فعلی به‌روز می‌شود.</p>
        <button onClick={download} className="btn mt-6 !border-[#14160f] !bg-[#dff25a] !text-[#14160f]"><Download size={16} /> دانلود PNG</button>
      </div>
      <div className="relative mx-auto w-full max-w-[320px]">
        <div className="absolute -inset-3 -rotate-2 rounded-[28px] bg-[#dff25a]" />
        <div className="relative aspect-[4/5] overflow-hidden rounded-[24px] border border-white/10 p-5" style={{ background: "linear-gradient(160deg,#1a2b86,#0e1430 55%,#141910)" }}>
          <img src="/logo.png" alt="" className="h-14 w-14 rounded-2xl object-cover" />
          <div className="absolute left-5 top-6 rounded-full bg-[#dff25a] px-2 py-1 text-[9px] font-extrabold text-[#14160f]">WEEKLY</div>
          <div className="absolute inset-x-0 bottom-0 p-5">
            <div className="text-[22px] font-black leading-snug text-white">این هفته،<br />عدد حرف زد.</div>
            <div dir="ltr" className="latin mt-4 text-[48px] font-bold leading-none text-[#dff25a]">{pct >= 0 ? "+" : ""}{pct.toFixed(1)}%</div>
            <div className="mt-4 grid grid-cols-3 gap-2 border-t border-white/10 pt-3 text-white">
              {[[`${profit >= 0 ? "+" : ""}${Math.round(profit)}`, "سود"], [`${win}%`, "برد"], [trades, "معامله"]].map(([v, l]) => (
                <div key={l}><div className="latin text-[11px] font-bold">{v}</div><div className="text-[9px] text-white/50">{l}</div></div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
