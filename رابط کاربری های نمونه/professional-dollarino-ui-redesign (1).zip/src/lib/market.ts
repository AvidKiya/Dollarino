export type Engine = "ai" | "strategy" | "copy";
export type Side = "long" | "short";

export interface Coin {
  sym: string;
  name: string;
  price: number;
  open: number;
  vol: string;
  color: string;
  dec: number;
  spark: number[];
}

export interface Signal {
  id: number;
  sym: string;
  side: Side;
  entry: number;
  tp: number;
  sl: number;
  conf: number;
  engine: Engine;
  born: number;
  resolveAt: number;
  status: "active" | "tp" | "sl";
  pnl: number;
  dec: number;
}

export interface Position {
  id: number;
  sym: string;
  side: Side;
  entry: number;
  margin: number;
  lev: number;
  dec: number;
  mirror?: string;
}

export interface Trader {
  id: string;
  name: string;
  tag: string;
  win: number;
  roi: number;
  copiers: number;
  risk: "کم" | "متوسط" | "بالا";
  focus: string;
  bias: Side;
  color: string;
  spark: number[];
}

const wobble = (base: number, vol: number, n = 28) => {
  const arr: number[] = [];
  let v = base;
  for (let i = 0; i < n; i++) {
    v += (Math.random() - 0.46) * vol;
    arr.push(v);
  }
  return arr;
};

const RAW = [
  { sym: "BTC", name: "Bitcoin", price: 97420, chg: 2.84, vol: "$38.2B", color: "#f7931a", dec: 0, sv: 420 },
  { sym: "ETH", name: "Ethereum", price: 3412, chg: 3.61, vol: "$19.4B", color: "#8a9cff", dec: 1, sv: 28 },
  { sym: "SOL", name: "Solana", price: 214.6, chg: -1.24, vol: "$4.8B", color: "#c084fc", dec: 2, sv: 2.4 },
  { sym: "BNB", name: "BNB", price: 692.4, chg: 1.12, vol: "$2.1B", color: "#f0b90b", dec: 1, sv: 6 },
  { sym: "XRP", name: "XRP", price: 2.41, chg: 5.37, vol: "$5.6B", color: "#25a4e8", dec: 3, sv: 0.03 },
  { sym: "DOGE", name: "Dogecoin", price: 0.382, chg: -2.18, vol: "$2.9B", color: "#c2a633", dec: 4, sv: 0.004 },
  { sym: "SUI", name: "Sui", price: 4.82, chg: 6.21, vol: "$1.8B", color: "#4da2ff", dec: 3, sv: 0.06 },
  { sym: "LINK", name: "Chainlink", price: 22.4, chg: 4.12, vol: "$540M", color: "#5b8cff", dec: 2, sv: 0.28 },
  { sym: "AVAX", name: "Avalanche", price: 38.7, chg: -0.84, vol: "$620M", color: "#ff6b6b", dec: 2, sv: 0.4 },
  { sym: "TON", name: "Toncoin", price: 5.62, chg: 0.94, vol: "$310M", color: "#0098ea", dec: 3, sv: 0.07 },
  { sym: "ADA", name: "Cardano", price: 0.98, chg: 1.87, vol: "$1.2B", color: "#6b8afd", dec: 4, sv: 0.012 },
  { sym: "TRX", name: "Tron", price: 0.264, chg: -1.62, vol: "$480M", color: "#ff5c5c", dec: 4, sv: 0.003 },
];

export const INITIAL_COINS: Coin[] = RAW.map((c) => ({
  sym: c.sym,
  name: c.name,
  price: c.price,
  open: c.price / (1 + c.chg / 100),
  vol: c.vol,
  color: c.color,
  dec: c.dec,
  spark: wobble(c.price, c.sv),
}));

export const TRADERS: Trader[] = [
  { id: "aurum", name: "Aurum", tag: "@aurum_ai", win: 78, roi: 42.6, copiers: 12840, risk: "کم", focus: "BTC", bias: "long", color: "#e4b84a", spark: wobble(100, 3) },
  { id: "orion", name: "Orion", tag: "@orion_swings", win: 73, roi: 35.9, copiers: 9870, risk: "کم", focus: "ETH", bias: "long", color: "#3ddc97", spark: wobble(100, 3.2) },
  { id: "falcon", name: "Falcon", tag: "@falcon_futures", win: 71, roi: 31.2, copiers: 8930, risk: "متوسط", focus: "SOL", bias: "long", color: "#7c93ff", spark: wobble(100, 3.8) },
  { id: "midnight", name: "Midnight", tag: "@midnight_quant", win: 69, roi: 27.8, copiers: 6210, risk: "متوسط", focus: "BNB", bias: "short", color: "#c084fc", spark: wobble(100, 4) },
  { id: "velvet", name: "Velvet", tag: "@velvet_bull", win: 64, roi: 19.4, copiers: 4102, risk: "بالا", focus: "DOGE", bias: "long", color: "#f0b90b", spark: wobble(100, 5) },
  { id: "saffron", name: "Saffron", tag: "@saffron_signals", win: 66, roi: 22.3, copiers: 3540, risk: "بالا", focus: "XRP", bias: "short", color: "#ff7a90", spark: wobble(100, 4.6) },
];

export const ENGINE_META: Record<Engine, { fa: string; en: string; color: string; short: string }> = {
  ai: { fa: "هوش مصنوعی دُرّبین", en: "Dorrbin", color: "#e4b84a", short: "AI" },
  strategy: { fa: "استراتژی دُرنا V1", en: "Dorna", color: "#3ddc97", short: "DRN" },
  copy: { fa: "کپی ترید", en: "Copy", color: "#8ea2ff", short: "CPY" },
};

export const changeOf = (c: Coin) => ((c.price - c.open) / c.open) * 100;

export const fmtPrice = (p: number, dec = 2) =>
  p.toLocaleString("en-US", { minimumFractionDigits: dec, maximumFractionDigits: dec });

export const fmtMoney = (n: number, digits = 0) => {
  const sign = n < 0 ? "-" : "";
  return sign + "$" + Math.abs(n).toLocaleString("en-US", { minimumFractionDigits: digits, maximumFractionDigits: digits });
};

export const timeAgo = (ts: number) => {
  const s = Math.max(1, Math.floor((Date.now() - ts) / 1000));
  if (s < 60) return `${s} ثانیه پیش`;
  const m = Math.floor(s / 60);
  if (m < 60) return `${m} دقیقه پیش`;
  return `${Math.floor(m / 60)} ساعت پیش`;
};

export const tickCoin = (c: Coin): Coin => {
  const drift = (Math.random() - 0.48) * c.price * 0.0016;
  const price = Math.max(c.price * 0.2, c.price + drift);
  return { ...c, price, spark: [...c.spark.slice(-27), price] };
};

let sigSeq = 40;
const ENGINES: Engine[] = ["ai", "strategy", "copy", "ai", "strategy"];

export function makeSignal(coins: Coin[], bornAgo = 0): Signal {
  const c = coins[Math.floor(Math.random() * coins.length)];
  const side: Side = Math.random() > 0.44 ? "long" : "short";
  const conf = 64 + Math.floor(Math.random() * 33);
  const tpPct = 0.012 + Math.random() * 0.026;
  const slPct = 0.008 + Math.random() * 0.014;
  const born = Date.now() - bornAgo;
  return {
    id: sigSeq++,
    sym: c.sym,
    side,
    entry: c.price,
    tp: side === "long" ? c.price * (1 + tpPct) : c.price * (1 - tpPct),
    sl: side === "long" ? c.price * (1 - slPct) : c.price * (1 + slPct),
    conf,
    engine: ENGINES[Math.floor(Math.random() * ENGINES.length)],
    born,
    resolveAt: born + 18000 + Math.random() * 32000,
    status: "active",
    pnl: 0,
    dec: c.dec,
  };
}

export function seedSignals(coins: Coin[]): Signal[] {
  const out: Signal[] = [];
  for (let i = 0; i < 6; i++) {
    const s = makeSignal(coins, (i + 2) * 70000);
    const win = Math.random() < s.conf / 140 + 0.22;
    s.status = win ? "tp" : "sl";
    s.pnl = win ? +(0.8 + Math.random() * 2.8).toFixed(2) : +(-(0.5 + Math.random() * 1.3)).toFixed(2);
    out.push(s);
  }
  for (let i = 0; i < 4; i++) out.push(makeSignal(coins, i * 9000 + 4000));
  return out.sort((a, b) => b.born - a.born);
}

export function positionPnl(p: Position, price: number) {
  const diff = (price - p.entry) / p.entry;
  const dir = p.side === "long" ? 1 : -1;
  return p.margin * p.lev * diff * dir;
}

export const INITIAL_POSITIONS: Position[] = [
  { id: 1, sym: "BTC", side: "long", entry: 95800, margin: 1200, lev: 10, dec: 0 },
  { id: 2, sym: "ETH", side: "long", entry: 3340, margin: 800, lev: 5, dec: 1, mirror: "@aurum_ai" },
  { id: 3, sym: "SOL", side: "short", entry: 221.4, margin: 450, lev: 8, dec: 2 },
];
