import { useEffect, useMemo, useRef, useState } from "react";
import { Coin, Engine, INITIAL_COINS, Lang, Position, Signal, T, TRADERS, Trader, View, fmtMoney } from "./lib/data";
import { Dock, Footer, Palette, QuickTrade, SidebarContent, TickerTape, Toast, Toasts, Topbar } from "./components/shell";
import Overview from "./views/Overview";
import Radar from "./views/Radar";
import Markets from "./views/Markets";
import Copy from "./views/Copy";
import Portfolio from "./views/Portfolio";
import { Faq, Pricing } from "./views/PricingFaq";

/* ---------- signal factory ---------- */
let sigId = 100;
const ENGINES: Engine[] = ["ai", "ai", "strategy", "strategy", "copy"];
function makeSignal(coins: Coin[], bornAgo = 0, force?: Partial<Signal>): Signal {
  const c = coins[Math.floor(Math.random() * coins.length)];
  const side = Math.random() > 0.42 ? "long" : "short";
  const conf = 62 + Math.floor(Math.random() * 36);
  const tpPct = 0.012 + Math.random() * 0.028;
  const slPct = 0.008 + Math.random() * 0.015;
  const now = Date.now() - bornAgo;
  return {
    id: sigId++, sym: c.sym, side, entry: c.price,
    tp: side === "long" ? c.price * (1 + tpPct) : c.price * (1 - tpPct),
    sl: side === "long" ? c.price * (1 - slPct) : c.price * (1 + slPct),
    conf, engine: ENGINES[Math.floor(Math.random() * ENGINES.length)],
    born: now, resolveAt: now + 25000 + Math.random() * 45000,
    status: "active", pnl: 0, dec: c.dec, ...force,
  };
}
function seedSignals(coins: Coin[]): Signal[] {
  const out: Signal[] = [];
  // resolved history
  for (let i = 0; i < 9; i++) {
    const s = makeSignal(coins, (i + 2) * 95000);
    const win = Math.random() < s.conf / 130 + 0.18;
    s.status = win ? "tp" : "sl";
    s.pnl = win ? 0.8 + Math.random() * 3 : -(0.6 + Math.random() * 1.4);
    out.push(s);
  }
  // active
  for (let i = 0; i < 5; i++) out.push(makeSignal(coins, i * 40000 + 8000));
  return out.sort((a, b) => b.born - a.born);
}

export default function App() {
  const [lang, setLang] = useState<Lang>("en");
  const [view, setView] = useState<View>("overview");
  const [coins, setCoins] = useState<Coin[]>(INITIAL_COINS);
  const [signals, setSignals] = useState<Signal[]>(() => seedSignals(INITIAL_COINS));
  const [stats, setStats] = useState({ total: 14, wins: 9, pnl: 1840, avgConf: 78 });
  const [positions, setPositions] = useState<Position[]>([
    { id: 1, sym: "BTC", side: "long", entry: 95800, margin: 1200, lev: 10, dec: 0 },
    { id: 2, sym: "ETH", side: "long", entry: 3340, margin: 800, lev: 5, dec: 0, mirror: "@aurum_ai" },
  ]);
  const [followed, setFollowed] = useState<string[]>(["aurum"]);
  const [cash, setCash] = useState(10000);
  const [realized, setRealized] = useState(640);
  const [closedWins, setClosedWins] = useState(7);
  const [closedTotal, setClosedTotal] = useState(10);
  const [equity, setEquity] = useState<number[]>(() => {
    const arr: number[] = [];
    let v = 9800;
    for (let i = 0; i < 48; i++) { v += Math.random() * 130 - 45; arr.push(v); }
    return arr;
  });
  const [palette, setPalette] = useState(false);
  const [drawer, setDrawer] = useState(false);
  const [qtSym, setQtSym] = useState<string | null>(null);
  const [toasts, setToasts] = useState<Toast[]>([]);

  const coinsRef = useRef(coins);
  coinsRef.current = coins;
  const posRef = useRef(positions);
  posRef.current = positions;
  const idRef = useRef(10);
  const t = T[lang];

  const pushToast = (text: string, kind: Toast["kind"] = "info") => {
    const id = Date.now() + Math.random();
    setToasts((p) => [...p.slice(-2), { id, text, kind }]);
    setTimeout(() => setToasts((p) => p.filter((x) => x.id !== id)), 3400);
  };

  /* ----- reveal on view change ----- */
  useEffect(() => {
    window.scrollTo({ top: 0 });
    const els = document.querySelectorAll(".reveal:not(.in)");
    const obs = new IntersectionObserver((es) => es.forEach((e) => e.isIntersecting && e.target.classList.add("in")), { threshold: 0.08 });
    els.forEach((el) => obs.observe(el));
    const fallback = setTimeout(() => els.forEach((el) => el.classList.add("in")), 1200);
    return () => { obs.disconnect(); clearTimeout(fallback); };
  }, [view]);

  /* ----- ctrl+k palette ----- */
  useEffect(() => {
    const h = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "k") { e.preventDefault(); setPalette((p) => !p); }
    };
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  }, []);

  /* ----- live tick: coins + signal resolution + equity ----- */
  useEffect(() => {
    const iv = setInterval(() => {
      setCoins((prev) => prev.map((c) => {
        const drift = (Math.random() - 0.485) * c.price * 0.0016;
        const price = Math.max(c.price * 0.5, c.price + drift);
        return { ...c, price, open: c.open + drift * 0.02, spark: [...c.spark.slice(1), price] };
      }));
      const now = Date.now();
      setSignals((prev) => {
        let changed = false;
        const next = prev.map((s) => {
          if (s.status !== "active" || now < s.resolveAt) return s;
          changed = true;
          const win = Math.random() < s.conf / 130 + 0.18;
          const pnl = win ? 0.8 + Math.random() * 3 : -(0.6 + Math.random() * 1.4);
          setStats((st) => ({ total: st.total, wins: st.wins + (win ? 1 : 0), pnl: st.pnl + (1000 * pnl) / 100, avgConf: st.avgConf }));
          setTimeout(() => pushToast(`${win ? t.toast.tp : t.toast.sl} · ${s.sym} ${s.side.toUpperCase()} ${pnl >= 0 ? "+" : ""}${pnl.toFixed(1)}%`, win ? "win" : "lose"), 0);
          return { ...s, status: win ? "tp" : "sl", pnl } as Signal;
        });
        return changed ? next : prev;
      });
      const unreal = posRef.current.reduce((sum, p) => {
        const cur = coinsRef.current.find((c) => c.sym === p.sym)?.price ?? p.entry;
        const pct = (cur - p.entry) / p.entry;
        return sum + p.margin * p.lev * (p.side === "long" ? pct : -pct);
      }, 0);
      setEquity((prev) => {
        const base = 12480 + unreal;
        const next = [...prev.slice(1), base + (Math.random() - 0.45) * 60];
        return next;
      });
    }, 1600);
    return () => clearInterval(iv);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  /* ----- new signals ----- */
  useEffect(() => {
    const iv = setInterval(() => {
      const s = makeSignal(coinsRef.current);
      setSignals((prev) => [s, ...prev].slice(0, 30));
      setStats((st) => ({ ...st, total: st.total + 1, avgConf: (st.avgConf * st.total + s.conf) / (st.total + 1) }));
    }, 9000);
    return () => clearInterval(iv);
  }, []);

  /* ----- derived ----- */
  const priceOf = (sym: string) => coins.find((c) => c.sym === sym)?.price ?? 0;
  const unreal = useMemo(() => positions.reduce((sum, p) => {
    const cur = priceOf(p.sym);
    const pct = (cur - p.entry) / p.entry;
    return sum + p.margin * p.lev * (p.side === "long" ? pct : -pct);
  }, 0), [positions, coins]); // eslint-disable-line
  const equityVal = cash + unreal;
  const consensus = useMemo(() => {
    const act = signals.filter((s) => s.status === "active");
    if (!act.length) return 18;
    return act.reduce((s, x) => s + (x.side === "long" ? x.conf : -x.conf), 0) / act.length;
  }, [signals]);
  const activeCount = signals.filter((s) => s.status === "active").length;
  const qtCoin = coins.find((c) => c.sym === qtSym) ?? coins[0];

  /* ----- actions ----- */
  const go = (v: View) => { setView(v); setDrawer(false); };
  const openQt = (sym: string) => setQtSym(sym);
  const confirmQt = (side: "long" | "short", lev: number, margin: number) => {
    setPositions((p) => [{ id: idRef.current++, sym: qtCoin.sym, side, entry: qtCoin.price, margin, lev, dec: qtCoin.dec }, ...p]);
    pushToast(`${T[lang].qt.opened} · ${qtCoin.sym} ${side.toUpperCase()} ${lev}×`, "info");
    setQtSym(null);
  };
  const closePos = (p: Position) => {
    const cur = priceOf(p.sym);
    const pct = (cur - p.entry) / p.entry;
    const pnl = p.margin * p.lev * (p.side === "long" ? pct : -pct);
    setCash((c) => c + pnl);
    setRealized((r) => r + pnl);
    setClosedTotal((x) => x + 1);
    if (pnl > 0) setClosedWins((x) => x + 1);
    setPositions((ps) => ps.filter((x) => x.id !== p.id));
    pushToast(`${t.toast.closed} · ${p.sym} ${pnl >= 0 ? "+" : ""}${fmtMoney(pnl)}`, pnl >= 0 ? "win" : "lose");
  };
  const toggleFollow = (tr: Trader) => {
    if (followed.includes(tr.id)) {
      setFollowed((f) => f.filter((x) => x !== tr.id));
      setPositions((ps) => ps.filter((p) => p.mirror !== tr.tag));
      pushToast(`${t.toast.unfollowed} ${tr.tag}`, "info");
    } else {
      setFollowed((f) => [...f, tr.id]);
      const c = coins.find((x) => x.sym === tr.focus) ?? coins[0];
      setPositions((ps) => [{ id: idRef.current++, sym: c.sym, side: tr.bias, entry: c.price, margin: 600, lev: 8, dec: c.dec, mirror: tr.tag }, ...ps]);
      pushToast(`${t.toast.followed} ${tr.tag}`, "win");
    }
  };

  return (
    <div dir={t.dir} className="noise min-h-screen">
      {/* ambient */}
      <div className="fixed inset-0 -z-10 overflow-hidden">
        <div className="absolute inset-0 bg-night" />
        <div className="absolute inset-0 grid-bg" />
        <div className="absolute -top-48 start-1/3 h-[480px] w-[520px] rounded-full bg-gold/[0.09] blur-[150px] glow-pulse" />
        <div className="absolute top-1/3 -end-48 h-[420px] w-[420px] rounded-full bg-jade/[0.06] blur-[150px]" />
        <div className="absolute bottom-0 -start-40 h-[380px] w-[380px] rounded-full bg-gold/[0.05] blur-[150px]" />
      </div>

      <div className="lg:flex lg:items-start">
        {/* sidebar desktop */}
        <aside className="hidden lg:block sticky top-0 h-screen w-[248px] shrink-0 border-e hairline bg-black/30 backdrop-blur-xl p-4">
          <SidebarContent view={view} setView={go} lang={lang} activeCount={activeCount} />
        </aside>

        {/* main */}
        <div className="flex-1 min-w-0">
          <Topbar lang={lang} setLang={setLang} equity={equityVal} onPalette={() => setPalette(true)} onMenu={() => setDrawer(true)} view={view} />
          <TickerTape coins={coins} lang={lang} onTrade={openQt} />
          <main key={view} className="mx-auto max-w-6xl px-3 sm:px-6 min-h-[70vh]">
            {view === "overview" && <Overview lang={lang} coins={coins} equity={equity} signals={signals} stats={stats} consensus={consensus} onGo={go} onTrade={openQt} />}
            {view === "markets" && <Markets lang={lang} coins={coins} onTrade={openQt} />}
            {view === "radar" && <Radar lang={lang} coins={coins} signals={signals} stats={stats} consensus={consensus} onTrade={openQt} />}
            {view === "copy" && <Copy lang={lang} followed={followed} onToggle={toggleFollow} />}
            {view === "portfolio" && <Portfolio lang={lang} coins={coins} positions={positions} cash={cash} realized={realized} winRate={closedTotal ? (closedWins / closedTotal) * 100 : 0} unreal={unreal} equity={equityVal} onClose={closePos} onTrade={() => openQt("BTC")} />}
            {view === "pricing" && <Pricing lang={lang} onStart={() => openQt("BTC")} />}
            {view === "faq" && <Faq lang={lang} />}
          </main>
          <Footer lang={lang} onGo={go} />
        </div>
      </div>

      {/* mobile drawer */}
      {drawer && (
        <div className="lg:hidden fixed inset-0 z-[70] bg-black/70 backdrop-blur-sm" onClick={() => setDrawer(false)}>
          <div className="absolute top-0 bottom-0 start-0 w-[280px] bg-[#0b0e09f5] border-e hairline p-4 pop-in" onClick={(e) => e.stopPropagation()}>
            <SidebarContent view={view} setView={go} lang={lang} activeCount={activeCount} onClose={() => setDrawer(false)} />
          </div>
        </div>
      )}

      <Dock view={view} setView={go} lang={lang} onTrade={() => openQt("BTC")} />
      <Palette open={palette} onClose={() => setPalette(false)} lang={lang} setLang={setLang} coins={coins} onGo={go} onTrade={openQt} />
      {qtSym && <QuickTrade coin={qtCoin} lang={lang} cash={cash} onClose={() => setQtSym(null)} onOpen={confirmQt} />}
      <Toasts items={toasts} />
    </div>
  );
}

export { TRADERS };
