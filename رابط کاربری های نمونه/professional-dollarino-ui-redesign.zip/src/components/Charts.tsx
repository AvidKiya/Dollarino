import { useEffect, useMemo, useRef, useState } from "react";

export function Sparkline({ data, up, w = 88, h = 30 }: { data: number[]; up: boolean; w?: number; h?: number }) {
  const { line, area } = useMemo(() => {
    const min = Math.min(...data), max = Math.max(...data), range = max - min || 1;
    const pts = data.map((v, i) => [i / (data.length - 1) * w, h - 3 - (v - min) / range * (h - 6)] as const);
    const line = pts.map((p, i) => `${i === 0 ? "M" : "L"}${p[0].toFixed(1)},${p[1].toFixed(1)}`).join(" ");
    return { line, area: `${line} L${w},${h} L0,${h} Z` };
  }, [data, w, h]);
  const color = up ? "var(--jade)" : "var(--rose)";
  return <svg width={w} height={h} className="shrink-0 overflow-visible"><path d={area} fill={color} opacity=".1" /><path d={line} fill="none" stroke={color} strokeWidth="1.8" strokeLinecap="round" /></svg>;
}

export interface Candle { o: number; h: number; l: number; c: number }
export function genCandles(base: number, n = 48): Candle[] {
  const out: Candle[] = []; let v = base * .984;
  for (let i = 0; i < n; i++) { const o = v, c = o + (Math.random() - .43) * base * .0035; out.push({ o, c, h: Math.max(o, c) + Math.random() * base * .0015, l: Math.min(o, c) - Math.random() * base * .0015 }); v = c; }
  return out;
}
export function CandleChart({ candles, line = false, height = 270 }: { candles: Candle[]; line?: boolean; height?: number }) {
  const W = 720;
  const { bars, pts, lo, hi, last } = useMemo(() => {
    const vals = candles.flatMap((c) => [c.h, c.l]); const min = Math.min(...vals), max = Math.max(...vals), pad = (max - min) * .12 || 1;
    const lo = min - pad, hi = max + pad, y = (v: number) => height - 18 - (v - lo) / (hi - lo) * (height - 40), step = W / candles.length;
    const pts = candles.map((c, i) => `${(i * step + step / 2).toFixed(1)},${y(c.c).toFixed(1)}`).join(" ");
    const bars = candles.map((c, i) => ({ x: i * step + step / 2, up: c.c >= c.o, yo: y(c.o), yc: y(c.c), yh: y(c.h), yl: y(c.l), vol: Math.abs(c.c - c.o) / (max - min || 1) }));
    return { bars, pts, lo, hi, last: candles[candles.length - 1]?.c ?? 0 };
  }, [candles, height]);
  const up = bars[bars.length - 1]?.up, lastY = bars[bars.length - 1]?.yc ?? 0;
  return <svg viewBox={`0 0 ${W} ${height}`} className="w-full h-full" preserveAspectRatio="none">
    <defs><linearGradient id="candleArea" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="var(--gold)" stopOpacity=".3" /><stop offset="100%" stopColor="var(--gold)" stopOpacity="0" /></linearGradient></defs>
    {[.2, .4, .6, .8].map((f) => <line key={f} x1="0" x2={W} y1={height * f} y2={height * f} stroke="var(--line)" strokeDasharray="3 6" />)}
    {Array.from({ length: 7 }, (_, i) => <line key={i} x1={i * W / 6} x2={i * W / 6} y1="0" y2={height} stroke="var(--line)" strokeDasharray="3 6" />)}
    {line && <polygon points={`0,${height} ${pts} ${W},${height}`} fill="url(#candleArea)" />}
    {line && <polyline points={pts} fill="none" stroke="var(--gold)" strokeWidth="2.5" strokeLinejoin="round" />}
    {!line && bars.map((b, i) => <g key={i} opacity=".8"><line x1={b.x} x2={b.x} y1={b.yh} y2={b.yl} stroke={b.up ? "var(--jade)" : "var(--rose)"} strokeWidth="1.2" /><rect x={b.x - 3.5} y={Math.min(b.yo, b.yc)} width="7" height={Math.max(2, Math.abs(b.yc - b.yo))} rx="1" fill={b.up ? "var(--jade)" : "var(--rose)"} /></g>)}
    {bars.map((b, i) => <rect key={`v${i}`} x={b.x - 3.5} y={height - b.vol * 30} width="7" height={b.vol * 30} fill={b.up ? "var(--jade)" : "var(--rose)"} opacity=".15" />)}
    <line x1="0" x2={W} y1={lastY} y2={lastY} stroke={up ? "var(--jade)" : "var(--rose)"} strokeDasharray="3 5" opacity=".6" />
    <text x={W - 6} y={Math.max(14, lastY - 9)} textAnchor="end" fill={up ? "var(--jade)" : "var(--rose)"} fontSize="12" fontWeight="700" fontFamily="Inter">{last.toLocaleString("en-US", { maximumFractionDigits: last < 10 ? 3 : 0 })}</text>
    <text x="8" y="16" fill="var(--faint)" fontSize="10" fontFamily="Inter">{hi.toLocaleString("en-US", { maximumFractionDigits: 0 })}</text><text x="8" y={height - 40} fill="var(--faint)" fontSize="10" fontFamily="Inter">{lo.toLocaleString("en-US", { maximumFractionDigits: 0 })}</text>
  </svg>;
}

export function EquityCurve({ data, width = 620, height = 230 }: { data: number[]; width?: number; height?: number }) {
  const { line, area, last, min, max } = useMemo(() => {
    const min = Math.min(...data), max = Math.max(...data), range = max - min || 1;
    const pts = data.map((v, i) => [i / (data.length - 1) * width, height - 14 - (v - min) / range * (height - 34)] as const);
    const line = pts.map((p, i) => `${i === 0 ? "M" : "L"}${p[0].toFixed(1)},${p[1].toFixed(1)}`).join(" ");
    return { line, area: `${line} L${width},${height} L0,${height} Z`, last: pts[pts.length - 1], min, max };
  }, [data, width, height]);
  return <svg viewBox={`0 0 ${width} ${height}`} className="w-full h-full" preserveAspectRatio="none">
    <defs><linearGradient id="eqArea" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="var(--gold)" stopOpacity=".35" /><stop offset="100%" stopColor="var(--gold)" stopOpacity="0" /></linearGradient><linearGradient id="eqLine" x1="0" y1="0" x2="1" y2="0"><stop offset="0%" stopColor="var(--gold-deep)" /><stop offset="60%" stopColor="var(--gold)" /><stop offset="100%" stopColor="var(--gold-soft)" /></linearGradient></defs>
    {[.25, .5, .75].map((f) => <line key={f} x1="0" x2={width} y1={height * f} y2={height * f} stroke="var(--line)" strokeDasharray="3 6" />)}
    <path d={area} fill="url(#eqArea)" /><path d={line} fill="none" stroke="url(#eqLine)" strokeWidth="2.4" strokeLinecap="round" />
    <circle cx={last[0]} cy={last[1]} r="5" fill="var(--gold-soft)" /><circle cx={last[0]} cy={last[1]} r="10" fill="var(--gold)" opacity=".25" />
    <text x="8" y="16" fill="var(--faint)" fontSize="11" fontWeight="700" fontFamily="Inter">${(max / 1000).toFixed(1)}k</text><text x="8" y={height - 6} fill="var(--faint)" fontSize="11" fontFamily="Inter">${(min / 1000).toFixed(1)}k</text>
  </svg>;
}

export function Donut({ slices, size = 190 }: { slices: { label: string; value: number; color: string }[]; size?: number }) {
  const total = slices.reduce((s, x) => s + x.value, 0) || 1, r = 70, C = 2 * Math.PI * r; let acc = 0;
  return <div className="relative shrink-0" style={{ width: size, height: size }}><svg viewBox="0 0 180 180" className="w-full h-full -rotate-90"><circle cx="90" cy="90" r={r} fill="none" stroke="var(--line)" strokeWidth="22" />{slices.map((s, i) => { const frac = s.value / total, dash = Math.max(0, frac * C - (slices.length > 1 ? 3 : 0)); const el = <circle key={i} cx="90" cy="90" r={r} fill="none" stroke={s.color} strokeWidth="22" strokeDasharray={`${dash} ${C - dash}`} strokeDashoffset={-acc * C} style={{ transition: "all .8s ease", filter: `drop-shadow(0 0 6px ${s.color}44)` }} />; acc += frac; return el; })}</svg><div className="absolute inset-0 grid place-items-center text-center"><div><p className="font-display font-bold text-2xl tabular">${(total / 1000).toFixed(1)}k</p><p className="text-[9px] text-white/40 font-black tracking-widest">TOTAL</p></div></div></div>;
}

export function Gauge({ value, longL, shortL }: { value: number; longL: string; shortL: string }) {
  const v = Math.max(-100, Math.min(100, value)), rad = (90 - v / 100 * 80) * Math.PI / 180;
  const x = 100 + 62 * Math.cos(rad), y = 96 - 62 * Math.sin(rad), bull = v >= 0;
  return <div className="relative"><svg viewBox="0 0 200 112" className="w-full"><defs><linearGradient id="gaugeG" x1="0" y1="0" x2="1" y2="0"><stop offset="0%" stopColor="var(--rose)" /><stop offset="50%" stopColor="var(--gold)" /><stop offset="100%" stopColor="var(--jade)" /></linearGradient></defs><path d="M 18 96 A 82 82 0 0 1 182 96" fill="none" stroke="var(--line)" strokeWidth="12" strokeLinecap="round" /><path d="M 18 96 A 82 82 0 0 1 182 96" fill="none" stroke="url(#gaugeG)" strokeWidth="12" strokeLinecap="round" opacity=".85" /><line x1="100" y1="96" x2={x} y2={y} stroke="var(--gold-soft)" strokeWidth="3.5" strokeLinecap="round" style={{ transition: "all .8s cubic-bezier(.22,1,.36,1)" }} /><circle cx="100" cy="96" r="8" fill="var(--panel)" stroke="var(--gold)" strokeWidth="3" /></svg><div className="flex justify-between text-[11px] font-black tracking-widest -mt-1"><span className="text-rose">{shortL}</span><span className={`font-display text-xl ${bull ? "text-jade" : "text-rose"}`}>{Math.abs(Math.round(v))}</span><span className="text-jade">{longL}</span></div></div>;
}

export function Counter({ to, suffix = "", decimals = 0, prefix = "" }: { to: number; suffix?: string; decimals?: number; prefix?: string }) {
  const ref = useRef<HTMLSpanElement>(null), done = useRef(false); const [val, setVal] = useState(0);
  useEffect(() => {
    if (done.current) { setVal(to); return; }
    const el = ref.current; if (!el) return;
    const obs = new IntersectionObserver(([e]) => { if (!e.isIntersecting || done.current) return; done.current = true; const start = performance.now(); const tick = (now: number) => { const p = Math.min(1, (now - start) / 1500); setVal(to * (1 - Math.pow(1 - p, 3))); if (p < 1) requestAnimationFrame(tick); }; requestAnimationFrame(tick); }, { threshold: .3 });
    obs.observe(el); return () => obs.disconnect();
  }, [to]);
  return <span ref={ref} className="tabular">{prefix}{val.toLocaleString("en-US", { minimumFractionDigits: decimals, maximumFractionDigits: decimals })}{suffix}</span>;
}
