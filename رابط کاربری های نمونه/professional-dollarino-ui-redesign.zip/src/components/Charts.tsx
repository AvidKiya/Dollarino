import { useMemo } from "react";

/* ---------------- sparkline ---------------- */
export function Sparkline({ data, up, w = 88, h = 30 }: { data: number[]; up: boolean; w?: number; h?: number }) {
  const { line, area } = useMemo(() => {
    const min = Math.min(...data), max = Math.max(...data);
    const range = max - min || 1;
    const pts = data.map((v, i) => {
      const x = (i / (data.length - 1)) * w;
      const y = h - 3 - ((v - min) / range) * (h - 6);
      return [x, y] as const;
    });
    const line = pts.map((p, i) => `${i === 0 ? "M" : "L"}${p[0].toFixed(1)},${p[1].toFixed(1)}`).join(" ");
    return { line, area: `${line} L${w},${h} L0,${h} Z` };
  }, [data, w, h]);
  const color = up ? "#10d9a3" : "#ff4d6d";
  return (
    <svg width={w} height={h} className="shrink-0 overflow-visible">
      <path d={area} fill={color} opacity={0.1} />
      <path d={line} fill="none" stroke={color} strokeWidth={1.8} strokeLinecap="round" />
    </svg>
  );
}

/* ---------------- equity curve ---------------- */
export function EquityCurve({ data, width = 620, height = 230 }: { data: number[]; width?: number; height?: number }) {
  const { line, area, last, min, max } = useMemo(() => {
    const min = Math.min(...data), max = Math.max(...data);
    const range = max - min || 1;
    const pts = data.map((v, i) => {
      const x = (i / (data.length - 1)) * width;
      const y = height - 14 - ((v - min) / range) * (height - 34);
      return [x, y] as const;
    });
    const line = pts.map((p, i) => `${i === 0 ? "M" : "L"}${p[0].toFixed(1)},${p[1].toFixed(1)}`).join(" ");
    return { line, area: `${line} L${width},${height} L0,${height} Z`, last: pts[pts.length - 1], min, max };
  }, [data, width, height]);
  return (
    <svg viewBox={`0 0 ${width} ${height}`} className="w-full h-full" preserveAspectRatio="none">
      <defs>
        <linearGradient id="eqArea" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#e8c15a" stopOpacity="0.35" />
          <stop offset="100%" stopColor="#e8c15a" stopOpacity="0" />
        </linearGradient>
        <linearGradient id="eqLine" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0%" stopColor="#9a7420" />
          <stop offset="60%" stopColor="#e8c15a" />
          <stop offset="100%" stopColor="#f5dd9a" />
        </linearGradient>
      </defs>
      {[0.25, 0.5, 0.75].map((f) => (
        <line key={f} x1="0" x2={width} y1={height * f} y2={height * f} stroke="rgba(232,193,90,.08)" strokeDasharray="3 6" />
      ))}
      <path d={area} fill="url(#eqArea)" />
      <path d={line} fill="none" stroke="url(#eqLine)" strokeWidth="2.4" strokeLinecap="round" />
      <circle cx={last[0]} cy={last[1]} r="5" fill="#f5dd9a" />
      <circle cx={last[0]} cy={last[1]} r="10" fill="#e8c15a" opacity="0.25" />
      <text x="8" y="16" fill="rgba(245,221,154,.5)" fontSize="11" fontWeight="700" fontFamily="Inter">${(max / 1000).toFixed(1)}k</text>
      <text x="8" y={height - 6} fill="rgba(245,221,154,.35)" fontSize="11" fontFamily="Inter">${(min / 1000).toFixed(1)}k</text>
    </svg>
  );
}

/* ---------------- donut ---------------- */
export function Donut({ slices, size = 190 }: { slices: { label: string; value: number; color: string }[]; size?: number }) {
  const total = slices.reduce((s, x) => s + x.value, 0) || 1;
  const r = 70, C = 2 * Math.PI * r;
  let acc = 0;
  return (
    <div className="relative shrink-0" style={{ width: size, height: size }}>
      <svg viewBox="0 0 180 180" className="w-full h-full -rotate-90">
        <circle cx="90" cy="90" r={r} fill="none" stroke="rgba(255,255,255,.06)" strokeWidth="22" />
        {slices.map((s, i) => {
          const frac = s.value / total;
          const dash = Math.max(0, frac * C - (slices.length > 1 ? 3 : 0));
          const el = (
            <circle
              key={i} cx="90" cy="90" r={r} fill="none" stroke={s.color} strokeWidth="22"
              strokeDasharray={`${dash} ${C - dash}`} strokeDashoffset={-acc * C}
              strokeLinecap="butt" style={{ transition: "all .8s ease", filter: `drop-shadow(0 0 6px ${s.color}66)` }}
            />
          );
          acc += frac;
          return el;
        })}
      </svg>
      <div className="absolute inset-0 grid place-items-center text-center">
        <div>
          <p className="font-display font-bold text-2xl tabular">${(total / 1000).toFixed(1)}k</p>
          <p className="text-[10px] text-white/40 font-bold tracking-widest">TOTAL</p>
        </div>
      </div>
    </div>
  );
}

/* ---------------- consensus gauge ---------------- */
export function Gauge({ value, longL, shortL }: { value: number; longL: string; shortL: string }) {
  const v = Math.max(-100, Math.min(100, value));
  const ang = (v / 100) * 80; // -80..80
  const rad = ((90 - ang) * Math.PI) / 180;
  const x = 100 + 62 * Math.cos(rad), y = 96 - 62 * Math.sin(rad);
  const bull = v >= 0;
  return (
    <div className="relative">
      <svg viewBox="0 0 200 112" className="w-full">
        <defs>
          <linearGradient id="gaugeG" x1="0" y1="0" x2="1" y2="0">
            <stop offset="0%" stopColor="#ff4d6d" />
            <stop offset="50%" stopColor="#e8c15a" />
            <stop offset="100%" stopColor="#10d9a3" />
          </linearGradient>
        </defs>
        <path d="M 18 96 A 82 82 0 0 1 182 96" fill="none" stroke="rgba(255,255,255,.08)" strokeWidth="12" strokeLinecap="round" />
        <path d="M 18 96 A 82 82 0 0 1 182 96" fill="none" stroke="url(#gaugeG)" strokeWidth="12" strokeLinecap="round" opacity="0.85" />
        <line x1="100" y1="96" x2={x} y2={y} stroke="#f5dd9a" strokeWidth="3.5" strokeLinecap="round" style={{ transition: "all .8s cubic-bezier(.22,1,.36,1)" }} />
        <circle cx="100" cy="96" r="8" fill="#0c0f0a" stroke="#e8c15a" strokeWidth="3" />
      </svg>
      <div className="flex justify-between text-[11px] font-black tracking-widest -mt-1">
        <span className="text-[#ff4d6d]">{shortL}</span>
        <span className={`font-display text-xl ${bull ? "text-jade" : "text-[#ff4d6d]"}`}>{Math.abs(Math.round(v))}</span>
        <span className="text-jade">{longL}</span>
      </div>
    </div>
  );
}

/* ---------------- animated counter ---------------- */
import { useEffect, useRef, useState } from "react";
export function Counter({ to, suffix = "", decimals = 0, prefix = "" }: { to: number; suffix?: string; decimals?: number; prefix?: string }) {
  const ref = useRef<HTMLSpanElement>(null);
  const [val, setVal] = useState(0);
  const done = useRef(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver(([e]) => {
      if (!e.isIntersecting || done.current) return;
      done.current = true;
      const start = performance.now();
      const tick = (now: number) => {
        const p = Math.min(1, (now - start) / 1500);
        setVal(to * (1 - Math.pow(1 - p, 3)));
        if (p < 1) requestAnimationFrame(tick);
      };
      requestAnimationFrame(tick);
    }, { threshold: 0.3 });
    obs.observe(el);
    return () => obs.disconnect();
  }, [to]);
  return <span ref={ref} className="tabular">{prefix}{val.toLocaleString("en-US", { minimumFractionDigits: decimals, maximumFractionDigits: decimals })}{suffix}</span>;
}
