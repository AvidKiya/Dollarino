import { useEffect, useMemo, useState } from "react";
import {
  LayoutDashboard, CandlestickChart, Radar, Users, Wallet, CreditCard, CircleHelp,
  Search, Globe, Menu, Zap, X, ArrowUpRight, ArrowDownRight, Coins, Check,
  Palette as PaletteIcon, Image, RotateCcw, Command,
} from "lucide-react";
import { Coin, Lang, T, View, changeOf, fmtMoney, fmtPrice } from "../lib/data";

type IconType = typeof Radar;
export function Logo({ size = 40 }: { size?: number }) {
  return (
    <span className="relative grid place-items-center shrink-0" style={{ width: size, height: size }}>
      <svg viewBox="0 0 48 48" className="w-full h-full drop-shadow-[0_4px_16px_rgba(232,193,90,.3)]">
        <defs><linearGradient id="coinG" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stopColor="var(--gold-a)" /><stop offset="45%" stopColor="var(--gold)" /><stop offset="100%" stopColor="var(--gold-deep)" /></linearGradient></defs>
        <circle cx="24" cy="24" r="21" fill="url(#coinG)" />
        <circle cx="24" cy="24" r="16.5" fill="none" stroke="var(--bg)" strokeOpacity=".4" strokeWidth="1.6" strokeDasharray="3 3" />
        <text x="24" y="31" textAnchor="middle" fontSize="17" fontWeight="900" fill="var(--bg)" fontFamily="Fraunces, serif">D$</text>
      </svg>
    </span>
  );
}

const MAIN: { v: View; icon: IconType }[] = [
  { v: "overview", icon: LayoutDashboard }, { v: "terminal", icon: CandlestickChart },
  { v: "markets", icon: Globe }, { v: "radar", icon: Radar },
  { v: "copy", icon: Users }, { v: "portfolio", icon: Wallet },
];
const ACCT: { v: View; icon: IconType }[] = [ { v: "pricing", icon: CreditCard }, { v: "faq", icon: CircleHelp } ];
export const viewLabel = (v: View, lang: Lang) => v === "terminal" ? T[lang].nav.terminal : v === "card" ? T[lang].nav.card : T[lang].shell[v];

export function SidebarContent({ view, setView, lang, activeCount, onTheme, onReset, onClose }: {
  view: View; setView: (v: View) => void; lang: Lang; activeCount: number;
  onTheme: () => void; onReset: () => void; onClose?: () => void;
}) {
  const t = T[lang];
  const item = (v: View, Icon: IconType, badge?: number) => {
    const on = view === v;
    return <button key={v} onClick={() => { setView(v); onClose?.(); }} className={`relative w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-[13px] font-semibold transition-all ${on ? "bg-gradient-to-r from-gold/20 to-gold/5 text-goldsoft" : "text-white/50 hover:text-white hover:bg-white/5"}`}>
      {on && <span className="absolute start-0 top-1/2 -translate-y-1/2 h-6 w-1 rounded-full bg-gold shadow-[0_0_12px_var(--gold)]" />}
      <Icon className="h-[18px] w-[18px] shrink-0" /><span className="truncate">{viewLabel(v, lang)}</span>
      {!!badge && <span className="ms-auto text-[10px] font-black bg-gold text-[#10130a] rounded-full px-2 py-0.5 tabular">{badge}</span>}
    </button>;
  };
  return <div className="flex flex-col h-full">
    <div className="flex items-center gap-2.5 px-2 pt-1 pb-6">
      <Logo /><div><p className="font-display font-bold text-[21px] leading-none">Dollarino<span className="text-gold">.</span></p><p className="text-[9px] font-black tracking-[0.25em] text-gold/80 mt-1.5">WEALTH OS · V6</p></div>
      {onClose && <button onClick={onClose} className="ms-auto lg:hidden h-9 w-9 grid place-items-center rounded-full btn-ghost"><X className="h-4 w-4" /></button>}
    </div>
    <p className="px-3.5 text-[9px] font-black tracking-[0.2em] text-white/30 mb-2">{t.shell.views}</p>
    <div className="space-y-0.5">{MAIN.map((n) => item(n.v, n.icon, n.v === "radar" ? activeCount : undefined))}</div>
    <p className="px-3.5 text-[9px] font-black tracking-[0.2em] text-white/30 mt-5 mb-2">{t.nav.studio}</p>
    <div className="space-y-0.5">{item("card", Image)}<button onClick={() => { onTheme(); onClose?.(); }} className="w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-[13px] font-semibold text-white/50 hover:text-white hover:bg-white/5 transition"><PaletteIcon className="h-[18px] w-[18px]" />{t.nav.appearance}</button></div>
    <p className="px-3.5 text-[9px] font-black tracking-[0.2em] text-white/30 mt-5 mb-2">{t.shell.account}</p>
    <div className="space-y-0.5">{ACCT.map((n) => item(n.v, n.icon))}</div>
    <div className="mt-auto pt-5">
      <div className="panel rounded-2xl p-4 relative overflow-hidden">
        <div className="absolute -top-8 -end-8 h-24 w-24 rounded-full bg-gold/20 blur-2xl" />
        <div className="flex items-center gap-2 mb-1.5"><span className="live-dot h-2 w-2 rounded-full bg-jade" /><p className="text-xs font-bold">{t.shell.enginesOn}</p></div>
        <div className="flex gap-1.5 mt-2.5">{["AI", "V1", "CP"].map((e, i) => <span key={e} className="flex-1 text-center text-[10px] font-black rounded-lg py-1.5 border" style={{ borderColor: ["#e8c15a55", "#10d9a355", "#38e1ff55"][i], color: ["#e8c15a", "#10d9a3", "#38e1ff"][i], background: ["#e8c15a14", "#10d9a314", "#38e1ff14"][i] }}>{e}</span>)}</div>
      </div>
      <button onClick={() => { onReset(); onClose?.(); }} className="flex items-center justify-center gap-1.5 text-[10px] font-semibold text-white/30 hover:text-gold transition w-full mt-3 py-1"><RotateCcw className="h-3 w-3" />{t.common.reset}</button>
    </div>
  </div>;
}

export function Topbar({ lang, setLang, equity, onPalette, onMenu, onTheme, onStart }: {
  lang: Lang; setLang: (l: Lang) => void; equity: number; onPalette: () => void;
  onMenu: () => void; onTheme: () => void; onStart: () => void; view: View;
}) {
  const t = T[lang];
  const [clock, setClock] = useState("");
  useEffect(() => {
    const f = () => setClock(new Date().toLocaleTimeString("en-GB", { timeZone: "UTC", hour: "2-digit", minute: "2-digit", second: "2-digit" }));
    f(); const iv = setInterval(f, 1000); return () => clearInterval(iv);
  }, []);
  return <div className="sticky top-0 z-40 backdrop-blur-xl bg-night/80 border-b hairline">
    <div className="mx-auto max-w-6xl px-3 sm:px-6 py-3 flex items-center gap-2 sm:gap-3">
      <button onClick={onMenu} aria-label={t.shell.menu} className="lg:hidden h-10 w-10 grid place-items-center rounded-xl btn-ghost shrink-0"><Menu className="h-5 w-5" /></button>
      <div className="lg:hidden flex items-center gap-2 shrink-0"><Logo size={30} /><span className="mobile-brand-name font-display font-bold text-lg">Dollarino<span className="text-gold">.</span></span></div>
      <button onClick={onPalette} aria-label={t.common.command} className="hidden lg:flex flex-1 max-w-sm items-center gap-2.5 panel rounded-xl px-4 py-2.5 text-[12px] text-white/40 hover:border-gold/40 transition text-start"><Search className="h-4 w-4 shrink-0" /><span className="truncate">{t.common.palette}</span><kbd className="ms-auto text-[9px] border border-white/15 rounded px-1">⌘K</kbd></button>
      <button onClick={onPalette} aria-label={t.common.command} className="lg:hidden h-10 w-10 grid place-items-center rounded-xl btn-ghost shrink-0"><Search className="h-4 w-4" /></button>
      <div className="ms-auto flex items-center gap-1.5 sm:gap-2">
        <span className="hidden xl:flex items-center gap-1.5 text-[10px] font-bold text-white/40 tabular"><span className="live-gold h-1.5 w-1.5 rounded-full bg-gold" />{clock} UTC</span>
        <button onClick={onTheme} title={t.nav.appearance} aria-label={t.nav.appearance} className="h-10 w-10 grid place-items-center rounded-xl btn-ghost"><PaletteIcon className="h-4 w-4 text-gold" /></button>
        <button onClick={() => setLang(lang === "en" ? "fa" : "en")} className="inline-flex items-center gap-1.5 text-xs font-bold px-2.5 py-2.5 rounded-xl btn-ghost"><Globe className="h-3.5 w-3.5 text-gold" />{lang === "en" ? "فارسی" : "EN"}</button>
        <button onClick={onStart} className="hidden md:inline-flex btn-gold items-center gap-1.5 text-xs font-black px-4 py-2.5 rounded-xl"><Zap className="h-3.5 w-3.5" />{t.nav.start}</button>
        <button onClick={onStart} className="hidden sm:inline-flex md:hidden items-center gap-2 panel rounded-xl px-3 py-2.5"><Wallet className="h-4 w-4 text-gold" /><span className="font-display font-bold tabular text-sm">{fmtMoney(equity)}</span></button>
      </div>
    </div>
    <div className="sm:hidden mx-3 mb-2.5 panel rounded-xl px-3.5 py-2 flex items-center justify-between"><span className="text-[11px] text-white/45 font-semibold flex items-center gap-1.5"><Wallet className="h-3.5 w-3.5 text-gold" />{t.shell.equity}</span><span className="font-display font-bold tabular">{fmtMoney(equity)}</span></div>
  </div>;
}

export function TickerTape({ coins, lang, onTrade }: { coins: Coin[]; lang: Lang; onTrade: (sym: string) => void }) {
  return <div className="border-b hairline bg-black/30 overflow-hidden"><div className="flex w-max gap-9 px-5 py-2 animate-ticker" style={lang === "fa" ? { animationName: "ticker-rtl" } : undefined}>
    {[...coins, ...coins].map((c, i) => { const ch = changeOf(c); return <button key={i} onClick={() => onTrade(c.sym)} className="flex items-center gap-2 text-[11px] font-semibold whitespace-nowrap hover:opacity-75 transition"><span className="font-bold" style={{ color: c.color }}>{c.sym}</span><span className="text-white/60 tabular">${fmtPrice(c.price, c.dec)}</span><span className={`tabular ${ch >= 0 ? "text-jade" : "text-[#ff4d6d]"}`}>{ch >= 0 ? "▲" : "▼"} {Math.abs(ch).toFixed(2)}%</span></button>; })}
  </div></div>;
}

export function Dock({ view, setView, lang, onTrade }: { view: View; setView: (v: View) => void; lang: Lang; onTrade: () => void }) {
  const t = T[lang];
  const items: { v: View; icon: IconType }[] = [{ v: "overview", icon: LayoutDashboard }, { v: "markets", icon: Globe }, { v: "radar", icon: Radar }, { v: "portfolio", icon: Wallet }];
  const btn = (l: typeof items[0]) => <button key={l.v} onClick={() => setView(l.v)} aria-label={viewLabel(l.v, lang)} className={`flex flex-col items-center gap-1 min-w-0 px-1 py-1.5 rounded-2xl transition ${view === l.v ? "text-gold" : "text-white/45"}`}><l.icon className="h-[22px] w-[22px]" /><span className="text-[8px] font-bold truncate w-full text-center">{viewLabel(l.v, lang)}</span></button>;
  return <nav className="lg:hidden fixed bottom-3 inset-x-3 z-50"><div className="panel rounded-[26px] px-2 py-2 grid grid-cols-[1fr_1fr_64px_1fr_1fr] items-center shadow-2xl shadow-black/40 !bg-[var(--bg)]">{[items[0], items[1]].map(btn)}<button onClick={onTrade} aria-label={t.common.quick} className="relative -mt-8 h-16 w-16 rounded-full btn-gold grid place-items-center shrink-0 overflow-hidden"><span className="absolute inset-0 shine" /><Zap className="h-7 w-7 relative" /></button>{[items[2], items[3]].map(btn)}</div></nav>;
}

export function Palette({ open, onClose, lang, setLang, coins, onGo, onTrade, onTheme, onReset }: {
  open: boolean; onClose: () => void; lang: Lang; setLang: (l: Lang) => void;
  coins: Coin[]; onGo: (v: View) => void; onTrade: (sym: string) => void; onTheme: () => void; onReset: () => void;
}) {
  const [q, setQ] = useState(""); const t = T[lang];
  useEffect(() => { if (open) setQ(""); }, [open]);
  useEffect(() => { const h = (e: KeyboardEvent) => e.key === "Escape" && onClose(); window.addEventListener("keydown", h); return () => window.removeEventListener("keydown", h); }, [onClose]);
  const views = useMemo(() => (["overview", "terminal", "markets", "radar", "copy", "portfolio", "card", "pricing", "faq"] as View[]).filter((v) => viewLabel(v, lang).toLowerCase().includes(q.toLowerCase()) || v.includes(q.toLowerCase())), [q, lang]);
  const filtered = useMemo(() => coins.filter((c) => c.sym.toLowerCase().includes(q.toLowerCase()) || c.name.toLowerCase().includes(q.toLowerCase())).slice(0, 5), [q, coins]);
  if (!open) return null;
  return <div className="fixed inset-0 z-[80] bg-black/70 backdrop-blur-sm p-4 grid place-items-start justify-items-center pt-[12vh]" onClick={onClose}>
    <div role="dialog" aria-modal="true" aria-label={t.common.command} className="pop-in w-full max-w-lg panel !bg-[var(--panel)] rounded-3xl overflow-hidden shadow-2xl" onClick={(e) => e.stopPropagation()}>
      <div className="flex items-center gap-3 px-5 py-4 border-b hairline"><Command className="h-5 w-5 text-gold shrink-0" /><input autoFocus value={q} onChange={(e) => setQ(e.target.value)} placeholder={t.common.palette} className="bg-transparent flex-1 outline-none text-[14px] font-medium placeholder:text-white/30" /><kbd className="text-[10px] font-bold text-white/35 border border-white/15 rounded-md px-1.5 py-0.5">ESC</kbd></div>
      <div className="max-h-[46vh] overflow-y-auto p-3 space-y-3">
        {!!views.length && <div><p className="px-3 text-[9px] font-black tracking-widest text-white/35 mb-1.5">{t.common.views}</p>{views.map((v) => <button key={v} onClick={() => { onGo(v); onClose(); }} className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl hover:bg-gold/10 transition text-start font-semibold text-sm"><LayoutDashboard className="h-4 w-4 text-gold" />{viewLabel(v, lang)}</button>)}</div>}
        <div><p className="px-3 text-[9px] font-black tracking-widest text-white/35 mb-1.5">{t.common.coins}</p>{filtered.map((c) => { const ch = changeOf(c); return <button key={c.sym} onClick={() => { onTrade(c.sym); onClose(); }} className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl hover:bg-gold/10 transition font-semibold text-sm"><span className="h-8 w-8 rounded-lg grid place-items-center font-bold text-xs" style={{ background: `${c.color}20`, color: c.color }}>{c.sym[0]}</span><span>{c.sym}<span className="text-white/35 font-medium"> /USDT</span></span><span className="ms-auto tabular text-white/60">${fmtPrice(c.price, c.dec)}</span><span className={`tabular text-xs ${ch >= 0 ? "text-jade" : "text-[#ff4d6d]"}`}>{ch >= 0 ? "+" : ""}{ch.toFixed(2)}%</span></button>; })}</div>
        <div><p className="px-3 text-[9px] font-black tracking-widest text-white/35 mb-1.5">{t.common.actions}</p>{[
          { icon: Globe, label: lang === "en" ? t.common.toFa : t.common.toEn, action: () => setLang(lang === "en" ? "fa" : "en") },
          { icon: PaletteIcon, label: t.nav.appearance, action: onTheme },
          { icon: RotateCcw, label: t.common.reset, action: onReset },
        ].map((a, i) => <button key={i} onClick={() => { a.action(); onClose(); }} className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl hover:bg-gold/10 transition font-semibold text-sm"><a.icon className="h-4 w-4 text-gold" />{a.label}</button>)}</div>
      </div>
    </div>
  </div>;
}

export function QuickTrade({ coin, lang, cash, initialSide = "long", onClose, onOpen }: {
  coin: Coin; lang: Lang; cash: number; initialSide?: "long" | "short";
  onClose: () => void; onOpen: (side: "long" | "short", lev: number, margin: number) => void;
}) {
  const t = T[lang]; const [side, setSide] = useState<"long" | "short">(initialSide); const [lev, setLev] = useState(10); const [amt, setAmt] = useState(500); const ch = changeOf(coin);
  return <div className="fixed inset-0 z-[80] bg-black/70 backdrop-blur-sm p-4 grid place-items-center overflow-y-auto" onClick={onClose}>
    <div role="dialog" aria-modal="true" aria-label={t.terminal.title} className="pop-in w-full max-w-sm panel !bg-[var(--panel)] rounded-[26px] p-6 shadow-2xl" onClick={(e) => e.stopPropagation()}>
      <div className="flex items-center justify-between mb-5"><div className="flex items-center gap-3"><span className="h-11 w-11 rounded-2xl grid place-items-center font-display font-bold" style={{ background: `${coin.color}20`, color: coin.color, border: `1px solid ${coin.color}44` }}>{coin.sym[0]}</span><div><p className="font-display font-bold text-lg leading-none">{coin.sym}/USDT</p><p className={`text-xs font-bold mt-1 tabular ${ch >= 0 ? "text-jade" : "text-[#ff4d6d]"}`}>${fmtPrice(coin.price, coin.dec)} · {ch >= 0 ? "+" : ""}{ch.toFixed(2)}%</p></div></div><button onClick={onClose} className="h-9 w-9 grid place-items-center rounded-full btn-ghost"><X className="h-4 w-4" /></button></div>
      <div className="grid grid-cols-2 gap-2 p-1 rounded-2xl bg-black/30 border hairline mb-5">{(["long", "short"] as const).map((s) => <button key={s} onClick={() => setSide(s)} className={`py-3 rounded-xl font-black text-sm transition flex items-center justify-center gap-1.5 ${side === s ? (s === "long" ? "bg-jade text-black" : "bg-[#ff4d6d] text-white") : "text-white/45"}`}>{s === "long" ? <ArrowUpRight className="h-4 w-4" /> : <ArrowDownRight className="h-4 w-4" />}{s === "long" ? t.terminal.long : t.terminal.short}</button>)}</div>
      <div className="flex justify-between text-sm mb-2"><span className="text-white/50">{t.terminal.leverage}</span><span className="font-display font-bold text-gold">{lev}×</span></div><input type="range" min={1} max={50} value={lev} onChange={(e) => setLev(+e.target.value)} className="w-full mb-4" style={{ "--fill": `${((lev - 1) / 49) * 100}%` } as React.CSSProperties} />
      <label className="text-sm text-white/50 block mb-2">{t.common.amount} <span className="text-white/30">· {t.common.balance} {fmtMoney(cash)}</span></label><input type="number" value={amt} onChange={(e) => setAmt(Math.max(0, +e.target.value))} className="field font-display font-bold text-lg tabular mb-2.5" />
      <div className="flex gap-2 mb-5">{[100, 500, 1000, 2500].map((v) => <button key={v} onClick={() => setAmt(v)} className={`flex-1 py-2 rounded-xl text-xs font-black transition ${amt === v ? "bg-gold text-[#10130a]" : "bg-white/5 text-white/50"}`}>{v}</button>)}</div>
      <div className="panel rounded-2xl p-3.5 space-y-1.5 text-[13px] mb-5"><div className="flex justify-between"><span className="text-white/45">{t.terminal.size}</span><span className="font-bold tabular">{fmtMoney(amt * lev)}</span></div><div className="flex justify-between"><span className="text-white/45">{t.terminal.liq}</span><span className="font-bold tabular text-[#ff4d6d]">${fmtPrice(coin.price * (side === "long" ? 1 - .9 / lev : 1 + .9 / lev), coin.dec)}</span></div></div>
      <button onClick={() => { if (amt > 0) onOpen(side, lev, amt); }} disabled={amt <= 0} className="btn-gold w-full py-4 rounded-2xl font-black flex items-center justify-center gap-2 disabled:opacity-40"><Zap className="h-5 w-5" />{t.common.confirm} · {coin.sym} {side.toUpperCase()} {lev}×</button>
    </div>
  </div>;
}

export interface Toast { id: number; text: string; kind: "win" | "lose" | "info" }
export function Toasts({ items }: { items: Toast[] }) {
  return <div className="fixed bottom-24 lg:bottom-8 left-1/2 -translate-x-1/2 z-[90] flex flex-col items-center gap-2 pointer-events-none px-4 w-full max-w-md">{items.map((x) => <div key={x.id} role="status" aria-live="polite" className="pop-in panel !bg-[var(--panel)] rounded-full ps-2 pe-5 py-2 text-[13px] font-bold shadow-2xl flex items-center gap-2.5 whitespace-nowrap"><span className={`h-7 w-7 rounded-full grid place-items-center ${x.kind === "win" ? "bg-jade/20 text-jade" : x.kind === "lose" ? "bg-[#ff4d6d]/20 text-[#ff4d6d]" : "bg-gold/20 text-gold"}`}>{x.kind === "win" ? <Check className="h-4 w-4" /> : x.kind === "lose" ? <X className="h-4 w-4" /> : <Coins className="h-4 w-4" />}</span>{x.text}</div>)}</div>;
}

export function Footer({ lang, onGo }: { lang: Lang; onGo: (v: View) => void }) {
  const t = T[lang];
  return <footer className="border-t hairline mt-16 pb-28 lg:pb-8"><div className="mx-auto max-w-6xl px-4 sm:px-6 py-10 flex flex-col md:flex-row items-center justify-between gap-6"><div className="flex items-center gap-2.5"><Logo size={36} /><div><p className="font-display font-bold">Dollarino OS</p><p className="text-xs text-white/40">{t.common.footT}</p></div></div><div className="flex flex-wrap justify-center gap-x-6 gap-y-2 text-[12px] font-semibold text-white/45">{(["markets", "radar", "copy", "pricing", "faq"] as View[]).map((v) => <button key={v} onClick={() => onGo(v)} className="hover:text-gold transition">{viewLabel(v, lang)}</button>)}</div><p className="text-xs text-white/35">{t.common.rights}</p></div><p className="text-center text-[10px] text-white/25 px-6 max-w-2xl mx-auto">{t.common.paperRisk}</p></footer>;
}
