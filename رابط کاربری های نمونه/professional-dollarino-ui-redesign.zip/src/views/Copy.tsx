import { BadgeCheck, Check, Copy as CopyIcon, Plus, ShieldCheck, Sparkles, Users } from "lucide-react";
import { Lang, T, TRADERS, Trader } from "../lib/data";
import { Sparkline } from "../components/Charts";

interface Props {
  lang: Lang; followed: string[];
  onToggle: (tr: Trader) => void;
}

const RISK_C: Record<string, string> = { Low: "#10d9a3", Medium: "#e8c15a", High: "#ff4d6d" };

export default function Copy({ lang, followed, onToggle }: Props) {
  const t = T[lang].cp;
  const totalCopiers = TRADERS.reduce((s, x) => s + x.copiers, 0);
  const avgRoi = TRADERS.reduce((s, x) => s + x.roi, 0) / TRADERS.length;

  return (
    <div className="pt-8 sm:pt-10">
      <div className="reveal in text-center max-w-2xl mx-auto">
        <div className="inline-flex items-center gap-2 text-xs font-black tracking-[0.2em] text-gold uppercase mb-3">
          <span className="live-gold h-2 w-2 rounded-full bg-gold" />{t.title}
        </div>
        <h2 className="font-display font-semibold text-4xl sm:text-5xl">{t.title}</h2>
        <p className="mt-2 text-white/50 text-[15px]">{t.sub}</p>
      </div>

      <div className="reveal in grid grid-cols-2 lg:grid-cols-4 gap-2.5 mt-7">
        {[
          { icon: Users, v: totalCopiers.toLocaleString(), l: t.copiers },
          { icon: Sparkles, v: `${avgRoi.toFixed(1)}%`, l: t.avgRoi },
          { icon: BadgeCheck, v: String(TRADERS.length), l: t.elite },
          { icon: ShieldCheck, v: "24/7", l: t.auto },
        ].map((s, i) => (
          <div key={i} className="panel rounded-3xl p-5 text-center">
            <s.icon className="h-5 w-5 mx-auto mb-2 text-gold" />
            <p className="font-display font-bold text-2xl tabular">{s.v}</p>
            <p className="text-xs text-white/40 font-semibold mt-1">{s.l}</p>
          </div>
        ))}
      </div>

      <div className="reveal grid sm:grid-cols-2 xl:grid-cols-3 gap-3.5 mt-6">
        {TRADERS.map((tr) => {
          const on = followed.includes(tr.id);
          const up = tr.roi >= 0;
          return (
            <div key={tr.id} className={`panel panel-hover rounded-[26px] p-5 sm:p-6 relative overflow-hidden ${on ? "!border-gold/40" : ""}`}>
              {on && <span className="absolute top-0 inset-x-0 h-1 bg-gradient-to-r from-transparent via-gold to-transparent" />}
              <div className="flex items-center gap-3 mb-4">
                <span className="relative h-13 w-13 shrink-0 grid place-items-center rounded-2xl font-display font-bold text-xl" style={{ width: 52, height: 52, background: `linear-gradient(140deg, ${tr.color}33, ${tr.color}0d)`, color: tr.color, border: `1px solid ${tr.color}44` }}>
                  {tr.name[0]}
                  <span className="absolute -bottom-1 -end-1 h-5 w-5 rounded-full bg-night grid place-items-center"><BadgeCheck className="h-4 w-4 text-gold" /></span>
                </span>
                <div className="min-w-0">
                  <p className="font-bold text-[17px] leading-tight">{tr.name}</p>
                  <p className="text-xs text-white/40 font-semibold">{tr.tag}</p>
                </div>
                <span className="ms-auto text-[10px] font-black px-2.5 py-1 rounded-lg" style={{ background: `${RISK_C[tr.risk]}18`, color: RISK_C[tr.risk] }}>{t.risk}: {tr.risk}</span>
              </div>
              <div className="grid grid-cols-3 gap-2 text-center mb-4">
                {[
                  { l: t.win, v: `${tr.win}%`, c: "text-jade" },
                  { l: t.roi, v: `+${tr.roi}%`, c: "text-goldsoft" },
                  { l: t.focus, v: tr.focus, c: "" },
                ].map((s, i) => (
                  <div key={i} className="rounded-xl bg-black/30 border border-white/6 py-2.5">
                    <p className={`font-display font-bold tabular ${s.c}`}>{s.v}</p>
                    <p className="text-[10px] text-white/35 font-bold">{s.l}</p>
                  </div>
                ))}
              </div>
              <div className="flex items-center justify-between mb-4">
                <Sparkline data={tr.spark} up={up} w={120} h={34} />
                <span className="text-xs text-white/40 font-semibold tabular">{tr.copiers.toLocaleString()} 👥</span>
              </div>
              <button
                onClick={() => onToggle(tr)}
                className={`w-full py-3.5 rounded-2xl font-black text-sm flex items-center justify-center gap-2 transition active:scale-[0.98] ${on ? "bg-jade/15 text-jade border border-jade/30" : "btn-gold"}`}
              >
                {on ? <><Check className="h-4.5 w-4.5" />{t.following}</> : <><Plus className="h-4.5 w-4.5" />{t.follow} · {tr.tag}</>}
              </button>
            </div>
          );
        })}
      </div>

      <div className="reveal panel rounded-[26px] p-6 sm:p-8 mt-6 flex flex-col md:flex-row md:items-center gap-6">
        <span className="h-14 w-14 rounded-2xl bg-gold/12 border border-gold/25 grid place-items-center shrink-0"><CopyIcon className="h-7 w-7 text-gold" /></span>
        <div className="flex-1">
          <h3 className="font-display font-bold text-xl mb-3">{t.how}</h3>
          <div className="grid sm:grid-cols-3 gap-3">
            {t.howSteps.map((s, i) => (
              <div key={i} className="flex gap-2.5 text-sm text-white/60">
                <span className="font-display italic font-bold text-gold text-lg leading-none">{i + 1}</span>{s}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
