import { useMemo, useState } from "react";
import { ArrowDownRight, ArrowUpDown, ArrowUpRight, Search, TrendingUp, Zap } from "lucide-react";
import { Coin, Lang, T, changeOf, fmtPrice } from "../lib/data";
import { Sparkline } from "../components/Charts";

export default function Markets({ lang, coins, onTrade }: { lang: Lang; coins: Coin[]; onTrade: (s: string) => void }) {
  const t = T[lang].mk;
  const [q, setQ] = useState("");
  const [sort, setSort] = useState(false);
  const list = useMemo(() => {
    let arr = [...coins];
    if (sort) arr.sort((a, b) => changeOf(b) - changeOf(a));
    if (q) arr = arr.filter((c) => c.sym.toLowerCase().includes(q.toLowerCase()) || c.name.toLowerCase().includes(q.toLowerCase()));
    return arr;
  }, [coins, q, sort]);

  return (
    <div className="pt-8 sm:pt-10">
      <div className="reveal in flex flex-col md:flex-row md:items-end justify-between gap-5">
        <div>
          <div className="inline-flex items-center gap-2 text-xs font-black tracking-[0.2em] text-gold uppercase mb-3">
            <span className="live-gold h-2 w-2 rounded-full bg-gold" />{t.title}
          </div>
          <h2 className="font-display font-semibold text-4xl sm:text-5xl">{t.title}</h2>
          <p className="mt-2 text-white/50 max-w-xl text-[15px]">{t.sub}</p>
        </div>
        <div className="flex gap-2.5">
          <div className="relative flex-1 sm:flex-none">
            <Search className="absolute start-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-white/35" />
            <input value={q} onChange={(e) => setQ(e.target.value)} placeholder={t.search} className="panel rounded-xl ps-10 pe-4 py-2.5 text-sm w-full sm:w-52 outline-none focus:border-gold/50 placeholder:text-white/30 transition" />
          </div>
          <button onClick={() => setSort(!sort)} className={`inline-flex items-center gap-1.5 rounded-xl px-4 py-2.5 text-xs font-black transition ${sort ? "bg-gold text-[#1a1405]" : "panel text-white/60"}`}>
            <ArrowUpDown className="h-3.5 w-3.5" />{t.chg}
          </button>
        </div>
      </div>

      <div className="reveal in panel rounded-[26px] overflow-hidden mt-6">
        <div className="hidden md:grid grid-cols-[1.4fr_1fr_0.9fr_1fr_1fr_0.7fr] gap-4 px-6 py-3.5 text-[10px] font-black tracking-[0.15em] text-white/35 uppercase border-b hairline">
          <span>{t.asset}</span><span>{t.price}</span><span>{t.chg}</span><span>{t.trend}</span><span>{t.range}</span><span></span>
        </div>
        <div className="divide-y divide-white/5">
          {list.map((c) => {
            const ch = changeOf(c);
            const up = ch >= 0;
            const lo = Math.min(...c.spark), hi = Math.max(...c.spark);
            const pos = hi > lo ? ((c.price - lo) / (hi - lo)) * 100 : 50;
            return (
              <div key={c.sym} className="grid grid-cols-[1.5fr_1fr_auto] md:grid-cols-[1.4fr_1fr_0.9fr_1fr_1fr_0.7fr] items-center gap-3 md:gap-4 px-4 sm:px-6 py-3.5 hover:bg-gold/[0.04] transition group">
                <span className="flex items-center gap-3 min-w-0">
                  <span className="h-10 w-10 rounded-xl grid place-items-center font-display font-bold shrink-0" style={{ background: `${c.color}1c`, color: c.color, border: `1px solid ${c.color}3d` }}>{c.sym[0]}</span>
                  <span className="min-w-0">
                    <span className="font-bold text-[15px]">{c.sym}<span className="text-white/30 text-xs font-semibold"> /USDT</span></span>
                    <span className="block text-xs text-white/40 truncate">{c.name}</span>
                  </span>
                </span>
                <span className="font-display font-semibold tabular text-[15px]">${fmtPrice(c.price, c.dec)}</span>
                <span className={`hidden md:inline-flex items-center gap-1 font-bold text-sm tabular ${up ? "text-jade" : "text-[#ff4d6d]"}`}>
                  {up ? <ArrowUpRight className="h-4 w-4" /> : <ArrowDownRight className="h-4 w-4" />}{Math.abs(ch).toFixed(2)}%
                </span>
                <span className="hidden md:block"><Sparkline data={c.spark} up={up} /></span>
                <span className="hidden md:flex items-center gap-2">
                  <span className="relative flex-1 h-1.5 rounded-full bg-white/8">
                    <span className="absolute top-1/2 -translate-y-1/2 h-2.5 w-2.5 rounded-full bg-gold shadow-[0_0_8px_#e8c15a]" style={{ left: `calc(${Math.max(2, Math.min(98, pos))}% - 5px)` }} />
                  </span>
                  <span className="text-[10px] text-white/35 tabular font-semibold">{c.vol}</span>
                </span>
                <span className={`md:hidden font-bold text-sm tabular ${up ? "text-jade" : "text-[#ff4d6d]"}`}>{up ? "+" : ""}{ch.toFixed(2)}%</span>
                <span className="hidden md:block text-end">
                  <button onClick={() => onTrade(c.sym)} className="inline-flex items-center gap-1 text-xs font-black px-3.5 py-2 rounded-xl bg-gold/10 text-gold border border-gold/25 opacity-0 group-hover:opacity-100 transition hover:bg-gold hover:text-[#1a1405]">
                    <Zap className="h-3.5 w-3.5" />{t.trade}
                  </button>
                </span>
                <button onClick={() => onTrade(c.sym)} className="md:hidden col-span-3 btn-ghost rounded-xl py-2 text-xs font-black text-gold">{t.trade} {c.sym}</button>
              </div>
            );
          })}
          {list.length === 0 && (
            <div className="py-16 text-center text-white/40 flex flex-col items-center gap-2">
              <TrendingUp className="h-8 w-8" />{t.empty}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
