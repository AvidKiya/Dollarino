import { ArrowRight, ArrowUpRight, BadgeCheck, BrainCircuit, Crosshair, Copy, Plug2, Layers, TrendingUp, Zap } from "lucide-react";
import { Coin, ENGINE_META, Lang, Signal, T, View, fmtMoney, fmtPrice, fmtSign, timeAgo } from "../lib/data";
import { Counter, EquityCurve, Gauge } from "../components/Charts";

interface Props {
  lang: Lang; coins: Coin[]; equity: number[]; signals: Signal[];
  stats: { total: number; wins: number; pnl: number };
  consensus: number; onGo: (v: View) => void; onTrade: (sym: string) => void;
}

const SHOWDOWN = [
  { e: "ai" as const, win: 71, roi: 34.2, icon: BrainCircuit },
  { e: "strategy" as const, win: 64, roi: 22.8, icon: Crosshair },
  { e: "copy" as const, win: 58, roi: 18.1, icon: Copy },
];

export default function Overview({ lang, coins, equity, signals, stats, consensus, onGo, onTrade }: Props) {
  const t = T[lang].ov;
  const tr = T[lang].radar;
  const winRate = stats.total ? (stats.wins / stats.total) * 100 : 0;
  const latest = signals.slice(0, 3);
  const cur = equity[equity.length - 1] ?? 0;
  const start = equity[0] ?? 1;
  const eqChg = ((cur - start) / start) * 100;

  return (
    <div className="pt-8 sm:pt-12 pb-4">
      {/* ---------- hero ---------- */}
      <div className="reveal in relative text-center max-w-3xl mx-auto">
        <div className="absolute left-1/2 top-0 -translate-x-1/2 h-72 w-[520px] max-w-full rounded-full bg-gold/12 blur-[110px] pointer-events-none" />
        <div className="relative inline-flex items-center gap-2 panel rounded-full px-4 py-2 text-xs font-bold text-goldsoft mb-7">
          <span className="live-gold h-2 w-2 rounded-full bg-gold" />{t.badge}
        </div>
        <h1 className="relative font-display font-semibold tracking-tight leading-[1.04] text-[52px] sm:text-7xl lg:text-[86px]">
          {t.t1} <em className="text-gold-grad not-italic font-display italic">{t.t2}</em>
        </h1>
        <p className="relative mt-6 text-white/55 text-[15px] sm:text-lg leading-relaxed max-w-2xl mx-auto">{t.sub}</p>
        <div className="relative mt-9 flex flex-wrap justify-center gap-3">
          <button onClick={() => onTrade("BTC")} className="btn-gold inline-flex items-center gap-2 font-black px-8 py-4 rounded-2xl text-[15px]">
            <Zap className="h-5 w-5" />{t.cta1}
          </button>
          <button onClick={() => onGo("radar")} className="btn-ghost inline-flex items-center gap-2 font-bold px-8 py-4 rounded-2xl text-[15px]">
            {t.cta2}<ArrowRight className="h-4 w-4 rtl:rotate-180" />
          </button>
        </div>
        <div className="relative mt-10 grid grid-cols-2 sm:grid-cols-4 gap-2.5 max-w-2xl mx-auto">
          {[
            { v: <Counter to={30} suffix="+" />, l: t.s1 },
            { v: <Counter to={stats.total} />, l: t.s2 },
            { v: <Counter to={winRate} suffix="%" decimals={1} />, l: t.s3 },
            { v: <Counter to={50} suffix="×" />, l: t.s4 },
          ].map((s, i) => (
            <div key={i} className="panel rounded-2xl px-3 py-4">
              <p className="font-display font-bold text-2xl text-goldsoft">{s.v}</p>
              <p className="text-[11px] text-white/40 font-semibold mt-1">{s.l}</p>
            </div>
          ))}
        </div>
      </div>

      {/* ---------- dashboard grid ---------- */}
      <div className="reveal grid lg:grid-cols-[1.5fr_1fr] gap-4 mt-12">
        <div className="panel rounded-[26px] p-5 sm:p-6 relative overflow-hidden">
          <div className="absolute -top-20 -end-20 h-56 w-56 rounded-full bg-gold/10 blur-[80px]" />
          <div className="relative flex items-center justify-between mb-1">
            <h3 className="font-display font-bold text-xl">{t.equity}</h3>
            <span className="inline-flex items-center gap-1.5 text-[10px] font-black tracking-widest text-jade"><span className="live-dot h-1.5 w-1.5 rounded-full bg-jade" />{t.live}</span>
          </div>
          <div className="relative flex items-end gap-3 mb-3">
            <p className="font-display font-bold text-3xl sm:text-4xl tabular">{fmtMoney(cur)}</p>
            <span className={`inline-flex items-center gap-1 text-xs font-black px-2 py-1 rounded-lg mb-1.5 ${eqChg >= 0 ? "bg-jade/15 text-jade" : "bg-[#ff4d6d]/15 text-[#ff4d6d]"}`}>
              <ArrowUpRight className="h-3.5 w-3.5" />{fmtSign(eqChg)}
            </span>
          </div>
          <div className="relative h-52 sm:h-60"><EquityCurve data={equity} /></div>
        </div>
        <div className="flex flex-col gap-4">
          <div className="panel rounded-[26px] p-5 sm:p-6">
            <h3 className="font-display font-bold text-xl mb-4">{t.consensus}</h3>
            <Gauge value={consensus} longL={t.long} shortL={t.short} />
          </div>
          <div className="panel rounded-[26px] p-5 sm:p-6 flex-1">
            <h3 className="font-display font-bold text-xl mb-4">{t.showdown}</h3>
            <div className="space-y-4">
              {SHOWDOWN.map((s) => {
                const meta = ENGINE_META[s.e];
                return (
                  <div key={s.e}>
                    <div className="flex items-center gap-2 mb-1.5">
                      <s.icon className="h-4 w-4" style={{ color: meta.color }} />
                      <span className="text-[13px] font-bold">{meta[lang]}</span>
                      <span className="ms-auto text-xs font-bold tabular" style={{ color: meta.color }}>{s.win}%</span>
                    </div>
                    <div className="h-2 rounded-full bg-white/8 overflow-hidden">
                      <div className="h-full rounded-full transition-all duration-1000" style={{ width: `${s.win}%`, background: `linear-gradient(90deg, ${meta.color}66, ${meta.color})` }} />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>

      {/* ---------- latest signals ---------- */}
      <div className="reveal flex items-center justify-between mt-12 mb-4">
        <h3 className="font-display font-bold text-2xl">{t.latest}</h3>
        <button onClick={() => onGo("radar")} className="inline-flex items-center gap-1.5 text-sm font-bold text-gold hover:text-goldsoft transition">
          {t.viewAll}<ArrowRight className="h-4 w-4 rtl:rotate-180" />
        </button>
      </div>
      <div className="reveal grid sm:grid-cols-3 gap-3">
        {latest.map((s) => {
          const coin = coins.find((c) => c.sym === s.sym);
          const meta = ENGINE_META[s.engine];
          const long = s.side === "long";
          return (
            <button key={s.id} onClick={() => onTrade(s.sym)} className="panel panel-hover rounded-3xl p-5 text-start">
              <div className="flex items-center gap-2.5 mb-3">
                <span className="h-10 w-10 rounded-xl grid place-items-center font-display font-bold" style={{ background: `${coin?.color}1f`, color: coin?.color }}>{s.sym[0]}</span>
                <div>
                  <p className="font-bold text-[15px]">{s.sym}<span className="text-white/35 text-xs"> /USDT</span></p>
                  <p className="text-[11px] font-bold" style={{ color: meta.color }}>{meta[lang]}</p>
                </div>
                <span className={`ms-auto text-[11px] font-black px-2.5 py-1 rounded-lg ${long ? "bg-jade/15 text-jade" : "bg-[#ff4d6d]/15 text-[#ff4d6d]"}`}>{long ? "LONG" : "SHORT"}</span>
              </div>
              <div className="flex items-center justify-between text-[13px]">
                <span className="text-white/45">{tr.entry} <b className="text-white/80 tabular">${fmtPrice(s.entry, s.dec)}</b></span>
                <span className="text-white/35 text-xs">{timeAgo(s.born, lang)}</span>
              </div>
              <div className="mt-3 flex items-center gap-2">
                <div className="flex-1 h-1.5 rounded-full bg-white/8 overflow-hidden">
                  <div className="h-full rounded-full bg-gold" style={{ width: `${s.conf}%` }} />
                </div>
                <span className="text-xs font-black text-gold tabular">{s.conf}%</span>
              </div>
            </button>
          );
        })}
      </div>

      {/* ---------- steps ---------- */}
      <h3 className="reveal font-display font-bold text-2xl sm:text-3xl text-center mt-16 mb-6">{t.stepsT}</h3>
      <div className="reveal grid sm:grid-cols-3 gap-3">
        {[
          { icon: Plug2, n: "01" }, { icon: Layers, n: "02" }, { icon: TrendingUp, n: "03" },
        ].map((s, i) => (
          <div key={i} className="panel rounded-3xl p-6 relative overflow-hidden group">
            <span className="absolute -top-2 end-4 font-display italic text-6xl text-gold/10 select-none">{s.n}</span>
            <span className="h-12 w-12 rounded-2xl bg-gold/12 border border-gold/25 grid place-items-center mb-4"><s.icon className="h-6 w-6 text-gold" /></span>
            <h4 className="font-bold text-lg mb-1.5">{t.steps[i][0]}</h4>
            <p className="text-sm text-white/50 leading-relaxed">{t.steps[i][1]}</p>
          </div>
        ))}
      </div>

      {/* ---------- exchanges + cta ---------- */}
      <div className="reveal flex flex-wrap items-center justify-center gap-2.5 mt-14">
        <span className="text-xs font-bold tracking-widest text-white/35 uppercase w-full text-center mb-1">{t.exT}</span>
        {["Paper Demo", "Toobit Futures", "KCEX Futures"].map((x) => (
          <span key={x} className="inline-flex items-center gap-1.5 panel rounded-full px-5 py-2.5 text-sm font-bold"><BadgeCheck className="h-4 w-4 text-jade" />{x}</span>
        ))}
        <span className="panel rounded-full px-5 py-2.5 text-sm font-bold text-white/35">+ {t.more}</span>
      </div>

      <div className="reveal relative overflow-hidden rounded-[30px] mt-10 p-8 sm:p-12 text-center border border-gold/25" style={{ background: "linear-gradient(150deg,#171204 0%,#0d0b05 55%,#0a0d07 100%)" }}>
        <div className="absolute inset-0 grid-bg opacity-70" />
        <div className="absolute left-1/2 top-0 -translate-x-1/2 h-48 w-[420px] rounded-full bg-gold/20 blur-[100px]" />
        <span className="absolute inset-0 grid place-items-center font-display font-bold text-[190px] text-gold/[0.05] select-none">D$</span>
        <div className="relative">
          <h3 className="font-display font-semibold text-3xl sm:text-5xl leading-tight">{t.ctaT}</h3>
          <p className="mt-3 text-white/55">{t.ctaS}</p>
          <button onClick={() => onTrade("BTC")} className="btn-gold mt-8 inline-flex items-center gap-2 font-black px-9 py-4 rounded-2xl">
            <Zap className="h-5 w-5" />{t.ctaB}
          </button>
        </div>
      </div>
    </div>
  );
}
