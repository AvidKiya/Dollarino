import { ArrowDownRight, ArrowUpRight, Briefcase, CircleDollarSign, PiggyBank, Target, Trophy, X, Zap } from "lucide-react";
import { Coin, Lang, Position, T, fmtMoney, fmtPrice } from "../lib/data";
import { Donut } from "../components/Charts";

interface Props {
  lang: Lang; coins: Coin[]; positions: Position[];
  cash: number; realized: number; winRate: number;
  unreal: number; equity: number;
  onClose: (p: Position) => void; onTrade: () => void;
}

export default function Portfolio({ lang, coins, positions, cash, realized, winRate, unreal, equity, onClose, onTrade }: Props) {
  const t = T[lang].pf;
  const colorOf = (sym: string) => coins.find((c) => c.sym === sym)?.color ?? "#e8c15a";
  const bySym = new Map<string, number>();
  positions.forEach((p) => bySym.set(p.sym, (bySym.get(p.sym) ?? 0) + p.margin));
  const slices = [
    ...[...bySym.entries()].map(([sym, v]) => ({ label: sym, value: v, color: colorOf(sym) })),
    { label: "USDT", value: Math.max(0, cash), color: "#10d9a3" },
  ];

  return (
    <div className="pt-8 sm:pt-10">
      <div className="reveal in">
        <div className="inline-flex items-center gap-2 text-xs font-black tracking-[0.2em] text-gold uppercase mb-3">
          <span className="live-gold h-2 w-2 rounded-full bg-gold" />{t.title}
        </div>
        <h2 className="font-display font-semibold text-4xl sm:text-5xl">{t.title}</h2>
        <p className="mt-2 text-white/50 max-w-xl text-[15px]">{t.sub}</p>
      </div>

      <div className="reveal in grid grid-cols-2 lg:grid-cols-4 gap-2.5 mt-7">
        {[
          { icon: Briefcase, l: t.equity, v: fmtMoney(equity), c: "text-gold" },
          { icon: CircleDollarSign, l: t.unrl, v: `${unreal >= 0 ? "+" : ""}${fmtMoney(unreal)}`, c: unreal >= 0 ? "text-jade" : "text-[#ff4d6d]" },
          { icon: PiggyBank, l: t.real, v: `${realized >= 0 ? "+" : ""}${fmtMoney(realized)}`, c: realized >= 0 ? "text-jade" : "text-[#ff4d6d]" },
          { icon: Trophy, l: t.winr, v: `${winRate.toFixed(0)}%`, c: "text-[#38e1ff]" },
        ].map((s, i) => (
          <div key={i} className="panel rounded-3xl p-5">
            <s.icon className={`h-5 w-5 mb-2.5 ${s.c}`} />
            <p className="font-display font-bold text-2xl tabular">{s.v}</p>
            <p className="text-xs text-white/40 font-semibold mt-1">{s.l}</p>
          </div>
        ))}
      </div>

      <div className="grid lg:grid-cols-[320px_1fr] gap-4 mt-4">
        <div className="reveal panel rounded-[26px] p-6 flex flex-col items-center">
          <h3 className="font-display font-bold text-xl self-start mb-4">{t.alloc}</h3>
          <Donut slices={slices} />
          <div className="w-full mt-5 space-y-2">
            {slices.map((s) => {
              const tot = slices.reduce((a, x) => a + x.value, 0) || 1;
              return (
                <div key={s.label} className="flex items-center gap-2.5 text-sm">
                  <span className="h-2.5 w-2.5 rounded-full" style={{ background: s.color }} />
                  <span className="font-bold">{s.label}</span>
                  <span className="ms-auto text-white/50 tabular font-semibold">{((s.value / tot) * 100).toFixed(1)}%</span>
                  <span className="tabular font-bold w-16 text-end">{fmtMoney(s.value)}</span>
                </div>
              );
            })}
          </div>
        </div>

        <div className="reveal panel rounded-[26px] p-5 sm:p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-display font-bold text-xl">{t.pos} ({positions.length})</h3>
            <button onClick={onTrade} className="btn-gold inline-flex items-center gap-1.5 text-xs font-black px-4 py-2.5 rounded-xl">
              <Zap className="h-3.5 w-3.5" />{t.emptyCta}
            </button>
          </div>
          {positions.length === 0 ? (
            <div className="rounded-2xl border border-dashed border-gold/25 py-14 text-center">
              <Target className="h-9 w-9 mx-auto text-gold/50 mb-3" />
              <p className="text-white/50 text-sm max-w-xs mx-auto">{t.empty}</p>
            </div>
          ) : (
            <div className="space-y-2.5 max-h-[460px] overflow-y-auto pe-1">
              {positions.map((p) => {
                const coin = coins.find((c) => c.sym === p.sym);
                const cur = coin?.price ?? p.entry;
                const pct = (cur - p.entry) / p.entry;
                const pnl = p.margin * p.lev * (p.side === "long" ? pct : -pct);
                const long = p.side === "long";
                return (
                  <div key={p.id} className="rounded-2xl border border-white/8 bg-white/[0.025] p-4 flex flex-wrap items-center gap-3">
                    <span className="h-10 w-10 rounded-xl grid place-items-center font-display font-bold shrink-0" style={{ background: `${coin?.color}1f`, color: coin?.color }}>{p.sym[0]}</span>
                    <div>
                      <p className="font-bold flex items-center gap-2">
                        {p.sym}
                        <span className={`inline-flex items-center gap-0.5 text-[10px] font-black px-1.5 py-0.5 rounded-md ${long ? "bg-jade/15 text-jade" : "bg-[#ff4d6d]/15 text-[#ff4d6d]"}`}>
                          {long ? <ArrowUpRight className="h-3 w-3" /> : <ArrowDownRight className="h-3 w-3" />}{p.side.toUpperCase()} {p.lev}×
                        </span>
                      </p>
                      <p className="text-[11px] text-white/40 tabular">{t.entry} ${fmtPrice(p.entry, p.dec)} → {t.mark} ${fmtPrice(cur, p.dec)}</p>
                    </div>
                    {p.mirror && <span className="text-[10px] font-black px-2 py-1 rounded-lg bg-gold/12 text-gold border border-gold/25">{t.mirror} · {p.mirror}</span>}
                    <span className="text-xs text-white/45 tabular">{t.margin} {fmtMoney(p.margin)}</span>
                    <span className={`ms-auto font-display font-bold text-lg tabular ${pnl >= 0 ? "text-jade" : "text-[#ff4d6d]"}`}>{pnl >= 0 ? "+" : ""}{fmtMoney(pnl)}</span>
                    <button onClick={() => onClose(p)} className="inline-flex items-center gap-1 text-xs font-black px-3.5 py-2 rounded-xl bg-white/6 hover:bg-[#ff4d6d]/20 hover:text-[#ff4d6d] transition">
                      <X className="h-3.5 w-3.5" />{t.close}
                    </button>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
