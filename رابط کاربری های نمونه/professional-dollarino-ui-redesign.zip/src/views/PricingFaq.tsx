import { useState } from "react";
import { Check, ChevronDown, Crown, Sparkles, Zap } from "lucide-react";
import { Lang, T } from "../lib/data";

export function Pricing({ lang, onStart }: { lang: Lang; onStart: () => void }) {
  const t = T[lang].pr;
  return (
    <div className="pt-8 sm:pt-10">
      <div className="reveal in text-center max-w-2xl mx-auto">
        <div className="inline-flex items-center gap-2 text-xs font-black tracking-[0.2em] text-gold uppercase mb-3">
          <span className="live-gold h-2 w-2 rounded-full bg-gold" />{t.title}
        </div>
        <h2 className="font-display font-semibold text-4xl sm:text-5xl">{t.title}</h2>
        <p className="mt-2 text-white/50 text-[15px]">{t.sub}</p>
      </div>
      <div className="reveal in grid md:grid-cols-3 gap-4 max-w-4xl mx-auto mt-9 items-stretch">
        {t.plans.map((p, i) => {
          const hot = i === 1;
          return (
            <div key={p.name} className={`relative rounded-[28px] p-7 flex flex-col transition hover:-translate-y-1.5 duration-300 ${hot ? "panel md:scale-[1.05] z-10 !border-gold/50" : "panel"}`} style={hot ? { boxShadow: "0 30px 80px -30px rgba(232,193,90,.5)" } : undefined}>
              {hot && (
                <span className="absolute -top-3.5 left-1/2 -translate-x-1/2 inline-flex items-center gap-1 btn-gold text-[11px] font-black px-4 py-1.5 rounded-full whitespace-nowrap">
                  <Crown className="h-3 w-3" />{t.pop}
                </span>
              )}
              <h3 className={`font-display font-bold text-2xl ${hot ? "text-gold-grad" : ""}`}>{p.name}</h3>
              <p className="text-sm text-white/45 mt-1">{p.desc}</p>
              <div className="mt-5 flex items-end gap-1">
                <span className="font-display font-bold text-5xl tabular">{p.price}</span>
                <span className="text-white/40 mb-1.5 text-sm">{t.mo}</span>
              </div>
              <ul className="mt-6 space-y-3 flex-1">
                {p.feats.map((f) => (
                  <li key={f} className="flex items-center gap-2.5 text-sm text-white/70">
                    <span className={`h-5 w-5 rounded-full grid place-items-center shrink-0 ${hot ? "bg-gold/20 text-gold" : "bg-white/8 text-white/50"}`}><Check className="h-3 w-3" /></span>{f}
                  </li>
                ))}
              </ul>
              <button onClick={onStart} className={`mt-8 w-full py-3.5 rounded-2xl font-black transition active:scale-[0.98] ${hot ? "btn-gold" : "btn-ghost"}`}>
                {t.cta}
              </button>
            </div>
          );
        })}
      </div>
      <div className="reveal panel rounded-3xl max-w-4xl mx-auto mt-6 p-6 flex flex-col sm:flex-row items-center gap-4 text-center sm:text-start">
        <span className="h-12 w-12 rounded-2xl bg-gold/12 border border-gold/25 grid place-items-center shrink-0"><Sparkles className="h-6 w-6 text-gold" /></span>
        <p className="text-sm text-white/55 flex-1">{lang === "fa" ? "همه پلن‌ها با ۷ روز ضمانت بازگشت وجه. بدون قید و شرط." : "Every plan ships with a 7-day money-back guarantee. No questions asked."}</p>
        <button onClick={onStart} className="btn-ghost inline-flex items-center gap-2 font-bold px-6 py-3 rounded-2xl text-sm shrink-0"><Zap className="h-4 w-4 text-gold" />{t.cta}</button>
      </div>
    </div>
  );
}

export function Faq({ lang }: { lang: Lang }) {
  const t = T[lang].fq;
  const [open, setOpen] = useState(0);
  return (
    <div className="pt-8 sm:pt-10 max-w-3xl mx-auto">
      <div className="reveal in text-center">
        <div className="inline-flex items-center gap-2 text-xs font-black tracking-[0.2em] text-gold uppercase mb-3">
          <span className="live-gold h-2 w-2 rounded-full bg-gold" />{t.title}
        </div>
        <h2 className="font-display font-semibold text-4xl sm:text-5xl">{t.title}</h2>
        <p className="mt-2 text-white/50 text-[15px]">{t.sub}</p>
      </div>
      <div className="reveal in space-y-3 mt-8">
        {t.items.map((it, i) => (
          <div key={i} className={`panel rounded-3xl overflow-hidden transition ${open === i ? "!border-gold/40" : ""}`}>
            <button onClick={() => setOpen(open === i ? -1 : i)} className="w-full flex items-center justify-between gap-4 px-6 py-5 text-start font-bold text-[15px]">
              {it[0]}
              <ChevronDown className={`h-5 w-5 shrink-0 text-gold transition-transform duration-300 ${open === i ? "rotate-180" : ""}`} />
            </button>
            <div className={`grid transition-all duration-300 ${open === i ? "grid-rows-[1fr] opacity-100" : "grid-rows-[0fr] opacity-0"}`}>
              <div className="overflow-hidden"><p className="px-6 pb-6 text-white/55 text-sm leading-relaxed">{it[1]}</p></div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
