import { useState } from "react";
import { Activity, ArrowDownRight, ArrowUpRight, Crosshair, Flame, Target, Trophy } from "lucide-react";
import { Coin, ENGINE_META, Engine, Lang, Signal, T, changeOf, fmtMoney, fmtPrice, fmtSign, timeAgo } from "../lib/data";
import { Gauge } from "../components/Charts";

interface Props {
  lang: Lang; coins: Coin[]; signals: Signal[];
  stats: { total: number; wins: number; pnl: number; avgConf: number };
  consensus: number; onTrade: (sym: string) => void;
}

export default function Radar({ lang, coins, signals, stats, consensus, onTrade }: Props) {
  const t = T[lang].radar;
  const to = T[lang].ov;
  const [filter, setFilter] = useState<"all" | Engine>("all");
  const winRate = stats.total ? (stats.wins / stats.total) * 100 : 0;
  const feed = signals.filter((s) => filter === "all" || s.engine === filter);
  const momentum = [...coins].sort((a, b) => Math.abs(changeOf(b)) - Math.abs(changeOf(a))).slice(0, 5);

  return (
    <div className="pt-8 sm:pt-10">
      <div className="reveal in flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 text-xs font-black tracking-[0.2em] text-gold uppercase mb-3">
            <span className="live-gold h-2 w-2 rounded-full bg-gold" />{t.title}
          </div>
          <h2 className="font-display font-semibold text-4xl sm:text-5xl">{t.title}</h2>
          <p className="mt-2 text-white/50 max-w-xl text-[15px]">{t.sub}</p>
        </div>
        <div className="flex gap-1.5 panel rounded-full p-1.5 w-fit">
          {(["all", "ai", "strategy", "copy"] as const).map((f) => (
            <button key={f} onClick={() => setFilter(f)} className={`px-4 py-2 rounded-full text-xs font-black transition whitespace-nowrap ${filter === f ? "bg-gold text-[#1a1405]" : "text-white/50 hover:text-white"}`}>
              {f === "all" ? t.all : ENGINE_META[f][lang]}
            </button>
          ))}
        </div>
      </div>

      <div className="reveal in grid grid-cols-2 lg:grid-cols-4 gap-2.5 mt-7">
        {[
          { icon: Activity, l: t.st1, v: String(stats.total), c: "text-gold" },
          { icon: Trophy, l: t.st2, v: `${winRate.toFixed(1)}%`, c: "text-jade" },
          { icon: Crosshair, l: t.st3, v: `${stats.avgConf.toFixed(0)}%`, c: "text-[#38e1ff]" },
          { icon: Target, l: t.st4, v: `${stats.pnl >= 0 ? "+" : ""}${fmtMoney(stats.pnl)}`, c: stats.pnl >= 0 ? "text-jade" : "text-[#ff4d6d]" },
        ].map((s, i) => (
          <div key={i} className="panel rounded-3xl p-5">
            <s.icon className={`h-5 w-5 mb-2.5 ${s.c}`} />
            <p className="font-display font-bold text-2xl sm:text-[27px] tabular">{s.v}</p>
            <p className="text-xs text-white/40 font-semibold mt-1">{s.l}</p>
          </div>
        ))}
      </div>

      <div className="grid lg:grid-cols-[1fr_300px] gap-4 mt-4">
        {/* feed */}
        <div className="reveal panel rounded-[26px] p-4 sm:p-5">
          <h3 className="font-display font-bold text-xl px-1 mb-4">{t.feed}</h3>
          <div className="space-y-2.5 max-h-[720px] overflow-y-auto pe-1">
            {feed.map((s) => <SignalCard key={s.id} s={s} lang={lang} coins={coins} onTrade={onTrade} />)}
          </div>
        </div>
        {/* side */}
        <div className="reveal flex flex-col gap-4">
          <div className="panel rounded-[26px] p-5">
            <h3 className="font-display font-bold text-lg mb-3">{to.consensus}</h3>
            <Gauge value={consensus} longL={to.long} shortL={to.short} />
          </div>
          <div className="panel rounded-[26px] p-5">
            <h3 className="font-display font-bold text-lg mb-4 flex items-center gap-2"><Flame className="h-4.5 w-4.5 text-gold" />{t.mom}</h3>
            <div className="space-y-3">
              {momentum.map((c) => {
                const ch = changeOf(c);
                return (
                  <button key={c.sym} onClick={() => onTrade(c.sym)} className="w-full flex items-center gap-2.5 group">
                    <span className="font-bold text-sm w-12 text-start" style={{ color: c.color }}>{c.sym}</span>
                    <div className="flex-1 h-2 rounded-full bg-white/8 overflow-hidden">
                      <div className={`h-full rounded-full ${ch >= 0 ? "bg-jade" : "bg-[#ff4d6d]"}`} style={{ width: `${Math.min(100, Math.abs(ch) * 12)}%` }} />
                    </div>
                    <span className={`text-xs font-black tabular w-14 text-end ${ch >= 0 ? "text-jade" : "text-[#ff4d6d]"}`}>{fmtSign(ch)}</span>
                  </button>
                );
              })}
            </div>
          </div>
          <div className="panel rounded-[26px] p-5">
            <h3 className="font-display font-bold text-lg mb-4">{t.board}</h3>
            <div className="space-y-3">
              {[
                { e: "ai" as Engine, win: 71, roi: "+34.2%" },
                { e: "strategy" as Engine, win: 64, roi: "+22.8%" },
                { e: "copy" as Engine, win: 58, roi: "+18.1%" },
              ].map((r, i) => {
                const m = ENGINE_META[r.e];
                return (
                  <div key={r.e} className="flex items-center gap-3">
                    <span className="font-display italic font-bold text-lg w-6" style={{ color: i === 0 ? "#e8c15a" : "rgba(255,255,255,.3)" }}>{i + 1}</span>
                    <div className="flex-1">
                      <p className="text-sm font-bold" style={{ color: m.color }}>{m[lang]}</p>
                      <p className="text-[11px] text-white/40 tabular">{r.win}% win · {r.roi} ROI</p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export function SignalCard({ s, lang, coins, onTrade }: { s: Signal; lang: Lang; coins: Coin[]; onTrade: (sym: string) => void }) {
  const t = T[lang].radar;
  const coin = coins.find((c) => c.sym === s.sym);
  const meta = ENGINE_META[s.engine];
  const long = s.side === "long";
  const cur = coin?.price ?? s.entry;
  const prog = s.status !== "active" ? (s.status === "tp" ? 100 : 0)
    : long
      ? Math.max(0, Math.min(100, ((cur - s.sl) / (s.tp - s.sl)) * 100))
      : Math.max(0, Math.min(100, ((s.sl - cur) / (s.sl - s.tp)) * 100));
  return (
    <div className="signal-in rounded-2xl border border-white/8 bg-white/[0.025] hover:border-gold/30 transition p-4">
      <div className="flex flex-wrap items-center gap-2.5">
        <span className="h-10 w-10 rounded-xl grid place-items-center font-display font-bold shrink-0" style={{ background: `${coin?.color}1f`, color: coin?.color }}>{s.sym[0]}</span>
        <div className="min-w-0">
          <p className="font-bold">{s.sym}<span className="text-white/35 text-xs font-semibold"> /USDT</span></p>
          <p className="text-[11px] font-bold" style={{ color: meta.color }}>{meta[lang]} · {timeAgo(s.born, lang)}</p>
        </div>
        <span className={`inline-flex items-center gap-1 text-[11px] font-black px-2.5 py-1 rounded-lg ${long ? "bg-jade/15 text-jade" : "bg-[#ff4d6d]/15 text-[#ff4d6d]"}`}>
          {long ? <ArrowUpRight className="h-3.5 w-3.5" /> : <ArrowDownRight className="h-3.5 w-3.5" />}{long ? "LONG" : "SHORT"} · {s.conf}%
        </span>
        <span className="ms-auto">
          {s.status === "active" ? (
            <span className="inline-flex items-center gap-1.5 text-[11px] font-black text-gold"><span className="live-gold h-1.5 w-1.5 rounded-full bg-gold" />{t.active}</span>
          ) : s.status === "tp" ? (
            <span className="text-[11px] font-black px-2.5 py-1 rounded-lg bg-jade/15 text-jade">✓ {t.tp} {fmtSign(s.pnl)}</span>
          ) : (
            <span className="text-[11px] font-black px-2.5 py-1 rounded-lg bg-[#ff4d6d]/15 text-[#ff4d6d]">✕ {t.sl} {fmtSign(s.pnl)}</span>
          )}
        </span>
      </div>
      <div className="mt-3 grid grid-cols-3 gap-2 text-center">
        {[
          { l: t.entry, v: s.entry, c: "text-white/85" },
          { l: t.tpL, v: s.tp, c: "text-jade" },
          { l: t.slL, v: s.sl, c: "text-[#ff4d6d]" },
        ].map((x, i) => (
          <div key={i} className="rounded-xl bg-black/30 border border-white/6 py-2 px-1">
            <p className="text-[10px] font-bold text-white/35">{x.l}</p>
            <p className={`text-[13px] font-bold tabular ${x.c}`}>${fmtPrice(x.v, s.dec)}</p>
          </div>
        ))}
      </div>
      <div className="mt-3 flex items-center gap-2.5">
        <div className="flex-1 h-1.5 rounded-full bg-white/8 overflow-hidden">
          <div className="h-full rounded-full transition-all duration-700" style={{ width: `${prog}%`, background: s.status === "sl" ? "#ff4d6d" : "linear-gradient(90deg,#9a7420,#e8c15a,#10d9a3)" }} />
        </div>
        <button onClick={() => onTrade(s.sym)} className="text-[11px] font-black text-gold hover:text-goldsoft transition shrink-0">
          {lang === "fa" ? "کپی معامله ←" : "Copy trade →"}
        </button>
      </div>
    </div>
  );
}
