import { useRef, useState } from "react";
import { Download, Layers, Sparkles, Target, TrendingUp, Trophy, WandSparkles } from "lucide-react";
import { Lang, T } from "../lib/data";

const THEMES = [
  { id: "gold", from: "#3b2a08", to: "#11130a", accent: "#e8c15a", text: "#f5e8bd" },
  { id: "cobalt", from: "#102a73", to: "#2b5cff", accent: "#38e1ff", text: "#eef2ff" },
  { id: "light", from: "#ffffff", to: "#e8edf9", accent: "#2b5cff", text: "#101827" },
  { id: "emerald", from: "#052e22", to: "#0a5c40", accent: "#10d9a3", text: "#d9fff0" },
  { id: "sunset", from: "#3b0f2e", to: "#8a1c4d", accent: "#ffb35c", text: "#ffe9f0" },
];

export default function WeeklyCard({ lang, stats, onToast }: { lang: Lang; stats: { pnl: number; trades: number; win: number }; onToast: (s: string) => void }) {
  const t = T[lang].card;
  const [name, setName] = useState("Avid"); const [pnl, setPnl] = useState(18.4); const [trades, setTrades] = useState(47); const [win, setWin] = useState(72);
  const [themeId, setThemeId] = useState("gold"); const [busy, setBusy] = useState(false);
  const cardRef = useRef<HTMLDivElement>(null);
  const theme = THEMES.find((x) => x.id === themeId) ?? THEMES[0];
  const light = theme.id === "light";
  const labelCls = "text-[10px] font-black tracking-widest text-white/40 uppercase block mb-2";
  const download = async () => {
    setBusy(true);
    try {
      await document.fonts.ready;
      const W = 1080, H = 1350;
      const cv = document.createElement("canvas"); cv.width = W; cv.height = H;
      const ctx = cv.getContext("2d")!;
      const g = ctx.createLinearGradient(0, 0, W, H); g.addColorStop(0, theme.from); g.addColorStop(1, theme.to);
      ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
      const rg = ctx.createRadialGradient(W * .85, H * .1, 0, W * .85, H * .1, 600);
      rg.addColorStop(0, theme.accent + "44"); rg.addColorStop(1, "transparent"); ctx.fillStyle = rg; ctx.fillRect(0, 0, W, H);
      // fine grid
      ctx.strokeStyle = light ? "rgba(43,92,255,.045)" : "rgba(255,255,255,.035)"; ctx.lineWidth = 1;
      for (let x = 0; x < W; x += 60) { ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, H); ctx.stroke(); }
      for (let y = 0; y < H; y += 60) { ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke(); }
      // watermark
      ctx.save(); ctx.textAlign = "center"; ctx.font = "700 420px 'Fraunces', Georgia, serif"; ctx.fillStyle = light ? "rgba(43,92,255,.055)" : "rgba(255,255,255,.055)"; ctx.fillText("D$", W / 2, H * .57); ctx.restore();
      // double frame
      ctx.strokeStyle = theme.accent + "88"; ctx.lineWidth = 2; ctx.beginPath(); ctx.roundRect(30, 30, W - 60, H - 60, 36); ctx.stroke();
      ctx.strokeStyle = theme.accent + "33"; ctx.lineWidth = 1; ctx.beginPath(); ctx.roundRect(44, 44, W - 88, H - 88, 28); ctx.stroke();
      const ink = light ? "#101827" : "#f5f2e8";
      const muted = light ? "rgba(16,24,39,.55)" : "rgba(245,242,232,.55)";
      ctx.textAlign = "left"; ctx.fillStyle = theme.accent; ctx.font = "800 26px Inter, sans-serif"; ctx.fillText("DOLLARINO · WEEKLY RESULTS", 82, 125);
      ctx.fillStyle = ink; ctx.font = "600 74px 'Fraunces', Georgia, serif"; ctx.fillText(name || "Trader", 82, 235);
      ctx.fillStyle = muted; ctx.font = "500 30px Inter, sans-serif"; ctx.fillText("A week worth framing.", 82, 295);
      ctx.fillStyle = muted; ctx.font = "600 30px Inter, sans-serif"; ctx.fillText("Weekly PnL", 82, 505);
      ctx.fillStyle = pnl >= 0 ? "#10d9a3" : "#ff4d6d"; ctx.font = "600 172px 'Fraunces', Georgia, serif"; ctx.fillText(`${pnl >= 0 ? "+" : ""}${pnl.toFixed(1)}%`, 78, 685);
      // stats
      const statsToDraw = [
        { label: "TOTAL TRADES", value: String(trades), icon: "layers" },
        { label: "WIN RATE", value: `${win}%`, icon: "target" },
        { label: "RETURN ON EQUITY", value: `${(pnl * .62).toFixed(1)}%`, icon: "trend" },
      ];
      statsToDraw.forEach((s, i) => {
        const x = 82 + i * 312, y = 840, w = 284, h = 218;
        ctx.fillStyle = light ? "rgba(43,92,255,.045)" : "rgba(255,255,255,.055)"; ctx.strokeStyle = light ? "rgba(43,92,255,.15)" : "rgba(255,255,255,.15)"; ctx.lineWidth = 1.5;
        ctx.beginPath(); ctx.roundRect(x, y, w, h, 24); ctx.fill(); ctx.stroke();
        ctx.fillStyle = theme.accent; ctx.font = "600 36px Inter, sans-serif"; ctx.fillText(["◈", "◎", "↗"][i], x + 25, y + 55);
        ctx.fillStyle = ink; ctx.font = "600 60px 'Fraunces', Georgia, serif"; ctx.fillText(s.value, x + 25, y + 130);
        ctx.fillStyle = muted; ctx.font = "600 18px Inter, sans-serif"; ctx.fillText(s.label, x + 25, y + 181);
      });
      const eng = lang === "fa" ? "دُرّبین + دُرنا + آینه" : "DORR-BIN + DORNA + MIRROR";
      ctx.fillStyle = theme.accent; ctx.font = "700 22px Inter, Vazirmatn, sans-serif"; ctx.fillText(eng, 82, 1140);
      ctx.fillStyle = muted; ctx.font = "400 24px Inter, sans-serif"; ctx.fillText("Every market. One engine.", 82, H - 105);
      ctx.textAlign = "right"; ctx.fillText("dollarino.app", W - 82, H - 105);
      const a = document.createElement("a"); a.download = `dollarino-weekly-${name || "trader"}.png`; a.href = cv.toDataURL("image/png"); a.click();
      onToast(t.exported);
    } catch { onToast(lang === "fa" ? "خروجی ناموفق بود. دوباره امتحان کن." : "Export failed. Please try again."); }
    finally { setBusy(false); }
  };
  return <div className="pt-8 sm:pt-10">
    <div className="reveal in text-center max-w-2xl mx-auto"><p className="text-[9px] font-black tracking-[.2em] text-gold uppercase mb-2.5 flex items-center justify-center gap-2"><Sparkles className="h-3.5 w-3.5" />THE WEEKLY CARD STUDIO</p><h2 className="font-display font-semibold text-4xl sm:text-5xl">{t.title}</h2><p className="mt-3 text-sm text-white/50">{t.sub}</p></div>
    <div className="reveal in grid lg:grid-cols-[1fr_1fr] gap-10 lg:gap-16 items-center mt-10">
      <div className="space-y-5">
        <div><label className={labelCls}>{t.name}</label><input value={name} onChange={(e) => setName(e.target.value.slice(0, 18))} className="field font-semibold" placeholder="Avid" /></div>
        <div className="grid grid-cols-3 gap-3"><div><label className={labelCls}>{t.pnl}</label><input type="number" step="0.1" value={pnl} onChange={(e) => setPnl(+e.target.value)} className="field font-semibold tabular" /></div><div><label className={labelCls}>{t.trades}</label><input type="number" value={trades} onChange={(e) => setTrades(Math.max(0, +e.target.value))} className="field font-semibold tabular" /></div><div><label className={labelCls}>{t.win}</label><input type="number" value={win} onChange={(e) => setWin(Math.min(100, Math.max(0, +e.target.value)))} className="field font-semibold tabular" /></div></div>
        <div><label className={labelCls}>{t.theme}</label><div className="flex gap-2.5 flex-wrap">{THEMES.map((th) => <button key={th.id} onClick={() => setThemeId(th.id)} title={t[th.id as "gold" | "cobalt" | "light" | "emerald" | "sunset"]} className={`h-11 w-11 rounded-full transition ${themeId === th.id ? "ring-2 ring-gold ring-offset-2 ring-offset-[var(--bg)] scale-110" : "opacity-70 hover:opacity-100"}`} style={{ background: `linear-gradient(135deg,${th.from},${th.to})`, border: `1px solid ${th.accent}66` }} />)}<span className="self-center text-xs text-white/50 ms-1">{t[themeId as "gold" | "cobalt" | "light" | "emerald" | "sunset"]}</span></div></div>
        <div className="flex flex-col sm:flex-row gap-3"><button onClick={download} disabled={busy} className="btn-gold inline-flex items-center justify-center gap-2 font-black px-7 py-4 rounded-2xl disabled:opacity-50"><Download className="h-5 w-5" />{busy ? "…" : t.download}</button><button onClick={() => { setPnl(stats.pnl); setTrades(stats.trades); setWin(stats.win); }} className="btn-ghost inline-flex items-center justify-center gap-2 font-bold px-6 py-4 rounded-2xl text-sm"><WandSparkles className="h-4 w-4 text-gold" />{t.useStats}</button></div>
        <p className="text-[11px] text-white/35">1080 × 1350 px · PNG · 4:5 · No watermark fees. Just your results.</p>
      </div>
      <div className="flex flex-col items-center"><p className="text-[9px] font-black tracking-widest text-white/35 uppercase mb-5 flex items-center gap-2"><span className="live-dot h-1.5 w-1.5 rounded-full bg-gold" />{t.preview}</p><div className="relative animate-floaty-slow"><div className="absolute -inset-6 rounded-[40px] blur-3xl opacity-25" style={{ background: `linear-gradient(135deg,${theme.from},${theme.to})` }} /><div ref={cardRef} className="relative w-[min(300px,calc(100vw-48px))] sm:w-[340px] aspect-[4/5] rounded-[26px] overflow-hidden border p-7 flex flex-col shadow-2xl" style={{ background: `linear-gradient(150deg,${theme.from},${theme.to})`, borderColor: theme.accent + "66", color: theme.text }}><div className="absolute -top-16 -end-16 h-56 w-56 rounded-full blur-3xl opacity-25" style={{ background: theme.accent }} /><span className="absolute inset-0 grid place-items-center font-display font-bold text-[190px] select-none" style={{ color: theme.accent + "12" }}>D$</span><div className="relative flex items-center justify-between"><span className="text-[9px] font-black tracking-[.2em]" style={{ color: theme.accent }}>DOLLARINO · WEEKLY</span><Trophy className="h-5 w-5" style={{ color: theme.accent }} /></div><div className="relative mt-6"><p className="text-xs opacity-60 font-semibold">{name || "Trader"}</p><p className="font-display font-bold text-2xl">Weekly Results</p></div><div className="relative mt-auto"><p className="text-xs opacity-60 font-semibold mb-1">{t.pnl}</p><p className={`font-display font-bold text-6xl tabular ${pnl >= 0 ? "text-jade" : "text-[#ff4d6d]"}`}>{pnl >= 0 ? "+" : ""}{pnl.toFixed(1)}%</p><div className="grid grid-cols-3 gap-2 mt-6">{[{ icon: Layers, label: t.trades, val: trades }, { icon: Target, label: t.win, val: `${win}%` }, { icon: TrendingUp, label: t.roi, val: `${(pnl * .62).toFixed(1)}%` }].map((s, i) => <div key={i} className="rounded-2xl p-3" style={{ background: light ? "rgba(43,92,255,.045)" : "rgba(255,255,255,.06)", borderColor: light ? "rgba(43,92,255,.12)" : "rgba(255,255,255,.15)" }}><s.icon className="h-4 w-4 mb-1.5 opacity-60" /><p className="font-display font-bold tabular">{s.val}</p><p className="text-[9px] opacity-60 font-semibold mt-0.5">{s.label}</p></div>)}</div><p className="mt-6 text-[10px] opacity-60 font-semibold">Every market. One engine. · dollarino.app</p></div></div></div></div>
    </div>
  </div>;
}
