import { chromium } from '@playwright/test';

const browser = await chromium.launch({ headless: true, args: ['--no-sandbox'] });
const errors = [];
const page = await browser.newPage({ viewport: { width: 1440, height: 1000 }, deviceScaleFactor: 1 });
page.on('pageerror', (e) => errors.push(e.message));
page.on('console', (m) => { if (m.type() === 'error') errors.push(m.text()); });
const base = 'http://127.0.0.1:5173';
const assert = (value, msg) => { if (!value) throw new Error(msg); console.log('PASS:', msg); };
const layout = async (label) => {
  const result = await page.evaluate(() => {
    const width = innerWidth;
    const overflow = [...document.querySelectorAll('body *')].filter((el) => {
      const r = el.getBoundingClientRect();
      const s = getComputedStyle(el);
      return r.width > 0 && s.position !== 'fixed' && (r.right > width + 2 || r.left < -2) && !el.closest('.animate-ticker,.no-scrollbar,.reveal');
    }).map((el) => ({ tag: el.tagName, cls: el.className?.baseVal ?? el.className, text: el.textContent?.slice(0, 35), right: Math.round(el.getBoundingClientRect().right), left: Math.round(el.getBoundingClientRect().left) })).slice(0, 15);
    return { width: innerWidth, scrollWidth: document.documentElement.scrollWidth, overflow };
  });
  console.log(label, result.scrollWidth <= result.width + 2 ? 'OK' : JSON.stringify(result));
  assert(result.scrollWidth <= result.width + 2, `${label}: no horizontal page overflow`);
};

try {
  await page.goto(base, { waitUntil: 'networkidle' });
  await page.waitForTimeout(1700);
  assert(await page.locator('h1').innerText() === 'Trade every\nmarket.\nAutomatically.', 'Combined hero renders');
  assert(await page.locator('aside').isVisible(), 'Desktop sidebar visible');
  await layout('Desktop 1440');
  console.log('HERO METRICS', await page.locator('h1').boundingBox(), await page.locator('.reveal.in').first().boundingBox());
  await page.screenshot({ path: '/tmp/dollarino-desktop.png', fullPage: false });

  // palette
  await page.keyboard.press('Control+k');
  await page.getByPlaceholder('Search views, coins, actions…').fill('SOL');
  await page.locator('[role="dialog"]').getByRole('button', { name: /SOL/ }).first().click();
  assert(await page.getByRole('dialog').getByText('SOL/USDT', { exact: true }).isVisible(), 'Command palette opens SOL quick trade');
  await page.getByRole('button', { name: /Confirm · SOL/ }).click();
  assert(await page.locator('.toast').count() >= 0, 'Quick trade executed');
  await page.locator('aside').getByRole('button', { name: 'Portfolio', exact: true }).click();
  assert(await page.locator('main').getByText('SOL', { exact: true }).count() > 0, 'SOL appears in portfolio');
  const before = await page.locator('main').innerText();
  await page.locator('main').getByRole('button', { name: 'Close', exact: true }).first().click();
  assert(await page.locator('main').getByText('SOL', { exact: true }).count() === 0, 'Close removes SOL position');

  // copy
  await page.locator('aside').getByRole('button', { name: 'Copy Trade', exact: true }).click();
  const orion = page.locator('main .panel-hover').filter({ hasText: '@orion_swings' });
  await orion.getByRole('button', { name: /Follow · @orion_swings/ }).click();
  await orion.getByRole('button', { name: 'Following', exact: true }).waitFor({ state: 'visible' });
  assert(await orion.getByRole('button', { name: 'Following', exact: true }).isVisible(), 'Follow mirrors trader');
  await orion.getByRole('button', { name: 'Following', exact: true }).click();
  await orion.getByRole('button', { name: /Follow · @orion_swings/ }).waitFor({ state: 'visible' });
  assert(await orion.getByRole('button', { name: /Follow · @orion_swings/ }).isVisible(), 'Unfollow stops mirror');

  // terminal
  await page.locator('aside').getByRole('button', { name: 'Terminal', exact: true }).click();
  await page.locator('main select').selectOption('strategy');
  await page.locator('main').getByRole('button', { name: 'SHORT', exact: true }).click();
  await page.locator('main input[type="range"]').fill('20');
  await page.locator('main').getByRole('button', { name: 'Open Position · BTC', exact: true }).click();
  assert(await page.locator('main').getByText('SHORT 20×', { exact: true }).isVisible(), 'Terminal opens short with 20x leverage');
  await page.getByTitle('Line', { exact: true }).click();
  assert(await page.getByTitle('Line', { exact: true }).getAttribute('class').then((s) => s.includes('bg-gold/15')), 'Line chart toggles');

  // appearance
  await page.getByTitle('Appearance', { exact: true }).click();
  await page.getByRole('button', { name: /Cobalt Blue/ }).click();
  assert(await page.locator('html').getAttribute('data-theme') === 'cobalt', 'Cobalt theme applies');
  await page.getByRole('button', { name: /Porcelain Light/ }).click();
  assert(await page.locator('html').getAttribute('data-theme') === 'light', 'Light theme applies');
  await page.getByRole('button', { name: /Obsidian Gold/ }).click();
  await page.getByRole('button', { name: "Looks good. Let's go." }).click();

  // language
  await page.getByRole('button', { name: 'فارسی', exact: true }).click();
  assert(await page.locator('html').getAttribute('dir') === 'rtl', 'Persian switches RTL');
  assert(await page.locator('h2').first().innerText() === 'ترمینال ترید', 'Persian terminal translated');
  await page.getByRole('button', { name: 'EN', exact: true }).click();

  // card download
  await page.locator('aside').getByRole('button', { name: 'Weekly Card', exact: true }).click();
  await page.locator('main input').first().fill('Kiya');
  const downloadPromise = page.waitForEvent('download');
  await page.getByRole('button', { name: 'Download PNG', exact: true }).click();
  const download = await downloadPromise;
  assert(download.suggestedFilename() === 'dollarino-weekly-Kiya.png', 'Weekly card exports real PNG');

  // pricing + faq
  await page.locator('aside').getByRole('button', { name: 'Pricing', exact: true }).click();
  await page.getByRole('button', { name: /Yearly/ }).click();
  assert((await page.locator('main').innerText()).includes('$15'), 'Yearly pricing updates');
  await page.locator('main').getByRole('button', { name: 'Get Started', exact: true }).nth(1).click();
  assert(await page.getByRole('dialog').getByText(/No payment is collected/).isVisible(), 'Plan selection clearly paper-only');
  await page.getByRole('button', { name: 'Try in Paper Demo' }).click();
  await page.locator('aside').getByRole('button', { name: 'FAQ', exact: true }).click();
  await page.getByRole('button', { name: 'Is this connected to my real money?' }).click();
  assert(await page.getByText(/No real orders are sent/).isVisible(), 'FAQ accordion works');

  // mobile sizes and views
  await page.setViewportSize({ width: 390, height: 844 });
  await page.goto(base, { waitUntil: 'networkidle' });
  await page.waitForTimeout(1400);
  await layout('Mobile 390 overview');
  assert(await page.locator('nav.fixed').isVisible(), 'Mobile dock visible');
  await page.screenshot({ path: '/tmp/dollarino-mobile.png', fullPage: false });
  for (const v of ['markets', 'radar', 'copy', 'portfolio', 'terminal', 'card', 'pricing', 'faq']) {
    await page.goto(`${base}/#${v}`, { waitUntil: 'networkidle' });
    await page.waitForTimeout(1100);
    await layout(`Mobile 390 ${v}`);
  }
  await page.setViewportSize({ width: 320, height: 740 });
  await page.goto(base, { waitUntil: 'networkidle' });
  await page.waitForTimeout(1200);
  await layout('Mobile 320 overview');
  await page.getByRole('button', { name: 'Menu', exact: true }).click();
  await page.locator('div.absolute.start-0').getByRole('button', { name: 'Weekly Card', exact: true }).click();
  await layout('Mobile 320 card');
  for (const v of ['markets', 'radar', 'copy', 'portfolio', 'terminal', 'card', 'pricing', 'faq']) {
    await page.goto(`${base}/#${v}`, { waitUntil: 'networkidle' });
    await page.waitForTimeout(1100);
    await layout(`Mobile 320 ${v}`);
  }
  await page.setViewportSize({ width: 1024, height: 768 });
  await page.goto(base, { waitUntil: 'networkidle' });
  await page.waitForTimeout(1200);
  await layout('Tablet 1024 overview');

  assert(errors.length === 0, `No browser errors (${errors.join('; ')})`);
  console.log('ALL SMOKE TESTS PASSED');
} finally {
  console.log('BROWSER ERRORS:', JSON.stringify(errors));
  await browser.close();
}
