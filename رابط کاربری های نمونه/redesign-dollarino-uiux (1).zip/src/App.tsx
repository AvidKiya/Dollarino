import { useCallback, useEffect, useRef, useState } from "react";
import { ArrowDownLeft, ArrowUpRight, BrainCircuit, Plus, Send, ShieldCheck, X } from "lucide-react";
import {
  engineById, initialMarkets, initialPositions, money, priceText,
  type EngineId, type Market, type NavKey, type Position, type Side, type Timeframe,
} from "./data";
import type { AppState } from "./state";
import { MobileDock, Navbar } from "./components/Shell";
import { Bento, Hero, Tape } from "./components/Landing";
import { Terminal } from "./components/Terminal";
import { Cta, Engines, Faq, Footer, Performance, Pricing, Testimonials } from "./components/Growth";
import { CoinIcon, Modal, Toast } from "./components/UI";

/* ---------- storage ---------- */
function load<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(`dollarino:${key}`);
    return raw !== null ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}
function save(key: string, value: unknown) {
  try {
    localStorage.setItem(`dollarino:${key}`, JSON.stringify(value));
  } catch { /* ignore */ }
}

/* ================= New trade modal ================= */
function NewTradeModal({ open, onClose, onSubmit, leverage, markets }: {
  open: boolean;
  onClose: () => void;
  onSubmit: (p: { symbol: string; side: Side; leverage: number; size: number; engine: EngineId }) => void;
  leverage: number;
  markets: Market[];
}) {
  const [symbol, setSymbol] = useState("BTC");
  const [side, setSide] = useState<Side>("long");
  const [lev, setLev] = useState(leverage);
  const [size, setSize] = useState(1000);
  const [engine, setEngine] = useState<EngineId>("ai");

  useEffect(() => { if (open) setLev(leverage); }, [open, leverage]);
  const m = markets.find((x) => x.symbol === symbol) ?? markets[0];

  return (
    <Modal open={open} onClose={onClose} title="معامله جدید" subtitle="اجرا روی حساب دمو با قیمت زنده بازار">
      <div className="space-y-4">
        <div className="rounded-2xl border border-hairline bg-[var(--glass)] p-3">
          <p className="mb-2 text-[10px] font-bold t-muted">انتخاب ارز</p>
          <div className="grid grid-cols-3 gap-2 sm:grid-cols-6">
            {markets.map((mk) => (
              <button key={mk.symbol} onClick={() => setSymbol(mk.symbol)} className="num press flex flex-col items-center gap-1.5 rounded-xl border p-2 text-[10px] font-bold transition-all" style={{ borderColor: symbol === mk.symbol ? `${mk.color}88` : "var(--border)", background: symbol === mk.symbol ? `${mk.color}18` : "transparent" }} dir="ltr">
                <CoinIcon symbol={mk.symbol} color={mk.color} size={26} />
                {mk.symbol}
              </button>
            ))}
          </div>
          <p className="num mt-3 text-center text-[10px] t-muted" dir="ltr">
            Current · <span className="font-bold" style={{ color: m.color }}>${priceText(m.price)}</span>
            <span style={{ color: m.change >= 0 ? "var(--mint)" : "var(--rose)" }}> {m.change >= 0 ? "+" : ""}{m.change.toFixed(2)}%</span>
          </p>
        </div>

        <div className="grid grid-cols-2 gap-2">
          <button onClick={() => setSide("long")} className="press flex h-11 items-center justify-center gap-2 rounded-xl border text-[11px] font-extrabold" style={{ borderColor: side === "long" ? "rgba(61,220,151,.6)" : "var(--border)", background: side === "long" ? "rgba(61,220,151,.12)" : "var(--glass)", color: side === "long" ? "var(--mint)" : "var(--muted)" }}><ArrowUpRight size={16} /> خرید · Long</button>
          <button onClick={() => setSide("short")} className="press flex h-11 items-center justify-center gap-2 rounded-xl border text-[11px] font-extrabold" style={{ borderColor: side === "short" ? "rgba(255,107,126,.6)" : "var(--border)", background: side === "short" ? "rgba(255,107,126,.12)" : "var(--glass)", color: side === "short" ? "var(--rose)" : "var(--muted)" }}><ArrowDownLeft size={16} /> فروش · Short</button>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <label className="block">
            <span className="mb-2 block text-[10px] font-bold t-muted">حجم (USD)</span>
            <input type="number" min={100} step={100} value={size} onChange={(e) => setSize(Math.max(100, Number(e.target.value) || 100))} className="input num h-11 rounded-xl px-3 text-[12px]" dir="ltr" />
          </label>
          <label className="block">
            <span className="mb-2 block text-[10px] font-bold t-muted">اهرم</span>
            <div className="flex h-11 items-center gap-2 rounded-xl border border-hairline bg-[var(--glass)] px-3">
              <input type="range" min={1} max={50} value={lev} onChange={(e) => setLev(Number(e.target.value))} className="slider h-1.5 flex-1" style={{ ["--fill" as string]: `${((lev - 1) / 49) * 100}%` }} />
              <span className="num w-9 text-left text-[11px] font-black t-accent" dir="ltr">{lev}x</span>
            </div>
          </label>
        </div>

        <div>
          <p className="mb-2 text-[10px] font-bold t-muted">موتور اجراکننده</p>
          <div className="grid grid-cols-3 gap-2">
            {(["ai", "strategy", "copy"] as EngineId[]).map((id) => (
              <button key={id} onClick={() => setEngine(id)} className="num press rounded-xl border px-2 py-2.5 text-[9.5px] font-bold transition-all" style={{ borderColor: engine === id ? "var(--lime)" : "var(--border)", background: engine === id ? "rgba(201,242,78,.1)" : "var(--glass)" }} dir="ltr">{engineById(id).latin}</button>
            ))}
          </div>
        </div>

        <div className="num flex items-center justify-between rounded-xl border border-hairline bg-[var(--glass)] px-3 py-2.5 text-[10px] t-muted" dir="ltr">
          <span>Margin · ${(size / lev).toLocaleString("en-US", { maximumFractionDigits: 2 })}</span>
          <span>Notional · ${size.toLocaleString("en-US")}</span>
        </div>
        <div className="flex items-center gap-2 rounded-xl border border-hairline bg-[var(--glass)] px-3 py-2.5 text-[9.5px] t-muted"><ShieldCheck size={14} className="shrink-0 t-mint" /> این معامله روی حساب دمو اجرا می‌شود.</div>
        <button onClick={() => onSubmit({ symbol, side, leverage: lev, size, engine })} className="btn-lime h-11 w-full rounded-xl text-[11.5px]"><Plus size={15} strokeWidth={2.6} /> ثبت و اجرای معامله</button>
      </div>
    </Modal>
  );
}

/* ================= AI assistant ================= */
interface ChatMsg { role: "ai" | "user"; text: string }

function assistantReply(q: string, ctx: { balance: number; pnl: number; count: number; engine: string; win: number }): string {
  const t = q.trim();
  if (/سلام|درود|هی|hello|hi/i.test(t)) return "سلام! من دُرّبینم، دستیار هوشمند دلارینو. درباره حسابت، موتورها یا بازار بپرس.";
  if (/سود|عملکرد|بالانس|موجودی|کیف/.test(t)) return `موجودی فعلی‌ات ${money(ctx.balance)} است و سود شناور ${money(ctx.pnl)} روی ${ctx.count} پوزیشن باز داری. وین‌ریت حدود ${ctx.win.toFixed(1)}٪ — روند حسابت صعودی و سالم است.`;
  if (/موتور|هوش|دربین|درنا|کپی/.test(t)) return `در حال حاضر موتور «${ctx.engine}» فعال است. برای بازار پرنوسان امروز، دُرّبین با وین‌ریت ۸۶.۴٪ بهترین انتخاب است.`;
  if (/سیگنال|پیشنهاد|بخر|بفروش|خرید|فروش/.test(t)) return "آخرین سیگنال قوی: لانگ BTC/USDT با اطمینان ۹۴٪ در محدوده ۶۹,۱۲۰ تا ۶۹,۳۴۰. حد ضرر یادت نره و اهرم را زیر 10x نگه دار.";
  if (/ریسک|اهرم|ضرر|لیکویید|مدیریت/.test(t)) return "قانون طلایی: در هر معامله بیش از ۲٪ سرمایه ریسک نکن و همیشه حد ضرر بگذار. حداکثر افت حسابت فقط ۳.۲٪ است.";
  if (/بازار|بیت|btc|اتریوم|eth|سول|sol/.test(t)) return "نمای بازار: BTC با قدرت خریدار همراه است، SOL زیر فشار نقدینگی در ۱۶۸ تا ۱۷۰ دلار است و XRP مومنتوم مثبت دارد.";
  if (/قیمت|هزینه|تعرفه|اشتراک/.test(t)) return "حساب دمو همیشه رایگان است. پلن پرو ماهانه ۲۹ دلار و سالانه ۲۳ دلار است — بخش تعرفه را ببین.";
  if (/ممنون|مرسی|thanks|عالی|خفن/.test(t)) return "قربانت! هر وقت تحلیل یا سیگنالی خواستی، من اینجام.";
  return "تحلیل کردم: شرایط فعلی برای لانگ BTC و XRP مساعد است. درباره «سود»، «موتور» یا «سیگنال» بپرس تا دقیق‌تر بگویم.";
}

function AiAssistant({ ctx }: { ctx: { balance: number; pnl: number; count: number; engine: string; win: number } }) {
  const [open, setOpen] = useState(false);
  const [typing, setTyping] = useState(false);
  const [input, setInput] = useState("");
  const [msgs, setMsgs] = useState<ChatMsg[]>([
    { role: "ai", text: "سلام! من دُرّبینم. درباره حسابت، بازار یا موتورها هر سوالی داری بپرس." },
  ]);
  const bodyRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bodyRef.current?.scrollTo({ top: bodyRef.current.scrollHeight, behavior: "smooth" });
  }, [msgs, typing, open]);

  const send = (text: string) => {
    const q = text.trim();
    if (!q || typing) return;
    setMsgs((m) => [...m, { role: "user", text: q }]);
    setInput("");
    setTyping(true);
    setTimeout(() => {
      setMsgs((m) => [...m, { role: "ai", text: assistantReply(q, ctx) }]);
      setTyping(false);
    }, 900);
  };

  return (
    <>
      {!open && (
        <button
          onClick={() => setOpen(true)}
          aria-label="دستیار هوشمند دُرّبین"
          className="btn-lime fixed bottom-[96px] left-3 z-[70] grid h-[54px] w-[54px] place-items-center rounded-[20px] lg:bottom-8 lg:left-8"
          style={{ animation: "floatSlow 3.5s ease-in-out infinite" }}
        >
          <BrainCircuit size={24} />
          <span className="absolute -right-0.5 -top-0.5 h-3 w-3 rounded-full bg-[var(--mint)] shadow-[0_0_10px_var(--mint)]" />
        </button>
      )}
      {open && (
        <div className="animate-enter fixed inset-x-3 bottom-[92px] z-[70] flex max-h-[70dvh] flex-col overflow-hidden rounded-[24px] border border-[var(--border-strong)] bg-[var(--card-solid)] shadow-[var(--shadow)] sm:left-4 sm:right-auto sm:w-[384px] lg:bottom-8 lg:left-8">
          <div className="flex items-center gap-3 border-b border-hairline bg-[var(--glass)] p-3.5">
            <span className="grid h-10 w-10 place-items-center rounded-2xl bg-[var(--lime)]" style={{ color: "var(--on-lime)" }}><BrainCircuit size={19} /></span>
            <div className="flex-1">
              <p className="text-[12.5px] font-black">دُرّبین <span className="num rounded-md bg-[rgba(201,242,78,.15)] px-1.5 py-0.5 text-[8.5px] t-lime" dir="ltr">AI</span></p>
              <p className="mt-0.5 flex items-center gap-1 text-[9.5px] t-mint"><span className="h-1.5 w-1.5 rounded-full bg-[var(--mint)]" /> آنلاین · پاسخ لحظه‌ای</p>
            </div>
            <button onClick={() => setOpen(false)} className="icon-btn h-8 w-8 rounded-lg" aria-label="بستن دستیار"><X size={16} /></button>
          </div>
          <div ref={bodyRef} className="min-h-[180px] flex-1 space-y-2.5 overflow-y-auto p-3.5 scroll-thin">
            {msgs.map((m, i) => (
              <div key={i} className="flex">
                <div className={`max-w-[88%] rounded-2xl px-3 py-2.5 text-[11px] leading-6 ${m.role === "user" ? "rounded-br-md bg-[var(--lime)] font-bold" : "rounded-bl-md border border-hairline bg-[var(--glass)]"}`} style={m.role === "user" ? { color: "var(--on-lime)" } : undefined}>
                  {m.text}
                </div>
              </div>
            ))}
            {typing && (
              <div className="flex w-fit gap-1.5 rounded-2xl rounded-bl-md border border-hairline bg-[var(--glass)] px-3.5 py-3.5">
                {[0, 1, 2].map((d) => (
                  <span key={d} className="h-1.5 w-1.5 animate-bounce rounded-full bg-[var(--muted)]" style={{ animationDelay: `${d * 150}ms` }} />
                ))}
              </div>
            )}
          </div>
          <div className="flex gap-1.5 overflow-x-auto px-3.5 pb-1 no-scrollbar">
            {["عملکرد حسابم چطوره؟", "چه سیگنالی داری؟", "تعرفه‌ها چقدره؟"].map((q) => (
              <button key={q} onClick={() => send(q)} className="chip h-7 shrink-0 whitespace-nowrap rounded-lg px-2.5 text-[9.5px] font-bold">{q}</button>
            ))}
          </div>
          <form onSubmit={(e) => { e.preventDefault(); send(input); }} className="flex items-center gap-2 p-3.5 pt-2">
            <input value={input} onChange={(e) => setInput(e.target.value)} placeholder="سوالت را بپرس..." className="input h-10 rounded-xl px-3 text-[11.5px]" />
            <button type="submit" aria-label="ارسال" className="btn-lime h-10 w-10 shrink-0 rounded-xl"><Send size={16} className="-scale-x-100" /></button>
          </form>
        </div>
      )}
    </>
  );
}

/* ================= App ================= */
export default function App() {
  const [boot, setBoot] = useState(true);
  const [theme, setTheme] = useState<"dark" | "light">(() => load("theme", "dark"));
  const [balanceHidden, setBalanceHidden] = useState(false);
  const [botActive, setBotActive] = useState(() => load("bot", true));
  const [proMode, setProMode] = useState(() => load("pro", false));
  const [activeEngine, setActiveEngine] = useState<EngineId>(() => load("engine", "ai"));
  const [leverage, setLeverage] = useState(() => load("leverage", 10));
  const [maxTrades, setMaxTrades] = useState(() => load("maxTrades", 12));
  const [timeframe, setTimeframe] = useState<Timeframe>("30D");
  const [realized, setRealized] = useState(24478.22);
  const [positions, setPositions] = useState<Position[]>(initialPositions);
  const [markets, setMarkets] = useState<Market[]>(initialMarkets);
  const [toast, setToast] = useState<string | null>(null);
  const [tradeModal, setTradeModal] = useState(false);
  const [progress, setProgress] = useState(0);
  const toastTimer = useRef<number | null>(null);
  const marketsRef = useRef(markets);

  const notify = useCallback((message: string) => {
    setToast(message);
    if (toastTimer.current) window.clearTimeout(toastTimer.current);
    toastTimer.current = window.setTimeout(() => setToast(null), 3200);
  }, []);

  useEffect(() => {
    const t = setTimeout(() => setBoot(false), 1400);
    return () => clearTimeout(t);
  }, []);

  useEffect(() => {
    document.documentElement.dataset.theme = theme;
    document.querySelector('meta[name="theme-color"]')?.setAttribute("content", theme === "dark" ? "#0b0d10" : "#f4f3ec");
    save("theme", theme);
  }, [theme]);
  useEffect(() => { save("bot", botActive); }, [botActive]);
  useEffect(() => { save("pro", proMode); }, [proMode]);
  useEffect(() => { save("engine", activeEngine); }, [activeEngine]);
  useEffect(() => { save("leverage", leverage); }, [leverage]);
  useEffect(() => { save("maxTrades", maxTrades); }, [maxTrades]);

  useEffect(() => {
    const onScroll = () => {
      const h = document.documentElement;
      const max = h.scrollHeight - h.clientHeight;
      setProgress(max > 0 ? (h.scrollTop / max) * 100 : 0);
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  /* live market + pnl */
  useEffect(() => {
    const id = window.setInterval(() => {
      const nextMarkets = marketsRef.current.map((m) => {
        const delta = (Math.random() - 0.485) * 0.0026;
        const price = Math.max(0.0001, m.price * (1 + delta));
        const change = Math.max(-9.99, Math.min(9.99, m.change + delta * 100));
        const last = m.spark[m.spark.length - 1];
        const spark = [...m.spark.slice(1), Math.max(8, Math.min(48, last + delta * 900))];
        return { ...m, price, change, spark };
      });
      marketsRef.current = nextMarkets;
      setMarkets(nextMarkets);

      setPositions((prev) =>
        prev.map((p) => {
          const mk = nextMarkets.find((x) => x.symbol === p.symbol);
          const dir = p.side === "long" ? 1 : -1;
          const target = mk ? mk.price : p.mark * (1 + (Math.random() - 0.5) * 0.004);
          const drift = (Math.random() - 0.5) * p.entry * 0.0012;
          const newMark = p.mark + (target - p.mark) * 0.4 + drift;
          let pnlPct = ((newMark - p.entry) / p.entry) * 100 * dir;
          pnlPct = Math.max(-9, Math.min(9, pnlPct));
          const pnl = Math.round(((p.size * pnlPct) / 100) * 10) / 10;
          const mark = p.entry * (1 + (pnlPct / 100) * dir);
          return { ...p, mark, pnl, pnlPct: Math.round(pnlPct * 100) / 100 };
        })
      );
    }, 2800);
    return () => window.clearInterval(id);
  }, []);

  useEffect(() => () => { if (toastTimer.current) window.clearTimeout(toastTimer.current); }, []);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const el = e.target as HTMLElement;
      if (el.tagName === "INPUT" || el.tagName === "TEXTAREA" || e.metaKey || e.ctrlKey) return;
      if (e.key === "n" || e.key === "N") setTradeModal(true);
      else if (e.key === "t" || e.key === "T") setTheme((t) => (t === "dark" ? "light" : "dark"));
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  const onSelectEngine = (id: EngineId) => {
    setActiveEngine(id);
    notify(`${engineById(id).name} فعال شد`);
  };

  const onClosePosition = (id: string) => {
    const p = positions.find((x) => x.id === id);
    if (!p) return;
    setPositions((prev) => prev.filter((x) => x.id !== id));
    setRealized((r) => r + p.pnl);
    notify(`پوزیشن ${p.symbol} بسته شد · ${money(p.pnl)}`);
  };

  const onCreateTrade = ({ symbol, side, leverage: lev, size, engine }: { symbol: string; side: Side; leverage: number; size: number; engine: EngineId }) => {
    const m = marketsRef.current.find((x) => x.symbol === symbol) ?? marketsRef.current[0];
    setPositions((prev) => [{
      id: `p-${Date.now()}`, symbol: m.symbol, name: m.name, color: m.color, side,
      leverage: lev, entry: m.price, mark: m.price, size, pnl: 0, pnlPct: 0, engine,
    }, ...prev]);
    setTradeModal(false);
    notify(`معامله ${m.symbol}/USDT با ${engineById(engine).label} اجرا شد`);
  };

  const scrollToPricing = () => document.getElementById("pricing")?.scrollIntoView({ behavior: "smooth" });

  const totalPnl = positions.reduce((a, p) => a + p.pnl, 0);
  const balance = realized + totalPnl;
  const winRate = positions.length ? (positions.filter((p) => p.pnl > 0).length / positions.length) * 100 : 0;

  const active: NavKey = "overview";
  const state: AppState = {
    active,
    onNavigate: () => {},
    notify,
    theme,
    onToggleTheme: () => setTheme((t) => (t === "dark" ? "light" : "dark")),
    balance,
    balanceHidden,
    onToggleHidden: () => setBalanceHidden((v) => !v),
    botActive,
    onToggleBot: (v) => { setBotActive(v); notify(v ? "ربات روشن شد" : "ربات خاموش شد"); },
    proMode,
    onTogglePro: setProMode,
    activeEngine,
    onSelectEngine,
    leverage,
    setLeverage,
    maxTrades,
    setMaxTrades,
    timeframe,
    setTimeframe,
    positions,
    onClosePosition,
    markets,
    onNewTrade: () => setTradeModal(true),
  };

  return (
    <div className="relative min-h-screen">
      <div className="app-backdrop" />
      <div className="app-grid" />
      <div className="app-noise" />

      <div className="fixed right-0 top-0 z-[100] h-[3px] bg-[var(--lime)]" style={{ width: `${progress}%`, boxShadow: "0 0 12px var(--lime)" }} />

      {boot && (
        <div className="fixed inset-0 z-[200] grid place-items-center bg-[#0b0d10]" style={{ animation: "splashOut .5s ease 1s both" }}>
          <div className="flex flex-col items-center gap-4">
            <div className="grid h-[72px] w-[72px] place-items-center rounded-[22px] bg-[var(--lime)] shadow-[0_0_60px_rgba(201,242,78,.5)]" style={{ animation: "floatSlow 1.6s ease-in-out infinite" }}>
              <svg viewBox="0 0 32 32" className="h-11 w-11" aria-hidden="true">
                <path d="M8 7h7.2c6.4 0 10.4 3.8 10.4 9s-4 9-10.4 9H8V7Z" fill="none" stroke="#141a05" strokeWidth="3.6" strokeLinejoin="round" />
                <path d="M14.1 12.6v6.8c2.5 0 4-1.3 4-3.4s-1.5-3.4-4-3.4Z" fill="#141a05" />
              </svg>
            </div>
            <div className="num text-xl font-bold tracking-tight text-white" dir="ltr">Dollarino<span className="text-[var(--lime)]">.</span></div>
            <div className="shimmer-text text-[11px] font-bold">در حال اتصال به بازار...</div>
          </div>
        </div>
      )}

      <div className="relative z-10">
        <Navbar theme={theme} onToggleTheme={state.onToggleTheme} onStart={scrollToPricing} botActive={botActive} />
        <main>
          <Hero markets={markets} balance={balance} onStart={scrollToPricing} />
          <Tape markets={markets} notify={notify} />
          <Bento />
          <Terminal s={state} />
          <Engines s={state} />
          <Performance s={state} />
          <Pricing notify={notify} />
          <Testimonials />
          <Faq />
          <Cta onStart={scrollToPricing} />
        </main>
        <Footer notify={notify} />
      </div>

      <MobileDock onTrade={() => setTradeModal(true)} />
      <AiAssistant ctx={{ balance, pnl: totalPnl, count: positions.length, engine: engineById(activeEngine).label, win: winRate }} />
      <Toast key={toast ?? "idle"} message={toast} />
      <NewTradeModal open={tradeModal} onClose={() => setTradeModal(false)} onSubmit={onCreateTrade} leverage={leverage} markets={markets} />
    </div>
  );
}
