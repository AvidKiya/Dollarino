import { useEffect, useId, useMemo, useRef, useState } from "react";
import { fmt } from "../data";

function smoothPath(points: { x: number; y: number }[]) {
  if (points.length < 2) return "";
  let d = `M ${points[0].x} ${points[0].y}`;
  for (let i = 1; i < points.length; i++) {
    const p0 = points[i - 1];
    const p1 = points[i];
    const mx = (p0.x + p1.x) / 2;
    d += ` C ${mx} ${p0.y}, ${mx} ${p1.y}, ${p1.x} ${p1.y}`;
  }
  return d;
}

export function Sparkline({
  values, color = "#7c92ff", height = 38, fill = false, className = "", animated = true, endDot = false,
}: {
  values: number[];
  color?: string;
  height?: number;
  fill?: boolean;
  className?: string;
  animated?: boolean;
  endDot?: boolean;
}) {
  const uid = useId().replace(/[^a-zA-Z0-9]/g, "");
  const min = Math.min(...values);
  const max = Math.max(...values);
  const span = max - min || 1;
  const pts = values.map((v, i) => ({ x: (i / (values.length - 1)) * 100, y: 34 - ((v - min) / span) * 28 }));
  const line = smoothPath(pts);
  const last = pts[pts.length - 1];
  return (
    <svg viewBox="0 0 100 40" preserveAspectRatio="none" height={height} className={`w-full overflow-visible ${className}`} aria-hidden="true">
      <defs>
        <linearGradient id={`spark-${uid}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity="0.32" />
          <stop offset="100%" stopColor={color} stopOpacity="0" />
        </linearGradient>
      </defs>
      {fill && <path d={`${line} L 100 40 L 0 40 Z`} fill={`url(#spark-${uid})`} />}
      <path
        d={line}
        fill="none"
        stroke={color}
        strokeWidth="2"
        strokeLinecap="round"
        vectorEffect="non-scaling-stroke"
        pathLength={100}
        className={animated ? "draw-line" : undefined}
        style={{ filter: `drop-shadow(0 0 5px ${color}66)` }}
      />
      {endDot && <circle cx={last.x} cy={last.y} r="2.6" fill={color} stroke="#fff" strokeWidth="1" vectorEffect="non-scaling-stroke" />}
    </svg>
  );
}

export function AreaChart({
  values, labels, color = "#7c92ff", height = 280,
}: {
  values: number[];
  labels: string[];
  color?: string;
  height?: number;
}) {
  const uid = useId().replace(/[^a-zA-Z0-9]/g, "");
  const [hover, setHover] = useState<number | null>(null);
  const boxRef = useRef<HTMLDivElement>(null);
  const W = 800;
  const H = 280;
  const top = 26;
  const bottom = 28;

  const { points, line, area, min, max } = useMemo(() => {
    const lo = Math.min(...values);
    const hi = Math.max(...values);
    const pad = (hi - lo) * 0.18 || 1;
    const mn = lo - pad;
    const mx = hi + pad;
    const pts = values.map((v, i) => ({
      x: (i / (values.length - 1)) * W,
      y: H - bottom - ((v - mn) / (mx - mn)) * (H - top - bottom),
    }));
    const l = smoothPath(pts);
    return { points: pts, line: l, area: `${l} L ${W} ${H} L 0 ${H} Z`, min: mn, max: mx };
  }, [values]);

  const active = hover !== null ? points[hover] : null;
  const last = points[points.length - 1];
  const hoverValue = hover !== null ? values[hover] : 0;
  const labelIndex = hover !== null ? Math.min(labels.length - 1, Math.floor((hover / (values.length - 1)) * labels.length)) : 0;
  const leftPct = active ? (active.x / W) * 100 : 0;

  const pick = (clientX: number) => {
    const rect = boxRef.current?.getBoundingClientRect();
    if (!rect) return;
    const ratio = Math.max(0, Math.min(1, (clientX - rect.left) / rect.width));
    setHover(Math.round(ratio * (values.length - 1)));
  };

  return (
    <div
      ref={boxRef}
      className="relative w-full cursor-crosshair select-none"
      style={{ height, touchAction: "pan-y" }}
      onPointerMove={(e) => pick(e.clientX)}
      onPointerDown={(e) => pick(e.clientX)}
      onPointerLeave={() => setHover(null)}
    >
      <svg viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="none" className="h-full w-full overflow-visible" aria-label="نمودار عملکرد سرمایه">
        <defs>
          <linearGradient id={`area-${uid}`} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={color} stopOpacity="0.38" />
            <stop offset="55%" stopColor={color} stopOpacity="0.11" />
            <stop offset="100%" stopColor={color} stopOpacity="0" />
          </linearGradient>
          <linearGradient id={`line-${uid}`} x1="0" y1="0" x2="1" y2="0">
            <stop offset="0%" stopColor={color} stopOpacity="0.5" />
            <stop offset="35%" stopColor={color} />
            <stop offset="100%" stopColor="#8ce0ff" />
          </linearGradient>
          <filter id={`glow-${uid}`} x="-40%" y="-40%" width="180%" height="180%">
            <feGaussianBlur stdDeviation="5" result="b" />
            <feMerge>
              <feMergeNode in="b" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>
        </defs>
        {[0, 1, 2, 3].map((i) => {
          const y = top + (i * (H - top - bottom)) / 3;
          return (
            <g key={i}>
              <line x1="0" x2={W} y1={y} y2={y} stroke="var(--grid-line)" strokeWidth="1" strokeDasharray="3 8" vectorEffect="non-scaling-stroke" />
              <text x={W - 4} y={y - 8} textAnchor="end" fill="var(--faint)" fontSize="11" fontFamily="Inter, sans-serif" className="num">
                ${fmt(max - ((max - min) * i) / 3, 0)}
              </text>
            </g>
          );
        })}
        <path d={area} fill={`url(#area-${uid})`} className="animate-fade" />
        <path
          key={values.length + values[0]}
          d={line}
          fill="none"
          stroke={`url(#line-${uid})`}
          strokeWidth="2.8"
          strokeLinecap="round"
          vectorEffect="non-scaling-stroke"
          pathLength={100}
          className="draw-line"
          filter={`url(#glow-${uid})`}
        />
        {!active && (
          <g>
            <circle cx={last.x} cy={last.y} r="10" fill={color} opacity="0.25">
              <animate attributeName="r" values="7;11;7" dur="2.4s" repeatCount="indefinite" />
              <animate attributeName="opacity" values="0.3;0.08;0.3" dur="2.4s" repeatCount="indefinite" />
            </circle>
            <circle cx={last.x} cy={last.y} r="4.5" fill="#fff" stroke={color} strokeWidth="2.5" vectorEffect="non-scaling-stroke" />
          </g>
        )}
        {active && (
          <g>
            <line x1={active.x} x2={active.x} y1={top - 14} y2={H - bottom} stroke={color} strokeOpacity="0.55" strokeWidth="1" strokeDasharray="4 5" vectorEffect="non-scaling-stroke" />
            <circle cx={active.x} cy={active.y} r="10" fill={color} opacity="0.22" />
            <circle cx={active.x} cy={active.y} r="5" fill="#fff" stroke={color} strokeWidth="2.5" vectorEffect="non-scaling-stroke" />
          </g>
        )}
      </svg>

      {active && (
        <div
          className="glass pointer-events-none absolute top-0 z-10 min-w-[124px] -translate-x-1/2 rounded-2xl px-3 py-2 text-center shadow-[var(--shadow)]"
          style={{ left: `${Math.max(10, Math.min(90, leftPct))}%` }}
        >
          <div className="text-[10px] t-muted">{labels[labelIndex]}</div>
          <div className="num mt-0.5 text-sm font-extrabold" dir="ltr">${fmt(hoverValue)}</div>
        </div>
      )}

      <div className="pointer-events-none absolute inset-x-0 bottom-0 flex justify-between text-[10px] t-faint">
        {labels.map((l) => (
          <span key={l}>{l}</span>
        ))}
      </div>
    </div>
  );
}

export function ProgressRing({
  value, size = 76, stroke = 7, color = "#37d6a5", children,
}: {
  value: number;
  size?: number;
  stroke?: number;
  color?: string;
  children?: React.ReactNode;
}) {
  const [display, setDisplay] = useState(0);
  useEffect(() => {
    let raf = 0;
    const from = display;
    const to = Math.max(0, Math.min(100, value));
    const start = performance.now();
    const dur = 900;
    const tick = (t: number) => {
      const p = Math.min(1, (t - start) / dur);
      const eased = 1 - Math.pow(1 - p, 3);
      setDisplay(from + (to - from) * eased);
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [value]);

  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  return (
    <div className="relative inline-flex items-center justify-center" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90" aria-hidden="true">
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="var(--border)" strokeWidth={stroke} />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          fill="none"
          stroke={color}
          strokeWidth={stroke}
          strokeLinecap="round"
          strokeDasharray={c}
          strokeDashoffset={c - (c * display) / 100}
          style={{ filter: `drop-shadow(0 0 5px ${color}88)` }}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">{children}</div>
    </div>
  );
}

export function Donut({ segments, size = 168 }: { segments: { value: number; color: string; label: string }[]; size?: number }) {
  const stroke = 16;
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  let offset = 0;
  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} className="-rotate-90" aria-hidden="true">
      <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="var(--border)" strokeWidth={stroke} />
      {segments.map((s) => {
        const len = (c * s.value) / 100;
        const el = (
          <circle
            key={s.label}
            cx={size / 2}
            cy={size / 2}
            r={r}
            fill="none"
            stroke={s.color}
            strokeWidth={stroke}
            strokeLinecap="round"
            strokeDasharray={`${Math.max(0, len - 5)} ${c}`}
            strokeDashoffset={-offset}
            style={{ transition: "stroke-dasharray .8s ease, stroke-dashoffset .8s ease" }}
          />
        );
        offset += len;
        return el;
      })}
    </svg>
  );
}

export function Bars({
  data, highlight, height = 176, format,
}: {
  data: { label: string; value: number; extra?: string }[];
  highlight?: number;
  height?: number;
  format?: (v: number) => string;
}) {
  const max = Math.max(...data.map((d) => d.value)) || 1;
  const [mounted, setMounted] = useState(false);
  useEffect(() => {
    const t = requestAnimationFrame(() => setMounted(true));
    return () => cancelAnimationFrame(t);
  }, []);
  return (
    <div className="flex items-end justify-between gap-2 sm:gap-3" style={{ height }}>
      {data.map((d, i) => (
        <div key={d.label} className="group flex h-full min-w-0 flex-1 flex-col items-center justify-end gap-2">
          <span className="num whitespace-nowrap text-[9px] font-bold t-mint opacity-0 transition-all duration-200 group-hover:translate-y-0 group-hover:opacity-100" dir="ltr">
            {format ? format(d.value) : d.extra ?? d.value}
          </span>
          <div className="flex w-full flex-1 items-end justify-center">
            <div
              className="bar-grow w-full max-w-[44px] rounded-t-[10px] transition-all duration-300 group-hover:brightness-125"
              style={{
                height: mounted ? `${Math.max(6, (d.value / max) * 100)}%` : "4%",
                animationDelay: `${i * 60}ms`,
                background: i === highlight
                  ? "linear-gradient(180deg,#8ba0ff,#3e5fe4)"
                  : "linear-gradient(180deg,rgba(124,146,255,.55),rgba(124,146,255,.10))",
                boxShadow: i === highlight ? "0 6px 22px rgba(91,124,255,.4)" : undefined,
              }}
            />
          </div>
          <span className="text-[10px] font-bold t-muted">{d.label}</span>
        </div>
      ))}
    </div>
  );
}
