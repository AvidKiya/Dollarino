import { useState } from "react";
import {
  Activity, ArrowUpLeft, Check, ChevronDown, Cpu, Gauge, Globe, Radio, Send,
  ShieldCheck, Sparkles, Star, Target, TrendingUp,
} from "lucide-react";
import { engines, faqs, money, plans, testimonials, weeklyBars } from "../data";
import type { AppState } from "../state";
import { Bars } from "./Charts";
import { AnimatedNumber, LiveDot, Logo, Reveal, SectionHeading } from "./UI";
import { StatCard } from "./Widgets";
import { WeeklyCard } from "./WeeklyCard";

const engineIcons = { ai: Sparkles, strategy: Cpu, copy: Radio } as const;

/* ================= ENGINES ================= */
export function Engines({ s }: { s: AppState }) {
  return (
    <section id="engines" className="mx-auto max-w-6xl px-4 py-16 sm:px-6 sm:py-24">
      <SectionHeading
        eyebrow="موتورها"
        title={<>سه موتور، <span className="marker">یک ترمینال</span></>}
        desc="هر موقعیتی، یک موتور مناسب دارد. با یک لمس جابه‌جا شو — همین حالا امتحان کن."
      />
      <div className="grid gap-3 sm:gap-4 md:grid-cols-3">
        {engines.map((e, i) => {
          const Icon = engineIcons[e.id];
          const active = s.activeEngine === e.id;
          return (
            <Reveal key={e.id} delay={i * 90}>
              <div className={`surface card lift relative flex h-full flex-col overflow-hidden p-5 sm:p-6 ${active ? "grad-border" : ""}`}>
                <div className="pointer-events-none absolute -left-12 -top-12 h-36 w-36 rounded-full blur-3xl" style={{ background: `${e.color}26` }} />
                <div className="relative flex items-start justify-between">
                  <span className="grid h-11 w-11 place-items-center rounded-2xl" style={{ background: `${e.color}1e`, color: e.color }}><Icon size={22} /></span>
                  {active
                    ? <span className="flex items-center gap-1.5 rounded-lg bg-[rgba(91,124,255,.2)] px-2 py-1 text-[9px] font-black t-accent"><LiveDot color="#8b9dff" /> فعال</span>
                    : <span className="rounded-lg border border-hairline px-2 py-1 text-[9px] font-bold t-faint">{e.badge}</span>}
                </div>
                <h3 className="relative mt-4 text-[15px] font-black">{e.name}</h3>
                <p className="num relative mt-1 text-[9px] font-bold tracking-[.14em] t-faint" dir="ltr">{e.latin}</p>
                <p className="relative mt-2.5 min-h-[44px] text-[11px] leading-6 t-muted">{e.description}</p>
                <div className="relative mt-4 flex items-center justify-between rounded-2xl border border-hairline bg-[var(--glass)] px-4 py-3">
                  <div><div className="num text-[18px] font-extrabold" dir="ltr"><AnimatedNumber value={e.winRate} format={(n) => `${n.toFixed(1)}%`} /></div><div className="text-[9px] t-faint">وین‌ریت</div></div>
                  <div className="text-left"><div className="num text-[18px] font-extrabold" dir="ltr">{e.trades.toLocaleString("en-US")}</div><div className="text-[9px] t-faint">معامله</div></div>
                </div>
                <button onClick={() => s.onSelectEngine(e.id)} className={`relative mt-4 h-10 w-full rounded-xl text-[11.5px] font-extrabold ${active ? "btn-ghost" : "btn-primary"}`}>
                  {active ? "موتور فعال دموی زنده" : "فعال‌سازی در دمو"}
                </button>
              </div>
            </Reveal>
          );
        })}
      </div>
    </section>
  );
}

/* ================= PERFORMANCE ================= */
export function Performance({ s }: { s: AppState }) {
  return (
    <section id="performance" className="border-y border-hairline bg-[var(--bg-soft)]/50">
      <div className="mx-auto max-w-6xl px-4 py-16 sm:px-6 sm:py-24">
        <SectionHeading
          eyebrow="عملکرد شفاف"
          title={<>عددها حرف می‌زنند، <span className="marker">نه وعده‌ها</span></>}
          desc="عملکرد واقعی موتورها در ۹۰ روز گذشته — بدون فیلتر، بدون اغراق."
        />
        <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
          <StatCard label="سود خالص ۹۰ روزه" raw={6650.72} format={(n) => money(n)} delta="36.5%" icon={TrendingUp} spark={[14, 18, 17, 24, 23, 31, 35, 42]} color="#7c92ff" />
          <StatCard label="وین‌ریت" raw={82.9} format={(n) => `${n.toFixed(1)}%`} delta="6.1%" icon={Target} spark={[20, 23, 22, 27, 28, 31, 33, 37]} color="#9d8cff" />
          <StatCard label="نسبت شارپ" raw={2.84} format={(n) => n.toFixed(2)} delta="0.4" icon={Gauge} spark={[18, 21, 20, 26, 25, 29, 31, 35]} color="#37d6a5" />
          <StatCard label="حداکثر افت" value="3.2%" delta="1.1%" icon={Activity} spark={[34, 32, 30, 28, 27, 25, 23, 20]} positive={false} color="#ff7185" />
        </div>
        <div className="mt-4 grid gap-3 sm:gap-4 lg:grid-cols-12">
          <Reveal className="lg:col-span-8">
            <div className="surface card h-full p-4 sm:p-6">
              <h3 className="text-[14px] font-black">سود روزهای هفته</h3>
              <p className="mt-1 text-[10.5px] t-muted">بهترین روز: سه‌شنبه با +$312</p>
              <div className="mt-4"><Bars data={weeklyBars.map((b) => ({ label: b.day, value: b.pnl }))} highlight={3} height={200} format={(v) => `+$${v}`} /></div>
            </div>
          </Reveal>
          <Reveal delay={120} className="lg:col-span-4">
            <WeeklyCard notify={s.notify} compact />
          </Reveal>
        </div>
      </div>
    </section>
  );
}

/* ================= PRICING ================= */
export function Pricing({ notify }: { notify: (m: string) => void }) {
  const [yearly, setYearly] = useState(false);
  return (
    <section id="pricing" className="mx-auto max-w-6xl px-4 py-16 sm:px-6 sm:py-24">
      <SectionHeading
        eyebrow="تعرفه"
        title={<>با رایگان شروع کن، <span className="marker">با سود بمون</span></>}
        desc="حساب دمو همیشه رایگان است. هر وقت آماده بودی، ارتقا بده."
      />
      <Reveal className="mb-8 flex justify-center">
        <div className="seg">
          <button data-active={!yearly} onClick={() => setYearly(false)}>ماهانه</button>
          <button data-active={yearly} onClick={() => setYearly(true)}>سالانه <span className="num rounded-md bg-black/15 px-1 text-[9px]" dir="ltr">-20%</span></button>
        </div>
      </Reveal>
      <div className="grid gap-3 sm:gap-4 md:grid-cols-3">
        {plans.map((p, i) => (
          <Reveal key={p.id} delay={i * 90}>
            <div className={`card relative flex h-full flex-col p-6 ${p.popular ? "coin-card-wallet text-white" : "surface lift"}`}>
              {p.popular && <span className="sticker absolute -top-3 right-6 px-3 py-1 text-[10px]">پیشنهاد دُرّبین</span>}
              <h3 className="text-[16px] font-black">{p.name}</h3>
              <p className={`mt-1 text-[11px] ${p.popular ? "text-white/70" : "t-muted"}`}>{p.tagline}</p>
              <div className="num mt-4 flex items-end gap-1.5" dir="ltr">
                <span className="text-[38px] font-extrabold leading-none">${yearly ? p.yearly : p.monthly}</span>
                <span className={`pb-1 text-[10.5px] font-bold ${p.popular ? "text-white/60" : "t-faint"}`}>/mo</span>
              </div>
              <ul className="mt-5 flex-1 space-y-2.5">
                {p.features.map((f) => (
                  <li key={f} className={`flex items-start gap-2 text-[11.5px] font-medium ${p.popular ? "text-white/90" : "t-muted"}`}>
                    <span className={`mt-0.5 grid h-[18px] w-[18px] shrink-0 place-items-center rounded-full ${p.popular ? "bg-white/15" : "bg-[rgba(91,124,255,.15)]"}`}>
                      <Check size={11} strokeWidth={3.5} className={p.popular ? "text-white" : "t-accent"} />
                    </span>
                    {f}
                  </li>
                ))}
              </ul>
              <button
                onClick={() => notify(p.id === "demo" ? "حساب دمو فعال شد — خوش آمدی!" : `پلن ${p.name} انتخاب شد`)}
                className={`mt-6 h-11 w-full rounded-2xl text-[12px] font-extrabold ${p.popular ? "bg-white text-[#2b4cd8] hover:bg-white/90" : "btn-primary"}`}
              >
                {p.cta}
              </button>
            </div>
          </Reveal>
        ))}
      </div>
    </section>
  );
}

/* ================= TESTIMONIALS ================= */
export function Testimonials() {
  return (
    <section className="mx-auto max-w-6xl px-4 pb-16 sm:px-6 sm:pb-24">
      <SectionHeading eyebrow="حرف‌های واقعی" title={<>تریدرها چه می‌گویند؟</>} />
      <div className="grid gap-3 sm:gap-4 md:grid-cols-3">
        {testimonials.map((t, i) => (
          <Reveal key={t.id} delay={i * 90}>
            <figure className="surface card lift flex h-full flex-col p-5 sm:p-6">
              <div className="flex gap-0.5" dir="ltr">
                {Array.from({ length: 5 }).map((_, k) => (<Star key={k} size={14} className="fill-[var(--amber)] text-[var(--amber)]" />))}
              </div>
              <blockquote className="mt-3 flex-1 text-[12.5px] font-medium leading-8">«{t.text}»</blockquote>
              <figcaption className="mt-4 flex items-center gap-2.5 border-t border-hairline pt-4">
                <span className="grid h-10 w-10 place-items-center rounded-full text-[11px] font-black" style={{ background: `${t.color}22`, color: t.color, border: `1px solid ${t.color}44` }}>{t.initials}</span>
                <span><span className="block text-[12px] font-black">{t.name}</span><span className="mt-0.5 block text-[10px] t-muted">{t.role}</span></span>
                <span className="num mr-auto rounded-lg bg-[rgba(55,214,165,.1)] px-2 py-1 text-[10px] font-black t-mint" dir="ltr">{t.profit}</span>
              </figcaption>
            </figure>
          </Reveal>
        ))}
      </div>
    </section>
  );
}

/* ================= FAQ ================= */
export function Faq() {
  const [open, setOpen] = useState<string | null>("f1");
  return (
    <section id="faq" className="mx-auto max-w-3xl px-4 pb-16 sm:px-6 sm:pb-24">
      <SectionHeading eyebrow="سوالات پرتکرار" title={<>هنوز سوال داری؟</>} />
      <div className="space-y-2.5">
        {faqs.map((f, i) => {
          const isOpen = open === f.id;
          return (
            <Reveal key={f.id} delay={i * 50}>
              <div className="surface overflow-hidden rounded-2xl transition-colors" style={isOpen ? { borderColor: "rgba(124,146,255,.55)" } : undefined}>
                <button onClick={() => setOpen(isOpen ? null : f.id)} className="flex w-full items-center justify-between gap-3 px-4 py-4 text-right text-[13px] font-extrabold sm:px-5">
                  {f.q}
                  <span className={`grid h-7 w-7 shrink-0 place-items-center rounded-lg transition-all duration-300 ${isOpen ? "rotate-180 bg-[rgba(91,124,255,.25)] t-accent" : "bg-[var(--glass)]"}`}>
                    <ChevronDown size={15} />
                  </span>
                </button>
                <div className={`faq-a ${isOpen ? "open" : ""}`}>
                  <div><p className="px-4 pb-5 text-[12px] leading-7 t-muted sm:px-5">{f.a}</p></div>
                </div>
              </div>
            </Reveal>
          );
        })}
      </div>
    </section>
  );
}

/* ================= CTA + FOOTER ================= */
export function Cta({ onEnter }: { onEnter: () => void }) {
  return (
    <section id="cta" className="mx-auto max-w-6xl px-4 pb-16 sm:px-6 sm:pb-24">
      <Reveal>
        <div className="coin-card-wallet card relative overflow-hidden p-8 text-center text-white sm:p-14">
          <div className="float-slow absolute right-8 top-8 hidden sm:block" style={{ ["--rot" as string]: "6deg" }}>
            <span className="sticker bg-white/15 px-3 py-1.5 text-[11px] text-white">+36.5% این ماه</span>
          </div>
          <div className="float-slow absolute bottom-8 left-8 hidden sm:block" style={{ ["--rot" as string]: "-6deg", animationDelay: "-2s" }}>
            <span className="sticker bg-white/15 px-3 py-1.5 text-[11px] text-white">بدون نیاز به تجربه</span>
          </div>
          <p className="num text-[11px] font-black tracking-[.2em] text-white/60" dir="ltr">JOIN 4,200+ TRADERS</p>
          <h2 className="h-display mx-auto mt-3 max-w-xl text-[28px] sm:text-[44px]">اولین معامله خودکارت،<br />همین امروز.</h2>
          <p className="mx-auto mt-3 max-w-md text-[12.5px] font-medium leading-7 text-white/75">حساب دمو رایگان، بدون کارت بانکی، بدون ریسک. در ۳۰ ثانیه شروع کن.</p>
          <div className="mt-7 flex flex-wrap items-center justify-center gap-2.5">
            <button onClick={onEnter} className="h-[52px] rounded-2xl bg-white px-8 text-[13.5px] font-extrabold transition hover:bg-white/90" style={{ color: "#2b4cd8" }}>ورود به ترمینال <span className="inline-block align-middle"><ArrowUpLeft size={18} /></span></button>
            <a href="#demo" className="flex h-[52px] items-center rounded-2xl bg-white/15 px-6 text-[13px] font-extrabold text-white transition hover:bg-white/25">اول دمو را ببین</a>
          </div>
        </div>
      </Reveal>
    </section>
  );
}

export function Footer({ notify }: { notify: (m: string) => void }) {
  const cols = [
    { t: "محصول", links: ["دموی زنده", "موتور دُرّبین", "کپی‌ترید", "تعرفه"] },
    { t: "منابع", links: ["راهنمای شروع", "مستندات API", "گزارش عملکرد", "وبلاگ"] },
    { t: "اعتماد", links: ["امنیت", "حریم خصوصی", "شرایط استفاده", "تماس"] },
  ];
  return (
    <footer className="border-t border-hairline bg-[var(--bg-soft)]/60">
      <div className="mx-auto grid max-w-6xl gap-10 px-4 py-12 sm:px-6 lg:grid-cols-12">
        <div className="lg:col-span-5">
          <Logo />
          <p className="mt-3 max-w-xs text-[12px] leading-7 t-muted">ترمینال هوشمند معاملات چندارزی — هوش مصنوعی، استراتژی منتخب و کپی‌ترید لحظه‌ای.</p>
          <div className="mt-4 flex gap-2">
            {[Send, Globe, ShieldCheck].map((Icon, i) => (
              <button key={i} onClick={() => notify("به‌زودی در این شبکه فعال می‌شویم")} className="icon-btn h-9 w-9 rounded-xl border border-hairline" aria-label="شبکه اجتماعی"><Icon size={16} /></button>
            ))}
          </div>
        </div>
        {cols.map((c) => (
          <div key={c.t} className="lg:col-span-2">
            <p className="text-[11px] font-black t-faint">{c.t}</p>
            <ul className="mt-3 space-y-2.5">
              {c.links.map((l) => (
                <li key={l}><button onClick={() => notify(`«${l}» به‌زودی منتشر می‌شود`)} className="text-[12px] font-medium t-muted transition-colors hover:text-[var(--text)]">{l}</button></li>
              ))}
            </ul>
          </div>
        ))}
        <div className="lg:col-span-1" />
      </div>
      <div className="border-t border-hairline">
        <div className="num mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-2 px-4 py-4 text-[10px] t-faint sm:px-6" dir="ltr">
          <span>© 2026 Dollarino. · v6.0</span>
          <span className="flex items-center gap-1.5"><span className="h-1.5 w-1.5 rounded-full bg-[var(--mint)]" /> All systems operational</span>
        </div>
      </div>
      <div className="h-[76px] lg:hidden" />
    </footer>
  );
}
