import { ArrowDown, ArrowUpLeft, BrainCircuit, Cpu, Layers3, Radio, Send, ShieldCheck, Star, TrendingUp, Zap } from "lucide-react";
import { money, pct, priceText, type Market } from "../data";
import { ProgressRing, Sparkline } from "./Charts";
import { AnimatedNumber, CoinIcon, LiveDot, Logo, Reveal } from "./UI";

/* ================= HERO ================= */
export function Hero({ markets, balance, onStart }: { markets: Market[]; balance: number; onStart: () => void }) {
  const btc = markets[0];
  return (
    <section id="top" className="relative mx-auto max-w-6xl px-4 pb-10 pt-10 sm:px-6 sm:pt-16">
      <div className="grid items-center gap-10 lg:grid-cols-2 lg:gap-6">
        <div>
          <Reveal>
            <span className="inline-flex items-center gap-2 rounded-full border border-hairline bg-[var(--glass)] px-3 py-1.5 text-[10.5px] font-extrabold">
              <LiveDot color="var(--lime)" /> زنده — نسخه ۶٫۰ دلارینو
            </span>
          </Reveal>
          <Reveal delay={80}>
            <h1 className="h-display mt-5 text-[38px] sm:text-[56px] lg:text-[60px]">
              ترید خودکار،
              <br />
              <span className="marker">به زبان ساده.</span>
            </h1>
          </Reveal>
          <Reveal delay={160}>
            <p className="lead mt-5 max-w-md text-[13.5px] sm:text-[15px]">
              دلارینو با سه موتور هوش مصنوعی، استراتژی منتخب و کپی‌ترید، روی ۳۰+ ارز بازار هم‌زمان معامله می‌کند — بدون دانش پیچیده، بدون خیره شدن به چارت.
            </p>
          </Reveal>
          <Reveal delay={240}>
            <div className="mt-7 flex flex-wrap items-center gap-2.5">
              <button onClick={onStart} className="btn-lime h-[52px] rounded-2xl px-7 text-[13.5px]">
                شروع رایگان در ۳۰ ثانیه <ArrowUpLeft size={18} strokeWidth={2.5} />
              </button>
              <a href="#terminal" className="btn-ghost h-[52px] rounded-2xl px-6 text-[13px] font-extrabold">
                تماشای ترمینال زنده <ArrowDown size={16} />
              </a>
            </div>
          </Reveal>
          <Reveal delay={320}>
            <div className="mt-8 flex flex-wrap items-center gap-x-6 gap-y-3">
              <div className="flex items-center gap-2.5">
                <div className="flex -space-x-2 space-x-reverse">
                  {[{ t: "س م", c: "#c9f24e" }, { t: "ا ر", c: "#9d8cff" }, { t: "ن ک", c: "#3ddc97" }, { t: "+", c: "var(--glass)" }].map((a, i) => (
                    <span key={i} className="grid h-9 w-9 place-items-center rounded-full border-2 border-[var(--bg)] text-[10px] font-black" style={{ background: a.c, color: a.t === "+" ? "var(--text)" : "#141a05" }}>{a.t}</span>
                  ))}
                </div>
                <div><p className="num text-[12px] font-black" dir="ltr">4,200+</p><p className="text-[10px] t-muted">تریدر فعال</p></div>
              </div>
              <div className="h-8 w-px bg-[var(--border)]" />
              <div>
                <p className="flex items-center gap-1" dir="ltr">
                  {Array.from({ length: 5 }).map((_, i) => (<Star key={i} size={13} className="fill-[var(--amber)] text-[var(--amber)]" />))}
                  <span className="num ml-1 text-[12px] font-black">4.9</span>
                </p>
                <p className="mt-0.5 text-[10px] t-muted">رضایت کاربران</p>
              </div>
              <div className="hidden h-8 w-px bg-[var(--border)] sm:block" />
              <div className="hidden sm:block"><p className="num text-[12px] font-black" dir="ltr">24/7</p><p className="text-[10px] t-muted">ربات همیشه روشن</p></div>
            </div>
          </Reveal>
        </div>

        {/* phone mock */}
        <Reveal delay={200} className="relative mx-auto w-full max-w-[380px]">
          <div className="absolute -inset-8 -z-10 rounded-[48px] bg-[radial-gradient(closest-side,rgba(201,242,78,.14),transparent)] blur-2xl" />
          <div className="surface card rotate-1 overflow-hidden p-5 transition-transform duration-500 hover:rotate-0">
            <div className="flex items-center justify-between">
              <Logo compact />
              <span className="num rounded-lg bg-[rgba(201,242,78,.14)] px-2 py-1 text-[9px] font-black t-lime" dir="ltr">PAPER DEMO</span>
            </div>
            <p className="mt-5 text-[10.5px] t-muted">موجودی کل</p>
            <div className="num mt-1 text-[34px] font-bold tracking-tight" dir="ltr">
              <AnimatedNumber value={balance} format={(n) => money(n)} />
            </div>
            <div className="mt-3 h-[86px]"><Sparkline values={btc.spark} color="#c9f24e" height={86} fill endDot /></div>
            <div className="mt-2 space-y-1.5">
              {markets.slice(0, 3).map((m) => (
                <div key={m.symbol} className="flex items-center gap-2.5 rounded-2xl border border-hairline bg-[var(--glass)] px-3 py-2">
                  <CoinIcon symbol={m.symbol} color={m.color} size={30} />
                  <span className="num text-[11px] font-bold" dir="ltr">{m.symbol}</span>
                  <span className="num mr-auto text-[11px] font-bold" dir="ltr">${priceText(m.price)}</span>
                  <span className="num text-[10px] font-bold" style={{ color: m.change >= 0 ? "var(--mint)" : "var(--rose)" }} dir="ltr">{pct(m.change)}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="float-slow absolute -right-3 top-16 rounded-2xl border border-[var(--border-strong)] bg-[var(--card-solid)] px-3.5 py-2.5 shadow-[var(--shadow)] sm:-right-8" style={{ ["--rot" as string]: "3deg" }}>
            <p className="text-[9px] t-muted">سود BTC/USDT</p>
            <p className="num mt-0.5 text-[14px] font-bold t-mint" dir="ltr">+$125.40</p>
          </div>
          <div className="float-slow absolute -left-3 bottom-24 rounded-2xl border border-[var(--border-strong)] bg-[var(--card-solid)] px-3.5 py-2.5 shadow-[var(--shadow)] sm:-left-8" style={{ ["--rot" as string]: "-3deg", animationDelay: "-2.5s" }}>
            <p className="flex items-center gap-1.5 text-[9px] t-muted"><LiveDot color="var(--lime)" /> سیگنال جدید</p>
            <p className="num mt-0.5 text-[12px] font-bold" dir="ltr">LONG BTC · 94%</p>
          </div>
          <div className="sticker sticker-lime absolute -top-3 left-8 px-3 py-1.5 text-[10.5px]">اهرم تا 50x</div>
        </Reveal>
      </div>

      {/* stats */}
      <Reveal delay={100}>
        <div className="surface card mt-12 grid grid-cols-2 divide-[var(--border)] max-sm:gap-y-6 max-sm:p-5 sm:grid-cols-4 sm:divide-x sm:divide-x-reverse sm:p-2">
          {[
            { v: "+36.5%", l: "سود ۳۰ روزه" },
            { v: "82.9%", l: "وین‌ریت موتورها" },
            { v: "0.8s", l: "سرعت اجرای سیگنال" },
            { v: "30+", l: "ارز تحت پوشش" },
          ].map((s) => (
            <div key={s.l} className="px-4 py-3 text-center sm:py-5">
              <div className="num text-[22px] font-bold sm:text-[26px]" dir="ltr">{s.v}</div>
              <div className="mt-1 text-[10.5px] t-muted">{s.l}</div>
            </div>
          ))}
        </div>
      </Reveal>
    </section>
  );
}

/* ================= Market tape ================= */
export function Tape({ markets, notify }: { markets: Market[]; notify: (m: string) => void }) {
  const items = [...markets, ...markets, ...markets];
  return (
    <div className="tape border-y border-hairline bg-[var(--bg-soft)]/60 py-3.5">
      <div className="tape-track gap-8" dir="ltr">
        {items.map((m, i) => (
          <button key={`${m.symbol}-${i}`} onClick={() => notify(`${m.symbol}: $${priceText(m.price)}`)} className="num flex items-center gap-2 whitespace-nowrap text-[12px]" aria-hidden={i >= markets.length}>
            <span className="h-1.5 w-1.5 rounded-full" style={{ background: m.color }} />
            <span className="font-bold">{m.symbol}</span>
            <span className="t-muted">${priceText(m.price)}</span>
            <span className="font-bold" style={{ color: m.change >= 0 ? "var(--mint)" : "var(--rose)" }}>{pct(m.change)}</span>
            <span className="mr-6 text-[8px] t-faint">◆</span>
          </button>
        ))}
      </div>
    </div>
  );
}

/* ================= Bento features ================= */
const bentoModels = ["DeepSeek", "Claude", "GPT", "Gemini"];

export function Bento() {
  return (
    <section className="mx-auto max-w-6xl px-4 py-16 sm:px-6 sm:py-24">
      <Reveal className="mb-10 max-w-2xl sm:mb-14">
        <span className="eyebrow">چرا دلارینو</span>
        <h2 className="h-display mt-3 text-[26px] sm:text-[38px]">یک ارتش تریدر،<br />توی جیب تو.</h2>
        <p className="lead mt-3 text-[13px] sm:text-[14px]">سه موتور، یک مغز متفکر؛ همه با هم برای یک هدف: سود مستمر با ریسک کنترل‌شده.</p>
      </Reveal>

      <div className="grid gap-3 sm:gap-4 lg:grid-cols-3">
        <Reveal className="lg:col-span-2">
          <div className="surface card lift group relative h-full overflow-hidden p-5 sm:p-7">
            <div className="pointer-events-none absolute -left-16 -top-16 h-56 w-56 rounded-full bg-[rgba(201,242,78,.12)] blur-3xl" />
            <span className="grid h-11 w-11 place-items-center rounded-2xl bg-[var(--lime)]" style={{ color: "var(--on-lime)" }}><BrainCircuit size={22} /></span>
            <h3 className="mt-4 text-[17px] font-black sm:text-[19px]">هوش مصنوعی دُرّبین</h3>
            <p className="mt-2 max-w-md text-[12px] leading-7 t-muted">ترکیب هوشمند چند مدل زبانی برای تحلیل روند، اخبار و نقدینگی — بدون نیاز به کلید API شخصی. هر تصمیم با درجه اطمینان شفاف.</p>
            <div className="mt-4 flex flex-wrap gap-1.5">
              {bentoModels.map((m) => (
                <span key={m} className="num rounded-lg border border-hairline bg-[var(--glass)] px-2.5 py-1 text-[10px] font-bold t-muted" dir="ltr">{m}</span>
              ))}
            </div>
            <div className="mt-5 flex items-center gap-3">
              <div className="h-2 flex-1 overflow-hidden rounded-full bg-[var(--border)]">
                <div className="h-full rounded-full bg-[var(--lime)]" style={{ width: "94%", boxShadow: "0 0 14px var(--lime)" }} />
              </div>
              <span className="num text-[12px] font-black" dir="ltr">94%</span>
            </div>
          </div>
        </Reveal>

        <Reveal delay={100}>
          <div className="surface card lift flex h-full flex-col p-5 sm:p-7">
            <span className="grid h-11 w-11 place-items-center rounded-2xl bg-[rgba(157,140,255,.14)] text-[var(--violet)]"><Cpu size={22} /></span>
            <h3 className="mt-4 text-[16px] font-black">استراتژی دُرنا V1</h3>
            <p className="mt-2 flex-1 text-[12px] leading-7 t-muted">روند، مومنتوم، شکار نقدینگی و ریبون غیرریپینت — رایگان در حساب دمو.</p>
            <div className="mt-4 flex justify-center"><ProgressRing value={78} size={96} stroke={9} color="#9d8cff"><span className="num text-[17px] font-bold" dir="ltr">78%</span><span className="text-[8px] t-faint">وین‌ریت</span></ProgressRing></div>
          </div>
        </Reveal>

        {[
          { icon: Radio, c: "var(--mint)", t: "کپی‌ترید لحظه‌ای", d: "کپی خودکار از کانال رسمی، کانال خودت یا وب‌هوک TradingView — زیر یک ثانیه.", big: "0.8s", bigL: "میانگین اجرا" },
          { icon: Layers3, c: "var(--lime)", t: "۲۰ معامله همزمان", d: "کل بازار را هم‌زمان شکار کن؛ چرخش خودکار روند هم فعال است.", big: "30+", bigL: "ارز تحت پوشش" },
          { icon: TrendingUp, c: "var(--amber)", t: "اهرم آزاد تا 50x", d: "در حالت حرفه‌ای، اهرم و حجم هر معامله دست خودت است.", big: "50x", bigL: "سقف اهرم" },
          { icon: Send, c: "var(--violet)", t: "ربات تلگرام ۲۴/۷", d: "سیگنال، گزارش روزانه و هشدار لیکوییدیشن — همیشه همراهت.", big: "24/7", bigL: "پاسخ‌گویی" },
        ].map((f, i) => (
          <Reveal key={f.t} delay={i * 70}>
            <div className="surface card lift flex h-full flex-col p-5 sm:p-6">
              <div className="flex items-center justify-between">
                <span className="grid h-10 w-10 place-items-center rounded-xl" style={{ background: `${f.c}16`, color: f.c }}><f.icon size={20} /></span>
                <div className="text-left"><div className="num text-[20px] font-bold" dir="ltr">{f.big}</div><div className="text-[9px] t-faint">{f.bigL}</div></div>
              </div>
              <h3 className="mt-3.5 text-[14.5px] font-black">{f.t}</h3>
              <p className="mt-1.5 text-[11.5px] leading-6 t-muted">{f.d}</p>
            </div>
          </Reveal>
        ))}

        <Reveal delay={120} className="lg:col-span-2">
          <div className="lime-card card flex flex-wrap items-center gap-4 p-5 sm:p-7">
            <span className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl bg-black/10"><ShieldCheck size={24} /></span>
            <div className="min-w-[200px] flex-1">
              <h3 className="text-[16px] font-black sm:text-[18px]">پولت همیشه پیش خودت می‌ماند</h3>
              <p className="mt-1 text-[11.5px] font-medium leading-6 opacity-70">کلیدها با AES-256 رمزنگاری می‌شوند و ربات فقط اجازه معامله دارد — نه برداشت.</p>
            </div>
            <div className="num flex items-center gap-2 rounded-2xl bg-black/10 px-4 py-2.5 text-[11px] font-black" dir="ltr"><Zap size={15} /> NO WITHDRAW ACCESS</div>
          </div>
        </Reveal>

        <Reveal delay={180}>
          <div className="surface card lift flex h-full flex-col justify-center p-5 sm:p-6" style={{ background: "linear-gradient(150deg, rgba(157,140,255,.12), var(--card))" }}>
            <p className="num text-[30px] font-bold" dir="ltr">4,508</p>
            <p className="mt-1 text-[11.5px] font-bold">معامله تحلیل‌شده این ماه</p>
            <p className="mt-2 text-[11px] leading-6 t-muted">توسط هر سه موتور، روی حساب‌های واقعی و دمو.</p>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
