import { useEffect, useState } from "react";
import { ArrowUpLeft, Home, Layers3, Menu, Moon, Plus, Sun, Tag, X, Zap } from "lucide-react";
import { LiveDot, Logo } from "./UI";

export const anchors = [
  { id: "terminal", label: "ترمینال" },
  { id: "engines", label: "موتورها" },
  { id: "performance", label: "عملکرد" },
  { id: "pricing", label: "تعرفه" },
  { id: "faq", label: "سوالات" },
];

export function Navbar({
  theme, onToggleTheme, onStart, botActive,
}: {
  theme: "dark" | "light";
  onToggleTheme: () => void;
  onStart: () => void;
  botActive: boolean;
}) {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <>
      <div className="relative z-40 flex items-center justify-center gap-2 bg-[var(--lime)] px-4 py-2 text-center text-[10.5px] font-extrabold" style={{ color: "var(--on-lime)" }}>
        <Zap size={13} strokeWidth={2.5} />
        نسخه ۶٫۰ منتشر شد — کپی‌ترید لحظه‌ای و اهرم آزاد تا 50x
        <a href="#pricing" className="hidden underline underline-offset-2 sm:inline">مشاهده تعرفه</a>
      </div>
      <header className={`sticky top-0 z-40 border-b transition-all duration-300 ${scrolled ? "border-[var(--border-strong)] bg-[var(--bg)]/85 shadow-[0_10px_30px_rgba(0,0,0,.15)] backdrop-blur-2xl" : "border-transparent bg-transparent"}`}>
        <div className="mx-auto flex h-[64px] max-w-6xl items-center justify-between gap-3 px-4 sm:px-6">
          <a href="#top" aria-label="دلارینو"><Logo /></a>
          <nav className="hidden items-center gap-6 text-[12.5px] font-bold t-muted lg:flex">
            {anchors.map((a) => (
              <a key={a.id} href={`#${a.id}`} className="navlink hover:text-[var(--text)]">{a.label}</a>
            ))}
          </nav>
          <div className="flex items-center gap-1.5">
            <span className="num hidden items-center gap-1.5 rounded-full border border-hairline bg-[var(--glass)] px-2.5 py-1.5 text-[9.5px] font-bold t-muted md:flex" dir="ltr">
              <LiveDot color={botActive ? "var(--mint)" : "var(--amber)"} /> {botActive ? "LIVE" : "PAUSED"}
            </span>
            <button onClick={onToggleTheme} className="icon-btn h-9 w-9 rounded-xl" aria-label="تغییر تم">
              {theme === "dark" ? <Sun size={17} /> : <Moon size={17} />}
            </button>
            <button onClick={onStart} className="btn-lime hidden h-10 rounded-2xl px-5 text-[12px] sm:inline-flex">
              شروع رایگان <ArrowUpLeft size={15} strokeWidth={2.5} />
            </button>
            <button onClick={() => setOpen((v) => !v)} className="icon-btn h-9 w-9 rounded-xl lg:hidden" aria-label="منو">
              {open ? <X size={19} /> : <Menu size={19} />}
            </button>
          </div>
        </div>
        {open && (
          <div className="animate-menu border-t border-hairline bg-[var(--bg)]/95 px-4 pb-5 pt-3 backdrop-blur-2xl lg:hidden">
            <div className="grid gap-1">
              {anchors.map((a, i) => (
                <a key={a.id} href={`#${a.id}`} onClick={() => setOpen(false)} className="flex items-center justify-between rounded-2xl px-3 py-3 text-[13px] font-bold transition-colors hover:bg-[var(--glass)]">
                  {a.label}
                  <span className="num text-[10px] t-faint" dir="ltr">0{i + 1}</span>
                </a>
              ))}
            </div>
            <button onClick={() => { setOpen(false); onStart(); }} className="btn-lime mt-3 h-11 w-full rounded-2xl text-[12.5px]">شروع رایگان <ArrowUpLeft size={16} /></button>
          </div>
        )}
      </header>
    </>
  );
}

export function MobileDock({ onTrade }: { onTrade: () => void }) {
  return (
    <nav className="fixed inset-x-3 bottom-3 z-[60] sm:hidden" style={{ paddingBottom: "env(safe-area-inset-bottom)" }}>
      <div className="glass mx-auto grid max-w-md grid-cols-5 items-end rounded-[26px] px-2 pb-2 pt-2 shadow-[0_16px_45px_rgba(0,0,0,.35)]">
        <a href="#top" className="flex flex-col items-center gap-1 rounded-2xl py-1.5 t-faint"><Home size={19} /><span className="text-[9px] font-bold">خانه</span></a>
        <a href="#terminal" className="flex flex-col items-center gap-1 rounded-2xl py-1.5 t-faint"><Layers3 size={19} /><span className="text-[9px] font-bold">ترمینال</span></a>
        <div className="flex flex-col items-center">
          <button onClick={onTrade} aria-label="معامله جدید" className="btn-lime -mt-7 grid h-[54px] w-[54px] place-items-center rounded-[20px] active:scale-90">
            <Plus size={24} strokeWidth={2.8} />
          </button>
          <span className="mt-1 text-[9px] font-bold t-muted">معامله</span>
        </div>
        <a href="#engines" className="flex flex-col items-center gap-1 rounded-2xl py-1.5 t-faint"><Zap size={19} /><span className="text-[9px] font-bold">موتورها</span></a>
        <a href="#pricing" className="flex flex-col items-center gap-1 rounded-2xl py-1.5 t-faint"><Tag size={19} /><span className="text-[9px] font-bold">تعرفه</span></a>
      </div>
    </nav>
  );
}
