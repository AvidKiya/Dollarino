import { useEffect, useRef, useState } from "react";
import {
  ArrowLeftRight, ArrowUpLeft, BarChart3, Bell, CheckCheck, ChevronLeft, Cpu, Globe,
  LayoutDashboard, Menu, Moon, MoreHorizontal, Plus, Radio, Search, Settings2, ShieldCheck,
  Sun, Wallet, X, Zap,
} from "lucide-react";
import type { LucideIcon } from "lucide-react";
import { initialMarkets, pageTitles, type NavKey } from "../data";
import { LiveDot, Logo } from "./UI";

interface NavItem { key: NavKey; label: string; icon: LucideIcon }

export const navItems: NavItem[] = [
  { key: "overview", label: "نمای کلی", icon: LayoutDashboard },
  { key: "trades", label: "معاملات", icon: ArrowLeftRight },
  { key: "signals", label: "سیگنال‌ها", icon: Radio },
  { key: "performance", label: "عملکرد", icon: BarChart3 },
  { key: "engines", label: "موتورها", icon: Cpu },
  { key: "wallet", label: "کیف پول", icon: Wallet },
  { key: "settings", label: "تنظیمات", icon: Settings2 },
];

const primary = navItems.slice(0, 4);
const secondary = navItems.slice(4);

export const siteAnchors = [
  { id: "demo", label: "دموی زنده" },
  { id: "engines", label: "موتورها" },
  { id: "performance", label: "عملکرد" },
  { id: "pricing", label: "تعرفه" },
  { id: "faq", label: "سوالات" },
];

/* ================= Landing navbar ================= */
export function Navbar({
  theme, onToggleTheme, onEnter, botActive,
}: {
  theme: "dark" | "light";
  onToggleTheme: () => void;
  onEnter: () => void;
  botActive: boolean;
}) {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <>
      <div className="relative z-40 flex items-center justify-center gap-2 bg-gradient-to-l from-[#5b7cff] to-[#3e5fe4] px-4 py-2 text-center text-[10.5px] font-extrabold text-white">
        <Zap size={13} strokeWidth={2.5} />
        نسخه ۶٫۰ منتشر شد — کپی‌ترید لحظه‌ای و اهرم آزاد تا 50x
        <a href="#pricing" className="hidden underline underline-offset-2 sm:inline">مشاهده تعرفه</a>
      </div>
      <header className={`sticky top-0 z-40 border-b transition-all duration-300 ${scrolled ? "border-[var(--border-strong)] bg-[var(--bg)]/85 shadow-[0_10px_30px_rgba(0,0,0,.18)] backdrop-blur-2xl" : "border-transparent bg-transparent"}`}>
        <div className="mx-auto flex h-[64px] max-w-6xl items-center justify-between gap-3 px-4 sm:px-6">
          <a href="#top" aria-label="دلارینو"><Logo /></a>
          <nav className="hidden items-center gap-6 text-[12.5px] font-bold t-muted lg:flex">
            {siteAnchors.map((a) => (
              <a key={a.id} href={`#${a.id}`} className="navlink hover:text-[var(--text)]">{a.label}</a>
            ))}
          </nav>
          <div className="flex items-center gap-1.5">
            <span className="num hidden items-center gap-1.5 rounded-full border border-hairline bg-[var(--glass)] px-2.5 py-1.5 text-[9.5px] font-bold t-muted md:flex" dir="ltr">
              <LiveDot color={botActive ? "var(--mint)" : "var(--amber)"} /> {botActive ? "LIVE" : "PAUSED"}
            </span>
            <button onClick={onToggleTheme} className="icon-btn h-9 w-9 rounded-xl" aria-label="تغییر تم">
              {theme === "dark" ? <Sun size={17} /> : <Moon size={17} />}
            </button>
            <button onClick={onEnter} className="btn-primary hidden h-10 rounded-2xl px-5 text-[12px] sm:inline-flex">
              ورود به ترمینال <ArrowUpLeft size={15} strokeWidth={2.5} />
            </button>
            <button onClick={() => setOpen((v) => !v)} className="icon-btn h-9 w-9 rounded-xl lg:hidden" aria-label="منو">
              {open ? <X size={19} /> : <Menu size={19} />}
            </button>
          </div>
        </div>
        {open && (
          <div className="animate-menu border-t border-hairline bg-[var(--bg)]/95 px-4 pb-5 pt-3 backdrop-blur-2xl lg:hidden">
            <div className="grid gap-1">
              {siteAnchors.map((a, i) => (
                <a key={a.id} href={`#${a.id}`} onClick={() => setOpen(false)} className="flex items-center justify-between rounded-2xl px-3 py-3 text-[13px] font-bold transition-colors hover:bg-[var(--glass)]">
                  {a.label}
                  <span className="num text-[10px] t-faint" dir="ltr">0{i + 1}</span>
                </a>
              ))}
            </div>
            <button onClick={() => { setOpen(false); onEnter(); }} className="btn-primary mt-3 h-11 w-full rounded-2xl text-[12.5px]">ورود به ترمینال <ArrowUpLeft size={16} /></button>
          </div>
        )}
      </header>
    </>
  );
}

/* ================= App sidebar ================= */
export function Sidebar({
  active, onNavigate, botActive, notify, openCount, onExit,
}: {
  active: NavKey;
  onNavigate: (key: NavKey) => void;
  botActive: boolean;
  notify: (m: string) => void;
  openCount: number;
  onExit: () => void;
}) {
  const group = (items: NavItem[]) =>
    items.map(({ key, label, icon: Icon }) => {
      const isActive = active === key;
      return (
        <button
          key={key}
          onClick={() => onNavigate(key)}
          className={`group relative flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-[12.5px] font-semibold transition-all duration-200 ${
            isActive ? "bg-[rgba(91,124,255,.13)] text-[var(--text)]" : "t-muted hover:translate-x-[-2px] hover:bg-[var(--glass)] hover:text-[var(--text)]"
          }`}
        >
          {isActive && <span className="absolute right-0 top-1/2 h-6 w-[3px] -translate-y-1/2 rounded-l-full bg-gradient-to-b from-[#8ba0ff] to-[#3e5fe4] shadow-[0_0_12px_rgba(91,124,255,.8)]" />}
          <Icon size={17} strokeWidth={isActive ? 2.3 : 1.8} className={isActive ? "text-[#8ca1ff]" : "transition-transform duration-200 group-hover:scale-110"} />
          <span>{label}</span>
          {key === "signals" && <span className="num mr-auto rounded-md border border-[rgba(91,124,255,.3)] bg-[rgba(91,124,255,.14)] px-1.5 py-0.5 text-[9px] font-bold text-[#9aadff]">۱۲</span>}
          {key === "trades" && openCount > 0 && <span className="num mr-auto rounded-md border border-[rgba(55,214,165,.3)] bg-[rgba(55,214,165,.12)] px-1.5 py-0.5 text-[9px] font-bold t-mint">{openCount}</span>}
        </button>
      );
    });

  return (
    <aside className="fixed inset-y-0 right-0 z-50 hidden w-[258px] flex-col border-l border-hairline bg-[var(--bg-soft)]/80 px-4 py-5 backdrop-blur-2xl lg:flex">
      <div className="flex items-center justify-between px-2">
        <Logo />
        <button onClick={onExit} className="icon-btn h-8 w-8 rounded-lg" aria-label="بازگشت به سایت" title="بازگشت به سایت"><Globe size={16} /></button>
      </div>

      <div className="mt-8 flex-1 space-y-7 overflow-y-auto scroll-thin">
        <div>
          <p className="mb-3 flex items-center gap-2 px-3 text-[10px] font-bold tracking-wide t-faint">فضای کار <span className="h-px flex-1 bg-[var(--border)]" /></p>
          <div className="space-y-1">{group(primary)}</div>
        </div>
        <div>
          <p className="mb-3 flex items-center gap-2 px-3 text-[10px] font-bold tracking-wide t-faint">سیستم <span className="h-px flex-1 bg-[var(--border)]" /></p>
          <div className="space-y-1">{group(secondary)}</div>
        </div>

        <div className="grad-border relative overflow-hidden rounded-[20px] bg-[linear-gradient(145deg,rgba(91,124,255,.16),rgba(91,124,255,.03))] p-4">
          <div className="absolute -left-8 -top-8 h-24 w-24 rounded-full bg-[#6d8dff]/25 blur-2xl" />
          <div className="relative">
            <span className="grid h-9 w-9 place-items-center rounded-xl bg-gradient-to-br from-[#6d8dff] to-[#3453d4] text-white shadow-[0_6px_18px_rgba(70,105,235,.45)]"><Zap size={17} fill="white" /></span>
            <p className="mt-3 text-[12.5px] font-extrabold">دلارینو پرو</p>
            <p className="mt-1 text-[10.5px] leading-5 t-muted">اهرم آزاد، ۲۰ معامله همزمان و تحلیل نامحدود AI.</p>
            <button onClick={() => notify("نسخه پرو: اهرم آزاد و ۲۰ معامله همزمان")} className="btn-primary mt-3 h-8 w-full rounded-lg text-[11px] font-bold">ارتقا حساب <ChevronLeft size={14} /></button>
          </div>
        </div>
      </div>

      <div className="mt-4 space-y-2">
        <div className="flex items-center gap-2.5 rounded-2xl border border-hairline bg-[var(--glass)] p-2.5">
          <span className="relative grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-gradient-to-br from-[#6f8cff] to-[#3453d4] text-[10px] font-extrabold text-white">AK
            <span className={`absolute -bottom-0.5 -left-0.5 h-2.5 w-2.5 rounded-full border-2 border-[var(--bg-soft)] ${botActive ? "bg-[var(--mint)]" : "bg-[var(--amber)]"}`} />
          </span>
          <div className="min-w-0"><p className="truncate text-[11px] font-bold">Avid Kiya</p><p className="num text-[9px] t-faint" dir="ltr">PRO · v6.0</p></div>
        </div>
        <div className="flex items-center gap-2 rounded-2xl border border-hairline px-3 py-2.5">
          <LiveDot color={botActive ? "var(--mint)" : "var(--amber)"} />
          <span className="text-[10.5px] font-bold">{botActive ? "همه سامانه‌ها پایدار" : "ربات در حالت توقف"}</span>
          <span className="num mr-auto text-[9px] t-faint" dir="ltr">24/7</span>
        </div>
      </div>
    </aside>
  );
}

/* ================= App topbar ================= */
const notifications = [
  { id: "n1", tab: "signal" as const, title: "سیگنال جدید BTC/USDT", sub: "موتور دُرّبین · اطمینان ۹۴٪", time: "۲ دقیقه پیش", color: "var(--mint)" },
  { id: "n2", tab: "signal" as const, title: "پوزیشن SOL بسته شد", sub: "سود +$76.60 · کپی‌ترید", time: "۱۸ دقیقه پیش", color: "#7c92ff" },
  { id: "n3", tab: "system" as const, title: "گزارش هفتگی آماده است", sub: "عملکرد +۱۸.۶٪", time: "۱ ساعت پیش", color: "var(--amber)" },
  { id: "n4", tab: "system" as const, title: "اتصال Toobit پایدار است", sub: "تأخیر ۴۲ میلی‌ثانیه", time: "۳ ساعت پیش", color: "var(--mint)" },
];

export function Topbar({
  active, theme, onToggleTheme, notify, botActive, onNavigate, onNewTrade, onExit,
}: {
  active: NavKey;
  theme: "dark" | "light";
  onToggleTheme: () => void;
  notify: (m: string) => void;
  botActive: boolean;
  onNavigate: (key: NavKey) => void;
  onNewTrade: () => void;
  onExit: () => void;
}) {
  const [searchOpen, setSearchOpen] = useState(false);
  const [notifOpen, setNotifOpen] = useState(false);
  const [notifTab, setNotifTab] = useState<"all" | "signal" | "system">("all");
  const [query, setQuery] = useState("");
  const [cursor, setCursor] = useState(0);
  const [read, setRead] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [latency, setLatency] = useState(42);
  const notifRef = useRef<HTMLDivElement>(null);
  const title = pageTitles[active];

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 10);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    const id = setInterval(() => setLatency(36 + Math.round(Math.random() * 18)), 3200);
    return () => clearInterval(id);
  }, []);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        setSearchOpen((v) => !v);
      }
      if (e.key === "Escape") {
        setSearchOpen(false);
        setNotifOpen(false);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  useEffect(() => {
    if (!notifOpen) return;
    const onDown = (e: MouseEvent) => {
      if (notifRef.current && !notifRef.current.contains(e.target as Node)) setNotifOpen(false);
    };
    document.addEventListener("mousedown", onDown);
    return () => document.removeEventListener("mousedown", onDown);
  }, [notifOpen]);

  useEffect(() => setCursor(0), [query]);

  const q = query.trim().toLowerCase();
  const pageResults = navItems.filter((n) => !q || n.label.includes(query.trim()) || n.key.includes(q));
  const marketResults = initialMarkets.filter((m) => !q || m.symbol.toLowerCase().includes(q) || m.name.includes(query.trim()));
  const flat: { label: string; run: () => void }[] = [
    ...pageResults.map((n) => ({ label: n.label, run: () => { onNavigate(n.key); setSearchOpen(false); setQuery(""); } })),
    ...marketResults.map((m) => ({ label: m.symbol, run: () => { notify(`قیمت ${m.symbol}: $${m.price.toLocaleString("en-US")}`); setSearchOpen(false); setQuery(""); } })),
  ];
  const notifList = notifications.filter((n) => notifTab === "all" || n.tab === notifTab);

  return (
    <>
      <header className={`sticky top-0 z-40 border-b backdrop-blur-2xl transition-all duration-300 ${scrolled ? "border-[var(--border-strong)] bg-[var(--bg)]/88 shadow-[0_10px_30px_rgba(0,0,0,.18)]" : "border-hairline bg-[var(--bg)]/70"}`}>
        <div className="mx-auto flex h-[66px] max-w-[1500px] items-center justify-between gap-3 px-4 sm:px-6 lg:px-8">
          <div className="flex min-w-0 items-center gap-3">
            <div className="lg:hidden"><Logo compact /></div>
            <div className="min-w-0">
              <p className="hidden text-[9px] font-bold t-faint sm:block">دلارینو / {title.title}</p>
              <h1 className="truncate text-[13px] font-extrabold sm:mt-0.5 sm:text-[15px]">{title.title}</h1>
              <p className="mt-0.5 hidden truncate text-[10.5px] t-muted sm:block">{title.subtitle}</p>
            </div>
          </div>

          <div className="flex items-center gap-1.5 sm:gap-2">
            <button onClick={() => setSearchOpen(true)} className="btn-ghost h-9 w-9 rounded-xl sm:w-[190px] sm:justify-start sm:px-3" aria-label="جستجو">
              <Search size={16} />
              <span className="hidden text-[11px] t-muted sm:inline">جستجوی سریع...</span>
              <kbd className="num mr-auto hidden rounded border border-hairline px-1.5 py-0.5 text-[9px] t-faint lg:inline" dir="ltr">⌘ K</kbd>
            </button>
            <button onClick={onNewTrade} className="btn-primary hidden h-9 rounded-xl px-3.5 text-[11px] font-bold xl:inline-flex"><Plus size={15} /> معامله جدید</button>

            <div className="relative" ref={notifRef}>
              <button onClick={() => setNotifOpen((v) => !v)} className="icon-btn relative h-9 w-9 rounded-xl" aria-label="اعلان‌ها">
                <Bell size={17} />
                {!read && <span className="absolute right-2 top-2 h-1.5 w-1.5 rounded-full bg-[var(--rose)] shadow-[0_0_8px_var(--rose)]" />}
              </button>
              {notifOpen && (
                <div className="animate-menu absolute left-0 top-11 z-50 w-[300px] rounded-2xl border border-[var(--border-strong)] bg-[var(--card-solid)] p-3 shadow-[var(--shadow)]">
                  <div className="mb-2 flex items-center justify-between px-1">
                    <span className="text-xs font-extrabold">اعلان‌ها</span>
                    <button onClick={() => { setRead(true); notify("همه اعلان‌ها خوانده شد"); }} className="flex items-center gap-1 text-[10px] font-bold t-accent"><CheckCheck size={13} /> خواندن همه</button>
                  </div>
                  <div className="seg mb-2">
                    {([["all", "همه"], ["signal", "سیگنال"], ["system", "سیستم"]] as const).map(([k, l]) => (
                      <button key={k} data-active={notifTab === k} onClick={() => setNotifTab(k)} className="flex-1">{l}</button>
                    ))}
                  </div>
                  <div className="max-h-[280px] overflow-y-auto scroll-thin">
                    {notifList.map((n) => (
                      <div key={n.id} className="flex gap-2.5 rounded-xl px-2 py-2.5 transition-colors hover:bg-[var(--glass)]">
                        <span className="mt-1.5 h-2 w-2 shrink-0 rounded-full" style={{ background: n.color, boxShadow: `0 0 8px ${n.color}` }} />
                        <div className="min-w-0">
                          <p className="text-[11px] font-bold">{n.title}</p>
                          <p className="mt-0.5 truncate text-[10px] t-faint">{n.sub}</p>
                          <p className="num mt-0.5 text-[9px] t-faint">{n.time}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            <button onClick={onToggleTheme} className="icon-btn h-9 w-9 overflow-hidden rounded-xl" aria-label="تغییر تم">
              <span key={theme} className="animate-menu block">{theme === "dark" ? <Sun size={17} /> : <Moon size={17} />}</span>
            </button>
            <button onClick={onExit} className="icon-btn hidden h-9 w-9 rounded-xl md:inline-flex" aria-label="بازگشت به سایت" title="بازگشت به سایت"><Globe size={17} /></button>
            <button onClick={() => onNavigate("settings")} className="relative mr-1 grid h-9 w-9 place-items-center rounded-xl bg-gradient-to-br from-[#6f8cff] to-[#3453d4] text-[11px] font-extrabold text-white shadow-[0_6px_18px_rgba(70,105,235,.35)] transition-transform hover:scale-105" aria-label="پروفایل">
              AK
              <span className={`absolute -bottom-0.5 -left-0.5 h-2.5 w-2.5 rounded-full border-2 border-[var(--bg)] ${botActive ? "bg-[var(--mint)]" : "bg-[var(--amber)]"}`} />
            </button>
          </div>
        </div>
        <div className="flex h-7 items-center gap-2 border-t border-hairline px-4 text-[10px] t-faint sm:px-6 lg:px-8">
          <LiveDot color={botActive ? "var(--mint)" : "var(--amber)"} />
          <span className="font-bold t-muted">{botActive ? "بازار زنده" : "ربات متوقف"}</span>
          <span className="hidden sm:inline">·</span>
          <span className="hidden sm:inline">اتصال به Paper Demo</span>
          <span className="num mr-auto flex items-center gap-1.5" dir="ltr">
            <span className="hidden items-center gap-1 sm:flex"><ShieldCheck size={12} /> AES-256</span>
            <span className="rounded-md border border-hairline px-1.5 py-0.5 font-bold t-muted">{latency}ms</span>
          </span>
        </div>
      </header>

      {searchOpen && (
        <div className="animate-fade fixed inset-0 z-[95] bg-[#03060e]/65 p-4 pt-[10vh] backdrop-blur-md" onClick={() => setSearchOpen(false)}>
          <div className="animate-modal mx-auto w-full max-w-lg overflow-hidden rounded-2xl border border-[var(--border-strong)] bg-[var(--card-solid)] shadow-[var(--shadow)]" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center gap-3 border-b border-hairline px-4">
              <Search size={18} className="t-muted" />
              <input
                autoFocus
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "ArrowDown") { e.preventDefault(); setCursor((c) => (c + 1) % Math.max(1, flat.length)); }
                  if (e.key === "ArrowUp") { e.preventDefault(); setCursor((c) => (c - 1 + flat.length) % Math.max(1, flat.length)); }
                  if (e.key === "Enter" && flat[cursor]) flat[cursor].run();
                }}
                placeholder="جستجوی صفحه یا ارز..."
                className="h-14 flex-1 bg-transparent text-[13px] outline-none placeholder:text-[var(--faint)]"
              />
              <button onClick={() => setSearchOpen(false)} className="icon-btn h-8 w-8 rounded-lg"><X size={16} /></button>
            </div>
            <div className="max-h-[320px] overflow-y-auto p-3 scroll-thin">
              {pageResults.length > 0 && <p className="px-2 pb-2 text-[10px] font-bold t-faint">صفحات</p>}
              {pageResults.map((n) => {
                const idx = flat.findIndex((f) => f.label === n.label);
                return (
                  <button key={n.key} onClick={() => { onNavigate(n.key); setSearchOpen(false); setQuery(""); }} onMouseEnter={() => setCursor(idx)} className={`flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-[12px] font-semibold ${cursor === idx ? "bg-[var(--glass)]" : ""}`}>
                    <n.icon size={16} className="t-accent" />{n.label}
                    <ChevronLeft size={14} className="mr-auto t-faint" />
                  </button>
                );
              })}
              {marketResults.length > 0 && <p className="px-2 pb-2 pt-3 text-[10px] font-bold t-faint">بازارها</p>}
              {marketResults.map((m) => {
                const idx = flat.findIndex((f) => f.label === m.symbol);
                return (
                  <button key={m.symbol} onClick={() => { notify(`قیمت ${m.symbol}: $${m.price.toLocaleString("en-US")}`); setSearchOpen(false); setQuery(""); }} onMouseEnter={() => setCursor(idx)} className={`num flex w-full items-center gap-3 rounded-xl px-3 py-2 text-[11px] ${cursor === idx ? "bg-[var(--glass)]" : ""}`} dir="ltr">
                    <span className="font-bold">{m.symbol}</span><span className="mr-auto t-muted">${m.price.toLocaleString("en-US")}</span>
                    <span style={{ color: m.change >= 0 ? "var(--mint)" : "var(--rose)" }}>{m.change > 0 ? "+" : ""}{m.change.toFixed(2)}%</span>
                  </button>
                );
              })}
              {flat.length === 0 && <p className="px-2 py-6 text-center text-[11px] t-muted">نتیجه‌ای پیدا نشد</p>}
            </div>
            <div className="num flex items-center gap-3 border-t border-hairline px-4 py-2.5 text-[9px] t-faint" dir="ltr">
              <span>↑↓ navigate</span><span>↵ select</span><span>esc close</span>
            </div>
          </div>
        </div>
      )}
    </>
  );
}

/* ================= Mobile dock (app) ================= */
export function MobileDock({
  active, onNavigate, theme, onToggleTheme, onNewTrade,
}: {
  active: NavKey;
  onNavigate: (key: NavKey) => void;
  theme: "dark" | "light";
  onToggleTheme: () => void;
  onNewTrade: () => void;
}) {
  const [moreOpen, setMoreOpen] = useState(false);
  const dockMain: NavKey[] = ["overview", "trades", "signals"];
  const moreItems = navItems.filter((n) => !dockMain.includes(n.key));
  const isMore = moreItems.some((n) => n.key === active);
  const item = (key: NavKey) => navItems.find((n) => n.key === key)!;

  return (
    <>
      {moreOpen && <div className="animate-fade fixed inset-0 z-[55] bg-[#03060e]/60 backdrop-blur-sm lg:hidden" onClick={() => setMoreOpen(false)} />}
      {moreOpen && (
        <div className="animate-enter fixed inset-x-3 bottom-[100px] z-[60] rounded-[24px] border border-[var(--border-strong)] bg-[var(--card-solid)] p-3 shadow-[var(--shadow)] lg:hidden">
          <div className="mx-auto mb-2 h-1 w-10 rounded-full bg-[var(--border-strong)]" />
          <p className="px-2 pb-2 text-[10px] font-bold t-faint">بیشتر</p>
          <div className="grid grid-cols-4 gap-2">
            {[{ key: "performance" }, { key: "engines" }, { key: "wallet" }, { key: "settings" }].map(({ key }) => {
              const n = item(key as NavKey);
              const Icon = n.icon;
              return (
                <button key={key} onClick={() => { onNavigate(n.key); setMoreOpen(false); }} className={`flex flex-col items-center gap-2 rounded-2xl border border-hairline py-3 text-[10px] font-bold ${active === n.key ? "bg-[rgba(91,124,255,.13)]" : ""}`}>
                  <Icon size={19} className="t-accent" />{n.label}
                </button>
              );
            })}
          </div>
          <button onClick={() => { onToggleTheme(); setMoreOpen(false); }} className="btn-ghost mt-2 h-10 w-full rounded-xl text-[11px]">
            {theme === "dark" ? <Sun size={15} /> : <Moon size={15} />} {theme === "dark" ? "حالت روشن" : "حالت تاریک"}
          </button>
        </div>
      )}
      <nav className="fixed inset-x-3 bottom-3 z-[60] lg:hidden" style={{ paddingBottom: "env(safe-area-inset-bottom)" }}>
        <div className="glass mx-auto grid max-w-md grid-cols-5 items-end rounded-[26px] px-2 pb-2 pt-2 shadow-[0_16px_45px_rgba(0,0,0,.35)]">
          {dockMain.slice(0, 2).map((key) => {
            const n = item(key);
            const Icon = n.icon;
            const isActive = active === key;
            return (
              <button key={key} onClick={() => onNavigate(key)} className={`flex flex-col items-center gap-1 rounded-2xl py-1.5 transition-colors ${isActive ? "text-[#9aadff]" : "t-faint"}`}>
                <span className={`grid h-8 w-full place-items-center rounded-xl transition-all ${isActive ? "bg-[rgba(91,124,255,.18)]" : ""}`}><Icon size={19} strokeWidth={isActive ? 2.2 : 1.8} /></span>
                <span className="text-[9px] font-bold">{n.label}</span>
              </button>
            );
          })}
          <div className="flex flex-col items-center">
            <button onClick={onNewTrade} aria-label="معامله جدید" className="btn-primary -mt-7 grid h-[54px] w-[54px] place-items-center rounded-[20px] active:scale-90">
              <Plus size={24} strokeWidth={2.5} />
            </button>
            <span className="mt-1 text-[9px] font-bold t-muted">معامله</span>
          </div>
          {(() => {
            const n = item("signals");
            const Icon = n.icon;
            const isActive = active === "signals";
            return (
              <button onClick={() => onNavigate("signals")} className={`flex flex-col items-center gap-1 rounded-2xl py-1.5 ${isActive ? "text-[#9aadff]" : "t-faint"}`}>
                <span className={`grid h-8 w-full place-items-center rounded-xl ${isActive ? "bg-[rgba(91,124,255,.18)]" : ""}`}><Icon size={19} strokeWidth={isActive ? 2.2 : 1.8} /></span>
                <span className="text-[9px] font-bold">سیگنال‌ها</span>
              </button>
            );
          })()}
          <button onClick={() => setMoreOpen((v) => !v)} className={`flex flex-col items-center gap-1 rounded-2xl py-1.5 ${isMore || moreOpen ? "text-[#9aadff]" : "t-faint"}`}>
            <span className={`grid h-8 w-full place-items-center rounded-xl ${moreOpen ? "bg-[rgba(91,124,255,.18)]" : ""}`}><MoreHorizontal size={20} /></span>
            <span className="text-[9px] font-bold">بیشتر</span>
          </button>
        </div>
      </nav>
    </>
  );
}

/* ================= Mobile dock (landing) ================= */
export function SiteDock({ onEnter }: { onEnter: () => void }) {
  return (
    <nav className="fixed inset-x-3 bottom-3 z-[60] lg:hidden" style={{ paddingBottom: "env(safe-area-inset-bottom)" }}>
      <div className="glass mx-auto flex max-w-md items-center justify-around rounded-[26px] px-2 py-2 shadow-[0_16px_45px_rgba(0,0,0,.35)]">
        <a href="#top" className="flex flex-col items-center gap-1 rounded-2xl py-1.5 text-[9px] font-bold t-faint"><LayoutDashboard size={19} /><span>خانه</span></a>
        <a href="#demo" className="flex flex-col items-center gap-1 rounded-2xl py-1.5 text-[9px] font-bold t-faint"><BarChart3 size={19} /><span>دمو</span></a>
        <div className="flex flex-col items-center">
          <button onClick={onEnter} aria-label="ورود به ترمینال" className="btn-primary -mt-7 grid h-[54px] w-[54px] place-items-center rounded-[20px] active:scale-90">
            <ArrowUpLeft size={24} strokeWidth={2.5} />
          </button>
          <span className="mt-1 text-[9px] font-bold t-muted">ترمینال</span>
        </div>
        <a href="#engines" className="flex flex-col items-center gap-1 rounded-2xl py-1.5 text-[9px] font-bold t-faint"><Zap size={19} /><span>موتورها</span></a>
        <a href="#pricing" className="flex flex-col items-center gap-1 rounded-2xl py-1.5 text-[9px] font-bold t-faint"><Wallet size={19} /><span>تعرفه</span></a>
      </div>
    </nav>
  );
}
