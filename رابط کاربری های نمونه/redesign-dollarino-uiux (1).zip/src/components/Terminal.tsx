import { ArrowUpLeft, Eye, EyeOff, Plus, Radio } from "lucide-react";
import { chartLabels, chartSeries, engineById, engines, fmt, money, pct, priceText } from "../data";
import type { AppState } from "../state";
import { AreaChart, Sparkline } from "./Charts";
import { AnimatedNumber, CoinIcon, LiveDot, Reveal, SectionHead, SectionHeading, SegControl, Switch } from "./UI";
import { LinkButton, MarketList, PositionsTable } from "./Widgets";

export function Terminal({ s }: { s: AppState }) {
  const openPnl = s.positions.reduce((a, p) => a + p.pnl, 0);
  const chartColor = s.theme === "dark" ? "#C9F24E" : "#4a7000";
  const engine = engineById(s.activeEngine);

  return (
    <section id="terminal" className="relative mx-auto max-w-6xl px-4 py-16 sm:px-6 sm:py-24">
      <SectionHeading
        eyebrow="ترمینال زنده"
        title={<>این دموی واقعی است، <span className="marker">نه اسکرین‌شات</span></>}
        desc="همین حالا با قیمت زنده بازار کار می‌کند. موتور را عوض کن، معامله باز کن، ربات را خاموش و روشن کن."
      />

      <Reveal>
        <div className="surface card overflow-hidden">
          {/* terminal toolbar */}
          <div className="flex flex-wrap items-center gap-3 border-b border-hairline bg-[var(--glass)] px-4 py-3 sm:px-5">
            <span className="flex items-center gap-1.5">
              <span className="h-2.5 w-2.5 rounded-full bg-[#ff5f57]" />
              <span className="h-2.5 w-2.5 rounded-full bg-[#febc2e]" />
              <span className="h-2.5 w-2.5 rounded-full bg-[#28c840]" />
            </span>
            <span className="num hidden rounded-lg border border-hairline px-2 py-1 text-[10px] font-bold t-muted sm:block" dir="ltr">dollarino.app/terminal</span>
            <span className="mr-auto flex items-center gap-1.5 rounded-lg bg-[rgba(61,220,151,.1)] px-2 py-1 text-[9.5px] font-extrabold t-mint">
              <LiveDot /> {s.botActive ? "ربات روشن" : "ربات خاموش"}
            </span>
          </div>

          <div className="space-y-4 p-4 sm:p-5">
            {/* controls */}
            <div className="flex flex-wrap items-center gap-2.5">
              <SegControl
                options={[
                  { value: "ai" as const, label: "دُرّبین" },
                  { value: "strategy" as const, label: "دُرنا" },
                  { value: "copy" as const, label: "کپی‌ترید" },
                ]}
                value={s.activeEngine}
                onChange={s.onSelectEngine}
              />
              <div className="mr-auto flex items-center gap-2.5">
                <Switch checked={s.botActive} onChange={s.onToggleBot} label="اجرای خودکار" />
                <button onClick={s.onNewTrade} className="btn-lime h-9 rounded-xl px-3.5 text-[11px]"><Plus size={15} strokeWidth={2.6} /> معامله</button>
              </div>
            </div>

            <div className="grid gap-4 xl:grid-cols-12">
              {/* balance */}
              <div className="lime-card card p-5 sm:p-6 xl:col-span-4">
                <div className="relative flex items-start justify-between">
                  <div>
                    <p className="text-[10.5px] font-bold opacity-60">موجودی کل · Paper Demo</p>
                    <div className="num mt-2 text-[30px] font-bold leading-none sm:text-[34px]" dir="ltr">
                      {s.balanceHidden ? "•• ••••" : <AnimatedNumber value={s.balance} format={(n) => money(n)} />}
                    </div>
                    <p className="num mt-2.5 flex items-center gap-1.5 text-[11px] font-bold" dir="ltr">
                      <span className="rounded-lg bg-black/10 px-1.5 py-0.5">{openPnl >= 0 ? "+" : "−"}${fmt(Math.abs(openPnl))}</span>
                      <span className="opacity-60">سود شناور</span>
                    </p>
                  </div>
                  <button onClick={s.onToggleHidden} className="grid h-8 w-8 place-items-center rounded-xl bg-black/10 transition hover:bg-black/20" aria-label="مخفی کردن موجودی">
                    {s.balanceHidden ? <EyeOff size={15} /> : <Eye size={15} />}
                  </button>
                </div>
                <div className="relative mt-4 h-[74px]">
                  <Sparkline values={chartSeries["30D"]} color="#141a05" height={74} fill animated={false} />
                </div>
                <div className="relative mt-4 flex gap-2">
                  <button onClick={s.onNewTrade} className="btn-ink h-10 flex-1 rounded-xl text-[11px]"><Plus size={15} /> معامله جدید</button>
                  <button onClick={() => document.getElementById("performance")?.scrollIntoView({ behavior: "smooth" })} className="h-10 rounded-xl bg-black/10 px-4 text-[11px] font-extrabold transition hover:bg-black/20">
                    <span className="flex items-center gap-1">عملکرد <ArrowUpLeft size={14} /></span>
                  </button>
                </div>
              </div>

              {/* chart */}
              <div className="rounded-[22px] border border-hairline bg-[var(--glass)] p-4 sm:p-5 xl:col-span-8">
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div>
                    <p className="text-[10.5px] t-muted">رشد سرمایه · موتور {engine.label}</p>
                    <div className="num mt-1 text-[22px] font-bold" dir="ltr"><AnimatedNumber value={s.balance} format={(n) => money(n)} /></div>
                  </div>
                  <SegControl
                    options={[{ value: "7D", label: "7D" }, { value: "30D", label: "30D" }, { value: "90D", label: "90D" }]}
                    value={s.timeframe}
                    onChange={s.setTimeframe}
                  />
                </div>
                <div className="mt-3"><AreaChart key={s.timeframe} values={chartSeries[s.timeframe]} labels={chartLabels[s.timeframe]} height={230} color={chartColor} /></div>
              </div>
            </div>

            <div className="grid gap-4 xl:grid-cols-12">
              <div className="rounded-[22px] border border-hairline bg-[var(--glass)] p-4 sm:p-5 xl:col-span-8">
                <SectionHead title={`معاملات باز (${s.positions.length})`} subtitle="قیمت‌ها لحظه‌ای به‌روز می‌شوند" />
                <PositionsTable positions={s.positions.slice(0, 4)} onClose={s.onClosePosition} />
              </div>
              <div className="space-y-4 xl:col-span-4">
                <div className="rounded-[22px] border border-hairline bg-[var(--glass)] p-4">
                  <SectionHead title="موتور فعال" />
                  <div className="space-y-2">
                    {engines.map((e) => (
                      <button key={e.id} onClick={() => s.onSelectEngine(e.id)} className="press flex w-full items-center gap-2.5 rounded-2xl border p-2.5 text-right transition-all" style={{ borderColor: s.activeEngine === e.id ? "var(--lime)" : "var(--border)", background: s.activeEngine === e.id ? "rgba(201,242,78,.08)" : "transparent" }}>
                        <CoinIcon symbol={e.latin.slice(0, 3)} color={e.color} size={30} />
                        <span className="min-w-0 flex-1"><span className="block truncate text-[11px] font-extrabold">{e.name}</span><span className="num block text-[9px] t-faint" dir="ltr">{e.winRate}% win</span></span>
                        {s.activeEngine === e.id && <LiveDot color="var(--lime)" />}
                      </button>
                    ))}
                  </div>
                </div>
                <div className="rounded-[22px] border border-hairline bg-[var(--glass)] p-4">
                  <SectionHead title="بازار لحظه‌ای" action={<LinkButton onClick={() => s.notify("فهرست کامل بازار به‌زودی")}>همه</LinkButton>} />
                  <MarketList markets={s.markets} limit={4} onSelect={(m) => s.notify(`${m.symbol}: $${priceText(m.price)} · ${pct(m.change)}`)} />
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2 rounded-2xl border border-dashed border-hairline px-4 py-3 text-[10.5px] t-muted">
              <Radio size={15} className="shrink-0 t-lime" />
              این یک دموی تعاملی است — همه دکمه‌ها واقعی کار می‌کنند. برای شروع واقعی، حساب دمو بساز.
            </div>
          </div>
        </div>
      </Reveal>
    </section>
  );
}
