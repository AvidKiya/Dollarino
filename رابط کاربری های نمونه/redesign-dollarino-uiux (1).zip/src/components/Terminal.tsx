import { ArrowUpLeft, Eye, EyeOff, Plus, Radio } from "lucide-react";
import { chartLabels, chartSeries, engineById, engines, fmt, money, pct, priceText } from "../data";
import type { AppState } from "../state";
import { AreaChart, Sparkline } from "./Charts";
import { AnimatedNumber, CoinIcon, LiveDot, Reveal, SectionHeading, SegControl, Switch } from "./UI";
import { LinkButton, MarketList, PositionsTable } from "./Widgets";

export function Terminal({ s, onEnter }: { s: AppState; onEnter: () => void }) {
  const openPnl = s.positions.reduce((a, p) => a + p.pnl, 0);
  const chartColor = s.theme === "dark" ? "#7c92ff" : "#3a62e8";
  const engine = engineById(s.activeEngine);

  return (
    <section id="demo" className="relative mx-auto max-w-6xl px-4 py-16 sm:px-6 sm:py-24">
      <SectionHeading
        eyebrow="دموی زنده"
        title={<>این دموی واقعی است، <span className="marker">نه اسکرین‌شات</span></>}
        desc="همین حالا با قیمت زنده بازار کار می‌کند. موتور را عوض کن، معامله باز کن، ربات را خاموش و روشن کن — بعد برو تو ترمینال کامل."
      />

      <Reveal>
        <div className="surface card overflow-hidden">
          <div className="flex flex-wrap items-center gap-3 border-b border-hairline bg-[var(--glass)] px-4 py-3 sm:px-5">
            <span className="flex items-center gap-1.5">
              <span className="h-2.5 w-2.5 rounded-full bg-[#ff5f57]" />
              <span className="h-2.5 w-2.5 rounded-full bg-[#febc2e]" />
              <span className="h-2.5 w-2.5 rounded-full bg-[#28c840]" />
            </span>
            <span className="num hidden rounded-lg border border-hairline px-2 py-1 text-[10px] font-bold t-muted sm:block" dir="ltr">dollarino.app/terminal</span>
            <span className="mr-auto flex items-center gap-1.5 rounded-lg bg-[rgba(55,214,165,.1)] px-2 py-1 text-[9.5px] font-extrabold t-mint">
              <LiveDot /> {s.botActive ? "ربات روشن" : "ربات خاموش"}
            </span>
          </div>

          <div className="space-y-4 p-4 sm:p-5">
            <div className="flex flex-wrap items-center gap-2.5">
              <SegControl
                options={[
                  { value: "ai" as const, label: "دُرّبین" },
                  { value: "strategy" as const, label: "دُرنا" },
                  { value: "copy" as const, label: "کپی‌ترید" },
                ]}
                value={s.activeEngine}
                onChange={s.onSelectEngine}
              />
              <div className="mr-auto flex items-center gap-2.5">
                <Switch checked={s.botActive} onChange={s.onToggleBot} label="اجرای خودکار" />
                <button onClick={s.onNewTrade} className="btn-primary h-9 rounded-xl px-3.5 text-[11px]"><Plus size={15} strokeWidth={2.6} /> معامله</button>
              </div>
            </div>

            <div className="grid gap-4 xl:grid-cols-12">
              <div className="coin-card-wallet card relative p-5 text-white sm:p-6 xl:col-span-4">
                <div className="coin-card-shine" />
                <div className="relative flex items-start justify-between">
                  <div>
                    <p className="text-[10.5px] font-bold text-white/70">موجودی کل · Paper Demo</p>
                    <div className="num mt-2 text-[30px] font-extrabold leading-none sm:text-[34px]" dir="ltr">
                      {s.balanceHidden ? "•• ••••" : <AnimatedNumber value={s.balance} format={(n) => money(n)} />}
                    </div>
                    <p className="num mt-2.5 flex items-center gap-1.5 text-[11px] font-bold" dir="ltr">
                      <span className="rounded-lg bg-white/15 px-1.5 py-0.5">{openPnl >= 0 ? "+" : "−"}${fmt(Math.abs(openPnl))}</span>
                      <span className="text-white/70">سود شناور</span>
                    </p>
                  </div>
                  <button onClick={s.onToggleHidden} className="grid h-8 w-8 place-items-center rounded-xl bg-white/10 transition hover:bg-white/20" aria-label="مخفی کردن موجودی">
                    {s.balanceHidden ? <EyeOff size={15} /> : <Eye size={15} />}
                  </button>
                </div>
                <div className="relative mt-4 h-[74px]">
                  <Sparkline values={chartSeries["30D"]} color="#ffffff" height={74} fill animated={false} />
                </div>
                <div className="relative mt-4 flex gap-2">
                  <button onClick={s.onNewTrade} className="btn-ghost h-10 flex-1 rounded-xl border-white/20 bg-white/15 text-[11px] font-bold text-white hover:bg-white/25"><span className="flex items-center justify-center gap-1"><Plus size={15} /> معامله جدید</span></button>
                  <button onClick={onEnter} className="flex h-10 items-center rounded-xl bg-white px-4 text-[11px] font-extrabold transition hover:bg-white/90" style={{ color: "#2b4cd8" }}>
                    <span className="flex items-center gap-1">ترمینال کامل <ArrowUpLeft size={14} /></span>
                  </button>
                </div>
              </div>

              <div className="rounded-[22px] border border-hairline bg-[var(--glass)] p-4 sm:p-5 xl:col-span-8">
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div>
                    <p className="text-[10.5px] t-muted">رشد سرمایه · موتور {engine.label}</p>
                    <div className="num mt-1 text-[22px] font-extrabold" dir="ltr"><AnimatedNumber value={s.balance} format={(n) => money(n)} /></div>
                  </div>
                  <SegControl
                    options={[{ value: "7D", label: "7D" }, { value: "30D", label: "30D" }, { value: "90D", label: "90D" }]}
                    value={s.timeframe}
                    onChange={s.setTimeframe}
                  />
                </div>
                <div className="mt-3"><AreaChart key={s.timeframe} values={chartSeries[s.timeframe]} labels={chartLabels[s.timeframe]} height={230} color={chartColor} /></div>
              </div>
            </div>

            <div className="grid gap-4 xl:grid-cols-12">
              <div className="rounded-[22px] border border-hairline bg-[var(--glass)] p-4 sm:p-5 xl:col-span-8">
                <div className="mb-4 flex items-center justify-between gap-3">
                  <div>
                    <h2 className="text-[15px] font-extrabold">معاملات باز ({s.positions.length})</h2>
                    <p className="mt-1 text-[11px] t-muted">قیمت‌ها لحظه‌ای به‌روز می‌شوند</p>
                  </div>
                  <LinkButton onClick={onEnter}>همه در ترمینال</LinkButton>
                </div>
                <PositionsTable positions={s.positions.slice(0, 4)} onClose={s.onClosePosition} />
              </div>
              <div className="space-y-4 xl:col-span-4">
                <div className="rounded-[22px] border border-hairline bg-[var(--glass)] p-4">
                  <div className="mb-4"><h2 className="text-[15px] font-extrabold">موتور فعال</h2></div>
                  <div className="space-y-2">
                    {engines.map((e) => (
                      <button key={e.id} onClick={() => s.onSelectEngine(e.id)} className="press flex w-full items-center gap-2.5 rounded-2xl border p-2.5 text-right transition-all" style={{ borderColor: s.activeEngine === e.id ? "rgba(124,146,255,.6)" : "var(--border)", background: s.activeEngine === e.id ? "rgba(91,124,255,.09)" : "transparent" }}>
                        <CoinIcon symbol={e.latin.slice(0, 3)} color={e.color} size={30} />
                        <span className="min-w-0 flex-1"><span className="block truncate text-[11px] font-extrabold">{e.name}</span><span className="num block text-[9px] t-faint" dir="ltr">{e.winRate}% win</span></span>
                        {s.activeEngine === e.id && <LiveDot />}
                      </button>
                    ))}
                  </div>
                </div>
                <div className="rounded-[22px] border border-hairline bg-[var(--glass)] p-4">
                  <div className="mb-4 flex items-center justify-between">
                    <h2 className="text-[15px] font-extrabold">بازار لحظه‌ای</h2>
                    <LinkButton onClick={() => s.notify("فهرست کامل بازار در ترمینال")}>همه</LinkButton>
                  </div>
                  <MarketList markets={s.markets} limit={4} onSelect={(m) => s.notify(`${m.symbol}: $${priceText(m.price)} · ${pct(m.change)}`)} />
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2 rounded-2xl border border-dashed border-hairline px-4 py-3 text-[10.5px] t-muted">
              <Radio size={15} className="shrink-0 t-accent" />
              این یک دموی تعاملی است — همه دکمه‌ها واقعی کار می‌کنند. برای شروع واقعی، وارد ترمینال شو.
            </div>
          </div>
        </div>
      </Reveal>
    </section>
  );
}
