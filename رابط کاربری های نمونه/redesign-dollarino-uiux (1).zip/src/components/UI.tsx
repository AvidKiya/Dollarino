import { useEffect, useRef, useState, type ReactNode } from "react";
import { ArrowDownLeft, ArrowUpRight, Check, X } from "lucide-react";
import type { Side } from "../data";

/* ---------------- Reveal on scroll ---------------- */
export function Reveal({ children, delay = 0, className = "" }: { children: ReactNode; delay?: number; className?: string }) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver(
      ([e]) => {
        if (e.isIntersecting) {
          el.classList.add("in");
          io.disconnect();
        }
      },
      { threshold: 0.1 }
    );
    io.observe(el);
    return () => io.disconnect();
  }, []);
  return (
    <div ref={ref} className={`reveal ${className}`} style={{ ["--d" as string]: `${delay}ms` }}>
      {children}
    </div>
  );
}

/* ---------------- Brand ---------------- */
export function Logo({ compact = false }: { compact?: boolean }) {
  return (
    <div className="group flex items-center gap-2.5">
      <div className="relative grid h-10 w-10 shrink-0 place-items-center overflow-hidden rounded-[14px] bg-[var(--lime)] shadow-[0_8px_24px_rgba(201,242,78,.35)] transition-transform duration-300 group-hover:scale-105 group-hover:-rotate-6">
        <svg viewBox="0 0 32 32" className="h-7 w-7" aria-hidden="true">
          <path d="M8 7h7.2c6.4 0 10.4 3.8 10.4 9s-4 9-10.4 9H8V7Z" fill="none" stroke="#141a05" strokeWidth="3.6" strokeLinejoin="round" />
          <path d="M14.1 12.6v6.8c2.5 0 4-1.3 4-3.4s-1.5-3.4-4-3.4Z" fill="#141a05" />
        </svg>
        <span className="pointer-events-none absolute inset-0 -translate-x-full bg-gradient-to-l from-transparent via-white/50 to-transparent transition-transform duration-700 group-hover:translate-x-full" />
      </div>
      {!compact && (
        <div className="leading-tight">
          <div className="num text-[16px] font-bold tracking-tight" dir="ltr">Dollarino<span className="t-lime">.</span></div>
          <div className="text-[10px] font-medium t-muted">ترید خودکار، به زبان ساده</div>
        </div>
      )}
    </div>
  );
}

export function CoinIcon({ symbol, color, size = 36 }: { symbol: string; color: string; size?: number }) {
  return (
    <div
      className="num grid shrink-0 place-items-center rounded-full text-[10px] font-bold"
      style={{
        width: size,
        height: size,
        background: `linear-gradient(140deg, ${color}30, ${color}0d)`,
        color,
        border: `1px solid ${color}45`,
        boxShadow: `inset 0 1px 0 rgba(255,255,255,.18), 0 4px 12px ${color}22`,
      }}
      dir="ltr"
    >
      {symbol.slice(0, 3)}
    </div>
  );
}

/* ---------------- Animated number ---------------- */
export function AnimatedNumber({
  value,
  format = (n: number) => n.toLocaleString("en-US"),
  duration = 700,
  className = "",
}: {
  value: number;
  format?: (n: number) => string;
  duration?: number;
  className?: string;
}) {
  const [display, setDisplay] = useState(value);
  const prev = useRef(value);
  useEffect(() => {
    const from = prev.current;
    if (from === value) return;
    let raf = 0;
    const start = performance.now();
    const tick = (t: number) => {
      const p = Math.min(1, (t - start) / duration);
      const eased = 1 - Math.pow(1 - p, 3);
      setDisplay(from + (value - from) * eased);
      if (p < 1) raf = requestAnimationFrame(tick);
      else prev.current = value;
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [value, duration]);
  useEffect(() => { prev.current = display; });
  return <span className={`num ${className}`} dir="ltr">{format(display)}</span>;
}

/* ---------------- Flash text ---------------- */
export function FlashText({
  value,
  format,
  className = "",
  positive,
}: {
  value: number;
  format: (n: number) => string;
  className?: string;
  positive?: boolean;
}) {
  const [flash, setFlash] = useState<"up" | "down" | null>(null);
  const prev = useRef(value);
  useEffect(() => {
    if (prev.current === value) return;
    setFlash(value > prev.current ? "up" : "down");
    prev.current = value;
    const t = setTimeout(() => setFlash(null), 1000);
    return () => clearTimeout(t);
  }, [value]);
  const color = positive !== undefined ? (positive ? "var(--mint)" : "var(--rose)") : undefined;
  return (
    <span className={`num ${flash === "up" ? "flash-up" : flash === "down" ? "flash-down" : ""} ${className}`} style={{ color }} dir="ltr">
      {format(value)}
    </span>
  );
}

/* ---------------- Switch ---------------- */
export function Switch({ checked, onChange, label }: { checked: boolean; onChange: (v: boolean) => void; label: string }) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      aria-label={label}
      onClick={() => onChange(!checked)}
      className="switch-track relative h-[28px] w-[50px] shrink-0 rounded-full border"
      style={{
        background: checked ? "var(--lime)" : "var(--border-strong)",
        borderColor: checked ? "var(--lime)" : "var(--border)",
        boxShadow: checked ? "0 4px 14px rgba(201,242,78,.4)" : undefined,
      }}
    >
      <span
        className="switch-thumb absolute top-[3px] right-[3px] grid h-[20px] w-[20px] place-items-center rounded-full bg-white shadow-[0_2px_6px_rgba(0,0,0,.3)]"
        style={{ transform: checked ? "translateX(-22px)" : "translateX(0)", background: checked ? "var(--on-lime)" : "#fff" }}
      >
        {checked && <Check size={11} strokeWidth={3.5} style={{ color: "var(--lime)" }} />}
      </span>
    </button>
  );
}

/* ---------------- Section head ---------------- */
export function SectionHead({ title, subtitle, action, eyebrow }: { title: string; subtitle?: string; action?: ReactNode; eyebrow?: string }) {
  return (
    <div className="mb-4 flex items-center justify-between gap-3">
      <div>
        {eyebrow && <span className="eyebrow mb-1.5">{eyebrow}</span>}
        <h2 className="text-[15px] font-black tracking-tight">{title}</h2>
        {subtitle && <p className="mt-1 text-[11px] t-muted">{subtitle}</p>}
      </div>
      {action}
    </div>
  );
}

/* ---------------- Big section heading (landing) ---------------- */
export function SectionHeading({ eyebrow, title, desc, center = true }: { eyebrow: string; title: ReactNode; desc?: string; center?: boolean }) {
  return (
    <Reveal className={`mb-10 max-w-2xl sm:mb-14 ${center ? "mx-auto text-center" : ""}`}>
      <span className={`eyebrow ${center ? "justify-center" : ""}`}>{eyebrow}</span>
      <h2 className="h-display mt-3 text-[26px] sm:text-[38px]">{title}</h2>
      {desc && <p className="lead mt-3 text-[13px] sm:text-[14px]">{desc}</p>}
    </Reveal>
  );
}

/* ---------------- Segmented control ---------------- */
export function SegControl<T extends string>({
  options,
  value,
  onChange,
}: {
  options: { value: T; label: string }[];
  value: T;
  onChange: (v: T) => void;
}) {
  return (
    <div className="seg" role="tablist">
      {options.map((o) => (
        <button key={o.value} role="tab" aria-selected={value === o.value} data-active={value === o.value} onClick={() => onChange(o.value)}>
          {o.label}
        </button>
      ))}
    </div>
  );
}

/* ---------------- Slider row ---------------- */
export function SliderRow({
  label,
  display,
  min,
  max,
  value,
  onChange,
}: {
  label: string;
  display: string;
  min: number;
  max: number;
  value: number;
  onChange: (v: number) => void;
}) {
  const fill = ((value - min) / (max - min)) * 100;
  return (
    <label className="block rounded-2xl border border-hairline bg-[var(--glass)] p-4">
      <span className="flex items-center justify-between text-[11px] font-bold">
        <span>{label}</span>
        <span className="num rounded-lg bg-[rgba(201,242,78,.16)] px-2 py-0.5 t-accent" dir="ltr">{display}</span>
      </span>
      <input
        type="range"
        min={min}
        max={max}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        className="slider mt-4 w-full"
        style={{ ["--fill" as string]: `${fill}%` }}
      />
      <span className="num mt-2 flex justify-between text-[9px] t-faint" dir="ltr"><span>{min}</span><span>{max}</span></span>
    </label>
  );
}

/* ---------------- Badges ---------------- */
export function DirectionBadge({ side, leverage }: { side: Side; leverage?: number }) {
  const long = side === "long";
  return (
    <span
      className="num inline-flex items-center gap-1 rounded-lg border px-2 py-1 text-[10px] font-bold tracking-wide"
      style={{
        color: long ? "var(--mint)" : "var(--rose)",
        background: long ? "rgba(61,220,151,.10)" : "rgba(255,107,126,.10)",
        borderColor: long ? "rgba(61,220,151,.28)" : "rgba(255,107,126,.28)",
      }}
      dir="ltr"
    >
      {long ? <ArrowUpRight size={12} strokeWidth={2.5} /> : <ArrowDownLeft size={12} strokeWidth={2.5} />}
      {long ? "LONG" : "SHORT"}{leverage ? ` ${leverage}x` : ""}
    </span>
  );
}

export function LiveDot({ color = "var(--mint)" }: { color?: string }) {
  return (
    <span className="relative inline-flex h-[7px] w-[7px]">
      <span className="live-ping absolute inset-0 rounded-full" style={{ background: color }} />
      <span className="pulse-dot relative inline-block h-[7px] w-[7px] rounded-full" style={{ background: color }} />
    </span>
  );
}

export function EngineChip({ label, color }: { label: string; color: string }) {
  return (
    <span className="inline-flex items-center gap-1.5 rounded-lg px-2 py-1 text-[9.5px] font-bold" style={{ background: `${color}14`, color }}>
      <span className="h-1.5 w-1.5 rounded-full" style={{ background: color }} />
      {label}
    </span>
  );
}

/* ---------------- Empty state ---------------- */
export function EmptyState({ icon, title, desc }: { icon: ReactNode; title: string; desc: string }) {
  return (
    <div className="grid place-items-center gap-2 rounded-2xl border border-dashed border-hairline px-6 py-10 text-center">
      <span className="grid h-12 w-12 place-items-center rounded-2xl bg-[var(--glass)] t-faint">{icon}</span>
      <p className="mt-1 text-[12px] font-bold">{title}</p>
      <p className="max-w-[240px] text-[10.5px] leading-6 t-muted">{desc}</p>
    </div>
  );
}

/* ---------------- Modal ---------------- */
export function Modal({ open, onClose, title, subtitle, children }: { open: boolean; onClose: () => void; title: string; subtitle?: string; children: ReactNode }) {
  useEffect(() => {
    if (!open) return;
    const handler = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", handler);
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", handler);
      document.body.style.overflow = "";
    };
  }, [open, onClose]);
  if (!open) return null;
  return (
    <div className="animate-fade fixed inset-0 z-[90] flex items-end justify-center bg-black/70 backdrop-blur-md sm:items-center sm:p-4" onClick={onClose}>
      <div
        className="animate-modal max-h-[92dvh] w-full max-w-md overflow-y-auto rounded-t-[28px] border border-[var(--border-strong)] bg-[var(--card-solid)] p-5 shadow-[var(--shadow)] scroll-thin sm:rounded-[26px] sm:p-6"
        onClick={(e) => e.stopPropagation()}
        role="dialog"
        aria-modal="true"
      >
        <div className="mx-auto mb-4 h-1 w-10 rounded-full bg-[var(--border-strong)] sm:hidden" />
        <div className="mb-5 flex items-start justify-between gap-3">
          <div>
            <h3 className="text-[15px] font-black">{title}</h3>
            {subtitle && <p className="mt-1 text-[10.5px] t-muted">{subtitle}</p>}
          </div>
          <button onClick={onClose} className="icon-btn h-9 w-9 shrink-0 rounded-xl" aria-label="بستن"><X size={18} /></button>
        </div>
        {children}
      </div>
    </div>
  );
}

/* ---------------- Toast ---------------- */
export function Toast({ message }: { message: string | null }) {
  if (!message) return null;
  return (
    <div className="animate-toast fixed top-4 left-1/2 z-[120] w-[calc(100%-2rem)] max-w-md -translate-x-1/2 overflow-hidden rounded-2xl border border-[var(--border-strong)] bg-[var(--card-solid)] px-4 py-3 shadow-[var(--shadow)]">
      <div className="flex items-center gap-2.5 text-[12px] font-bold">
        <span className="grid h-6 w-6 shrink-0 place-items-center rounded-full bg-[var(--lime)]" style={{ color: "var(--on-lime)" }}><Check size={14} strokeWidth={3} /></span>
        <span className="leading-6">{message}</span>
      </div>
      <span className="absolute bottom-0 right-0 h-[2px] w-full origin-right bg-[var(--lime)]" style={{ animation: "toastBar 3.2s linear both" }} />
    </div>
  );
}
