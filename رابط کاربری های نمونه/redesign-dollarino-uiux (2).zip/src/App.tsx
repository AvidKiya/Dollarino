import Header from "./components/Header";
import Rail from "./components/Rail";
import Hero from "./components/Hero";
import Features from "./components/Features";
import Manifesto from "./components/Manifesto";
import Engines from "./components/Engines";
import Showcase from "./components/Showcase";
import WeeklyCard from "./components/WeeklyCard";
import Tools from "./components/Tools";
import Closing from "./components/Closing";

export default function App() {
  return (
    <div dir="rtl" className="relative min-h-screen overflow-x-clip bg-paper">
      <a
        href="#home"
        className="sr-only focus:not-sr-only focus:fixed focus:right-4 focus:top-4 focus:z-[60] focus:rounded-full focus:bg-ink focus:px-4 focus:py-2 focus:text-sm focus:text-white"
      >
        رفتن به محتوای اصلی
      </a>
      <Header />
      <Rail />
      {/* paper grain — gives the page a printed, tactile surface */}
      <div className="grain pointer-events-none fixed inset-0 z-[9999]" aria-hidden="true" />
      <main>
        <Hero />
        <Features />
        <Manifesto />
        <Engines />
        <Showcase />
        <WeeklyCard />
        <Tools />
        <Closing />
      </main>
    </div>
  );
}
