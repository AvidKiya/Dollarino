import { useEffect, useState } from "react";
import { ArrowLeft, ArrowUpLeft, Menu, X } from "lucide-react";
import { cn } from "../utils/cn";
import { CTA, Logo, LogoMark } from "./ui";

const links = [
  { label: "امکانات", href: "#features" },
  { label: "موتورها", href: "#engines" },
  { label: "شروع سریع", href: "#how" },
  { label: "پنل حرفه‌ای", href: "#panel" },
  { label: "کارت هفتگی", href: "#weekly" },
  { label: "سوالات", href: "#faq" },
];

export default function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const [showDock, setShowDock] = useState(false);
  const [activeSection, setActiveSection] = useState("#home");

  useEffect(() => {
    const onScroll = () => {
      setScrolled(window.scrollY > 12);
      setShowDock(window.scrollY > 620);
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    const sections = links
      .map((link) => document.querySelector<HTMLElement>(link.href))
      .filter((section): section is HTMLElement => Boolean(section));
    if (!sections.length) return;
    const observer = new IntersectionObserver(
      (entries) => {
        const visible = entries
          .filter((entry) => entry.isIntersecting)
          .sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
        if (visible) setActiveSection(`#${visible.target.id}`);
      },
      { rootMargin: "-25% 0px -55% 0px", threshold: [0.05, 0.25, 0.6] }
    );
    sections.forEach((section) => observer.observe(section));
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") setOpen(false);
    };
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = "";
      window.removeEventListener("keydown", onKey);
    };
  }, [open]);

  return (
    <>
      <header className="fixed inset-x-0 top-0 z-50">
        <div className="container-x pt-3 sm:pt-4">
          <div
            className={cn(
              "flex items-center justify-between gap-4 rounded-[20px] border px-3 py-2.5 transition-all duration-500 sm:rounded-full sm:px-4",
              scrolled
                ? "border-line bg-white/90 shadow-soft backdrop-blur-xl"
                : "border-white/70 bg-white/60 backdrop-blur-md"
            )}
          >
            <a href="#home" className="shrink-0" aria-label="دلارینو، خانه">
              <Logo />
            </a>

            <nav className="hidden items-center gap-0.5 lg:flex" aria-label="ناوبری اصلی">
              {links.map((link) => (
                <a
                  key={link.href}
                  href={link.href}
                  className={cn(
                    "group relative rounded-full px-3.5 py-2 text-[12.5px] font-medium transition-colors hover:bg-paper hover:text-ink xl:text-[13px]",
                    activeSection === link.href ? "bg-paper text-ink" : "text-ink/65"
                  )}
                  aria-current={activeSection === link.href ? "true" : undefined}
                >
                  {link.label}
                  <span
                    className={cn(
                      "absolute inset-x-3.5 -bottom-0.5 h-px bg-brand/50 transition-transform duration-300 group-hover:scale-x-100",
                      activeSection === link.href ? "scale-x-100" : "scale-x-0"
                    )}
                  />
                </a>
              ))}
            </nav>

            <div className="flex items-center gap-2">
              <a
                href="#start"
                className="hidden items-center gap-1.5 rounded-full px-3 py-2 text-[13px] font-semibold text-ink/70 transition-colors hover:text-ink sm:inline-flex"
              >
                ورود
                <ArrowUpLeft size={14} className="opacity-60" />
              </a>
              <CTA
                href="#start"
                arrow={false}
                className="!gap-1.5 !px-4 !py-2.5 !text-[12px] sm:!px-5 sm:!text-[13px]"
                icon={<span className="relative flex size-1.5 rounded-full bg-lime" />}
              >
                شروع رایگان
              </CTA>
              <button
                type="button"
                onClick={() => setOpen((value) => !value)}
                className="grid size-10 place-items-center rounded-full border border-line bg-white text-ink transition-colors hover:bg-paper lg:hidden"
                aria-label={open ? "بستن منو" : "باز کردن منو"}
                aria-expanded={open}
              >
                {open ? <X size={18} /> : <Menu size={19} />}
              </button>
            </div>
          </div>

          {/* Mobile menu */}
          <div
            onClick={() => setOpen(false)}
            aria-hidden="true"
            className={cn(
              "fixed inset-0 -z-10 bg-ink/25 backdrop-blur-[2px] transition-opacity duration-300 lg:hidden",
              open ? "opacity-100" : "pointer-events-none opacity-0"
            )}
          />
          <div
            className={cn(
              "overflow-hidden transition-all duration-500 lg:hidden",
              open ? "mt-2 max-h-[560px] opacity-100" : "max-h-0 opacity-0"
            )}
          >
            <div className="rounded-[26px] border border-line bg-white/95 p-3 shadow-lift backdrop-blur-xl">
              <nav className="flex flex-col" aria-label="ناوبری موبایل">
                {links.map((link, index) => (
                  <a
                    key={link.href}
                    href={link.href}
                    onClick={() => setOpen(false)}
                    className="flex items-center justify-between border-b border-line/70 px-3 py-3.5 text-[14px] font-semibold text-ink/80 last:border-0 hover:text-brand"
                  >
                    <span>{link.label}</span>
                    <span className="font-latin text-[10px] text-muted/50">0{index + 1}</span>
                  </a>
                ))}
              </nav>
              <div className="mt-3 grid grid-cols-2 gap-2 px-1 pb-1">
                <a
                  href="#start"
                  onClick={() => setOpen(false)}
                  className="flex items-center justify-center gap-2 rounded-full border border-line bg-white px-4 py-3 text-[13px] font-bold text-ink"
                >
                  ورود به حساب
                </a>
                <a
                  href="#start"
                  onClick={() => setOpen(false)}
                  className="flex items-center justify-center gap-2 rounded-full bg-ink px-4 py-3 text-[13px] font-bold text-white"
                >
                  دموی رایگان
                  <ArrowLeft size={15} />
                </a>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Floating mobile CTA */}
      <div
        className={cn(
          "fixed inset-x-3 bottom-3 z-40 transition-all duration-500 sm:hidden",
          showDock && !open ? "translate-y-0 opacity-100" : "pointer-events-none translate-y-24 opacity-0"
        )}
      >
        <div className="flex items-center justify-between gap-3 rounded-full border border-line/80 bg-white/95 p-1.5 pr-3 shadow-lift backdrop-blur-xl">
          <div className="flex items-center gap-2.5">
            <LogoMark className="size-8 rounded-xl" />
            <div className="leading-tight">
              <p className="text-[11.5px] font-bold text-ink">دموی رایگان، بدون ریسک</p>
              <p className="mt-0.5 text-[9.5px] text-muted">در ۲ دقیقه شروع کنید</p>
            </div>
          </div>
          <a
            href="#start"
            className="flex items-center gap-1.5 rounded-full bg-ink px-4 py-2.5 text-[11.5px] font-bold text-white"
          >
            شروع
            <ArrowLeft size={14} />
          </a>
        </div>
      </div>
    </>
  );
}
