import { useEffect, useRef, useState } from "react";
import {
  ArrowDownToLine,
  Check,
  Copy,
  Hash,
  Share2,
  Sparkles,
  Target,
  Trophy,
  Wallet,
} from "lucide-react";
import { cn } from "../utils/cn";
import { LiveDot, LogoMark, Reveal, SectionHeading } from "./ui";

/* -------------------------------------------------------------------------- */
/*                                   Data                                     */
/* -------------------------------------------------------------------------- */

type EngineKey = "ai" | "strategy" | "copy";
type PeriodKey = "week" | "month";

const engines: { id: EngineKey; label: string; name: string }[] = [
  { id: "ai", label: "هوش مصنوعی", name: "دُربین" },
  { id: "strategy", label: "استراتژی منتخب", name: "دُرنا" },
  { id: "copy", label: "کپی‌ترید", name: "لحظه‌ای" },
];

const data: Record<EngineKey, Record<PeriodKey, {
  change: string;
  profit: string;
  trades: string;
  win: string;
  best: string;
  bars: number[];
  caption: string;
}>> = {
  ai: {
    week: {
      change: "+12.8",
      profit: "+1,286.40",
      trades: "9",
      win: "78%",
      best: "+4.2%",
      bars: [34, 52, 44, 66, 58, 78, 92],
      caption: "۷ ترید موفق از ۹ معامله",
    },
    month: {
      change: "+22.9",
      profit: "+2,914.70",
      trades: "38",
      win: "74%",
      best: "+7.8%",
      bars: [28, 44, 38, 58, 52, 72, 66, 84, 78, 96],
      caption: "۲۸ ترید موفق از ۳۸ معامله",
    },
  },
  strategy: {
    week: {
      change: "+8.4",
      profit: "+842.10",
      trades: "14",
      win: "71%",
      best: "+3.1%",
      bars: [40, 34, 52, 46, 62, 55, 74],
      caption: "۱۰ ترید موفق از ۱۴ معامله",
    },
    month: {
      change: "+17.6",
      profit: "+1,764.20",
      trades: "52",
      win: "69%",
      best: "+5.4%",
      bars: [32, 46, 40, 55, 48, 68, 60, 76, 70, 88],
      caption: "۳۶ ترید موفق از ۵۲ معامله",
    },
  },
  copy: {
    week: {
      change: "+16.2",
      profit: "+2,140.00",
      trades: "6",
      win: "83%",
      best: "+5.6%",
      bars: [26, 48, 42, 68, 60, 82, 96],
      caption: "۵ ترید موفق از ۶ معامله",
    },
    month: {
      change: "+27.4",
      profit: "+5,480.00",
      trades: "24",
      win: "79%",
      best: "+9.2%",
      bars: [22, 40, 34, 56, 48, 70, 62, 82, 74, 94],
      caption: "۱۹ ترید موفق از ۲۴ معامله",
    },
  },
};

const periodLabel: Record<PeriodKey, string> = {
  week: "این هفته",
  month: "این ماه",
};

const monthName = "۱۸ خرداد ۱۴۰۵";

/* -------------------------------------------------------------------------- */
/*                            Canvas PNG export                               */
/* -------------------------------------------------------------------------- */

function roundRect(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}

function drawCard(
  engine: EngineKey,
  period: PeriodKey,
  canvas: HTMLCanvasElement
) {
  const W = 1080;
  const H = 1350;
  const dpr = 2;
  canvas.width = W * dpr;
  canvas.height = H * dpr;
  const ctx = canvas.getContext("2d");
  if (!ctx) return;
  ctx.scale(dpr, dpr);
  ctx.direction = "rtl";
  const entry = data[engine][period];

  // background
  const bg = ctx.createLinearGradient(W, 0, 0, H);
  bg.addColorStop(0, "#16231e");
  bg.addColorStop(0.55, "#0f1a16");
  bg.addColorStop(1, "#0b1310");
  ctx.fillStyle = bg;
  ctx.fillRect(0, 0, W, H);

  // cobalt glow
  const glow = ctx.createRadialGradient(W * 0.15, H * 0.12, 20, W * 0.15, H * 0.12, 620);
  glow.addColorStop(0, "rgba(43,75,242,0.55)");
  glow.addColorStop(1, "rgba(43,75,242,0)");
  ctx.fillStyle = glow;
  ctx.fillRect(0, 0, W, H);

  const limeGlow = ctx.createRadialGradient(W * 0.92, H * 0.95, 20, W * 0.92, H * 0.95, 520);
  limeGlow.addColorStop(0, "rgba(221,245,111,0.18)");
  limeGlow.addColorStop(1, "rgba(221,245,111,0)");
  ctx.fillStyle = limeGlow;
  ctx.fillRect(0, 0, W, H);

  // watermark mark — echoes the Dollarino logo
  ctx.save();
  ctx.globalAlpha = 0.06;
  ctx.strokeStyle = "#ffffff";
  ctx.lineWidth = 30;
  ctx.beginPath();
  ctx.arc(170, H - 150, 210, 0, Math.PI * 2);
  ctx.stroke();
  ctx.restore();

  const pad = 84;
  const right = W - pad;

  // header
  ctx.fillStyle = "#FFB224";
  roundRect(ctx, right - 64, pad, 64, 64, 20);
  ctx.fill();
  ctx.fillStyle = "#0e1714";
  ctx.font = "800 34px 'Manrope Variable', sans-serif";
  ctx.direction = "ltr";
  ctx.textAlign = "center";
  ctx.fillText("$", right - 32, pad + 43);

  ctx.direction = "rtl";
  ctx.textAlign = "start";
  ctx.fillStyle = "#ffffff";
  ctx.font = "800 34px 'Vazirmatn Variable', sans-serif";
  ctx.fillText("دلارینو", right - 84, pad + 32);

  ctx.direction = "ltr";
  ctx.textAlign = "start";
  ctx.fillStyle = "rgba(255,255,255,0.45)";
  ctx.font = "700 16px 'Manrope Variable', sans-serif";
  ctx.fillText("DOLLARINO", pad, pad + 26);

  ctx.direction = "rtl";
  ctx.textAlign = "end";
  ctx.fillStyle = "rgba(255,255,255,0.35)";
  ctx.font = "600 20px 'Vazirmatn Variable', sans-serif";
  ctx.fillText(monthName, pad, pad + 58);

  // title
  ctx.textAlign = "start";
  ctx.fillStyle = "rgba(255,255,255,0.5)";
  ctx.font = "600 28px 'Vazirmatn Variable', sans-serif";
  ctx.fillText(
    `عملکرد ${periodLabel[period]} · موتور ${engines.find((e) => e.id === engine)?.name}`,
    right,
    300
  );

  // big number — kept LTR so "+22.9%" reads correctly
  ctx.direction = "ltr";
  ctx.textAlign = "end";
  ctx.font = "800 84px 'Manrope Variable', sans-serif";
  ctx.fillStyle = "#FFB224";
  ctx.fillText("%", right, 500);
  const pctWidth = ctx.measureText("%").width;
  ctx.font = "800 190px 'Manrope Variable', sans-serif";
  ctx.fillStyle = "#ffffff";
  ctx.fillText(entry.change, right - pctWidth - 18, 500);

  ctx.direction = "rtl";
  ctx.textAlign = "start";
  ctx.fillStyle = "rgba(255,255,255,0.55)";
  ctx.font = "600 30px 'Vazirmatn Variable', sans-serif";
  ctx.fillText(entry.caption, right, 566);

  // bars
  const bars = entry.bars;
  const barAreaW = W - pad * 2;
  const gap = 18;
  const barW = (barAreaW - gap * (bars.length - 1)) / bars.length;
  const baseY = 860;
  bars.forEach((value, index) => {
    const h = (value / 100) * 240;
    const x = pad + index * (barW + gap);
    const y = baseY - h;
    ctx.fillStyle = index === bars.length - 1 ? "#FFB224" : "rgba(255,255,255,0.16)";
    roundRect(ctx, x, y, barW, h, 10);
    ctx.fill();
  });

  // divider
  ctx.fillStyle = "rgba(255,255,255,0.12)";
  ctx.fillRect(pad, 930, W - pad * 2, 2);

  // stats
  const stats: [string, string][] = [
    ["سود خالص", entry.profit],
    ["تعداد معاملات", entry.trades],
    ["نرخ موفقیت", entry.win],
    ["بهترین معامله", entry.best],
  ];
  const colW = (W - pad * 2) / 4;
  stats.forEach(([label, value], index) => {
    const x = W - pad - index * colW - 24;
    ctx.direction = "rtl";
    ctx.textAlign = "start";
    ctx.fillStyle = "rgba(255,255,255,0.45)";
    ctx.font = "600 24px 'Vazirmatn Variable', sans-serif";
    ctx.fillText(label, x, 1010);
    ctx.direction = "ltr";
    ctx.textAlign = "end";
    ctx.fillStyle = index === 0 ? "#FFB224" : "#ffffff";
    ctx.font = "800 36px 'Manrope Variable', sans-serif";
    ctx.fillText(value, x, 1064);
  });

  // footer chip
  ctx.fillStyle = "rgba(255,255,255,0.08)";
  roundRect(ctx, pad, H - 190, W - pad * 2, 96, 40);
  ctx.fill();
  ctx.direction = "rtl";
  ctx.textAlign = "start";
  ctx.fillStyle = "#ffffff";
  ctx.font = "700 26px 'Vazirmatn Variable', sans-serif";
  ctx.fillText("ساخته‌شده با دلارینو · حساب دمو", W - pad - 36, H - 132);
  ctx.direction = "ltr";
  ctx.textAlign = "start";
  ctx.fillStyle = "rgba(255,255,255,0.45)";
  ctx.font = "600 22px 'Manrope Variable', sans-serif";
  ctx.fillText("@Dollarinoofficial", pad + 36, H - 134);
  ctx.direction = "rtl";
}

/* -------------------------------------------------------------------------- */
/*                                   Section                                  */
/* -------------------------------------------------------------------------- */

export default function WeeklyCard() {
  const [engine, setEngine] = useState<EngineKey>("ai");
  const [period, setPeriod] = useState<PeriodKey>("week");
  const [toast, setToast] = useState<string | null>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const entry = data[engine][period];

  useEffect(() => {
    if (!toast) return;
    const timer = window.setTimeout(() => setToast(null), 2600);
    return () => window.clearTimeout(timer);
  }, [toast]);

  const download = async () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    try {
      await (document as Document & { fonts?: FontFaceSet }).fonts?.ready;
      drawCard(engine, period, canvas);
      const url = canvas.toDataURL("image/png");
      const link = document.createElement("a");
      link.href = url;
      link.download = `dollarino-${engine}-${period}.png`;
      document.body.appendChild(link);
      link.click();
      link.remove();
      setToast("تصویر کارت آماده شد و دانلود شد.");
    } catch {
      setToast("دانلود انجام نشد؛ لطفاً دوباره تلاش کنید.");
    }
  };

  const copySummary = async () => {
    const engineName = engines.find((item) => item.id === engine)?.name;
    const text = `عملکرد ${periodLabel[period]} دلارینو · موتور ${engineName}\nسود ${entry.change}٪ · نرخ موفقیت ${entry.win} · ${entry.trades} معامله\n@Dollarinoofficial`;
    try {
      await navigator.clipboard.writeText(text);
      setToast("متن خلاصه در کلیپ‌بورد کپی شد.");
    } catch {
      setToast("کپی انجام نشد؛ دوباره تلاش کنید.");
    }
  };

  return (
    <section id="weekly" className="relative overflow-hidden border-y border-line bg-white py-16 sm:py-20 lg:py-28">
      <div className="pointer-events-none absolute inset-0 -z-10">
        <div className="absolute -left-20 top-10 size-96 rounded-full bg-brand/[0.07] blur-[110px]" />
        <div className="dot-grid absolute right-8 top-16 hidden h-40 w-52 opacity-30 lg:block" />
      </div>

      <div className="container-x grid items-center gap-10 lg:grid-cols-[0.95fr_1.05fr] lg:gap-16">
        {/* ------------------------------- text ------------------------------- */}
        <div>
          <SectionHeading
            eyebrow="کارت هفتگی دلارینو"
            title={
              <>
                نتیجه‌ی هفته، در یک کارت
                <br className="hidden sm:block" /> قابل اشتراک.
              </>
            }
            desc="کارت ۴:۵ آماده برای استوری و کانال؛ با لوگوی بزرگ دلارینو در پس‌زمینه و خروجی PNG باکیفیت. کافی است موتور و بازه را انتخاب کنید."
          />

          <Reveal delay={120}>
            <div className="mt-7 space-y-3">
              <div>
                <p className="text-[9.5px] font-bold uppercase tracking-[0.14em] text-muted/70">موتور</p>
                <div className="mt-2 flex flex-wrap gap-1.5">
                  {engines.map((item) => (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => setEngine(item.id)}
                      aria-pressed={engine === item.id}
                      className={cn(
                        "flex items-center gap-1.5 rounded-full border px-3.5 py-2 text-[10.5px] font-bold transition-all duration-300",
                        engine === item.id
                          ? "border-ink bg-ink text-white shadow-sm"
                          : "border-line bg-white text-muted hover:border-ink/25 hover:text-ink"
                      )}
                    >
                      {item.id === "ai" && <Sparkles size={11} />}
                      {item.label}
                      <span className={cn("font-latin text-[8.5px]", engine === item.id ? "text-lime" : "text-muted/50")}>
                        {item.name}
                      </span>
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <p className="text-[9.5px] font-bold uppercase tracking-[0.14em] text-muted/70">بازه زمانی</p>
                <div className="mt-2 inline-flex rounded-full border border-line bg-paper p-1">
                  {(Object.keys(periodLabel) as PeriodKey[]).map((key) => (
                    <button
                      key={key}
                      type="button"
                      onClick={() => setPeriod(key)}
                      aria-pressed={period === key}
                      className={cn(
                        "rounded-full px-5 py-2 text-[10.5px] font-bold transition-all duration-300",
                        period === key ? "bg-white text-ink shadow-sm" : "text-muted hover:text-ink"
                      )}
                    >
                      {periodLabel[key]}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </Reveal>

          <Reveal delay={170}>
            <div className="mt-6 grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={download}
                className="group flex items-center justify-center gap-2 rounded-full bg-ink px-4 py-3.5 text-[11.5px] font-extrabold text-white transition-colors hover:bg-brand"
              >
                <ArrowDownToLine size={14} className="transition-transform group-hover:translate-y-0.5" />
                دانلود تصویر PNG
              </button>
              <button
                type="button"
                onClick={copySummary}
                className="flex items-center justify-center gap-2 rounded-full border border-line bg-white px-4 py-3.5 text-[11.5px] font-extrabold text-ink transition-colors hover:border-ink/25"
              >
                <Copy size={13} />
                کپی خلاصه
              </button>
            </div>
          </Reveal>

          <Reveal delay={210}>
            <div className="mt-3 flex items-start gap-2 rounded-2xl border border-dashed border-line bg-paper/60 px-3.5 py-3">
              <Share2 size={13} className="mt-0.5 shrink-0 text-brand" />
              <p className="text-[9.5px] leading-[1.9] text-muted">
                تصویر خروجی ۱۰۸۰×۱۳۵۰ پیکسل است؛ یعنی دقیقاً همان اندازه‌ی استوری اینستاگرام و پست
                تلگرام. بدون واترمارک اضافه.
              </p>
            </div>
          </Reveal>
        </div>

        {/* ------------------------------- card ------------------------------- */}
        <Reveal delay={100}>
          <div className="relative mx-auto w-full max-w-[430px] lg:mr-0">
            <div className="pointer-events-none absolute inset-8 -z-10 rounded-[44px] bg-brand/20 blur-[60px]" />

            <div
              className="relative overflow-hidden rounded-[30px] shadow-lift ring-1 ring-white/10"
              style={{
                aspectRatio: "4 / 5",
                fontSize: "clamp(30px, 7.6vw, 42px)",
                background: "linear-gradient(145deg, #16231e 0%, #0f1a16 55%, #0b1310 100%)",
              }}
            >
              {/* glows */}
              <div className="pointer-events-none absolute -left-10 -top-12 size-56 rounded-full bg-brand/40 blur-[60px]" />
              <div className="pointer-events-none absolute -bottom-16 -right-10 size-52 rounded-full bg-lime/10 blur-[60px]" />
              <LogoMark className="pointer-events-none absolute -bottom-[0.35em] -left-[0.45em] size-[2.6em] rounded-[0.7em] opacity-[0.08]" />

              <div className="relative flex h-full flex-col p-[0.62em] text-white">
                {/* header */}
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-[0.18em]">
                    <LogoMark className="size-[0.62em] rounded-[0.19em]" />
                    <div>
                      <p className="text-[0.27em] font-extrabold leading-none">دلارینو</p>
                      <p className="font-latin mt-[0.09em] text-[0.105em] font-bold tracking-[0.18em] text-white/45">
                        DOLLARINO
                      </p>
                    </div>
                  </div>
                  <div className="text-left">
                    <p className="text-[0.175em] font-semibold text-white/55">{periodLabel[period]}</p>
                    <p className="mt-[0.08em] text-[0.16em] text-white/35">{monthName}</p>
                  </div>
                </div>

                {/* headline number */}
                <div className="mt-[0.42em]">
                  <p className="text-[0.19em] font-semibold text-white/50">
                    عملکرد موتور {engines.find((item) => item.id === engine)?.name}
                  </p>
                  <div className="mt-[0.12em] flex items-end gap-[0.12em]">
                    <p
                      dir="ltr"
                      className="font-latin text-[1.02em] font-extrabold leading-[0.92] tracking-tight"
                    >
                      {entry.change}
                      <span className="text-[0.42em] text-lime">%</span>
                    </p>
                    <p className="mb-[0.14em] text-[0.19em] font-semibold text-white/55">سود خالص</p>
                  </div>
                  <p className="mt-[0.12em] text-[0.185em] text-white/50">{entry.caption}</p>
                </div>

                {/* bars */}
                <div className="mt-[0.34em] flex flex-1 items-end gap-[0.075em] pb-[0.12em]" dir="ltr">
                  {entry.bars.map((value, index) => (
                    <span
                      key={index}
                      className={cn(
                        "flex-1 rounded-[0.05em] transition-all duration-500",
                        index === entry.bars.length - 1 ? "bg-lime" : "bg-white/15"
                      )}
                      style={{ height: `${value}%` }}
                    />
                  ))}
                </div>

                {/* stats */}
                <div className="grid grid-cols-2 gap-x-[0.3em] border-t border-white/10 pt-[0.24em]">
                  {(
                    [
                      { icon: Wallet, label: "سود خالص", value: entry.profit, tone: "text-lime" },
                      { icon: Hash, label: "تعداد معاملات", value: entry.trades, tone: "text-white" },
                      { icon: Target, label: "نرخ موفقیت", value: entry.win, tone: "text-white" },
                      { icon: Trophy, label: "بهترین معامله", value: entry.best, tone: "text-white" },
                    ] as const
                  ).map((stat) => (
                    <div key={stat.label} className="flex items-center gap-[0.12em] py-[0.11em]">
                      <stat.icon size={13} className="shrink-0 text-white/35" />
                      <div className="min-w-0">
                        <p className="text-[0.145em] text-white/45">{stat.label}</p>
                        <p className={cn("font-latin truncate text-[0.21em] font-extrabold", stat.tone)} dir="ltr">
                          {stat.value}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>

                {/* footer */}
                <div className="mt-[0.16em] flex items-center justify-between rounded-[0.22em] border border-white/10 bg-white/[0.05] px-[0.24em] py-[0.16em]">
                  <div className="flex items-center gap-[0.12em]">
                    <span className="grid size-[0.28em] place-items-center rounded-full bg-lime/20">
                      <span className="size-[0.09em] rounded-full bg-lime" />
                    </span>
                    <p className="text-[0.15em] font-semibold text-white/60">ساخته‌شده با دلارینو · حساب دمو</p>
                  </div>
                  <p className="font-latin text-[0.135em] font-bold text-white/35">@Dollarinoofficial</p>
                </div>
              </div>
            </div>

            {/* badge */}
            <div className="absolute -top-3 left-4 flex items-center gap-1.5 rounded-full border border-line bg-white px-3 py-1.5 shadow-soft">
              <LiveDot />
              <span className="text-[9px] font-bold text-ink/70">خروجی ۱۰۸۰×۱۳۵۰</span>
            </div>

            <div className="mt-3 flex items-center justify-between rounded-2xl border border-line bg-white px-3.5 py-2.5">
              <span className="flex items-center gap-1.5 text-[9.5px] font-semibold text-muted">
                <Check size={11} className="text-up" />
                انتخاب‌های شما بلافاصله در کارت اعمال می‌شود
              </span>
              <span className="font-latin text-[8.5px] font-bold text-muted/60">PNG · 2x</span>
            </div>
          </div>
        </Reveal>
      </div>

      {/* hidden export canvas */}
      <canvas ref={canvasRef} className="hidden" aria-hidden="true" />

      {/* toast */}
      <div
        className={cn(
          "fixed inset-x-0 bottom-20 z-50 mx-auto flex w-fit max-w-[90vw] items-center gap-2 rounded-full bg-ink px-4 py-2.5 text-[10.5px] font-bold text-white shadow-lift transition-all duration-400",
          toast ? "translate-y-0 opacity-100" : "pointer-events-none translate-y-4 opacity-0"
        )}
        role="status"
        aria-live="polite"
      >
        <Check size={13} className="text-lime" />
        {toast}
      </div>
    </section>
  );
}
