import { useRef, useState } from "react";
import {
  Activity, ArrowUpRight, BarChart3, BrainCircuit, Cpu, Eye, EyeOff, Gauge, Layers3,
  Nfc, Plus, Radio, Settings2, ShieldCheck, Sparkles, Target, TrendingUp, Wallet, X,
} from "lucide-react";
import {
  aiBrief, chartLabels, chartSeries, engineById, engines, fmt, greetingByHour, money,
  pct, priceText, todayLabel, type EngineId,
} from "../data";
import type { AppState } from "../state";
import { AreaChart, ProgressRing, Sparkline } from "./Charts";
import { AnimatedNumber, DirectionBadge, EngineChip, LiveDot, SectionHead, SegControl, SliderRow, Switch } from "./UI";
import { LinkButton, MarketList, PositionsTable, StatCard } from "./Widgets";
import { WeeklyCard } from "./WeeklyCard";

const engineIcons: Record<EngineId, typeof Sparkles> = { ai: Sparkles, strategy: Cpu, copy: Radio };

/* ================= Live ticker ================= */
function Ticker({ s }: { s: AppState }) {
  const items = [...s.markets, ...s.markets];
  return (
    <div className="surface flex items-center gap-3 overflow-hidden rounded-2xl px-3 py-2.5">
      <div className="flex shrink-0 items-center gap-2 border-l border-hairline pl-3">
        <LiveDot />
        <span className="text-[10px] font-bold t-muted">بازار زنده</span>
      </div>
      <div className="relative flex-1 overflow-hidden [mask-image:linear-gradient(to_right,transparent,black_8%,black_92%,transparent)]">
        <div className="ticker-track flex w-max items-center gap-7" dir="ltr">
          {items.map((m, i) => (
            <button key={`${m.symbol}-${i}`} onClick={() => s.notify(`${m.symbol}: $${priceText(m.price)} · ${pct(m.change)}`)} className="num flex items-center gap-1.5 whitespace-nowrap text-[10.5px] transition-opacity hover:opacity-70" aria-hidden={i >= s.markets.length}>
              <span className="font-bold">{m.symbol}</span>
              <span className="t-muted">${priceText(m.price)}</span>
              <span style={{ color: m.change >= 0 ? "var(--mint)" : "var(--rose)" }}>{pct(m.change)}</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ================= 3D tilt wallet card ================= */
function WalletCard({ s }: { s: AppState }) {
  const [mode, setMode] = useState<"demo" | "live">("demo");
  const ref = useRef<HTMLDivElement>(null);

  const onMove = (e: React.PointerEvent) => {
    const el = ref.current;
    if (!el || window.matchMedia("(pointer: coarse)").matches) return;
    const r = el.getBoundingClientRect();
    const rx = ((e.clientY - r.top) / r.height - 0.5) * -7;
    const ry = ((e.clientX - r.left) / r.width - 0.5) * 9;
    el.style.transform = `perspective(900px) rotateX(${rx}deg) rotateY(${ry}deg)`;
    el.style.setProperty("--mx", `${((e.clientX - r.left) / r.width) * 100}%`);
    el.style.setProperty("--my", `${((e.clientY - r.top) / r.height) * 100}%`);
  };
  const onLeave = () => {
    const el = ref.current;
    if (el) el.style.transform = "perspective(900px) rotateX(0deg) rotateY(0deg)";
  };

  return (
    <div
      ref={ref}
      onPointerMove={onMove}
      onPointerLeave={onLeave}
      className="coin-card-wallet relative flex h-full min-h-[264px] flex-col rounded-[26px] p-5 text-white transition-transform duration-200 ease-out sm:p-6"
    >
      <div className="coin-card-shine" />
      <div className="relative flex items-start justify-between gap-3">
        <div>
          <div className="flex items-center gap-2 text-[11px] font-medium text-white/70">
            موجودی کل
            <button onClick={s.onToggleHidden} className="grid h-6 w-6 place-items-center rounded-lg bg-white/10 text-white/80 transition hover:bg-white/20" aria-label="نمایش یا مخفی کردن موجودی">
              {s.balanceHidden ? <EyeOff size={13} /> : <Eye size={13} />}
            </button>
          </div>
          <div className="num mt-3 text-[34px] font-extrabold leading-none tracking-tight sm:text-[42px]" dir="ltr">
            {s.balanceHidden ? "•• •••• ••" : <AnimatedNumber value={s.balance} format={(n) => money(n)} />}
          </div>
          <div className="mt-3 flex flex-wrap items-center gap-2">
            <span className="num flex items-center gap-1 rounded-lg border border-white/20 bg-white/15 px-2 py-1 text-[10.5px] font-bold" dir="ltr"><ArrowUpRight size={12} /> +12.4%</span>
            <span className="num text-[10.5px] text-white/70" dir="ltr">+$2,741.28 این ماه</span>
          </div>
        </div>
        <div className="flex flex-col items-end gap-2">
          <div className="seg seg-on-dark">
            {(["demo", "live"] as const).map((m) => (
              <button
                key={m}
                data-active={mode === m}
                onClick={() => {
                  if (m === "live") s.notify("برای حساب واقعی، صرافی خود را در تنظیمات متصل کنید");
                  setMode(m);
                }}
                className="num seg-mini"
                style={{ color: mode === m ? "#fff" : "rgba(255,255,255,.65)" }}
                dir="ltr"
              >
                {m === "demo" ? "DEMO" : "LIVE"}
              </button>
            ))}
          </div>
          <span className="num flex items-center gap-1 text-[9px] text-white/60"><ShieldCheck size={11} /> AES-256 SECURE</span>
        </div>
      </div>

      <div className="relative mt-5 flex items-center gap-3">
        <span className="grid h-9 w-12 place-items-center rounded-lg border border-white/25 bg-white/10"><Nfc size={17} className="text-white/80" /></span>
        <span className="num text-[13px] font-bold tracking-[.22em] text-white/85" dir="ltr">5892 •••• •••• 4021</span>
        <span className="num mr-auto text-[9px] font-bold text-white/50" dir="ltr">DOLLARINO PAY</span>
      </div>

      <div className="pointer-events-none absolute bottom-0 left-0 h-24 w-2/3 opacity-40">
        <Sparkline values={chartSeries["30D"]} color="#ffffff" height={96} fill animated={false} />
      </div>

      <div className="relative mt-auto flex flex-wrap items-center gap-2 pt-6">
        <button onClick={() => s.notify("درگاه واریز در حساب دمو غیرفعال است")} className="h-9 rounded-xl border border-white/20 bg-white/15 px-3.5 text-[11px] font-bold text-white backdrop-blur-md transition hover:bg-white/25"><span className="flex items-center gap-1.5"><Plus size={14} /> افزایش موجودی</span></button>
        <button onClick={() => s.onNavigate("wallet")} className="h-9 rounded-xl border border-white/20 bg-white/10 px-3.5 text-[11px] font-bold text-white backdrop-blur-md transition hover:bg-white/20"><span className="flex items-center gap-1.5"><Wallet size={14} /> کیف پول</span></button>
        <span className="num mr-auto hidden text-[10px] text-white/60 sm:block" dir="ltr">USD · Available {s.balanceHidden ? "••••" : `$${fmt(s.balance)}`}</span>
      </div>
    </div>
  );
}

/* ================= Engine control ================= */
function EngineControl({ s }: { s: AppState }) {
  const engine = engineById(s.activeEngine);
  const Icon = engineIcons[s.activeEngine];
  const openPnl = s.positions.reduce((sum, p) => sum + p.pnl, 0);
  return (
    <div className="surface flex h-full flex-col rounded-[26px] p-5">
      <div className="flex items-start justify-between gap-2">
        <div>
          <div className="flex flex-wrap items-center gap-2">
            <h2 className="text-[14px] font-extrabold">موتور فعال</h2>
            <span className="flex items-center gap-1.5 rounded-lg border border-[rgba(55,214,165,.25)] bg-[rgba(55,214,165,.09)] px-2 py-1 text-[9px] font-bold t-mint">
              <LiveDot color={s.botActive ? "var(--mint)" : "var(--amber)"} /> {s.botActive ? "در حال اجرا" : "متوقف"}
            </span>
          </div>
          <p className="mt-1 text-[10.5px] t-muted">کنترل لحظه‌ای ربات معامله‌گر</p>
        </div>
        <ProgressRing value={98} size={64} stroke={6} color="#37d6a5">
          <span className="num text-[12px] font-extrabold" dir="ltr">98%</span>
          <span className="text-[7px] t-faint">سلامت</span>
        </ProgressRing>
      </div>

      <button onClick={() => s.onNavigate("engines")} className="mt-4 flex w-full items-center gap-3 rounded-2xl border border-hairline bg-[var(--glass)] p-3 text-right transition-all hover:border-[var(--border-strong)]">
        <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl transition-transform hover:scale-105" style={{ background: `${engine.color}1f`, color: engine.color, border: `1px solid ${engine.color}33` }}><Icon size={19} /></span>
        <span className="min-w-0 flex-1"><span className="block truncate text-[12px] font-bold">{engine.name}</span><span className="num mt-0.5 block text-[9px] t-faint" dir="ltr">{engine.latin} · v6.0</span></span>
        <Settings2 size={15} className="t-faint" />
      </button>

      <div className="mt-3 grid grid-cols-3 gap-2 text-center">
        {[
          { l: "پوزیشن باز", v: `${s.positions.length}` },
          { l: "اهرم", v: `${s.leverage}x` },
          { l: "سود شناور", v: openPnl },
        ].map((x) => (
          <div key={x.l} className="rounded-xl border border-hairline bg-[var(--glass)] py-2.5">
            <div className="num text-[13px] font-extrabold" dir="ltr">{typeof x.v === "number" ? <AnimatedNumber value={x.v} format={(n) => `$${fmt(n, 0)}`} /> : x.v}</div>
            <div className="mt-0.5 text-[9px] t-muted">{x.l}</div>
          </div>
        ))}
      </div>

      <div className="mt-4 space-y-1">
        <div className="flex items-center justify-between border-t border-hairline py-3">
          <div><p className="text-[11px] font-bold">اجرای خودکار</p><p className="mt-0.5 text-[9.5px] t-muted">ورود و خروج هوشمند پوزیشن</p></div>
          <Switch checked={s.botActive} onChange={s.onToggleBot} label="اجرای خودکار" />
        </div>
        <div className="flex items-center justify-between border-t border-hairline py-3">
          <div><p className="text-[11px] font-bold">حالت حرفه‌ای</p><p className="mt-0.5 text-[9.5px] t-muted">کنترل اهرم و حجم معاملات</p></div>
          <Switch checked={s.proMode} onChange={s.onTogglePro} label="حالت حرفه‌ای" />
        </div>
      </div>

      {s.proMode && (
        <div className="animate-enter grid gap-3 sm:grid-cols-2">
          <SliderRow label="اهرم آزاد" display={`${s.leverage}x`} min={1} max={50} value={s.leverage} onChange={s.setLeverage} />
          <SliderRow label="معامله همزمان" display={`${s.maxTrades} / 20`} min={1} max={20} value={s.maxTrades} onChange={s.setMaxTrades} />
        </div>
      )}

      <div className="mt-auto pt-4">
        <button onClick={() => s.onNavigate("engines")} className="btn-ghost h-9 w-full rounded-xl text-[11px] font-bold"><Settings2 size={14} /> مدیریت موتورها</button>
      </div>
    </div>
  );
}

/* ================= Engine quick list ================= */
function EngineMiniList({ s }: { s: AppState }) {
  return (
    <div className="surface rounded-[24px] p-4">
      <SectionHead title="موتورهای دلارینو" subtitle="انتخاب موتور معاملاتی" action={<LinkButton onClick={() => s.onNavigate("engines")}>جزئیات</LinkButton>} />
      <div className="space-y-2">
        {engines.map((e) => {
          const Icon = engineIcons[e.id];
          const isActive = s.activeEngine === e.id;
          return (
            <button
              key={e.id}
              onClick={() => s.onSelectEngine(e.id)}
              className="press flex w-full items-center gap-3 rounded-2xl border p-3 text-right transition-all duration-200 hover:-translate-y-0.5"
              style={{ borderColor: isActive ? `${e.color}66` : "var(--border)", background: isActive ? `${e.color}12` : "var(--glass)", boxShadow: isActive ? `0 8px 24px ${e.color}22` : undefined }}
            >
              <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl" style={{ background: `${e.color}1f`, color: e.color }}><Icon size={17} /></span>
              <span className="min-w-0 flex-1"><span className="block truncate text-[11.5px] font-bold">{e.name}</span><span className="mt-0.5 block text-[9.5px] t-muted">{e.label}</span></span>
              <span className="text-left"><span className="num block text-[11px] font-extrabold" style={{ color: e.color }} dir="ltr">{e.winRate}%</span><span className="text-[9px] t-faint">وین‌ریت</span></span>
              <span className="h-2 w-2 shrink-0 rounded-full transition-all" style={{ background: isActive ? e.color : "var(--border-strong)", boxShadow: isActive ? `0 0 8px ${e.color}` : undefined }} />
            </button>
          );
        })}
      </div>
    </div>
  );
}

/* ================= AI daily brief ================= */
function AiBrief({ s }: { s: AppState }) {
  const [dismissed, setDismissed] = useState<string | null>(null);
  const list = aiBrief.filter((b) => b.id !== dismissed);
  if (list.length === 0) return null;
  return (
    <div className="grad-border surface overflow-hidden rounded-[24px]">
      <div className="flex items-center justify-between gap-3 border-b border-hairline px-4 py-3 sm:px-5">
        <div className="flex items-center gap-2.5">
          <span className="grid h-8 w-8 place-items-center rounded-xl bg-gradient-to-br from-[#6d8dff] to-[#8b5cf6] text-white shadow-[0_6px_16px_rgba(109,141,255,.4)]" style={{ animation: "orbFloat 3s ease-in-out infinite" }}><BrainCircuit size={16} /></span>
          <div>
            <p className="text-[12.5px] font-extrabold">تحلیل امروز دُرّبین <span className="num rounded-md bg-[rgba(91,124,255,.14)] px-1.5 py-0.5 text-[9px] t-accent" dir="ltr">AI</span></p>
            <p className="mt-0.5 text-[9.5px] t-muted">سه نکته مهم قبل از شروع معاملات امروز</p>
          </div>
        </div>
        <LinkButton onClick={() => s.onNavigate("signals")}>سیگنال‌ها</LinkButton>
      </div>
      <div className="grid gap-3 p-4 sm:p-5 lg:grid-cols-3">
        {list.map((b) => (
          <div key={b.id} className="group relative overflow-hidden rounded-2xl border border-hairline bg-[var(--glass)] p-3.5">
            <button onClick={() => setDismissed(b.id)} className="icon-btn absolute left-2 top-2 h-6 w-6 rounded-lg opacity-0 transition-opacity group-hover:opacity-100" aria-label="بستن"><X size={12} /></button>
            <div className="flex items-center gap-2">
              <EngineChip label={b.tag} color={b.color} />
              <span className="num mr-auto text-[9.5px] font-bold t-muted" dir="ltr">{b.confidence}%</span>
            </div>
            <p className="mt-2.5 text-[11.5px] font-bold leading-6">{b.title}</p>
            <p className="mt-1 text-[10px] leading-6 t-muted">{b.body}</p>
            <div className="mt-3 h-1 overflow-hidden rounded-full bg-[var(--border)]">
              <div className="h-full rounded-full" style={{ width: `${b.confidence}%`, background: `linear-gradient(90deg, ${b.color}, #37d6a5)` }} />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ================= Overview page ================= */
export function Overview({ s }: { s: AppState }) {
  const [insightOff, setInsightOff] = useState(false);
  const openPnl = s.positions.reduce((sum, p) => sum + p.pnl, 0);
  const wins = s.positions.filter((p) => p.pnl > 0).length;
  const winRate = s.positions.length ? (wins / s.positions.length) * 100 : 0;
  const hour = new Date().getHours();

  return (
    <div className="animate-page space-y-4">
      <Ticker s={s} />

      <div className="flex flex-wrap items-end justify-between gap-3 pt-1">
        <div>
          <p className="flex items-center gap-1.5 text-[10.5px] font-medium t-muted">
            <LiveDot /> {todayLabel()} · آخرین به‌روزرسانی همین الان
          </p>
          <h2 className="mt-1.5 text-[21px] font-black tracking-tight sm:text-[25px]">
            {greetingByHour(hour)}، کیا
          </h2>
          <p className="mt-1.5 flex flex-wrap items-center gap-x-1.5 gap-y-1 text-[11px] t-muted">
            ربات روی <span className="num font-extrabold t-accent" dir="ltr">{s.positions.length} پوزیشن</span> فعال است
            <span className="t-faint">·</span> موتور <span className="font-bold" style={{ color: engineById(s.activeEngine).color }}>{engineById(s.activeEngine).label}</span>
            <span className="t-faint">·</span> سود شناور <span className="num font-extrabold" style={{ color: openPnl >= 0 ? "var(--mint)" : "var(--rose)" }} dir="ltr">{money(openPnl)}</span>
          </p>
        </div>
        <div className="flex gap-2">
          <button onClick={() => s.onNavigate("performance")} className="btn-ghost h-10 rounded-xl px-3.5 text-[11px] font-bold"><BarChart3 size={15} /> گزارش عملکرد</button>
          <button onClick={s.onNewTrade} className="btn-primary h-10 rounded-xl px-4 text-[11px] font-bold"><Plus size={15} /> معامله جدید</button>
        </div>
      </div>

      <div className="grid gap-4 xl:grid-cols-12">
        <div className="xl:col-span-7"><WalletCard s={s} /></div>
        <div className="xl:col-span-5"><EngineControl s={s} /></div>
      </div>

      <div className="stagger grid grid-cols-2 gap-3 lg:grid-cols-4 lg:gap-4">
        <StatCard label="سود امروز" raw={1284.5} format={(n) => money(n)} delta="8.2%" icon={TrendingUp} spark={[18, 22, 21, 28, 26, 33, 31, 39, 42]} />
        <StatCard label="سود شناور" raw={openPnl} format={(n) => money(n)} delta="5.4%" icon={Activity} spark={[20, 24, 22, 29, 27, 35, 33, 38, 41]} />
        <StatCard label="وین‌ریت" raw={winRate} format={(n) => `${fmt(n, 1)}%`} delta="3.1%" icon={Target} spark={[24, 23, 27, 26, 30, 29, 33, 35, 38]} />
        <StatCard label="معاملات باز" value={`${s.positions.length} / ${s.maxTrades}`} delta="2+" icon={Layers3} spark={[20, 26, 22, 30, 28, 34, 31, 36, 40]} />
      </div>

      <AiBrief s={s} />

      <div className="grid gap-4 xl:grid-cols-12">
        <div className="surface rounded-[24px] p-4 sm:p-5 xl:col-span-8">
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div>
              <p className="eyebrow num" dir="ltr">Equity curve</p>
              <div className="num mt-1.5 text-[25px] font-black tracking-tight" dir="ltr">
                <AnimatedNumber value={s.balance} format={(n) => money(n)} />
              </div>
              <div className="num mt-1.5 flex items-center gap-1.5 text-[10.5px] font-bold t-mint" dir="ltr"><ArrowUpRight size={13} /> +36.5% <span className="font-medium t-muted">در ۳۰ روز گذشته</span></div>
            </div>
            <SegControl
              options={[{ value: "7D", label: "7D" }, { value: "30D", label: "30D" }, { value: "90D", label: "90D" }]}
              value={s.timeframe}
              onChange={s.setTimeframe}
            />
          </div>
          <div className="mt-4"><AreaChart key={s.timeframe} values={chartSeries[s.timeframe]} labels={chartLabels[s.timeframe]} height={260} /></div>
          {!insightOff && (
            <div className="animate-enter mt-3 flex items-start gap-2.5 rounded-2xl border border-[rgba(124,146,255,.25)] bg-[rgba(91,124,255,.07)] p-3">
              <Sparkles size={15} className="mt-0.5 shrink-0 t-accent" />
              <p className="flex-1 text-[10.5px] leading-6 t-muted"><span className="font-bold t-accent">جمع‌بندی دُرّبین:</span> شیب منحنی در ۵ روز اخیر تندتر شده؛ بهترین عملکرد مربوط به معاملات لانگ BTC با وین‌ریت ۹۱٪ است.</p>
              <button onClick={() => setInsightOff(true)} className="icon-btn h-6 w-6 rounded-lg" aria-label="بستن"><X size={12} /></button>
            </div>
          )}
          <div className="mt-3 grid grid-cols-3 gap-2 border-t border-hairline pt-4">
            {[{ l: "بهترین روز", v: "+$412.80" }, { l: "میانگین سود", v: "+$221.70" }, { l: "حداکثر افت", v: "3.2%" }].map((x) => (
              <div key={x.l} className="rounded-xl px-2 py-1"><div className="num text-[12px] font-extrabold" dir="ltr">{x.v}</div><div className="mt-0.5 text-[9.5px] t-muted">{x.l}</div></div>
            ))}
          </div>
        </div>
        <div className="xl:col-span-4"><WeeklyCard notify={s.notify} /></div>
      </div>

      <div className="grid gap-4 xl:grid-cols-12">
        <div className="surface rounded-[24px] p-4 sm:p-5 xl:col-span-8">
          <SectionHead title="معاملات باز" subtitle="پوزیشن‌های در حال اجرا با قیمت لحظه‌ای" action={<LinkButton onClick={() => s.onNavigate("trades")}>همه معاملات</LinkButton>} />
          <PositionsTable positions={s.positions.slice(0, 5)} onClose={s.onClosePosition} />
        </div>
        <div className="space-y-4 xl:col-span-4">
          <EngineMiniList s={s} />
          <div className="surface rounded-[24px] p-4">
            <SectionHead title="بازار لحظه‌ای" subtitle="۳۰+ ارز پرنقدینگی" action={<LinkButton onClick={() => s.notify("فهرست کامل بازار به‌زودی اضافه می‌شود")}>همه</LinkButton>} />
            <MarketList markets={s.markets} limit={5} onSelect={(m) => s.notify(`${m.symbol}: $${priceText(m.price)} · ${pct(m.change)}`)} />
          </div>
        </div>
      </div>

      <div className="surface flex flex-wrap items-center justify-between gap-3 rounded-[22px] p-4">
        <div className="flex items-center gap-3">
          <span className="grid h-10 w-10 place-items-center rounded-xl border border-[rgba(55,214,165,.25)] bg-[rgba(55,214,165,.10)] t-mint"><Gauge size={19} /></span>
          <div><p className="text-[12px] font-extrabold">زیرساخت پایدار، همیشه روشن</p><p className="num mt-0.5 text-[10px] t-muted" dir="ltr">Cloudflare Workers · D1 · Durable Objects · Telegram 24/7</p></div>
        </div>
        <div className="flex items-center gap-2">
          <DirectionBadge side="long" leverage={s.leverage} />
          <span className="num flex items-center gap-1.5 rounded-lg border border-hairline px-2 py-1.5 text-[10px] font-bold t-muted" dir="ltr"><LiveDot /> 42ms</span>
        </div>
      </div>
    </div>
  );
}
