import { useState, type ReactNode } from "react";
import {
  Activity, ArrowDownLeft, ArrowUpRight, BarChart3, Bell, Check, ChevronDown, Cpu, Gauge,
  Globe2, Layers3, LockKeyhole, Moon, Plus, Radio, ShieldCheck, Sparkles, Sun,
  Target, TrendingUp, Wallet, Zap, SearchX,
} from "lucide-react";
import {
  chartLabels, chartSeries, engineById, engines, fmt, money, priceText, signals,
  transactions, weeklyBars, type EngineId, type Signal,
} from "../data";
import type { AppState } from "../state";
import { AreaChart, Bars, Donut, ProgressRing, Sparkline } from "./Charts";
import { AnimatedNumber, CoinIcon, DirectionBadge, EmptyState, LiveDot, SectionHead, SegControl, SliderRow, Switch } from "./UI";
import { MarketList, PositionsTable, StatCard } from "./Widgets";
import { WeeklyCard } from "./WeeklyCard";

const engineIcons: Record<EngineId, typeof Sparkles> = { ai: Sparkles, strategy: Cpu, copy: Radio };
const chipClass = "chip h-8 rounded-xl px-3 text-[10.5px] font-bold";

/* ---------------- Shared page hero ---------------- */
function PageHero({
  icon, color, title, desc, action, live,
}: {
  icon: ReactNode; color: string; title: string; desc: string; action?: ReactNode; live?: boolean;
}) {
  return (
    <div className="surface flex flex-wrap items-center justify-between gap-3 rounded-[22px] p-4">
      <div className="flex items-center gap-3">
        <span
          className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl"
          style={{ background: `linear-gradient(140deg, ${color}2e, ${color}0d)`, color, border: `1px solid ${color}3d`, boxShadow: `0 8px 20px ${color}22` }}
        >
          {icon}
        </span>
        <div>
          <h2 className="flex items-center gap-2 text-[13.5px] font-extrabold">{title}{live && <LiveDot />}</h2>
          <p className="mt-0.5 text-[10px] t-muted">{desc}</p>
        </div>
      </div>
      {action && <div className="flex items-center gap-2">{action}</div>}
    </div>
  );
}

/* ================= TRADES ================= */
export function TradesPage({ s }: { s: AppState }) {
  const [filter, setFilter] = useState<"all" | "profit" | "loss">("all");
  const filtered = s.positions.filter((p) => filter === "all" || (filter === "profit" ? p.pnl > 0 : p.pnl < 0));
  const openPnl = s.positions.reduce((sum, p) => sum + p.pnl, 0);
  const avgLeverage = s.positions.length ? s.positions.reduce((sum, p) => sum + p.leverage, 0) / s.positions.length : 0;
  const counts = {
    all: s.positions.length,
    profit: s.positions.filter((p) => p.pnl > 0).length,
    loss: s.positions.filter((p) => p.pnl < 0).length,
  };

  return (
    <div className="animate-page space-y-4">
      <PageHero
        icon={<Layers3 size={20} />} color="#7c92ff"
        title="مدیریت پوزیشن‌ها" desc={`ربات تا ${s.maxTrades} معامله همزمان را پشتیبانی می‌کند.`}
        action={<button onClick={s.onNewTrade} className="btn-primary h-10 rounded-xl px-4 text-[11px] font-bold"><Plus size={15} /> معامله جدید</button>}
      />

      <div className="stagger grid grid-cols-2 gap-3 lg:grid-cols-4">
        <StatCard label="پوزیشن باز" raw={s.positions.length} format={(n) => `${Math.round(n)}`} delta="2+" icon={Layers3} spark={[18, 22, 25, 24, 30, 28, 34, 36]} />
        <StatCard label="سود شناور" raw={openPnl} format={(n) => money(n)} delta="5.4%" icon={TrendingUp} spark={[16, 20, 19, 26, 25, 31, 30, 38]} />
        <StatCard label="میانگین اهرم" raw={avgLeverage} format={(n) => `${fmt(n, 1)}x`} delta="1.2x" icon={Gauge} spark={[24, 23, 25, 27, 26, 29, 28, 31]} />
        <StatCard label="حجم درگیر" raw={s.positions.reduce((a, p) => a + p.size, 0)} format={(n) => `$${fmt(n, 0)}`} delta="6.8%" icon={Wallet} spark={[20, 23, 22, 27, 25, 30, 32, 35]} />
      </div>

      <div className="surface rounded-[24px] p-4 sm:p-5">
        <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
          <div><h2 className="text-[14px] font-extrabold">معاملات باز</h2><p className="mt-1 text-[10px] t-muted">برای بستن، دو بار روی ضربدر بزنید</p></div>
          <div className="flex gap-2">
            {([["all", "همه"], ["profit", "سودده"], ["loss", "زیان‌ده"]] as const).map(([k, label]) => (
              <button key={k} data-active={filter === k} onClick={() => setFilter(k)} className={chipClass}>
                {label} <span className="num rounded-md bg-black/20 px-1 text-[9px]" dir="ltr">{counts[k]}</span>
              </button>
            ))}
          </div>
        </div>
        <PositionsTable positions={filtered} onClose={s.onClosePosition} emptyText="پوزیشنی با این فیلتر وجود ندارد." />
      </div>

      <div className="grid gap-4 lg:grid-cols-12">
        <div className="surface rounded-[24px] p-4 sm:p-5 lg:col-span-8">
          <SectionHead title="تاریخچه معاملات" subtitle="آخرین پوزیشن‌های بسته‌شده" eyebrow="History" />
          <div className="space-y-1.5">
            {[
              { sym: "BNB", name: "بایننس کوین", color: "#e8c55b", side: "long" as const, pnl: 88.4, time: "امروز ۱۲:۱۸" },
              { sym: "ADA", name: "کاردانو", color: "#4f8bff", side: "long" as const, pnl: 42.1, time: "دیروز ۲۱:۴۰" },
              { sym: "DOT", name: "پولکادات", color: "#ff6b9c", side: "short" as const, pnl: -18.7, time: "دیروز ۱۹:۰۲" },
              { sym: "ARB", name: "آربیتروم", color: "#8aa2e8", side: "long" as const, pnl: 64.2, time: "۲ تیر ۱۵:۳۰" },
            ].map((t) => (
              <div key={t.sym} className="flex items-center gap-3 rounded-2xl border border-transparent px-3 py-2.5 transition-all hover:border-[var(--border)] hover:bg-[var(--glass)]">
                <CoinIcon symbol={t.sym} color={t.color} size={34} />
                <div><div className="num text-[11px] font-bold" dir="ltr">{t.sym}/USDT</div><div className="text-[9px] t-faint">{t.name}</div></div>
                <div className="hidden sm:block"><DirectionBadge side={t.side} leverage={8} /></div>
                <span className="mr-auto text-[9.5px] t-faint">{t.time}</span>
                <span className="num rounded-lg px-2 py-1 text-[11.5px] font-extrabold" style={{ color: t.pnl >= 0 ? "var(--mint)" : "var(--rose)", background: t.pnl >= 0 ? "rgba(55,214,165,.09)" : "rgba(255,113,133,.09)" }} dir="ltr">{money(t.pnl)}</span>
              </div>
            ))}
          </div>
        </div>
        <div className="surface rounded-[24px] p-4 lg:col-span-4">
          <SectionHead title="بازار تحت نظر" subtitle="نقدینگی برتر امروز" />
          <MarketList markets={s.markets} limit={6} onSelect={(m) => s.notify(`${m.symbol} · $${priceText(m.price)}`)} />
        </div>
      </div>
    </div>
  );
}

/* ================= SIGNALS ================= */
const statusMeta: Record<Signal["status"], { label: string; color: string }> = {
  active: { label: "فعال", color: "var(--mint)" },
  closed: { label: "بسته شد", color: "var(--muted)" },
  waiting: { label: "در انتظار", color: "var(--amber)" },
};

export function SignalsPage({ s }: { s: AppState }) {
  const [filter, setFilter] = useState<"all" | Signal["status"]>("all");
  const [copied, setCopied] = useState<string | null>(null);
  const [channels, setChannels] = useState({ official: true, telegram: false, webhook: true });
  const list = signals.filter((x) => filter === "all" || x.status === filter);
  const counts = {
    all: signals.length,
    active: signals.filter((x) => x.status === "active").length,
    closed: signals.filter((x) => x.status === "closed").length,
    waiting: signals.filter((x) => x.status === "waiting").length,
  };

  const copy = (sig: Signal) => {
    setCopied(sig.id);
    s.notify(`سیگنال ${sig.symbol} به صف اجرا اضافه شد`);
    setTimeout(() => setCopied((c) => (c === sig.id ? null : c)), 2000);
  };

  return (
    <div className="animate-page space-y-4">
      <PageHero
        icon={<Radio size={20} />} color="#37d6a5"
        title="فید سیگنال زنده" desc="خروجی موتورها به‌صورت لحظه‌ای، بدون تأخیر" live
        action={<span className="num flex items-center gap-2 rounded-xl border border-hairline bg-[var(--glass)] px-3 py-2 text-[10px] font-bold t-muted" dir="ltr"><Activity size={14} /> 12 today</span>}
      />

      <div className="stagger grid grid-cols-2 gap-3 lg:grid-cols-4">
        <StatCard label="سیگنال امروز" raw={12} format={(n) => `${Math.round(n)}`} delta="4+" icon={Radio} spark={[16, 20, 18, 25, 24, 30, 28, 34]} />
        <StatCard label="میانگین اطمینان" raw={86.5} format={(n) => `${fmt(n, 1)}%`} delta="2.4%" icon={Target} spark={[20, 22, 25, 23, 28, 30, 32, 34]} />
        <StatCard label="نرخ موفقیت" raw={82.9} format={(n) => `${fmt(n, 1)}%`} delta="6.1%" icon={TrendingUp} spark={[18, 22, 21, 27, 26, 31, 34, 38]} />
        <StatCard label="میانگین اجرا" value="0.8s" delta="0.2s" icon={Zap} spark={[30, 28, 27, 25, 24, 22, 20, 18]} />
      </div>

      <div className="grid gap-4 lg:grid-cols-12">
        <div className="surface rounded-[24px] p-4 sm:p-5 lg:col-span-8">
          <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
            <div><h2 className="text-[14px] font-extrabold">آخرین سیگنال‌ها</h2><p className="mt-1 text-[10px] t-muted">برای کپی سریع، روی دکمه کپی بزنید</p></div>
            <div className="flex flex-wrap gap-2">
              {([["all", "همه"], ["active", "فعال"], ["closed", "بسته"], ["waiting", "انتظار"]] as const).map(([k, label]) => (
                <button key={k} data-active={filter === k} onClick={() => setFilter(k)} className={chipClass}>
                  {label} <span className="num rounded-md bg-black/20 px-1 text-[9px]" dir="ltr">{counts[k]}</span>
                </button>
              ))}
            </div>
          </div>
          {list.length === 0 ? (
            <EmptyState icon={<SearchX size={22} />} title="سیگنالی نیست" desc="با این فیلتر سیگنالی ثبت نشده است." />
          ) : (
            <div className="space-y-2.5">
              {list.map((sig) => {
                const engine = engineById(sig.engine);
                const meta = statusMeta[sig.status];
                const isCopied = copied === sig.id;
                return (
                  <div key={sig.id} className="lift rounded-2xl border border-hairline bg-[var(--glass)] p-3.5">
                    <div className="flex flex-wrap items-center gap-2.5">
                      <span className="num grid h-10 w-10 place-items-center rounded-xl text-[9px] font-extrabold" style={{ background: `${engine.color}1c`, color: engine.color, border: `1px solid ${engine.color}33` }} dir="ltr">{sig.symbol.slice(0, 3)}</span>
                      <div><div className="num text-[12px] font-extrabold" dir="ltr">{sig.symbol}</div><div className="mt-0.5 text-[9px] t-faint">{engine.label}</div></div>
                      <DirectionBadge side={sig.side} />
                      <span className="num flex items-center gap-1 rounded-lg px-2 py-1 text-[9px] font-bold" style={{ color: meta.color, background: `${meta.color}16` }}>
                        {sig.status === "active" && <LiveDot color={meta.color} />}{meta.label}
                      </span>
                      <span className="num mr-auto text-[10px] t-faint" dir="ltr">{sig.time}</span>
                      <button onClick={() => copy(sig)} className={`h-8 rounded-lg px-3 text-[10px] font-bold transition-all ${isCopied ? "" : "btn-ghost"}`} style={isCopied ? { background: "rgba(55,214,165,.15)", color: "var(--mint)" } : undefined}>
                        {isCopied ? <span className="flex items-center gap-1"><Check size={13} strokeWidth={3} /> کپی شد</span> : "کپی سیگنال"}
                      </button>
                    </div>
                    <div className="mt-3 flex flex-wrap items-center gap-4 border-t border-hairline pt-3">
                      <div><div className="text-[9px] t-faint">محدوده ورود</div><div className="num mt-0.5 text-[10.5px] font-semibold" dir="ltr">{sig.entry}</div></div>
                      <div className="mr-auto min-w-[130px] flex-1">
                        <div className="mb-1.5 flex items-center justify-between text-[9px]"><span className="t-faint">اطمینان موتور</span><span className="num font-extrabold" dir="ltr">{sig.confidence}%</span></div>
                        <div className="h-1.5 overflow-hidden rounded-full bg-[var(--border)]"><div className="h-full rounded-full transition-all duration-700" style={{ width: `${sig.confidence}%`, background: `linear-gradient(90deg, ${engine.color}, #37d6a5)` }} /></div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        <div className="space-y-4 lg:col-span-4">
          <div className="surface rounded-[24px] p-4">
            <SectionHead title="منابع متصل" subtitle="ورودی‌های کپی‌ترید" />
            <div className="space-y-2">
              {([
                { key: "official" as const, title: "کانال رسمی دلارینو", sub: "@Dollarinoofficial", icon: Radio },
                { key: "telegram" as const, title: "کانال اختصاصی", sub: "ربات تلگرام ۲۴/۷", icon: Globe2 },
                { key: "webhook" as const, title: "TradingView Webhook", sub: "اجرای زیر یک ثانیه", icon: Zap },
              ]).map((c) => (
                <div key={c.key} className="flex items-center gap-3 rounded-2xl border border-hairline bg-[var(--glass)] p-3">
                  <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-[rgba(91,124,255,.12)] t-accent"><c.icon size={16} /></span>
                  <div className="min-w-0 flex-1"><p className="truncate text-[11px] font-bold">{c.title}</p><p className="num mt-0.5 truncate text-[9px] t-faint" dir="ltr">{c.sub}</p></div>
                  <Switch checked={channels[c.key]} onChange={(v) => { setChannels((prev) => ({ ...prev, [c.key]: v })); s.notify(`${c.title} ${v ? "فعال" : "غیرفعال"} شد`); }} label={c.title} />
                </div>
              ))}
            </div>
          </div>
          <div className="surface rounded-[24px] p-4">
            <SectionHead title="توزیع سیگنال" subtitle="بر اساس موتور" />
            <div className="space-y-3.5">
              {engines.map((e) => (
                <div key={e.id}>
                  <div className="mb-1.5 flex items-center justify-between text-[10px]"><span className="font-bold">{e.label}</span><span className="num font-extrabold" dir="ltr">{e.winRate}%</span></div>
                  <div className="h-2 overflow-hidden rounded-full bg-[var(--border)]"><div className="h-full rounded-full transition-all duration-700" style={{ width: `${e.winRate}%`, background: e.color, boxShadow: `0 0 10px ${e.color}66` }} /></div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ================= PERFORMANCE ================= */
export function PerformancePage({ s }: { s: AppState }) {
  return (
    <div className="animate-page space-y-4">
      <div className="stagger grid grid-cols-2 gap-3 lg:grid-cols-4">
        <StatCard label="سود خالص" raw={6650.72} format={(n) => money(n)} delta="36.5%" icon={TrendingUp} spark={[14, 18, 17, 24, 23, 31, 35, 42]} />
        <StatCard label="وین‌ریت" raw={82.9} format={(n) => `${fmt(n, 1)}%`} delta="6.1%" icon={Target} spark={[20, 23, 22, 27, 28, 31, 33, 37]} />
        <StatCard label="نسبت شارپ" raw={2.84} format={(n) => fmt(n, 2)} delta="0.4" icon={Gauge} spark={[18, 21, 20, 26, 25, 29, 31, 35]} />
        <StatCard label="حداکثر افت" value="3.2%" delta="1.1%" icon={Activity} spark={[34, 32, 30, 28, 27, 25, 23, 20]} positive={false} />
      </div>

      <div className="grid gap-4 lg:grid-cols-12">
        <div className="surface rounded-[24px] p-4 sm:p-5 lg:col-span-8">
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div>
              <p className="eyebrow num" dir="ltr">Equity curve</p>
              <h2 className="mt-1 text-[14px] font-extrabold">منحنی سرمایه</h2>
              <p className="mt-1 text-[10px] t-muted">رشد حساب در بازه انتخابی</p>
            </div>
            <SegControl options={[{ value: "7D", label: "7D" }, { value: "30D", label: "30D" }, { value: "90D", label: "90D" }]} value={s.timeframe} onChange={s.setTimeframe} />
          </div>
          <div className="mt-5"><AreaChart key={s.timeframe} values={chartSeries[s.timeframe]} labels={chartLabels[s.timeframe]} height={300} color="#6f9dff" /></div>
          <div className="mt-2 grid grid-cols-2 gap-3 border-t border-hairline pt-4 sm:grid-cols-4">
            {[{ l: "سرمایه اولیه", v: "$18,200" }, { l: "سرمایه فعلی", v: money(s.balance) }, { l: "کل معاملات", v: "4,508" }, { l: "بهترین ماه", v: "+24.8%" }].map((x) => (
              <div key={x.l}><div className="num text-[12px] font-extrabold" dir="ltr">{x.v}</div><div className="mt-0.5 text-[9.5px] t-muted">{x.l}</div></div>
            ))}
          </div>
        </div>

        <div className="space-y-4 lg:col-span-4">
          <WeeklyCard notify={s.notify} compact />
          <div className="surface rounded-[24px] p-4">
            <SectionHead title="کیفیت اجرا" subtitle="شاخص‌های پایداری" />
            <div className="flex items-center justify-around gap-2">
              <ProgressRing value={83} size={88} stroke={8} color="#6f9dff"><span className="num text-[15px] font-extrabold" dir="ltr">83%</span><span className="text-[8px] t-faint">وین‌ریت</span></ProgressRing>
              <ProgressRing value={98} size={88} stroke={8} color="#37d6a5"><span className="num text-[15px] font-extrabold" dir="ltr">98%</span><span className="text-[8px] t-faint">آپتایم</span></ProgressRing>
            </div>
          </div>
        </div>
      </div>

      <div className="grid gap-4 lg:grid-cols-12">
        <div className="surface rounded-[24px] p-4 sm:p-5 lg:col-span-8">
          <SectionHead title="سود روزهای هفته" subtitle="عملکرد هفتگی به تفکیک روز" eyebrow="Weekly" />
          <Bars data={weeklyBars.map((b) => ({ label: b.day, value: b.pnl }))} highlight={3} height={190} format={(v) => `+$${v}`} />
        </div>
        <div className="surface rounded-[24px] p-4 lg:col-span-4">
          <SectionHead title="سهم موتورها" subtitle="از سود کل" />
          <div className="space-y-4">
            {engines.map((e, i) => (
              <div key={e.id}>
                <div className="mb-1.5 flex items-center justify-between text-[10px]"><span className="font-bold">{e.label}</span><span className="num font-extrabold" dir="ltr">{[48, 32, 20][i]}%</span></div>
                <div className="h-2.5 overflow-hidden rounded-full bg-[var(--border)]"><div className="h-full rounded-full transition-all duration-700" style={{ width: `${[48, 32, 20][i]}%`, background: e.color }} /></div>
              </div>
            ))}
            <div className="rounded-2xl border border-hairline bg-[var(--glass)] p-3 text-[10px] leading-6 t-muted">موتور <span className="font-bold t-accent">دُرّبین</span> بیشترین سهم را در سود این دوره داشته است.</div>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ================= ENGINES ================= */
export function EnginesPage({ s }: { s: AppState }) {
  const [marketMode, setMarketMode] = useState("ALL_MARKET");
  return (
    <div className="animate-page space-y-4">
      <PageHero
        icon={<Cpu size={20} />} color="#8b9dff"
        title="سه موتور رسمی، یک ترمینال" desc="موتور دلخواهتان را فعال کنید؛ تنظیمات بلافاصله اعمال می‌شود."
        action={<span className="flex items-center gap-2 rounded-xl border border-hairline bg-[var(--glass)] px-3 py-2 text-[11px] font-bold"><LiveDot color={s.botActive ? "var(--mint)" : "var(--amber)"} /> {s.botActive ? "ربات فعال" : "ربات متوقف"}</span>}
      />

      <div className="stagger grid gap-4 md:grid-cols-2 xl:grid-cols-3">
        {engines.map((e) => {
          const Icon = engineIcons[e.id];
          const active = s.activeEngine === e.id;
          return (
            <div
              key={e.id}
              className={`surface lift relative flex flex-col overflow-hidden rounded-[24px] p-5 ${active ? "grad-border" : ""}`}
              style={active ? { borderColor: `${e.color}55` } : undefined}
            >
              <div className="pointer-events-none absolute -left-12 -top-12 h-36 w-36 rounded-full blur-3xl" style={{ background: `${e.color}26` }} />
              <div className="relative flex items-start justify-between">
                <span className="grid h-11 w-11 place-items-center rounded-[14px]" style={{ background: `${e.color}20`, color: e.color, border: `1px solid ${e.color}40` }}><Icon size={21} /></span>
                <span className="rounded-lg border px-2 py-1 text-[9px] font-bold" style={{ background: `${e.color}16`, color: e.color, borderColor: `${e.color}35` }}>{e.badge}</span>
              </div>
              <h3 className="relative mt-4 text-[14px] font-extrabold">{e.name}</h3>
              <p className="num relative mt-1 text-[9px] font-bold tracking-[.14em] t-faint" dir="ltr">{e.latin}</p>
              <p className="relative mt-3 min-h-[48px] text-[10.5px] leading-6 t-muted">{e.description}</p>
              <div className="relative mt-4 flex items-center justify-between rounded-2xl border border-hairline bg-[var(--glass)] p-3">
                <ProgressRing value={e.winRate} size={60} stroke={5} color={e.color}><span className="num text-[11px] font-extrabold" dir="ltr">{Math.round(e.winRate)}%</span></ProgressRing>
                <div className="text-left"><div className="num text-[14px] font-extrabold" dir="ltr"><AnimatedNumber value={e.trades} format={(n) => Math.round(n).toLocaleString("en-US")} /></div><div className="text-[9px] t-faint">معامله تحلیل‌شده</div></div>
              </div>
              <ul className="relative mt-4 flex-1 space-y-2">
                {e.details.map((d) => (
                  <li key={d} className="flex items-center gap-2 text-[10px] t-muted"><Check size={13} strokeWidth={3} className="t-mint" />{d}</li>
                ))}
              </ul>
              <button
                onClick={() => s.onSelectEngine(e.id)}
                className={`relative mt-5 h-10 w-full rounded-xl text-[11px] font-bold ${active ? "btn-ghost" : "btn-primary"}`}
                style={active ? { color: e.color, borderColor: `${e.color}55` } : undefined}
              >
                {active ? <span className="flex items-center gap-1.5"><Check size={14} strokeWidth={3} /> موتور فعال</span> : "فعال‌سازی موتور"}
              </button>
            </div>
          );
        })}
      </div>

      <div className="grid gap-4 lg:grid-cols-12">
        <div className="surface rounded-[24px] p-4 sm:p-5 lg:col-span-8">
          <SectionHead title="پیکربندی موتور" subtitle={`تنظیمات موتور ${engineById(s.activeEngine).name}`} eyebrow="Config" />
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="rounded-2xl border border-hairline bg-[var(--glass)] p-4">
              <div className="flex items-center justify-between"><span className="text-[11px] font-bold">حالت حرفه‌ای تریدرها</span><Switch checked={s.proMode} onChange={s.onTogglePro} label="حالت حرفه‌ای" /></div>
              <p className="mt-2 text-[10px] leading-5 t-muted">دسترسی به اهرم آزاد، چرخش خودکار روند و حداکثر معاملات همزمان.</p>
            </div>
            <div className="rounded-2xl border border-hairline bg-[var(--glass)] p-4">
              <div className="flex items-center justify-between"><span className="text-[11px] font-bold">اجرای خودکار</span><Switch checked={s.botActive} onChange={s.onToggleBot} label="اجرای خودکار" /></div>
              <p className="mt-2 text-[10px] leading-5 t-muted">ربات بدون دخالت دستی، سیگنال‌ها را روی حساب اجرا می‌کند.</p>
            </div>
          </div>
          <div className="mt-4 grid gap-4 sm:grid-cols-2">
            <SliderRow label="اهرم آزاد" display={`${s.leverage}x`} min={1} max={50} value={s.leverage} onChange={s.setLeverage} />
            <SliderRow label="حداکثر معامله همزمان" display={`${s.maxTrades} / 20`} min={1} max={20} value={s.maxTrades} onChange={s.setMaxTrades} />
          </div>
        </div>
        <div className="surface rounded-[24px] p-4 lg:col-span-4">
          <SectionHead title="حالت بازار" subtitle="دامنه رصد ارزها" />
          <div className="space-y-2">
            {[{ t: "ALL_MARKET", d: "رصد ۳۰+ ارز پرنقدینگی" }, { t: "TOP_COINS", d: "۱۰ ارز برتر بازار" }, { t: "SINGLE", d: "تمرکز روی یک ارز" }].map((m) => (
              <button
                key={m.t}
                onClick={() => { setMarketMode(m.t); s.notify(`حالت ${m.t} انتخاب شد`); }}
                className="press flex w-full items-center justify-between rounded-2xl border px-3 py-3 text-right transition-all hover:bg-[var(--glass)]"
                style={{ borderColor: marketMode === m.t ? "rgba(55,214,165,.45)" : "var(--border)", background: marketMode === m.t ? "rgba(55,214,165,.07)" : undefined }}
              >
                <div><div className="num text-[11px] font-extrabold" dir="ltr">{m.t}</div><div className="mt-0.5 text-[9.5px] t-faint">{m.d}</div></div>
                <span className="grid h-5 w-5 place-items-center rounded-full border" style={{ borderColor: marketMode === m.t ? "var(--mint)" : "var(--border-strong)", background: marketMode === m.t ? "var(--mint)" : "transparent" }}>
                  {marketMode === m.t && <Check size={12} strokeWidth={3.5} className="text-white" />}
                </span>
              </button>
            ))}
          </div>
          <div className="mt-4 rounded-2xl border border-hairline bg-[var(--glass)] p-3 text-[10px] leading-6 t-muted">چرخش خودکار روند (<span className="num" dir="ltr">auto_flip</span>) و معاملات دوطرفه پشتیبانی می‌شود.</div>
        </div>
      </div>
    </div>
  );
}

/* ================= WALLET ================= */
export function WalletPage({ s }: { s: AppState }) {
  const [txFilter, setTxFilter] = useState<"all" | "profit" | "deposit" | "fee">("all");
  const allocation = [
    { label: "معاملات باز", value: 42, color: "#6f8cff" },
    { label: "موجودی آزاد", value: 35, color: "#37d6a5" },
    { label: "مارجین", value: 15, color: "#f4c46b" },
    { label: "رزرو", value: 8, color: "#9b6cf5" },
  ];
  const txList = transactions.filter((t) => txFilter === "all" || t.type === txFilter);
  return (
    <div className="animate-page space-y-4">
      <div className="grid gap-4 lg:grid-cols-12">
        <div className="coin-card-wallet relative min-h-[240px] overflow-hidden rounded-[24px] p-5 text-white lg:col-span-5">
          <div className="coin-card-shine" />
          <div className="relative flex items-start justify-between">
            <div>
              <p className="eyebrow" style={{ color: "rgba(255,255,255,.5)" }}>Total balance</p>
              <p className="mt-1 text-[11px] text-white/70">موجودی کل حساب</p>
              <div className="num mt-3 text-[32px] font-black sm:text-[36px]" dir="ltr">
                {s.balanceHidden ? "••••••" : <AnimatedNumber value={s.balance} format={(n) => money(n)} />}
              </div>
              <p className="num mt-3 text-[11px] text-white/75" dir="ltr">+$2,741.28 · +12.4% this month</p>
            </div>
            <button onClick={s.onToggleHidden} className="grid h-9 w-9 place-items-center rounded-xl bg-white/15 transition hover:bg-white/25" aria-label="مخفی کردن موجودی">
              <Wallet size={16} />
            </button>
          </div>
          <div className="relative mt-6 grid grid-cols-2 gap-3">
            <div className="rounded-2xl border border-white/15 bg-white/10 p-3 backdrop-blur-md"><div className="text-[9px] text-white/60">موجودی آزاد</div><div className="num mt-1 text-[14px] font-extrabold" dir="ltr">$8,697.75</div></div>
            <div className="rounded-2xl border border-white/15 bg-white/10 p-3 backdrop-blur-md"><div className="text-[9px] text-white/60">مارجین درگیر</div><div className="num mt-1 text-[14px] font-extrabold" dir="ltr">$3,727.60</div></div>
          </div>
          <div className="pointer-events-none absolute bottom-0 left-0 h-20 w-2/3 opacity-30"><Sparkline values={chartSeries["30D"]} color="#fff" height={80} fill animated={false} /></div>
        </div>

        <div className="surface grid gap-4 rounded-[24px] p-5 sm:grid-cols-2 lg:col-span-7">
          <div className="flex items-center justify-center">
            <div className="relative">
              <Donut segments={allocation} size={168} />
              <div className="absolute inset-0 flex flex-col items-center justify-center"><span className="num text-[19px] font-black" dir="ltr">100%</span><span className="text-[9px] t-muted">تخصیص</span></div>
            </div>
          </div>
          <div className="flex flex-col justify-center gap-3">
            <h3 className="text-[13px] font-extrabold">تخصیص سرمایه</h3>
            {allocation.map((a) => (
              <div key={a.label} className="flex items-center gap-2 text-[10.5px]">
                <span className="h-2 w-2 rounded-full" style={{ background: a.color, boxShadow: `0 0 8px ${a.color}` }} />
                <span className="t-muted">{a.label}</span>
                <span className="num mr-auto font-extrabold" dir="ltr">{a.value}%</span>
              </div>
            ))}
            <div className="rounded-xl border border-hairline bg-[var(--glass)] p-2.5 text-[9.5px] leading-5 t-muted">مدیریت ریسک هوشمند، سقف درگیری سرمایه را کنترل می‌کند.</div>
          </div>
        </div>
      </div>

      <div className="stagger grid grid-cols-2 gap-3 lg:grid-cols-4">
        <StatCard label="سود امروز" raw={1284.5} format={(n) => money(n)} delta="8.2%" icon={TrendingUp} spark={[18, 22, 20, 27, 26, 32, 35, 40]} />
        <StatCard label="سود این ماه" raw={2741.28} format={(n) => money(n)} delta="12.4%" icon={BarChart3} spark={[16, 20, 19, 25, 27, 30, 34, 39]} />
        <StatCard label="واریزی کل" value="$20,000" delta="5k" icon={Wallet} spark={[14, 16, 20, 22, 25, 28, 31, 34]} />
        <StatCard label="کارمزد پرداختی" value="$42.60" delta="0.8%" icon={Activity} spark={[34, 31, 30, 28, 26, 24, 22, 20]} positive={false} />
      </div>

      <div className="grid gap-4 lg:grid-cols-12">
        <div className="surface rounded-[24px] p-4 sm:p-5 lg:col-span-8">
          <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
            <SectionHead title="تراکنش‌های اخیر" subtitle="تاریخچه مالی حساب دمو" />
            <div className="flex flex-wrap gap-2">
              {([["all", "همه"], ["profit", "سود"], ["deposit", "واریز"], ["fee", "کارمزد"]] as const).map(([k, l]) => (
                <button key={k} data-active={txFilter === k} onClick={() => setTxFilter(k)} className={chipClass}>{l}</button>
              ))}
            </div>
          </div>
          {txList.length === 0 ? (
            <EmptyState icon={<SearchX size={22} />} title="تراکنشی نیست" desc="با این فیلتر تراکنشی ثبت نشده است." />
          ) : (
            <div className="space-y-1.5">
              {txList.map((t) => (
                <div key={t.id} className="flex items-center gap-3 rounded-2xl border border-transparent px-3 py-3 transition-all hover:border-[var(--border)] hover:bg-[var(--glass)]">
                  <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl" style={{ background: t.amount >= 0 ? "rgba(55,214,165,.11)" : "rgba(255,113,133,.11)", color: t.amount >= 0 ? "var(--mint)" : "var(--rose)" }}>{t.amount >= 0 ? <ArrowUpRight size={16} /> : <ArrowDownLeft size={16} />}</span>
                  <div className="min-w-0"><p className="truncate text-[11px] font-bold">{t.title}</p><p className="mt-0.5 text-[9px] t-faint">{t.date}</p></div>
                  <span className="num mr-auto text-[11.5px] font-extrabold" style={{ color: t.amount >= 0 ? "var(--mint)" : "var(--rose)" }} dir="ltr">{money(t.amount)}</span>
                </div>
              ))}
            </div>
          )}
        </div>
        <div className="space-y-4 lg:col-span-4">
          <div className="surface rounded-[24px] p-4">
            <SectionHead title="صرافی‌های متصل" subtitle="اتصال امن و رمزنگاری‌شده" />
            {[{ n: "Paper Demo", d: "قیمت زنده · رایگان", on: true }, { n: "Toobit Futures", d: "متصل نشده", on: false }, { n: "KCEX Futures", d: "متصل نشده", on: false }].map((x) => (
              <button key={x.n} onClick={() => s.notify(x.on ? `${x.n} فعال است` : `برای اتصال ${x.n} به تنظیمات بروید`)} className="press mb-2 flex w-full items-center gap-2.5 rounded-2xl border border-hairline p-2.5 text-right transition-all last:mb-0 hover:bg-[var(--glass)]">
                <span className="num grid h-8 w-8 shrink-0 place-items-center rounded-lg bg-[rgba(91,124,255,.12)] text-[9px] font-extrabold t-accent" dir="ltr">{x.n.slice(0, 2).toUpperCase()}</span>
                <span className="min-w-0 flex-1"><span className="num block truncate text-[10.5px] font-bold" dir="ltr">{x.n}</span><span className="mt-0.5 block text-[9px] t-faint">{x.d}</span></span>
                <span className="flex shrink-0 items-center gap-1 text-[9px] font-bold" style={{ color: x.on ? "var(--mint)" : "var(--faint)" }}><span className="h-1.5 w-1.5 rounded-full" style={{ background: x.on ? "var(--mint)" : "var(--faint)", boxShadow: x.on ? "0 0 6px var(--mint)" : undefined }} />{x.on ? "فعال" : "غیرفعال"}</span>
              </button>
            ))}
          </div>
          <div className="surface flex items-start gap-3 rounded-[24px] p-4">
            <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl border border-[rgba(55,214,165,.25)] bg-[rgba(55,214,165,.10)] t-mint"><LockKeyhole size={17} /></span>
            <div><p className="text-[11px] font-extrabold">امنیت سطح بانکی</p><p className="mt-1 text-[10px] leading-6 t-muted">کلیدهای API با AES-256 رمزنگاری و در Cloudflare Secrets نگهداری می‌شوند.</p></div>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ================= SETTINGS ================= */
export function SettingsPage({ s }: { s: AppState }) {
  const [alerts, setAlerts] = useState(true);
  const [telegram, setTelegram] = useState(true);
  const [reducedRisk, setReducedRisk] = useState(false);
  const [exchange, setExchange] = useState("Paper Demo");
  const [saved, setSaved] = useState(false);

  const row = (title: string, desc: string, value: boolean, onChange: (v: boolean) => void) => (
    <div className="flex items-center justify-between gap-4 border-b border-hairline py-3.5 last:border-0">
      <div><p className="text-[11.5px] font-bold">{title}</p><p className="mt-1 text-[10px] t-muted">{desc}</p></div>
      <Switch checked={value} onChange={onChange} label={title} />
    </div>
  );

  const save = () => {
    setSaved(true);
    s.notify("تنظیمات با موفقیت ذخیره شد");
    setTimeout(() => setSaved(false), 2200);
  };

  return (
    <div className="animate-page grid gap-4 lg:grid-cols-12">
      <div className="space-y-4 lg:col-span-8">
        <div className="surface rounded-[24px] p-4 sm:p-5">
          <SectionHead title="ظاهر ترمینال" subtitle="تجربه‌ای هماهنگ با سلیقه شما" eyebrow="Theme" />
          <div className="grid grid-cols-2 gap-3">
            {([
              { key: "dark" as const, title: "حالت تاریک", desc: "تمرکز بیشتر، مناسب ترید شبانه", icon: Moon, preview: "linear-gradient(140deg,#101a37,#060a13)" },
              { key: "light" as const, title: "حالت روشن", desc: "شفاف و خوانا در نور روز", icon: Sun, preview: "linear-gradient(140deg,#ffffff,#dbe6fa)" },
            ]).map((t) => (
              <button key={t.key} onClick={() => s.theme !== t.key && s.onToggleTheme()} className="press rounded-2xl border p-4 text-right transition-all" style={{ borderColor: s.theme === t.key ? "rgba(91,124,255,.55)" : "var(--border)", background: s.theme === t.key ? "rgba(91,124,255,.10)" : "var(--glass)", boxShadow: s.theme === t.key ? "0 10px 28px rgba(91,124,255,.18)" : undefined }}>
                <span className="block h-14 overflow-hidden rounded-xl border border-hairline" style={{ background: t.preview }}>
                  <span className="mx-3 mt-3 block h-2 w-1/2 rounded-full bg-[rgba(127,145,200,.4)]" />
                  <span className="mx-3 mt-2 block h-2 w-1/3 rounded-full bg-[rgba(127,145,200,.25)]" />
                </span>
                <span className="mt-3 flex items-center gap-2 text-[12px] font-extrabold"><t.icon size={15} className="t-accent" />{t.title}</span>
                <p className="mt-1 text-[9.5px] t-muted">{t.desc}</p>
                <p className="mt-3 flex items-center gap-1 text-[9.5px] font-bold t-accent">{s.theme === t.key ? <span className="flex items-center gap-1"><Check size={12} strokeWidth={3} /> انتخاب‌شده</span> : "انتخاب"}</p>
              </button>
            ))}
          </div>
        </div>

        <div className="surface rounded-[24px] p-4 sm:p-5">
          <SectionHead title="اعلان‌ها و اتصالات" subtitle="همیشه در جریان باشید" />
          {row("اعلان‌های لحظه‌ای", "سیگنال‌ها، ورود و خروج پوزیشن‌ها", alerts, (v) => { setAlerts(v); s.notify(`اعلان‌ها ${v ? "فعال" : "غیرفعال"} شد`); })}
          {row("ربات تلگرام ۲۴/۷", "گزارش روزانه و هشدارهای مهم", telegram, setTelegram)}
          {row("مدیریت ریسک محافظه‌کار", "محدود کردن اهرم و حجم هر معامله", reducedRisk, setReducedRisk)}
        </div>

        <div className="surface rounded-[24px] p-4 sm:p-5">
          <SectionHead title="صرافی و حساب" subtitle="اتصال حساب معاملاتی" />
          <div className="grid gap-2 sm:grid-cols-3">
            {["Paper Demo", "Toobit Futures", "KCEX Futures"].map((x) => (
              <button key={x} onClick={() => { setExchange(x); s.notify(`${x} انتخاب شد`); }} className="num press rounded-2xl border px-3 py-3 text-[10.5px] font-extrabold transition-all" style={{ borderColor: exchange === x ? "rgba(91,124,255,.55)" : "var(--border)", background: exchange === x ? "rgba(91,124,255,.10)" : "var(--glass)" }} dir="ltr">{x}</button>
            ))}
          </div>
          <div className="mt-4 flex items-center gap-3 rounded-2xl border border-hairline bg-[var(--glass)] p-3">
            <ShieldCheck size={18} className="shrink-0 t-mint" />
            <div><p className="text-[11px] font-bold">کلیدهای API امن هستند</p><p className="mt-0.5 text-[9.5px] t-muted">هیچ کلیدی در مرورگر یا مخزن کد ذخیره نمی‌شود.</p></div>
          </div>
          <button onClick={save} className="btn-primary mt-4 h-10 w-full rounded-xl text-[11px] font-bold">
            {saved ? <span className="flex items-center gap-1.5"><Check size={15} strokeWidth={3} /> ذخیره شد</span> : "ذخیره تغییرات"}
          </button>
        </div>
      </div>

      <div className="space-y-4 lg:col-span-4">
        <div className="surface rounded-[24px] p-4">
          <SectionHead title="پروفایل" subtitle="حساب کاربری" />
          <div className="flex items-center gap-3 rounded-2xl border border-hairline bg-[var(--glass)] p-3">
            <span className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl bg-gradient-to-br from-[#6f8cff] to-[#3453d4] text-[12px] font-extrabold text-white shadow-[0_6px_16px_rgba(70,105,235,.4)]">AK</span>
            <div className="min-w-0"><p className="text-[12px] font-extrabold">Avid Kiya</p><p className="num mt-0.5 text-[9.5px] t-faint" dir="ltr">owner · v6.0.0</p></div>
            <span className="mr-auto rounded-lg border border-[rgba(244,196,107,.35)] bg-[rgba(244,196,107,.14)] px-2 py-1 text-[9px] font-extrabold" style={{ color: "var(--amber)" }}>PRO</span>
          </div>
          <div className="mt-3 space-y-1">
            {[{ t: "حالت حرفه‌ای", v: s.proMode, f: s.onTogglePro }, { t: "اجرای خودکار ربات", v: s.botActive, f: s.onToggleBot }, { t: "نمایش موجودی", v: !s.balanceHidden, f: (_v: boolean) => s.onToggleHidden() }].map((r) => (
              <div key={r.t} className="flex items-center justify-between rounded-xl px-1 py-1.5"><span className="text-[10.5px] font-semibold t-muted">{r.t}</span><Switch checked={r.v} onChange={(val) => r.f(val)} label={r.t} /></div>
            ))}
          </div>
        </div>
        <div className="surface rounded-[24px] p-4">
          <SectionHead title="زبان و منطقه" subtitle="نمایش اعداد و تاریخ" />
          <button onClick={() => s.notify("زبان فارسی در حال حاضر زبان فعال ترمینال است")} className="input flex h-11 items-center justify-between rounded-xl px-3 text-[11px]"><span className="flex items-center gap-2"><Globe2 size={15} className="t-accent" /> فارسی (ایران)</span><ChevronDown size={15} className="t-faint" /></button>
          <div className="mt-3 flex items-center gap-2 rounded-xl border border-hairline bg-[var(--glass)] p-3 text-[10px] t-muted"><Bell size={14} className="shrink-0 t-accent" /> منطقه زمانی: Asia/Tehran (UTC+3:30)</div>
        </div>
        <div className="surface rounded-[24px] p-4">
          <SectionHead title="درباره دلارینو" subtitle="نسخه v6.0.0" />
          <div className="space-y-2 text-[10px] leading-6 t-muted">
            <p>ترمینال هوشمند چندارزی مبتنی بر Cloudflare Workers، D1 و Durable Objects.</p>
            <p className="num flex items-center justify-between border-t border-hairline pt-2" dir="ltr"><span>Status</span><span className="flex items-center gap-1.5 t-mint"><LiveDot /> All systems operational</span></p>
            <button onClick={() => s.notify("حساب دمو ریست شد و موجودی به حالت اولیه برگشت")} className="h-9 w-full rounded-xl border border-[rgba(255,113,133,.3)] text-[10.5px] font-bold transition-colors hover:bg-[rgba(255,113,133,.08)]" style={{ color: "var(--rose)" }}>ریست حساب دمو</button>
          </div>
        </div>
      </div>
    </div>
  );
}
