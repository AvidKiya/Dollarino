import { useState } from "react";
import { Check, Download, Loader2, Sparkles } from "lucide-react";
import { Sparkline } from "./Charts";
import { AnimatedNumber, Logo } from "./UI";

const weekValues = [22, 27, 24, 33, 30, 39, 36, 47, 44, 56];

export function WeeklyCard({ notify, compact = false }: { notify: (message: string) => void; compact?: boolean }) {
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState(false);
  const exportCard = async () => {
    if (busy) return;
    setBusy(true);
    try {
      await document.fonts.ready;
      const canvas = document.createElement("canvas");
      canvas.width = 1080;
      canvas.height = 1350;
      const ctx = canvas.getContext("2d");
      if (!ctx) return;
      const bg = ctx.createLinearGradient(0, 0, 1080, 1350);
      bg.addColorStop(0, "#1d2d5e");
      bg.addColorStop(0.55, "#101a37");
      bg.addColorStop(1, "#081026");
      ctx.fillStyle = bg;
      ctx.fillRect(0, 0, 1080, 1350);
      const glow = ctx.createRadialGradient(980, 80, 10, 980, 80, 700);
      glow.addColorStop(0, "rgba(118,142,255,.45)");
      glow.addColorStop(1, "rgba(118,142,255,0)");
      ctx.fillStyle = glow;
      ctx.fillRect(0, 0, 1080, 1350);
      const glow2 = ctx.createRadialGradient(80, 1300, 10, 80, 1300, 650);
      glow2.addColorStop(0, "rgba(45,214,175,.22)");
      glow2.addColorStop(1, "rgba(45,214,175,0)");
      ctx.fillStyle = glow2;
      ctx.fillRect(0, 0, 1080, 1350);

      ctx.textAlign = "right";
      ctx.direction = "rtl";
      ctx.fillStyle = "rgba(255,255,255,.62)";
      ctx.font = "500 34px Vazirmatn, Tahoma, sans-serif";
      ctx.fillText("گزارش عملکرد هفتگی", 990, 170);
      ctx.fillStyle = "#ffffff";
      ctx.font = "800 62px Vazirmatn, Tahoma, sans-serif";
      ctx.fillText("Dollarino.", 990, 240);
      ctx.textAlign = "left";
      ctx.fillStyle = "rgba(255,255,255,.45)";
      ctx.font = "600 28px Inter, sans-serif";
      ctx.fillText("WEEKLY REPORT  /  V6.0", 90, 220);

      ctx.textAlign = "right";
      ctx.fillStyle = "rgba(255,255,255,.65)";
      ctx.font = "500 34px Vazirmatn, Tahoma, sans-serif";
      ctx.fillText("سود خالص هفته", 990, 430);
      ctx.fillStyle = "#61e5b6";
      ctx.font = "800 132px Inter, Vazirmatn, sans-serif";
      ctx.textAlign = "left";
      ctx.fillText("+18.6%", 90, 560);
      ctx.fillStyle = "rgba(255,255,255,.78)";
      ctx.font = "600 42px Inter, sans-serif";
      ctx.fillText("+$1,501.40", 90, 625);

      const boxes = [
        { label: "وین ریت", value: "82.9%" },
        { label: "معاملات", value: "47" },
        { label: "بهترین ارز", value: "BTC" },
      ];
      boxes.forEach((b, i) => {
        const x = 90 + i * 305;
        ctx.fillStyle = "rgba(255,255,255,.065)";
        ctx.beginPath();
        ctx.roundRect(x, 720, 280, 220, 34);
        ctx.fill();
        ctx.strokeStyle = "rgba(255,255,255,.12)";
        ctx.lineWidth = 2;
        ctx.stroke();
        ctx.textAlign = "center";
        ctx.fillStyle = "rgba(255,255,255,.6)";
        ctx.font = "500 28px Vazirmatn, Tahoma, sans-serif";
        ctx.fillText(b.label, x + 140, 800);
        ctx.fillStyle = "#ffffff";
        ctx.font = "800 58px Inter, Vazirmatn, sans-serif";
        ctx.fillText(b.value, x + 140, 885);
      });

      ctx.strokeStyle = "rgba(97,229,182,.9)";
      ctx.lineWidth = 9;
      ctx.lineJoin = "round";
      ctx.lineCap = "round";
      ctx.beginPath();
      weekValues.forEach((v, i) => {
        const px = 110 + (i / (weekValues.length - 1)) * 860;
        const py = 1160 - v * 5;
        if (i === 0) ctx.moveTo(px, py);
        else ctx.lineTo(px, py);
      });
      ctx.stroke();

      ctx.textAlign = "right";
      ctx.direction = "rtl";
      ctx.fillStyle = "rgba(255,255,255,.5)";
      ctx.font = "500 28px Vazirmatn, Tahoma, sans-serif";
      ctx.fillText("هوش مصنوعی دلارینو · موتور دُرّبین", 990, 1270);
      ctx.textAlign = "left";
      ctx.fillStyle = "rgba(255,255,255,.35)";
      ctx.font = "600 26px Inter, sans-serif";
      ctx.fillText("dollarino.app", 90, 1270);

      const link = document.createElement("a");
      link.download = "dollarino-weekly.png";
      link.href = canvas.toDataURL("image/png");
      link.click();
      setDone(true);
      notify("کارت هفتگی با کیفیت بالا دانلود شد");
      setTimeout(() => setDone(false), 2400);
    } catch {
      notify("خطا در ساخت کارت، دوباره تلاش کنید");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="surface rounded-[24px] p-4">
      <div className={`weekly-card relative overflow-hidden ${compact ? "rounded-[18px] p-4" : "rounded-[20px] p-5"}`}>
        <div className="pointer-events-none absolute -left-8 bottom-2 select-none text-[140px] font-black leading-none text-white/[.045]" dir="ltr">D</div>
        <div className="relative flex items-start justify-between">
          <div>
            <div className="num text-[9px] font-bold tracking-[.18em] text-white/50" dir="ltr">WEEKLY REPORT</div>
            <div className="mt-1 text-[11px] font-semibold text-white/75">عملکرد هفتگی</div>
          </div>
          <span className="grid h-8 w-8 place-items-center rounded-xl bg-white/10 text-[#9df3d3]"><Sparkles size={15} /></span>
        </div>
        <div className="num relative mt-7 text-[40px] font-black leading-none tracking-tight text-[#7ee9be]" dir="ltr" style={{ textShadow: "0 0 30px rgba(126,233,190,.35)" }}><AnimatedNumber value={18.6} format={(n) => `+${n.toFixed(1)}%`} /></div>
        <p className="num mt-2 text-[11px] font-semibold text-white/65" dir="ltr">+$1,501.40 profit</p>
        <div className="relative mt-4 h-10"><Sparkline values={weekValues} color="#7ee9be" height={40} fill endDot /></div>
        <div className="relative mt-4 grid grid-cols-3 gap-2 border-t border-white/10 pt-4">
          {[{ l: "وین ریت", v: "82.9%" }, { l: "معاملات", v: "47" }, { l: "بهترین", v: "BTC" }].map((s) => (
            <div key={s.l}>
              <div className="num text-[13px] font-bold text-white" dir="ltr">{s.v}</div>
              <div className="mt-0.5 text-[9px] text-white/50">{s.l}</div>
            </div>
          ))}
        </div>
      </div>
      <div className="mt-3 flex items-center justify-between gap-2">
        <Logo compact />
        <button onClick={exportCard} disabled={busy} className="btn-ghost h-9 rounded-xl px-3 text-[11px] font-bold disabled:opacity-60">
          {busy ? <Loader2 size={14} className="animate-spin" /> : done ? <Check size={14} strokeWidth={3} className="t-mint" /> : <Download size={14} />}
          {busy ? "در حال ساخت..." : done ? "دانلود شد" : "خروجی PNG"}
        </button>
      </div>
    </div>
  );
}
