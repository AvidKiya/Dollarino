import { useEffect, useRef, useState } from "react";
import { ArrowDownRight, ArrowUpRight, Check, ChevronLeft, SearchX, X } from "lucide-react";
import type { LucideIcon } from "lucide-react";
import { engineById, fmt, money, pct, priceText, type Market, type Position } from "../data";
import { Sparkline } from "./Charts";
import { AnimatedNumber, CoinIcon, DirectionBadge, EngineChip, EmptyState, FlashText } from "./UI";

/* ---------------- Stat card ---------------- */
export function StatCard({
  label,
  value,
  raw,
  format,
  delta,
  icon: Icon,
  spark,
  color = "#7c92ff",
  positive = true,
}: {
  label: string;
  value?: string;
  raw?: number;
  format?: (n: number) => string;
  delta: string;
  icon: LucideIcon;
  spark: number[];
  color?: string;
  positive?: boolean;
}) {
  return (
    <div className="surface lift press group relative overflow-hidden rounded-[22px] p-4">
      <div className="pointer-events-none absolute -left-10 -top-10 h-28 w-28 rounded-full opacity-0 blur-3xl transition-opacity duration-500 group-hover:opacity-100" style={{ background: `${color}33` }} />
      <div className="relative flex items-start justify-between">
        <div
          className="grid h-9 w-9 place-items-center rounded-xl transition-transform duration-300 group-hover:scale-110"
          style={{ background: `linear-gradient(140deg, ${color}2e, ${color}0f)`, color, border: `1px solid ${color}33` }}
        >
          <Icon size={17} />
        </div>
        <span
          className="num flex items-center gap-0.5 rounded-lg border px-1.5 py-1 text-[10px] font-bold"
          style={{
            color: positive ? "var(--mint)" : "var(--rose)",
            background: positive ? "rgba(55,214,165,.09)" : "rgba(255,113,133,.09)",
            borderColor: positive ? "rgba(55,214,165,.22)" : "rgba(255,113,133,.22)",
          }}
          dir="ltr"
        >
          {positive ? <ArrowUpRight size={12} /> : <ArrowDownRight size={12} />}{delta}
        </span>
      </div>
      <p className="relative mt-4 text-[11px] font-medium t-muted">{label}</p>
      <p className="num relative mt-1 text-[20px] font-extrabold tracking-tight" dir="ltr">
        {raw !== undefined ? <AnimatedNumber value={raw} format={format ?? ((n) => n.toLocaleString("en-US"))} /> : value}
      </p>
      <div className="relative -mb-1 mt-1 h-8 opacity-90">
        <Sparkline values={spark} color={positive ? "#37d6a5" : "#ff7185"} height={32} endDot />
      </div>
    </div>
  );
}

/* ---------------- Market list with price flash ---------------- */
function useFlashKey(price: number) {
  const prev = useRef(price);
  const [dir, setDir] = useState<"up" | "down" | null>(null);
  useEffect(() => {
    if (prev.current === price) return;
    setDir(price > prev.current ? "up" : "down");
    prev.current = price;
    const t = setTimeout(() => setDir(null), 900);
    return () => clearTimeout(t);
  }, [price]);
  return dir;
}

function MarketRow({ m, onSelect, rank }: { m: Market; onSelect?: (m: Market) => void; rank: number }) {
  const dir = useFlashKey(m.price);
  return (
    <button
      onClick={() => onSelect?.(m)}
      className="group flex w-full items-center gap-2.5 rounded-2xl border border-transparent px-2 py-2 text-right transition-all duration-200 hover:border-[var(--border)] hover:bg-[var(--glass)]"
    >
      <span className="num w-4 text-center text-[9px] font-bold t-faint" dir="ltr">{rank}</span>
      <CoinIcon symbol={m.symbol} color={m.color} size={34} />
      <div className="min-w-0 text-right">
        <div className="num text-[11.5px] font-bold" dir="ltr">{m.symbol}</div>
        <div className="truncate text-[9.5px] t-faint">{m.name}</div>
      </div>
      <div className="mx-1 hidden h-7 w-[64px] shrink-0 sm:block">
        <Sparkline values={m.spark} color={m.change >= 0 ? "#37d6a5" : "#ff7185"} height={28} animated={false} />
      </div>
      <div className="mr-auto text-left">
        <div className={`num text-[11px] font-bold ${dir === "up" ? "flash-up" : dir === "down" ? "flash-down" : ""}`} dir="ltr">
          ${priceText(m.price)}
        </div>
        <div
          className="num mt-0.5 inline-block rounded-md px-1.5 py-px text-[9px] font-bold"
          style={{ color: m.change >= 0 ? "var(--mint)" : "var(--rose)", background: m.change >= 0 ? "rgba(55,214,165,.10)" : "rgba(255,113,133,.10)" }}
          dir="ltr"
        >
          {pct(m.change)}
        </div>
      </div>
      <ChevronLeft size={13} className="t-faint opacity-0 transition-all duration-200 group-hover:-translate-x-0.5 group-hover:opacity-100" />
    </button>
  );
}

export function MarketList({ markets, limit = 6, onSelect }: { markets: Market[]; limit?: number; onSelect?: (m: Market) => void }) {
  return (
    <div className="space-y-0.5">
      {markets.slice(0, limit).map((m, i) => (
        <MarketRow key={m.symbol} m={m} rank={i + 1} onSelect={onSelect} />
      ))}
    </div>
  );
}

/* ---------------- Positions table with two-tap close ---------------- */
function CloseButton({ armed, onClick, label }: { armed: boolean; onClick: () => void; label: string }) {
  return (
    <button
      onClick={onClick}
      aria-label={label}
      className="icon-btn h-8 rounded-lg border px-2 text-[10px] font-bold"
      style={
        armed
          ? { color: "#fff", background: "var(--rose)", borderColor: "var(--rose)" }
          : { borderColor: "var(--border)" }
      }
    >
      {armed ? <span className="flex items-center gap-1"><Check size={13} strokeWidth={3} /> تأیید</span> : <X size={14} />}
    </button>
  );
}

export function PositionsTable({
  positions,
  onClose,
  emptyText = "پوزیشن بازی وجود ندارد",
}: {
  positions: Position[];
  onClose?: (id: string) => void;
  emptyText?: string;
}) {
  const [arming, setArming] = useState<string | null>(null);
  useEffect(() => {
    if (!arming) return;
    const t = setTimeout(() => setArming(null), 2600);
    return () => clearTimeout(t);
  }, [arming]);

  const handleClose = (id: string) => {
    if (arming === id) {
      setArming(null);
      onClose?.(id);
    } else {
      setArming(id);
    }
  };

  if (positions.length === 0) {
    return <EmptyState icon={<SearchX size={22} />} title="موردی پیدا نشد" desc={emptyText} />;
  }

  return (
    <>
      <div className="hidden overflow-x-auto md:block scroll-thin">
        <table className="w-full min-w-[660px] text-right text-[11px]">
          <thead>
            <tr className="border-b border-hairline text-[10px] t-faint">
              <th className="pb-3 pr-2 font-semibold">ارز</th>
              <th className="pb-3 font-semibold">جهت / اهرم</th>
              <th className="pb-3 font-semibold">ورود</th>
              <th className="pb-3 font-semibold">فعلی</th>
              <th className="pb-3 font-semibold">سود شناور</th>
              <th className="pb-3 font-semibold">موتور</th>
              {onClose && <th className="pb-3 pl-2 font-semibold"></th>}
            </tr>
          </thead>
          <tbody>
            {positions.map((p) => {
              const engine = engineById(p.engine);
              return (
                <tr key={p.id} className="group border-b border-hairline/60 transition-colors last:border-0 hover:bg-[var(--glass)]">
                  <td className="py-2.5 pr-2">
                    <div className="flex items-center gap-2.5">
                      <CoinIcon symbol={p.symbol} color={p.color} size={32} />
                      <div><div className="num font-bold" dir="ltr">{p.symbol}/USDT</div><div className="text-[9.5px] t-faint">{p.name}</div></div>
                    </div>
                  </td>
                  <td><DirectionBadge side={p.side} leverage={p.leverage} /></td>
                  <td className="num t-muted" dir="ltr">${priceText(p.entry)}</td>
                  <td><FlashText value={p.mark} format={(n) => `$${priceText(n)}`} className="font-semibold" /></td>
                  <td>
                    <FlashText value={p.pnl} format={(n) => money(n)} positive={p.pnl >= 0} className="text-[11.5px] font-extrabold" />
                    <div className="num mt-0.5 text-[9px] t-faint" dir="ltr">{pct(p.pnlPct)}</div>
                  </td>
                  <td><EngineChip label={engine.label} color={engine.color} /></td>
                  {onClose && (
                    <td className="pl-2 text-left">
                      <CloseButton armed={arming === p.id} onClick={() => handleClose(p.id)} label={`بستن ${p.symbol}`} />
                    </td>
                  )}
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      <div className="space-y-2.5 md:hidden">
        {positions.map((p) => {
          const engine = engineById(p.engine);
          const barW = Math.min(100, Math.abs(p.pnlPct) * 12);
          return (
            <div key={p.id} className="rounded-2xl border border-hairline bg-[var(--glass)] p-3.5" style={{ boxShadow: "var(--inner)" }}>
              <div className="flex items-center gap-2.5">
                <CoinIcon symbol={p.symbol} color={p.color} size={36} />
                <div className="min-w-0">
                  <div className="num text-[12px] font-bold" dir="ltr">{p.symbol}/USDT</div>
                  <div className="mt-0.5 text-[10px] t-faint">{p.name} · {engine.label}</div>
                </div>
                <div className="mr-auto"><DirectionBadge side={p.side} leverage={p.leverage} /></div>
              </div>
              <div className="mt-3 h-1 overflow-hidden rounded-full bg-[var(--border)]">
                <div
                  className="h-full rounded-full transition-all duration-700"
                  style={{ width: `${barW}%`, background: p.pnl >= 0 ? "linear-gradient(90deg,#37d6a5,#7ee9be)" : "linear-gradient(90deg,#ff7185,#ff9d9d)" }}
                />
              </div>
              <div className="mt-3 flex items-end justify-between border-t border-hairline pt-3">
                <div><div className="text-[9px] t-faint">قیمت فعلی</div><FlashText value={p.mark} format={(n) => `$${priceText(n)}`} className="mt-0.5 block text-[11px] font-semibold" /></div>
                <div><div className="text-[9px] t-faint">حجم</div><div className="num mt-0.5 text-[11px] font-semibold" dir="ltr">${fmt(p.size, 0)}</div></div>
                <div className="text-left">
                  <div className="text-[9px] t-faint">سود شناور</div>
                  <FlashText value={p.pnl} format={(n) => money(n)} positive={p.pnl >= 0} className="mt-0.5 block text-[13px] font-extrabold" />
                </div>
                {onClose && <CloseButton armed={arming === p.id} onClick={() => handleClose(p.id)} label="بستن پوزیشن" />}
              </div>
            </div>
          );
        })}
      </div>
    </>
  );
}

export function LinkButton({ children, onClick }: { children: React.ReactNode; onClick: () => void }) {
  return (
    <button onClick={onClick} className="group flex shrink-0 items-center gap-0.5 text-[11px] font-bold t-accent transition-opacity hover:opacity-75">
      {children}<ChevronLeft size={14} className="transition-transform group-hover:-translate-x-0.5" />
    </button>
  );
}
