export type NavKey =
  | "overview"
  | "trades"
  | "signals"
  | "performance"
  | "engines"
  | "wallet"
  | "settings";

export type EngineId = "ai" | "strategy" | "copy";
export type Timeframe = "7D" | "30D" | "90D";
export type Side = "long" | "short";

export interface Engine {
  id: EngineId;
  name: string;
  latin: string;
  label: string;
  description: string;
  color: string;
  badge: string;
  winRate: number;
  trades: number;
  details: string[];
}

export interface Position {
  id: string;
  symbol: string;
  name: string;
  color: string;
  side: Side;
  leverage: number;
  entry: number;
  mark: number;
  size: number;
  pnl: number;
  pnlPct: number;
  engine: EngineId;
}

export interface Market {
  symbol: string;
  name: string;
  color: string;
  price: number;
  change: number;
  spark: number[];
}

export interface Signal {
  id: string;
  time: string;
  symbol: string;
  side: Side;
  confidence: number;
  engine: EngineId;
  entry: string;
  status: "active" | "closed" | "waiting";
}

export const pageTitles: Record<NavKey, { title: string; subtitle: string }> = {
  overview: { title: "نمای کلی", subtitle: "یک نگاه به همه چیز، همین حالا" },
  trades: { title: "معاملات", subtitle: "مدیریت پوزیشن‌های باز و تاریخچه" },
  signals: { title: "سیگنال‌ها", subtitle: "خروجی لحظه‌ای موتورهای دلارینو" },
  performance: { title: "عملکرد", subtitle: "تحلیل سود، ریسک و ثبات استراتژی" },
  engines: { title: "موتورها", subtitle: "سه موتور رسمی، یک ترمینال" },
  wallet: { title: "کیف پول", subtitle: "موجودی، تخصیص سرمایه و تراکنش‌ها" },
  settings: { title: "تنظیمات", subtitle: "ترمینال را به سبک خودت بچین" },
};

export const engines: Engine[] = [
  {
    id: "ai",
    name: "هوش مصنوعی دلارینو",
    latin: "DORRBIN AI",
    label: "موتور دُرّبین",
    description: "ترکیب هوشمند چند مدل AI برای تحلیل روند، اخبار و نقدینگی بازار.",
    color: "#7c92ff",
    badge: "هوشمندترین",
    winRate: 86.4,
    trades: 1428,
    details: ["DeepSeek · Claude · GPT · Gemini", "تحلیل چندعاملی بدون نیاز به API شخصی", "تصمیم‌گیری تطبیقی در هر تایم‌فریم"],
  },
  {
    id: "strategy",
    name: "استراتژی منتخب دلارینو",
    latin: "DORNA V1",
    label: "موتور دُرنا V1",
    description: "ترکیب روند، مومنتوم، شکار نقدینگی و ریبون غیرریپینت.",
    color: "#37d6a5",
    badge: "رایگان در دمو",
    winRate: 78.2,
    trades: 2146,
    details: ["فیلتر روند و مومنتوم", "شکار نقدینگی هوشمند", "اندیکاتورهای غیرریپینت"],
  },
  {
    id: "copy",
    name: "کپی ترید دلارینو",
    latin: "COPY TRADE",
    label: "سیگنال‌یاب لحظه‌ای",
    description: "کپی خودکار سیگنال‌ها از کانال رسمی، کانال اختصاصی یا TradingView.",
    color: "#f4c46b",
    badge: "آنلاین",
    winRate: 81.7,
    trades: 934,
    details: ["کانال رسمی @Dollarinoofficial", "پشتیبانی TradingView Webhook", "اجرای زیر یک ثانیه"],
  },
];

export const engineById = (id: EngineId) => engines.find((e) => e.id === id) ?? engines[0];

export const initialPositions: Position[] = [
  { id: "p1", symbol: "BTC", name: "بیت‌کوین", color: "#f7a63b", side: "long", leverage: 10, entry: 67420.5, mark: 69184.2, size: 4800, pnl: 125.4, pnlPct: 2.62, engine: "ai" },
  { id: "p2", symbol: "ETH", name: "اتریوم", color: "#8aa2e8", side: "long", leverage: 8, entry: 3482.8, mark: 3561.4, size: 3200, pnl: 91.2, pnlPct: 2.26, engine: "strategy" },
  { id: "p3", symbol: "SOL", name: "سولانا", color: "#9b6cf5", side: "short", leverage: 12, entry: 178.42, mark: 173.16, size: 2600, pnl: 76.6, pnlPct: 2.95, engine: "copy" },
  { id: "p4", symbol: "XRP", name: "ریپل", color: "#c8d4e8", side: "long", leverage: 5, entry: 0.6134, mark: 0.6281, size: 1800, pnl: 43.1, pnlPct: 2.40, engine: "ai" },
  { id: "p5", symbol: "AVAX", name: "اولانچ", color: "#ff6b6b", side: "short", leverage: 6, entry: 38.24, mark: 38.91, size: 1400, pnl: -24.5, pnlPct: -1.75, engine: "strategy" },
  { id: "p6", symbol: "LINK", name: "چین‌لینک", color: "#4f8bff", side: "long", leverage: 7, entry: 17.82, mark: 18.34, size: 1600, pnl: 46.7, pnlPct: 2.92, engine: "copy" },
  { id: "p7", symbol: "TON", name: "تون‌کوین", color: "#36b6e8", side: "long", leverage: 5, entry: 7.24, mark: 7.41, size: 1200, pnl: 28.2, pnlPct: 2.35, engine: "ai" },
  { id: "p8", symbol: "DOGE", name: "دوج‌کوین", color: "#d5b46c", side: "short", leverage: 4, entry: 0.1642, mark: 0.1668, size: 900, pnl: -14.2, pnlPct: -1.58, engine: "strategy" },
];

export const initialMarkets: Market[] = [
  { symbol: "BTC", name: "بیت‌کوین", color: "#f7a63b", price: 69184.2, change: 2.34, spark: [22, 25, 23, 29, 27, 34, 32, 38, 35, 43] },
  { symbol: "ETH", name: "اتریوم", color: "#8aa2e8", price: 3561.4, change: 1.86, spark: [20, 22, 19, 24, 26, 23, 29, 31, 30, 35] },
  { symbol: "SOL", name: "سولانا", color: "#9b6cf5", price: 173.16, change: -0.92, spark: [38, 36, 34, 35, 31, 29, 30, 27, 25, 23] },
  { symbol: "XRP", name: "ریپل", color: "#c8d4e8", price: 0.6281, change: 3.12, spark: [18, 20, 19, 25, 24, 28, 26, 31, 34, 38] },
  { symbol: "BNB", name: "بایننس کوین", color: "#e8c55b", price: 604.72, change: 0.74, spark: [26, 24, 27, 25, 29, 28, 30, 29, 32, 33] },
  { symbol: "TON", name: "تون", color: "#36b6e8", price: 7.41, change: 1.28, spark: [21, 23, 22, 26, 25, 27, 26, 30, 32, 34] },
];

export const signals: Signal[] = [
  { id: "s1", time: "۱۴:۳۲", symbol: "BTC/USDT", side: "long", confidence: 94, engine: "ai", entry: "69,120 – 69,340", status: "active" },
  { id: "s2", time: "۱۴:۲۱", symbol: "SOL/USDT", side: "short", confidence: 88, engine: "copy", entry: "178.20 – 179.10", status: "active" },
  { id: "s3", time: "۱۳:۵۸", symbol: "ETH/USDT", side: "long", confidence: 82, engine: "strategy", entry: "3,476 – 3,498", status: "closed" },
  { id: "s4", time: "۱۳:۴۰", symbol: "XRP/USDT", side: "long", confidence: 91, engine: "ai", entry: "0.6120 – 0.6150", status: "active" },
  { id: "s5", time: "۱۳:۰۶", symbol: "LINK/USDT", side: "long", confidence: 79, engine: "copy", entry: "17.72 – 17.90", status: "waiting" },
  { id: "s6", time: "۱۲:۴۴", symbol: "AVAX/USDT", side: "short", confidence: 85, engine: "strategy", entry: "38.10 – 38.45", status: "closed" },
];

export const transactions = [
  { id: "t1", title: "سود معامله BTC/USDT", date: "امروز، ۱۴:۳۲", amount: 125.4, type: "profit" },
  { id: "t2", title: "واریز به حساب دمو", date: "دیروز، ۲۰:۱۴", amount: 5000, type: "deposit" },
  { id: "t3", title: "سود معامله SOL/USDT", date: "دیروز، ۱۸:۰۲", amount: 76.6, type: "profit" },
  { id: "t4", title: "کارمزد شبکه", date: "۲ تیر، ۱۱:۴۰", amount: -3.2, type: "fee" },
  { id: "t5", title: "سود معامله ETH/USDT", date: "۱ تیر، ۲۲:۱۸", amount: 91.2, type: "profit" },
];

const noise = (i: number, seed: number) => {
  const x = Math.sin(i * 12.9898 + seed * 78.233) * 43758.5453;
  return x - Math.floor(x);
};

function makeSeries(seed: number, start: number, end: number, points = 56) {
  const values: number[] = [];
  let drift = 0;
  for (let i = 0; i < points; i++) {
    const t = i / (points - 1);
    drift += (noise(i, seed) - 0.46) * (end - start) * 0.11;
    const wave = Math.sin(i * 0.44 + seed) * (end - start) * 0.055 + Math.sin(i * 0.16 + seed * 2) * (end - start) * 0.045;
    values.push(start + (end - start) * t + wave + drift);
  }
  values[values.length - 1] = end;
  return values;
}

export const chartSeries: Record<Timeframe, number[]> = {
  "7D": makeSeries(1, 23100, 24850, 48),
  "30D": makeSeries(2, 18200, 24850, 60),
  "90D": makeSeries(3, 12800, 24850, 72),
};

export const chartLabels: Record<Timeframe, string[]> = {
  "7D": ["شنبه", "یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه"],
  "30D": ["۱ تیر", "۵ تیر", "۱۰ تیر", "۱۵ تیر", "۲۰ تیر", "۲۵ تیر", "امروز"],
  "90D": ["فروردین", "اردیبهشت", "خرداد", "تیر"],
};

export const weeklyBars = [
  { day: "ش", value: 62, pnl: 184 },
  { day: "ی", value: 78, pnl: 246 },
  { day: "د", value: 44, pnl: 128 },
  { day: "س", value: 91, pnl: 312 },
  { day: "چ", value: 70, pnl: 205 },
  { day: "پ", value: 86, pnl: 284 },
  { day: "ج", value: 54, pnl: 142 },
];

export const fmt = (n: number, digits = 2) =>
  new Intl.NumberFormat("en-US", { minimumFractionDigits: digits, maximumFractionDigits: digits }).format(Math.abs(n));

export const money = (n: number, digits = 2) => `${n < 0 ? "−" : ""}$${fmt(n, digits)}`;
export const pct = (n: number, digits = 2) => `${n > 0 ? "+" : n < 0 ? "−" : ""}${fmt(n, digits)}%`;

export const priceText = (n: number) => {
  if (n >= 1000) return fmt(n, 2);
  if (n >= 1) return fmt(n, 2);
  return fmt(n, 4);
};

export const todayLabel = () =>
  new Intl.DateTimeFormat("fa-IR", { weekday: "long", day: "numeric", month: "long" }).format(new Date());

export const greetingByHour = (h: number) =>
  h < 5 ? "نیمه‌شب بخیر" : h < 12 ? "صبح بخیر" : h < 17 ? "ظهر بخیر" : h < 20 ? "عصر بخیر" : "شب بخیر";

export interface AiInsight {
  id: string;
  tag: string;
  title: string;
  body: string;
  confidence: number;
  color: string;
}

export const aiBrief: AiInsight[] = [
  {
    id: "b1",
    tag: "مومنتوم",
    title: "قدرت خریدار در BTC ادامه دارد",
    body: "حجم معاملات اسپات ۲۳٪ بالاتر از میانگین هفتگی است و فاندینگ‌ریت در محدوده سالم قرار دارد.",
    confidence: 94,
    color: "#7c92ff",
  },
  {
    id: "b2",
    tag: "نقدینگی",
    title: "خوشه لیکوییدیشن زیر SOL",
    body: "تراکم نقدینگی در ۱۶۸ تا ۱۷۰ دلار، احتمال حرکت نزولی کوتاه‌مدت را بالا برده است.",
    confidence: 88,
    color: "#37d6a5",
  },
  {
    id: "b3",
    tag: "ریسک",
    title: "پیشنهاد سقف اهرم 10x برای امروز",
    body: "نوسان ضمنی بازار بالاست؛ دُرّبین پیشنهاد می‌کند اهرم معاملات جدید محدود بماند.",
    confidence: 91,
    color: "#f4c46b",
  },
];
