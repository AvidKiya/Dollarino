import type { EngineId, Market, NavKey, Position, Timeframe } from "./data";

export interface AppState {
  active: NavKey;
  onNavigate: (key: NavKey) => void;
  notify: (message: string) => void;
  theme: "dark" | "light";
  onToggleTheme: () => void;
  balance: number;
  balanceHidden: boolean;
  onToggleHidden: () => void;
  botActive: boolean;
  onToggleBot: (value: boolean) => void;
  proMode: boolean;
  onTogglePro: (value: boolean) => void;
  activeEngine: EngineId;
  onSelectEngine: (id: EngineId) => void;
  leverage: number;
  setLeverage: (value: number) => void;
  maxTrades: number;
  setMaxTrades: (value: number) => void;
  timeframe: Timeframe;
  setTimeframe: (value: Timeframe) => void;
  positions: Position[];
  onClosePosition: (id: string) => void;
  markets: Market[];
  onNewTrade: () => void;
}
