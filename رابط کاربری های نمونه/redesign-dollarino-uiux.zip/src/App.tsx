import Header from "./components/Header";
import Hero from "./components/Hero";
import Features from "./components/Features";
import Engines from "./components/Engines";
import Showcase from "./components/Showcase";
import Tools from "./components/Tools";
import Closing from "./components/Closing";

export default function App() {
  return (
    <div dir="rtl" className="min-h-screen overflow-x-clip bg-paper">
      <a
        href="#home"
        className="sr-only focus:not-sr-only focus:fixed focus:right-4 focus:top-4 focus:z-[60] focus:rounded-full focus:bg-ink focus:px-4 focus:py-2 focus:text-sm focus:text-white"
      >
        رفتن به محتوای اصلی
      </a>
      <Header />
      <main>
        <Hero />
        <Features />
        <Engines />
        <Showcase />
        <Tools />
        <Closing />
      </main>
    </div>
  );
}
