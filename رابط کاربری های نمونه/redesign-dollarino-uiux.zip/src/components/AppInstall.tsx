import { useEffect, useState } from "react";
import {
  Bell,
  Check,
  Download,
  Lock,
  Monitor,
  MoreVertical,
  PlusSquare,
  Share,
  Smartphone,
  Zap,
} from "lucide-react";
import { cn } from "../utils/cn";
import { AreaChart, LiveDot, LogoMark, Reveal } from "./ui";

type Platform = "android" | "ios" | "windows";

const platforms: {
  id: Platform;
  label: string;
  icon: typeof Smartphone;
  steps: { icon: typeof Share; text: string }[];
}[] = [
  {
    id: "android",
    label: "اندروید",
    icon: Smartphone,
    steps: [
      { icon: MoreVertical, text: "در Chrome روی منوی سه‌نقطه بزنید." },
      { icon: Download, text: "گزینه «نصب برنامه» را انتخاب کنید." },
      { icon: Check, text: "آیکون دلارینو روی صفحه اصلی اضافه می‌شود." },
    ],
  },
  {
    id: "ios",
    label: "آیفون",
    icon: Smartphone,
    steps: [
      { icon: Share, text: "در Safari دکمه اشتراک‌گذاری را بزنید." },
      { icon: PlusSquare, text: "«Add to Home Screen» را انتخاب کنید." },
      { icon: Check, text: "دلارینو مثل یک اپ واقعی، تمام‌صفحه باز می‌شود." },
    ],
  },
  {
    id: "windows",
    label: "ویندوز",
    icon: Monitor,
    steps: [
      { icon: Download, text: "در Chrome یا Edge روی آیکون نصب نوار آدرس بزنید." },
      { icon: Check, text: "«Install» را تأیید کنید." },
      { icon: Zap, text: "از منوی Start یا تسک‌بار، یک‌کلیکی وارد شوید." },
    ],
  },
];

type InstallPromptEvent = Event & { prompt: () => Promise<void> };

export default function AppInstall() {
  const [platform, setPlatform] = useState<Platform>("android");
  const [promptEvent, setPromptEvent] = useState<InstallPromptEvent | null>(null);
  const active = platforms.find((item) => item.id === platform) ?? platforms[0];

  useEffect(() => {
    const ua = navigator.userAgent.toLowerCase();
    if (/iphone|ipad|ipod/.test(ua)) setPlatform("ios");
    else if (/windows|macintosh/.test(ua)) setPlatform("windows");

    const onPrompt = (event: Event) => {
      event.preventDefault();
      setPromptEvent(event as InstallPromptEvent);
    };
    window.addEventListener("beforeinstallprompt", onPrompt);
    return () => window.removeEventListener("beforeinstallprompt", onPrompt);
  }, []);

  const install = async () => {
    if (promptEvent) {
      await promptEvent.prompt();
      setPromptEvent(null);
      return;
    }
    document.getElementById("install-steps")?.scrollIntoView({ behavior: "smooth", block: "center" });
  };

  return (
    <section id="app" className="pb-16 sm:pb-20 lg:pb-28">
      <div className="container-x">
        <div className="relative overflow-hidden rounded-[32px] bg-ink px-5 py-10 text-white sm:rounded-[40px] sm:px-10 sm:py-14 lg:px-14 lg:py-16">
          <div className="stars pointer-events-none absolute inset-0" />
          <div className="pointer-events-none absolute -left-24 -top-24 size-[420px] rounded-full bg-brand/35 blur-[110px]" />
          <div className="pointer-events-none absolute -bottom-28 right-10 size-[320px] rounded-full bg-cyan/15 blur-[100px]" />
          <div className="orbit pointer-events-none absolute -bottom-40 -right-24 size-[420px]" />

          <div className="relative grid items-center gap-10 lg:grid-cols-[1.1fr_0.9fr]">
            {/* copy */}
            <div>
              <span className="inline-flex items-center gap-2 rounded-full border border-white/12 bg-white/5 px-3 py-1.5 text-[11px] font-semibold text-white/75">
                <LiveDot dark />
                نسخه وب‌اپلیکیشن ویندوز و موبایل
              </span>
              <h2 className="mt-5 text-[1.85rem] font-extrabold leading-[1.45] tracking-[-0.035em] text-balance sm:text-[2.45rem] lg:text-[2.8rem]">
                دلارینو را مثل یک اپ واقعی
                <br className="hidden sm:block" /> <span className="text-gradient-cobalt">نصب کنید.</span>
              </h2>
              <p className="mt-4 max-w-lg text-[13px] leading-[2.05] text-white/55 sm:text-[14px]">
                تنها با یک کلیک، دلارینو روی دسکتاپ ویندوز یا صفحه اصلی موبایل نصب می‌شود؛ همیشه
                تمام‌صفحه، پرسرعت و با اعلان لحظه‌ای معاملات. بدون فروشگاه، بدون حجم اضافه.
              </p>

              <div className="mt-6 inline-flex rounded-full border border-white/12 bg-white/[0.05] p-1" role="tablist" aria-label="انتخاب سیستم‌عامل">
                {platforms.map((item) => (
                  <button
                    key={item.id}
                    type="button"
                    role="tab"
                    aria-selected={platform === item.id}
                    onClick={() => setPlatform(item.id)}
                    className={cn(
                      "flex items-center gap-1.5 rounded-full px-4 py-2 text-[11px] font-bold transition-all duration-300",
                      platform === item.id ? "bg-white text-ink" : "text-white/55 hover:text-white"
                    )}
                  >
                    <item.icon size={13} />
                    {item.label}
                  </button>
                ))}
              </div>

              <ol id="install-steps" key={platform} className="animate-rise mt-5 space-y-2">
                {active.steps.map((step, index) => (
                  <li
                    key={step.text}
                    className="flex items-center gap-3 rounded-2xl border border-white/10 bg-white/[0.04] px-3.5 py-3 backdrop-blur"
                  >
                    <span className="font-latin grid size-7 shrink-0 place-items-center rounded-full bg-brand/25 text-[10px] font-extrabold text-[#9cc0ff]">
                      {index + 1}
                    </span>
                    <span className="flex-1 text-[11.5px] font-semibold text-white/80">{step.text}</span>
                    <step.icon size={15} className="shrink-0 text-white/35" />
                  </li>
                ))}
              </ol>

              <div className="mt-6 flex flex-col gap-2.5 sm:flex-row">
                <button
                  type="button"
                  onClick={install}
                  className="group flex items-center justify-center gap-2 rounded-full bg-lime px-6 py-3.5 text-[12.5px] font-extrabold text-ink shadow-[0_14px_40px_-12px_rgba(22,230,100,0.7)] transition-colors hover:bg-white"
                >
                  <Download size={15} className="transition-transform group-hover:translate-y-0.5" />
                  نصب فوری اپ {active.label}
                </button>
                <a
                  href="#start"
                  className="flex items-center justify-center gap-2 rounded-full border border-white/15 bg-white/[0.06] px-6 py-3.5 text-[12.5px] font-bold text-white transition-colors hover:bg-white/[0.12]"
                >
                  ورود به نسخه وب
                </a>
              </div>

              <p className="mt-4 flex items-center gap-1.5 text-[10px] text-white/40">
                <Lock size={11} />
                رمزنگاری بانکی AES-256-GCM روی همه دستگاه‌ها
              </p>
            </div>

            {/* phone */}
            <Reveal delay={120}>
              <div className="relative mx-auto w-[248px] sm:w-[268px]">
                <div className="pointer-events-none absolute inset-6 -z-10 rounded-[60px] bg-brand/40 blur-[60px]" />
                <div className="rounded-[46px] border border-white/15 bg-gradient-to-b from-[#1b2a52] to-[#0a1328] p-2.5 shadow-lift">
                  <div className="relative overflow-hidden rounded-[38px] bg-[#040814]" style={{ aspectRatio: "9 / 19" }}>
                    <div className="absolute left-1/2 top-2.5 h-5 w-20 -translate-x-1/2 rounded-full bg-black" />
                    <div className="stars absolute inset-0 opacity-60" />
                    <div className="absolute -right-10 -top-10 size-40 rounded-full bg-brand/50 blur-3xl" />

                    <div className="relative flex h-full flex-col px-3.5 pb-4 pt-10">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-1.5">
                          <LogoMark className="size-7" />
                          <span className="text-[11px] font-extrabold">دلارینو</span>
                        </div>
                        <span className="relative grid size-7 place-items-center rounded-full bg-white/10">
                          <Bell size={12} />
                          <span className="absolute right-1.5 top-1.5 size-1.5 rounded-full bg-flame" />
                        </span>
                      </div>

                      <div className="btn-cobalt mt-4 rounded-2xl p-3">
                        <p className="text-[8px] text-white/70">کیف پول دلارینو</p>
                        <p dir="ltr" className="font-latin mt-1 text-right text-[19px] font-extrabold">$12,480.50</p>
                        <span className="mt-1.5 inline-flex rounded-full bg-lime px-1.5 py-0.5 font-latin text-[7px] font-extrabold text-ink">
                          +8.46%
                        </span>
                      </div>

                      <div className="mt-3 rounded-2xl border border-white/10 bg-white/[0.05] p-2.5">
                        <AreaChart values={[30, 34, 31, 40, 37, 46, 43, 52, 50, 60, 57, 68]} stroke="#16E664" fill="#16E664" height={64} />
                      </div>

                      <div className="mt-3 space-y-1.5">
                        {[
                          ["BTC/USDT", "+4.82%"],
                          ["ETH/USDT", "+2.16%"],
                          ["SOL/USDT", "+3.40%"],
                          ["AVAX/USDT", "+1.92%"],
                        ].map(([pair, pnl]) => (
                          <div key={pair} className="flex items-center justify-between rounded-xl bg-white/[0.05] px-2.5 py-2">
                            <span className="font-latin text-[8.5px] font-bold">{pair}</span>
                            <span className="font-latin text-[8.5px] font-extrabold text-lime">{pnl}</span>
                          </div>
                        ))}
                      </div>

                      {/* iOS dock */}
                      <div className="mt-auto flex items-center justify-around rounded-2xl border border-white/10 bg-white/[0.07] py-2 backdrop-blur">
                        {[0, 1, 2, 3].map((dot) => (
                          <span key={dot} className={cn("size-5 rounded-lg", dot === 0 ? "btn-cobalt" : "bg-white/10")} />
                        ))}
                      </div>
                    </div>
                  </div>
                </div>

                {/* notification */}
                <div className="animate-float absolute -left-10 top-24 w-[180px] rounded-2xl border border-white/15 bg-white/95 p-2.5 text-ink shadow-lift sm:-left-16">
                  <div className="flex items-center gap-2">
                    <LogoMark className="size-7" />
                    <div className="min-w-0">
                      <p className="text-[9px] font-extrabold">پوزیشن با سود بسته شد</p>
                      <p dir="ltr" className="font-latin mt-0.5 text-right text-[8.5px] font-bold text-up">BTC +$184.20</p>
                    </div>
                  </div>
                </div>
              </div>
            </Reveal>
          </div>
        </div>
      </div>
    </section>
  );
}
