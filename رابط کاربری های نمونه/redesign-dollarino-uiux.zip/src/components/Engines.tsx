import { useState } from "react";
import {
  ArrowLeft,
  ArrowUpRight,
  Bot,
  BrainCircuit,
  Check,
  Info,
  Link2,
  Radio,
  ShieldCheck,
  Sparkles,
  UserPlus,
  Workflow,
  Zap,
} from "lucide-react";
import { cn } from "../utils/cn";
import { AreaChart, CTA, LiveDot, LogoMark, Reveal, SectionHeading } from "./ui";

type EngineId = "ai" | "strategy" | "copy";

const tabs: {
  id: EngineId;
  label: string;
  name: string;
  title: string;
  desc: string;
  points: string[];
  note: string;
  icon: typeof Sparkles;
}[] = [
  {
    id: "ai",
    label: "هوش مصنوعی دلارینو",
    name: "دُربین",
    title: "سه مدل هوشمند، یک تصمیم مطمئن.",
    desc: "دُربین تحلیل‌های چند مدل هوش مصنوعی را کنار هم می‌گذارد، اختلاف نظرها را می‌سنجد و فقط وقتی تصویر روشن باشد وارد معامله می‌شود.",
    points: [
      "ترکیب هوشمند ۱ تا ۳ مدل پیشرفته",
      "انتخاب و مدیریت مدل‌ها توسط تیم دلارینو",
      "بدون نیاز به ثبت کلید API شخصی",
      "تحلیل شفاف، همراه با درصد اطمینان",
    ],
    note: "مناسب کسانی که می‌خواهند تصمیم‌گیری را به یک تحلیل جمعی و منظم بسپارند.",
    icon: BrainCircuit,
  },
  {
    id: "strategy",
    label: "استراتژی منتخب",
    name: "دُرنا V1",
    title: "یک استراتژی آزموده، در تمام بازارها.",
    desc: "دُرنا ترکیبی از روند، مومنتوم، شکار نقدینگی و ریبون غیرریپینت است؛ یک موتور آرام که به‌صورت خودکار خودش را با شرایط بازار هماهنگ می‌کند.",
    points: [
      "ترکیب چهار لایه تحلیلی مستقل",
      "ریبون غیرریپینت و سیگنال‌های پایدار",
      "شناسایی نقاط ورود و خروج نقدینگی",
      "رایگان در حساب دمو برای همه کاربران",
    ],
    note: "برای معامله‌گرانی که به یک قاعده مشخص و قابل تکرار اعتقاد دارند.",
    icon: Workflow,
  },
  {
    id: "copy",
    label: "کپی‌ترید دلارینو",
    name: "لحظه‌ای",
    title: "سیگنال، همان لحظه در حساب شما.",
    desc: "سیگنال‌های کانال رسمی دلارینو یا کانال اختصاصی خودتان را بدون تأخیر و بدون جا ماندن، به‌صورت خودکار در صرافی اجرا کنید.",
    points: [
      "اتصال به کانال @Dollarinoofficial",
      "پشتیبانی از کانال اختصاصی و Webhook",
      "اجرای خودکار با تنظیم ریسک دلخواه",
      "گزارش شفاف هر اجرا در پنل",
    ],
    note: "برای کسانی که تحلیل مورد اعتماد خود را دارند و فقط اجرای سریع می‌خواهند.",
    icon: Radio,
  },
];

/* -------------------------------------------------------------------------- */
/*                               Engine visuals                               */
/* -------------------------------------------------------------------------- */

function AiVisual() {
  return (
    <div className="relative">
      <div className="rounded-[24px] border border-line bg-white p-3.5 shadow-card">
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span className="grid size-8 place-items-center rounded-xl bg-brand-soft text-brand">
              <Sparkles size={15} />
            </span>
            <div className="leading-tight">
              <p className="text-[10.5px] font-extrabold text-ink">BTC/USDT</p>
              <p className="font-latin mt-0.5 text-[7.5px] tracking-wide text-muted">PERPETUAL · M15</p>
            </div>
          </div>
          <span className="flex items-center gap-1.5 rounded-full bg-mint/60 px-2 py-1 text-[8px] font-bold text-mint-deep">
            <LiveDot /> تحلیل زنده
          </span>
        </div>

        <div className="mt-3 space-y-1.5">
          {[
            { model: "GPT", note: "روند صعودی", score: 88, bg: "#101615" },
            { model: "Claude", note: "تأیید نقدینگی", score: 84, bg: "#c88a5a" },
            { model: "Gemini", note: "مومنتوم متوسط", score: 79, bg: "#5367d8" },
          ].map((row) => (
            <div key={row.model} className="flex items-center gap-2.5 rounded-xl border border-line/70 bg-paper/60 p-2.5">
              <span
                className="font-latin grid size-7 shrink-0 place-items-center rounded-full text-[9px] font-extrabold text-white"
                style={{ background: row.bg }}
              >
                {row.model.slice(0, 1)}
              </span>
              <div className="min-w-0 flex-1">
                <div className="flex items-center justify-between gap-2">
                  <p className="font-latin text-[9px] font-extrabold text-ink">{row.model}</p>
                  <p className="text-[8px] text-muted">{row.note}</p>
                </div>
                <div className="mt-1.5 h-1 overflow-hidden rounded-full bg-line">
                  <div className="h-full rounded-full bg-brand/50" style={{ width: `${row.score}%` }} />
                </div>
              </div>
              <span className="flex size-4 shrink-0 items-center justify-center rounded-full bg-mint text-mint-deep">
                <Check size={8} strokeWidth={4} />
              </span>
            </div>
          ))}
        </div>
      </div>

      <div className="relative z-10 mx-auto mt-2.5 flex items-center justify-center gap-2 rounded-[22px] border border-line bg-paper px-3 py-2.5 text-[9px] font-bold text-muted">
        <Sparkles size={12} className="text-brand" />
        هم‌گرایی نظر مدل‌ها
        <span className="font-latin rounded-full bg-white px-2 py-0.5 text-[8px] font-extrabold text-ink">3 / 3</span>
      </div>

      <div className="relative -mt-1 overflow-hidden rounded-[24px] bg-ink p-4 text-white shadow-lift">
        <div className="pointer-events-none absolute -right-12 -top-16 size-40 rounded-full bg-brand/40 blur-3xl" />
        <div className="relative flex items-center justify-between gap-3">
          <div>
            <p className="text-[8px] text-white/40">تصمیم نهایی دُربین</p>
            <p className="mt-1 text-[13px] font-extrabold">ورود خرید · تأییدشده</p>
            <div className="mt-2 flex items-center gap-1.5">
              <span className="rounded-full bg-mint-deep/20 px-2 py-1 text-[8px] font-bold text-[#4ef08f]">
                اجرای خودکار
              </span>
              <span className="font-latin rounded-full border border-white/10 px-2 py-1 text-[8px] font-bold text-white/40">
                LEV 10x
              </span>
            </div>
          </div>
          <div className="relative grid size-[76px] shrink-0 place-items-center">
            <svg viewBox="0 0 80 80" className="absolute inset-0 size-full -rotate-90">
              <circle cx="40" cy="40" r="33" fill="none" stroke="rgba(255,255,255,0.08)" strokeWidth="7" />
              <circle
                cx="40"
                cy="40"
                r="33"
                fill="none"
                stroke="#16E664"
                strokeWidth="7"
                strokeLinecap="round"
                strokeDasharray="207"
                strokeDashoffset="29"
              />
            </svg>
            <div className="text-center">
              <p className="font-latin text-[18px] font-extrabold leading-none">86%</p>
              <p className="mt-1 text-[7px] text-white/40">اطمینان</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function StrategyVisual() {
  const layers = [
    { label: "روند و ساختار بازار", value: 32 },
    { label: "مومنتوم و شتاب حرکت", value: 28 },
    { label: "شکار نقدینگی", value: 24 },
    { label: "ریبون غیرریپینت", value: 16 },
  ];

  return (
    <div className="relative">
      <div className="rounded-[24px] border border-line bg-white p-4 shadow-card">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="grid size-8 place-items-center rounded-xl bg-ink text-lime">
              <Workflow size={15} />
            </span>
            <div className="leading-tight">
              <p className="text-[10.5px] font-extrabold text-ink">دُرنا V1</p>
              <p className="font-latin mt-0.5 text-[7.5px] text-muted">MULTI-STRATEGY ENGINE</p>
            </div>
          </div>
          <span className="rounded-full border border-line bg-paper px-2 py-1 text-[8px] font-bold text-muted">
            BTC/USDT
          </span>
        </div>

        <div className="mt-4 space-y-3">
          {layers.map((layer, index) => (
            <div key={layer.label}>
              <div className="flex items-center justify-between text-[9px]">
                <span className="font-semibold text-ink/70">{layer.label}</span>
                <span className="font-latin font-extrabold text-ink">{layer.value}%</span>
              </div>
              <div className="mt-1.5 h-1.5 overflow-hidden rounded-full bg-paper-2">
                <div
                  className={cn(
                    "h-full rounded-full",
                    index === 0 ? "bg-brand" : index === 1 ? "bg-ink/75" : index === 2 ? "bg-[#8fa1ff]" : "bg-line"
                  )}
                  style={{ width: `${layer.value * 2.4}%` }}
                />
              </div>
            </div>
          ))}
        </div>

        <div className="mt-4 overflow-hidden rounded-xl bg-paper px-2 pt-3">
          <AreaChart values={[30, 34, 31, 38, 36, 44, 41, 48, 52, 50, 58, 56, 64, 61, 70]} stroke="#2b4bf2" height={70} />
        </div>

        <div className="mt-2 flex items-center justify-between rounded-xl border border-line bg-white px-2.5 py-2">
          <div className="flex items-center gap-1.5">
            <span className="rounded-full bg-mint px-2 py-1 text-[8px] font-extrabold text-mint-deep">سیگنال خرید</span>
            <span className="text-[8px] text-muted">همه فیلترها سبز</span>
          </div>
          <span className="font-latin text-[8px] font-bold text-up">4 / 4</span>
        </div>
      </div>

      <div className="relative z-10 mx-auto mt-2.5 flex max-w-[250px] items-center justify-between gap-2 rounded-full border border-line bg-white px-4 py-2.5 shadow-soft">
        <span className="flex items-center gap-1.5 text-[9px] font-bold text-ink/70">
          <ShieldCheck size={12} className="text-up" /> بدون ریپینت
        </span>
        <span className="h-3 w-px bg-line" />
        <span className="flex items-center gap-1.5 text-[9px] font-bold text-ink/70">
          <Zap size={12} className="text-brand" /> چرخش خودکار
        </span>
      </div>
    </div>
  );
}

function CopyVisual() {
  return (
    <div className="relative">
      <div className="overflow-hidden rounded-[24px] border border-line bg-white shadow-card">
        <div className="flex items-center gap-2 border-b border-line bg-paper/60 px-3.5 py-2.5">
          <LogoMark className="size-7 rounded-lg" />
          <div className="leading-tight">
            <p className="font-latin text-[9.5px] font-extrabold text-ink">Dollarino Official</p>
            <p className="font-latin mt-0.5 text-[7.5px] text-muted">@Dollarinoofficial</p>
          </div>
          <span className="mr-auto flex size-5 items-center justify-center rounded-full bg-brand/10 text-brand">
            <Radio size={11} />
          </span>
        </div>

        <div className="p-3.5">
          <div className="rounded-xl rounded-tr-sm border border-line bg-white p-3">
            <div className="flex items-center justify-between">
              <p className="font-latin text-[10px] font-extrabold text-ink">#BTCUSDT · LONG</p>
              <span className="font-latin text-[7.5px] text-muted">12:42</span>
            </div>
            <div className="mt-2 grid grid-cols-3 gap-1.5">
              {[
                ["Entry", "67,210", "text-ink"],
                ["Take Profit", "68,900", "text-up"],
                ["Stop Loss", "66,450", "text-danger"],
              ].map(([label, value, color]) => (
                <div key={label} className="rounded-lg bg-paper px-1.5 py-1.5">
                  <p className="font-latin text-[6.5px] uppercase tracking-wide text-muted">{label}</p>
                  <p className={cn("font-latin mt-0.5 text-[9px] font-extrabold", color)}>{value}</p>
                </div>
              ))}
            </div>
            <div className="mt-2 flex items-center gap-1.5 text-[8px] text-muted">
              <span className="font-latin rounded bg-brand-soft px-1.5 py-0.5 text-[7px] font-bold text-brand">10x</span>
              ریسک هر معامله ۱٪ از موجودی
            </div>
          </div>

          <div className="my-2 flex items-center justify-center gap-1.5 text-[7.5px] text-muted/60">
            <span className="h-3 w-px bg-line" />
            دریافت سیگنال
            <span className="h-3 w-px bg-line" />
          </div>

          <div className="rounded-xl border border-line bg-paper/70 p-2.5">
            <div className="flex items-center justify-between">
              <span className="flex items-center gap-1.5 text-[8.5px] font-bold text-ink/70">اجرای خودکار در صرافی</span>
              <span className="font-latin text-[7px] font-bold text-muted">0.8s</span>
            </div>
            <div className="mt-2 flex items-center justify-between rounded-lg bg-white px-2.5 py-2">
              <span className="flex items-center gap-1.5 text-[8.5px] font-extrabold text-mint-deep">
                <span className="grid size-4 place-items-center rounded-full bg-mint text-mint-deep">
                  <Check size={8} strokeWidth={4} />
                </span>
                پوزیشن باز شد
              </span>
              <span className="font-latin text-[7.5px] text-muted">#DR-2481</span>
            </div>
          </div>
        </div>
      </div>

      <div className="relative z-10 mx-auto mt-2.5 flex flex-wrap items-center justify-center gap-1.5">
        {["کانال رسمی", "کانال اختصاصی", "TradingView Webhook"].map((source) => (
          <span
            key={source}
            className="rounded-full border border-line bg-white px-2.5 py-1.5 text-[8px] font-bold text-ink/55 shadow-sm"
          >
            {source}
          </span>
        ))}
      </div>
    </div>
  );
}

/* -------------------------------------------------------------------------- */
/*                                  Engines                                   */
/* -------------------------------------------------------------------------- */

const steps = [
  {
    icon: UserPlus,
    title: "حساب دمو بسازید",
    desc: "در کمتر از دو دقیقه ثبت‌نام کنید و با قیمت زنده بازار شروع کنید. رایگان و بدون کارت بانکی.",
    meta: "۲ دقیقه",
  },
  {
    icon: Link2,
    title: "صرافی را وصل کنید",
    desc: "کلید API محدود به معامله در Toobit یا KCEX بسازید. بدون دسترسی برداشت، بدون ریسک نگهداری دارایی.",
    meta: "امن",
  },
  {
    icon: Bot,
    title: "ربات را روشن کنید",
    desc: "موتور، اهرم و سقف ریسک را انتخاب کنید. از این لحظه، دلارینو ۲۴/۷ بازار را رصد می‌کند.",
    meta: "۲۴/۷",
  },
];

export default function Engines() {
  const [active, setActive] = useState<EngineId>("ai");
  const engine = tabs.find((tab) => tab.id === active) ?? tabs[0];

  return (
    <>
      <section id="engines" className="border-y border-line bg-white py-16 sm:py-20 lg:py-24">
        <div className="container-x">
          <SectionHeading
            eyebrow="سه موتور، یک هدف"
            title="موتور معاملاتی‌ای که به آن اعتماد می‌کنید."
            desc="لازم نیست همه چیز را خودتان تحلیل کنید. یکی از سه موتور دلارینو را انتخاب کنید و در هر لحظه میان آن‌ها جابه‌جا شوید."
            center
          />

          <div className="mx-auto mt-8 flex max-w-[720px] gap-1 overflow-x-auto rounded-2xl border border-line bg-paper p-1.5 no-scrollbar sm:rounded-full">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                type="button"
                onClick={() => setActive(tab.id)}
                aria-pressed={active === tab.id}
                className={cn(
                  "flex shrink-0 flex-1 items-center justify-center gap-1.5 whitespace-nowrap rounded-xl px-3 py-2.5 text-[10.5px] font-bold transition-all duration-300 sm:rounded-full sm:px-4 sm:text-[11.5px]",
                  active === tab.id
                    ? "bg-white text-ink shadow-sm ring-1 ring-ink/5"
                    : "text-muted hover:text-ink"
                )}
              >
                <tab.icon size={13} className={active === tab.id ? "text-brand" : ""} />
                {tab.label}
              </button>
            ))}
          </div>

          <div key={active} className="animate-rise mt-8 grid items-center gap-8 lg:mt-12 lg:grid-cols-2 lg:gap-14">
            <div className="order-2 lg:order-1 lg:pl-4">
              <div className="relative mx-auto max-w-[400px]">
                <div className="pointer-events-none absolute inset-6 -z-10 rounded-[36px] bg-brand/10 blur-[60px]" />
                {active === "ai" ? <AiVisual /> : active === "strategy" ? <StrategyVisual /> : <CopyVisual />}
              </div>
            </div>

            <div className="order-1 lg:order-2">
              <div className="flex items-center gap-2.5">
                <span className="rounded-full bg-brand-soft px-2.5 py-1 text-[9.5px] font-extrabold tracking-wide text-brand">
                  موتور {tabs.findIndex((tab) => tab.id === active) + 1} از ۳
                </span>
                <span className="font-latin text-[11px] font-extrabold tracking-wide text-ink/35">{engine.name}</span>
              </div>

              <h3 className="mt-4 text-[24px] font-extrabold leading-[1.5] tracking-[-0.035em] text-ink sm:text-[30px]">
                {engine.title}
              </h3>
              <p className="mt-3 max-w-lg text-[13px] leading-[2.05] text-muted">{engine.desc}</p>

              <ul className="mt-6 grid gap-2.5 sm:grid-cols-2">
                {engine.points.map((point) => (
                  <li
                    key={point}
                    className="flex items-start gap-2 rounded-xl border border-line/70 bg-paper/60 px-3 py-2.5 text-[10.5px] font-semibold leading-relaxed text-ink/70"
                  >
                    <span className="mt-0.5 grid size-4 shrink-0 place-items-center rounded-full bg-mint text-mint-deep">
                      <Check size={9} strokeWidth={4} />
                    </span>
                    {point}
                  </li>
                ))}
              </ul>

              <div className="mt-5 flex items-start gap-2.5 rounded-2xl border border-dashed border-line bg-white px-4 py-3">
                <Info size={15} className="mt-0.5 shrink-0 text-brand" />
                <p className="text-[10.5px] leading-[1.9] text-muted">{engine.note}</p>
              </div>

              <div className="mt-6 flex flex-col gap-2.5 sm:flex-row sm:items-center">
                <CTA href="#start" variant="dark">
                  فعال‌سازی در حساب دمو
                </CTA>
                <a
                  href="#faq"
                  className="group inline-flex items-center justify-center gap-1.5 px-2 py-2 text-[12px] font-bold text-ink/60 transition-colors hover:text-ink"
                >
                  سوالات این موتور
                  <ArrowUpRight size={14} className="transition-transform group-hover:-translate-y-0.5" />
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ------------------------------- Steps ------------------------------- */}
      <section id="how" className="relative py-16 sm:py-20 lg:py-28">
        <div className="pointer-events-none absolute inset-x-0 top-1/3 -z-10 h-72 bg-gradient-to-b from-transparent via-mint/25 to-transparent" />
        <div className="container-x">
          <SectionHeading
            eyebrow="شروع، ساده‌تر از آنچه فکر می‌کنید"
            title="سه قدم تا اولین معامله خودکار."
            desc="از ثبت‌نام تا روشن شدن ربات، کمتر از یک فنجان قهوه وقت می‌برد."
            center
          />

          <div className="relative mt-10 grid gap-4 lg:mt-14 lg:grid-cols-3">
            {steps.map((step, index) => (
              <Reveal key={step.title} delay={index * 100}>
                <article className="group relative flex h-full flex-col overflow-hidden rounded-[28px] border border-line bg-white p-6 shadow-card transition-all duration-500 hover:-translate-y-1 hover:border-ink/20 hover:shadow-soft sm:p-7">
                  <span className="font-latin absolute left-5 top-4 text-[52px] font-extrabold leading-none tracking-tighter text-paper-2 transition-colors group-hover:text-brand-soft sm:text-[64px]">
                    0{index + 1}
                  </span>
                  <span className="relative grid size-11 place-items-center rounded-[14px] bg-paper text-ink ring-1 ring-line">
                    <step.icon size={19} />
                  </span>
                  <div className="relative mt-6">
                    <div className="flex items-center gap-2">
                      <h3 className="text-[17px] font-extrabold tracking-tight text-ink">{step.title}</h3>
                      <span className="rounded-full bg-mint/70 px-2 py-0.5 text-[8.5px] font-bold text-mint-deep">
                        {step.meta}
                      </span>
                    </div>
                    <p className="mt-2 text-[11.5px] leading-[2] text-muted">{step.desc}</p>
                  </div>
                  <div className="relative mt-auto flex items-center justify-between border-t border-line pt-4">
                    <span className="text-[9px] font-semibold text-muted/70">قدم {index + 1} از ۳</span>
                    <span className="grid size-7 place-items-center rounded-full bg-paper text-ink/60 transition-colors group-hover:bg-ink group-hover:text-white">
                      <ArrowLeft size={13} />
                    </span>
                  </div>
                </article>
              </Reveal>
            ))}
          </div>

          <Reveal delay={220}>
            <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row">
              <CTA href="#start">همین حالا شروع کنید</CTA>
              <span className="flex items-center gap-1.5 text-[10.5px] font-medium text-muted">
                <ShieldCheck size={13} className="text-up" />
                میانگین زمان راه‌اندازی: کمتر از ۲ دقیقه
              </span>
            </div>
          </Reveal>
        </div>
      </section>
    </>
  );
}
