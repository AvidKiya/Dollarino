import { useState } from "react";
import {
  ArrowLeft,
  ArrowUpRight,
  BarChart3,
  Check,
  Crown,
  FlaskConical,
  RefreshCw,
  Send,
  SlidersHorizontal,
  Sparkles,
} from "lucide-react";
import { cn } from "../utils/cn";
import { CTA, CoinBadge, LiveDot, LogoMark, Reveal, SectionHeading, Sparkline, coins, usd } from "./ui";

/* -------------------------------------------------------------------------- */
/*                                Social proof                                */
/* -------------------------------------------------------------------------- */

const exchanges = [
  { name: "PAPER DEMO", icon: FlaskConical, className: "font-latin tracking-[0.12em] text-[12px]" },
  { name: "toobit", icon: null, className: "font-latin font-extrabold lowercase tracking-[-0.03em] text-[21px]" },
  { name: "KCEX", icon: null, className: "font-latin font-extrabold italic tracking-[-0.04em] text-[21px]" },
  { name: "TradingView", icon: BarChart3, className: "font-latin font-bold tracking-[-0.03em] text-[18px]" },
  { name: "Telegram", icon: Send, className: "font-latin font-semibold tracking-[-0.02em] text-[17px]" },
];

const stats = [
  { value: "30+", label: "ارز پرمعامله", hint: "رصد مداوم بازار" },
  { value: "20", label: "پوزیشن همزمان", hint: "مدیریت خودکار" },
  { value: "24/7", label: "ربات فعال", hint: "بدون توقف" },
  { value: "50x", label: "اهرم آزاد", hint: "از ۱ تا ۵۰" },
];

function TrustStrip() {
  return (
    <section className="border-b border-line bg-paper">
      <div className="container-x py-10 sm:py-12">
        <Reveal>
          <p className="text-center text-[10px] font-bold uppercase tracking-[0.2em] text-muted/70">
            یکپارچه با ابزارها و صرافی‌هایی که می‌شناسید
          </p>
        </Reveal>
        <div className="mt-6 flex flex-wrap items-center justify-center gap-x-8 gap-y-5 sm:gap-x-12 lg:gap-x-16">
          {exchanges.map((exchange, index) => (
            <Reveal key={exchange.name} delay={index * 60}>
              <div className="group flex cursor-default items-center gap-1.5 text-ink/45 transition-colors duration-300 hover:text-ink">
                {exchange.icon && (
                  <exchange.icon
                    size={19}
                    strokeWidth={1.8}
                    className="transition-transform duration-300 group-hover:-translate-y-0.5"
                  />
                )}
                <span className={exchange.className}>{exchange.name}</span>
              </div>
            </Reveal>
          ))}
        </div>

        <div className="mt-10 grid grid-cols-2 gap-y-8 border-t border-line pt-8 sm:mt-12 sm:pt-9 lg:grid-cols-4">
          {stats.map((stat, index) => (
            <Reveal key={stat.label} delay={index * 80}>
              <div
                className={cn(
                  "flex flex-col px-4 sm:px-6 lg:px-8",
                  index !== 0 && "lg:border-r lg:border-line",
                  index % 2 !== 0 && "border-r border-line lg:border-r"
                )}
              >
                <span className="font-latin text-[28px] font-extrabold tracking-[-0.04em] text-ink sm:text-[34px]">
                  {stat.value}
                </span>
                <span className="mt-1 text-[12px] font-bold text-ink/75">{stat.label}</span>
                <span className="mt-0.5 text-[10px] text-muted/75">{stat.hint}</span>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

/* -------------------------------------------------------------------------- */
/*                                   Bento                                    */
/* -------------------------------------------------------------------------- */

function AiCard() {
  return (
    <Reveal className="md:col-span-7">
      <article className="group relative flex h-full flex-col overflow-hidden rounded-[30px] bg-ink p-6 text-white shadow-lift ring-1 ring-black/5 sm:p-8">
        <div className="dot-grid-light pointer-events-none absolute inset-0 opacity-25" />
        <div className="pointer-events-none absolute -left-20 -top-24 size-72 rounded-full bg-brand/40 blur-[90px]" />
        <div className="pointer-events-none absolute -bottom-24 -right-16 size-64 rounded-full bg-lime/10 blur-[80px]" />
        <LogoMark className="pointer-events-none absolute -bottom-12 -left-10 size-52 opacity-[0.07]" />

        <div className="relative flex items-center justify-between gap-3">
          <span className="grid size-10 place-items-center rounded-[13px] bg-lime text-ink">
            <Sparkles size={18} />
          </span>
          <span className="inline-flex items-center gap-1.5 rounded-full border border-white/10 bg-white/5 px-2.5 py-1.5 text-[9.5px] font-bold tracking-wide text-white/60">
            <LiveDot dark />
            موتور دُربین
          </span>
        </div>

        <h3 className="relative mt-6 text-[22px] font-extrabold leading-[1.5] tracking-[-0.03em] sm:text-[26px]">
          هوش مصنوعی، به‌جای
          <br className="hidden sm:block" /> حدس و گمان.
        </h3>
        <p className="relative mt-2.5 max-w-md text-[12.5px] leading-[2] text-white/55 sm:text-[13px]">
          دُربین چند مدل هوش مصنوعی را هم‌زمان بررسی می‌کند و از دل تحلیل‌های متفاوت، یک تصمیم
          شفاف می‌سازد. بدون نیاز به کلید API.
        </p>

        <div className="relative mt-5 flex flex-wrap gap-1.5">
          {["GPT", "Claude", "Gemini", "DeepSeek"].map((model) => (
            <span
              key={model}
              className="font-latin rounded-full border border-white/10 bg-white/[0.04] px-2.5 py-1 text-[9px] font-bold tracking-wide text-white/55 transition-colors group-hover:border-white/20 group-hover:text-white/80"
            >
              {model}
            </span>
          ))}
        </div>

        <div className="relative mt-auto pt-6">
          <div className="rounded-2xl border border-white/10 bg-white/[0.045] p-3.5 backdrop-blur sm:p-4">
            <div className="flex items-center justify-between gap-3">
              <div>
                <p className="text-[9px] text-white/40">تحلیل نهایی · BTC/USDT</p>
                <p className="mt-1 text-[12.5px] font-extrabold">روند صعودی با تأیید مومنتوم</p>
              </div>
              <span className="rounded-full bg-mint-deep/20 px-2.5 py-1 text-[9.5px] font-extrabold text-[#4ef08f]">
                خرید
              </span>
            </div>
            <div className="mt-3 flex items-center gap-3">
              <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-white/10">
                <div className="h-full w-[86%] rounded-full bg-gradient-to-l from-lime to-[#a8e6c6]" />
              </div>
              <span className="font-latin text-[10px] font-extrabold text-white/80">86%</span>
              <span className="text-[8.5px] text-white/35">اطمینان</span>
            </div>
          </div>
        </div>
      </article>
    </Reveal>
  );
}

function CopyTradeCard() {
  return (
    <Reveal delay={90} className="md:col-span-5">
      <article className="card group flex h-full flex-col p-6 transition-all duration-500 hover:-translate-y-1 hover:border-ink/20 hover:shadow-soft sm:p-7">
        <div className="flex items-center justify-between">
          <span className="grid size-10 place-items-center rounded-[13px] bg-brand-soft text-brand">
            <Send size={17} />
          </span>
          <span className="rounded-full border border-line bg-paper px-2.5 py-1 text-[9px] font-bold text-muted">
            کپی‌ترید
          </span>
        </div>
        <h3 className="mt-5 text-[20px] font-extrabold leading-[1.55] tracking-[-0.03em] text-ink sm:text-[22px]">
          سیگنال‌ها را با تأخیر صفر کپی کنید.
        </h3>
        <p className="mt-2 text-[12px] leading-[1.95] text-muted">
          از کانال رسمی دلارینو، کانال اختصاصی خودتان یا Webhook تریدینگ‌ویو.
        </p>

        <div className="mt-auto pt-5">
          <div className="rounded-2xl border border-line bg-paper/80 p-3">
            <div className="flex items-center gap-2">
              <LogoMark className="size-7 rounded-lg" />
              <div className="leading-tight">
                <p className="font-latin text-[9.5px] font-extrabold text-ink">Dollarino Official</p>
                <p className="font-latin mt-0.5 text-[8px] text-muted/70">@Dollarinoofficial</p>
              </div>
              <span className="mr-auto rounded-full bg-white px-1.5 py-0.5 text-[8px] font-bold text-muted">سیگنال</span>
            </div>

            <div className="mt-2.5 rounded-xl rounded-tr-sm border border-line bg-white p-2.5">
              <p className="font-latin text-[9.5px] font-extrabold text-ink">#BTCUSDT · LONG</p>
              <div className="mt-1.5 grid grid-cols-3 gap-1.5 text-center">
                {[
                  ["ورود", "67,210"],
                  ["هدف", "68,900"],
                  ["حد ضرر", "66,450"],
                ].map(([label, value]) => (
                  <div key={label} className="rounded-md bg-paper px-1 py-1">
                    <p className="text-[7.5px] text-muted">{label}</p>
                    <p className="font-latin mt-0.5 text-[9px] font-bold text-ink">{value}</p>
                  </div>
                ))}
              </div>
            </div>

            <div className="mt-2 flex items-center justify-between gap-2 rounded-xl bg-mint/70 px-2.5 py-2">
              <span className="flex items-center gap-1.5 text-[9.5px] font-bold text-mint-deep">
                <span className="grid size-3.5 place-items-center rounded-full bg-mint-deep text-white">
                  <Check size={8} strokeWidth={4} />
                </span>
                در صرافی اجرا شد
              </span>
              <span className="font-latin text-[8px] font-bold text-mint-deep/70">0.8s</span>
            </div>
          </div>

          <div className="mt-3 flex items-center justify-between border-t border-line pt-3">
            <span className="text-[10px] font-semibold text-muted">اجرای خودکار سیگنال</span>
            <span className="flex items-center gap-1.5 rounded-full bg-ink px-2.5 py-1 text-[8.5px] font-bold text-white">
              <span className="size-1.5 rounded-full bg-lime" />
              فعال
            </span>
          </div>
        </div>
      </article>
    </Reveal>
  );
}

function MarketsCard() {
  return (
    <Reveal delay={40} className="sm:col-span-2 md:col-span-6 lg:col-span-4">
      <article className="card flex h-full flex-col p-5 transition-all duration-500 hover:-translate-y-1 hover:border-ink/20 hover:shadow-soft sm:p-6">
        <div className="flex items-start justify-between">
          <div>
            <h3 className="text-[17px] font-extrabold tracking-tight text-ink">۳۰+ بازار، یک ربات</h3>
            <p className="mt-1 text-[10.5px] text-muted">رصد هم‌زمان، انتخاب بهترین فرصت.</p>
          </div>
          <span className="grid size-8 shrink-0 place-items-center rounded-[10px] bg-paper text-ink/60">
            <RefreshCw size={14} />
          </span>
        </div>

        <div className="mt-auto space-y-1 pt-4">
          {coins.slice(0, 3).map((coin) => (
            <div
              key={coin.symbol}
              className="flex items-center gap-2 rounded-xl px-1 py-1.5 transition-colors hover:bg-paper"
            >
              <CoinBadge coin={coin} className="size-7 text-[9px]" />
              <div className="leading-tight">
                <p className="font-latin text-[10px] font-extrabold text-ink">{coin.symbol}</p>
                <p className="mt-0.5 text-[8px] text-muted">{coin.name}</p>
              </div>
              <Sparkline values={coin.spark} stroke={coin.change >= 0 ? "#0e8f64" : "#d9534f"} className="mr-auto h-6 w-14" />
              <div className="text-left" dir="ltr">
                <p className="font-latin text-[9.5px] font-bold text-ink">${usd(coin.price)}</p>
                <p
                  className={cn(
                    "font-latin mt-0.5 text-[8px] font-bold",
                    coin.change >= 0 ? "text-up" : "text-danger"
                  )}
                >
                  {coin.change >= 0 ? "+" : ""}
                  {coin.change.toFixed(2)}%
                </p>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-3 flex items-center justify-between rounded-xl border border-dashed border-line bg-paper/60 px-3 py-2">
          <span className="text-[9px] font-semibold text-muted">چرخش خودکار روند</span>
          <span className="flex items-center gap-1 text-[8.5px] font-bold text-up">
            <RefreshCw size={9} /> فعال
          </span>
        </div>
      </article>
    </Reveal>
  );
}

function RiskCard() {
  const [leverage, setLeverage] = useState(10);
  const [autoFlip, setAutoFlip] = useState(true);
  const margin = 1000 / leverage;
  const distance = (100 / leverage) * 0.9;
  const level = leverage <= 5 ? "ریسک کم" : leverage <= 20 ? "ریسک متعادل" : "ریسک بالا";
  const levelColor = leverage <= 5 ? "text-up" : leverage <= 20 ? "text-[#b07716]" : "text-danger";

  return (
    <Reveal delay={90} className="sm:col-span-2 md:col-span-6 lg:col-span-4">
      <article className="flex h-full flex-col rounded-[28px] border border-line bg-sand/60 p-5 shadow-card sm:p-6">
        <div className="flex items-start justify-between">
          <span className="grid size-8 place-items-center rounded-[10px] bg-white text-ink/70">
            <SlidersHorizontal size={14} />
          </span>
          <span className="rounded-full border border-ink/10 bg-white/60 px-2 py-1 text-[8.5px] font-bold text-ink/50">
            ریسک در دست شما
          </span>
        </div>

        <h3 className="mt-4 text-[17px] font-extrabold tracking-tight text-ink">اهرم را خودت انتخاب کن.</h3>
        <p className="mt-1 text-[10.5px] leading-relaxed text-muted">مارجین و فاصله لیکویید، لحظه‌ای به‌روز می‌شود.</p>

        <div className="mt-4 flex items-end justify-between">
          <div>
            <p className="text-[9px] text-muted">اهرم انتخابی</p>
            <p className="font-latin mt-1 text-[27px] font-extrabold leading-none tracking-tight text-ink">
              {leverage}
              <span className="text-[14px] text-muted">x</span>
            </p>
          </div>
          <span className={cn("text-[9.5px] font-bold", levelColor)}>{level}</span>
        </div>

        <div className="mt-4">
          <input
            type="range"
            min={1}
            max={50}
            step={1}
            value={leverage}
            onChange={(event) => setLeverage(Number(event.target.value))}
            className="range"
            style={{ "--fill": `${(leverage / 50) * 100}%` } as React.CSSProperties}
            dir="ltr"
            aria-label="انتخاب اهرم"
          />
          <div className="font-latin mt-1.5 flex justify-between text-[8px] text-muted/60">
            <span>1x</span>
            <span>25x</span>
            <span>50x</span>
          </div>
        </div>

        <div className="mt-auto grid grid-cols-2 gap-2 pt-3">
          <div className="rounded-xl border border-ink/[0.06] bg-white/70 px-2.5 py-2">
            <p className="text-[8px] text-muted">مارجین · ۱٬۰۰۰ USDT</p>
            <p className="font-latin mt-1 text-[12px] font-extrabold text-ink">${margin.toFixed(0)}</p>
          </div>
          <div className="rounded-xl border border-ink/[0.06] bg-white/70 px-2.5 py-2">
            <p className="text-[8px] text-muted">فاصله لیکویید</p>
            <p className="font-latin mt-1 text-[12px] font-extrabold text-ink">{distance.toFixed(1)}%</p>
          </div>
        </div>

        <button
          type="button"
          onClick={() => setAutoFlip((value) => !value)}
          className="mt-2 flex w-full items-center justify-between rounded-xl border border-ink/[0.06] bg-white/70 px-2.5 py-2 text-right"
          aria-pressed={autoFlip}
        >
          <span className="text-[9px] font-semibold text-ink/65">چرخش خودکار روند</span>
          <span
            className={cn(
              "relative h-4 w-7 rounded-full transition-colors duration-300",
              autoFlip ? "bg-ink" : "bg-line"
            )}
          >
            <span
              className={cn(
                "absolute top-0.5 size-3 rounded-full bg-white transition-all duration-300",
                autoFlip ? "right-0.5" : "right-3.5"
              )}
            />
          </span>
        </button>
      </article>
    </Reveal>
  );
}

function ProCard() {
  return (
    <Reveal delay={140} className="sm:col-span-2 md:col-span-12 lg:col-span-4">
      <article className="card group flex h-full flex-col overflow-hidden p-5 transition-all duration-500 hover:-translate-y-1 hover:border-ink/20 hover:shadow-soft sm:p-6">
        <div className="relative overflow-hidden rounded-2xl bg-ink p-3 text-white">
          <div className="pointer-events-none absolute -left-10 -top-10 size-32 rounded-full bg-brand/40 blur-3xl" />
          <div className="relative flex items-center justify-between">
            <div className="flex items-center gap-1.5">
              <LogoMark className="size-5 rounded-md" />
              <span className="font-latin text-[7px] font-bold tracking-[0.18em] text-white/40">DOLLARINO</span>
            </div>
            <span className="font-latin rounded-full bg-lime px-2 py-0.5 text-[7px] font-extrabold tracking-wide text-ink">
              PRO
            </span>
          </div>
          <div className="relative mt-3 flex items-end justify-between gap-2">
            <div>
              <p className="text-[7px] text-white/40">سود خالص هفته</p>
              <p dir="ltr" className="font-latin mt-0.5 text-[15px] font-extrabold">+$1,286.40</p>
            </div>
            <div className="flex items-end gap-0.5 pb-0.5" dir="ltr">
              {[35, 52, 44, 68, 60, 82, 76].map((height, index) => (
                <span
                  key={index}
                  className={cn("w-1.5 rounded-t-sm", index === 6 ? "bg-lime" : "bg-white/15")}
                  style={{ height: `${height / 3}px` }}
                />
              ))}
            </div>
          </div>
        </div>

        <h3 className="mt-5 text-[17px] font-extrabold tracking-tight text-ink">حالت حرفه‌ای، برای روزهای جدی.</h3>
        <p className="mt-1.5 text-[10.5px] leading-[1.9] text-muted">
          کارت‌های تحلیلی، مدیریت ۲۰ پوزیشن و خروجی کارت هفتگی؛ همه در یک پنل آرام.
        </p>

        <ul className="mt-3 space-y-1.5">
          {["مدیریت هم‌زمان ۲۰ معامله", "کارت هفتگی قابل اشتراک"].map((item) => (
            <li key={item} className="flex items-center gap-1.5 text-[9.5px] font-medium text-ink/65">
              <span className="grid size-3.5 place-items-center rounded-full bg-mint text-mint-deep">
                <Check size={8} strokeWidth={4} />
              </span>
              {item}
            </li>
          ))}
        </ul>

        <a
          href="#panel"
          className="mt-auto flex items-center justify-between border-t border-line pt-3 text-[10px] font-bold text-ink"
        >
          مشاهده پنل حرفه‌ای
          <span className="grid size-6 place-items-center rounded-full bg-paper transition-colors group-hover:bg-ink group-hover:text-white">
            <ArrowLeft size={12} />
          </span>
        </a>
      </article>
    </Reveal>
  );
}

export default function Features() {
  return (
    <>
      <TrustStrip />

      <section id="features" className="relative py-16 sm:py-20 lg:py-28">
        <div className="container-x">
          <SectionHeading
            eyebrow="یک پنل، همه‌چیز"
            title={
              <>
                ساخته‌شده برای تمرکز،
                <br className="hidden sm:block" /> نه شلوغی.
              </>
            }
            desc="هر چیزی که برای معامله‌ی مطمئن لازم دارید — از هوش مصنوعی و کپی‌ترید تا کنترل اهرم و ریسک — بدون پیچیدگی اضافه."
            action={<CTA href="#engines" variant="light">آشنایی با موتورها</CTA>}
          />

          <div className="mt-10 grid grid-cols-1 gap-4 sm:grid-cols-2 md:grid-cols-12 lg:mt-14">
            <AiCard />
            <CopyTradeCard />
            <MarketsCard />
            <RiskCard />
            <ProCard />
          </div>

          <Reveal delay={60}>
            <div className="mt-4 flex flex-col items-center justify-between gap-4 rounded-[24px] border border-line bg-white/60 px-5 py-4 sm:flex-row sm:px-7">
              <div className="flex items-center gap-3">
                <span className="grid size-9 shrink-0 place-items-center rounded-full bg-white text-ink shadow-sm">
                  <Crown size={16} />
                </span>
                <p className="text-[11.5px] leading-relaxed text-muted">
                  <span className="font-bold text-ink">همه امکانات در حساب دمو رایگان است.</span> بدون تعهد، بدون
                  کارت بانکی؛ با قیمت زنده بازار تمرین کنید.
                </p>
              </div>
              <a
                href="#start"
                className="group flex shrink-0 items-center gap-1.5 text-[11px] font-extrabold text-brand"
              >
                شروع دمو
                <ArrowUpRight size={14} className="transition-transform group-hover:-translate-y-0.5" />
              </a>
            </div>
          </Reveal>
        </div>
      </section>
    </>
  );
}
