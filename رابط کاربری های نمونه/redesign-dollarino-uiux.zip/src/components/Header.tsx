import { useEffect, useState } from "react";
import { ArrowLeft, ArrowUpLeft, Menu, X } from "lucide-react";
import { cn } from "../utils/cn";
import { Logo, LogoMark } from "./ui";

const links = [
  { label: "امکانات", href: "#features" },
  { label: "موتورها", href: "#engines" },
  { label: "پنل حرفه‌ای", href: "#panel" },
  { label: "تعرفه‌ها", href: "#pricing" },
  { label: "اپلیکیشن", href: "#app" },
  { label: "سوالات", href: "#faq" },
];

export default function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const [showDock, setShowDock] = useState(false);
  const [activeSection, setActiveSection] = useState("#home");

  useEffect(() => {
    const onScroll = () => {
      setScrolled(window.scrollY > 40);
      setShowDock(window.scrollY > 720);
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") setOpen(false);
    };
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = "";
      window.removeEventListener("keydown", onKey);
    };
  }, [open]);

  useEffect(() => {
    const sections = links
      .map((link) => document.querySelector<HTMLElement>(link.href))
      .filter((section): section is HTMLElement => Boolean(section));
    if (!sections.length) return;
    const observer = new IntersectionObserver(
      (entries) => {
        const visible = entries
          .filter((entry) => entry.isIntersecting)
          .sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
        if (visible) setActiveSection(`#${visible.target.id}`);
      },
      { rootMargin: "-25% 0px -55% 0px", threshold: [0.05, 0.25, 0.6] }
    );
    sections.forEach((section) => observer.observe(section));
    return () => observer.disconnect();
  }, []);

  // over the cosmic hero (and while the mobile menu is closed) the bar is dark glass
  const dark = !scrolled && !open;

  return (
    <>
      <header className="fixed inset-x-0 top-0 z-50">
        <div className="container-x pt-3 sm:pt-4">
          <div
            className={cn(
              "flex items-center justify-between gap-4 rounded-[20px] border px-3 py-2.5 transition-all duration-500 sm:rounded-full sm:px-4",
              dark
                ? "border-white/10 bg-white/[0.04] backdrop-blur-md"
                : "border-line bg-white/90 shadow-soft backdrop-blur-xl"
            )}
          >
            <a href="#home" className="shrink-0" aria-label="دلارینو، خانه">
              <Logo light={dark} />
            </a>

            <nav className="hidden items-center gap-0.5 lg:flex" aria-label="ناوبری اصلی">
              {links.map((link) => {
                const active = activeSection === link.href;
                return (
                  <a
                    key={link.href}
                    href={link.href}
                    aria-current={active ? "true" : undefined}
                    className={cn(
                      "relative rounded-full px-3.5 py-2 text-[12.5px] font-medium transition-colors xl:text-[13px]",
                      dark
                        ? "text-white/65 hover:bg-white/10 hover:text-white"
                        : active
                          ? "bg-brand-soft text-brand-dark"
                          : "text-ink/65 hover:bg-paper hover:text-ink"
                    )}
                  >
                    {link.label}
                  </a>
                );
              })}
            </nav>

            <div className="flex items-center gap-2">
              <a
                href="#start"
                className={cn(
                  "hidden items-center gap-1.5 rounded-full px-3 py-2 text-[13px] font-semibold transition-colors sm:inline-flex",
                  dark ? "text-white/70 hover:text-white" : "text-ink/70 hover:text-ink"
                )}
              >
                ورود
                <ArrowUpLeft size={14} className="opacity-60" />
              </a>
              <a
                href="#start"
                className="btn-cobalt inline-flex items-center gap-1.5 rounded-full px-4 py-2.5 text-[12px] font-extrabold text-white transition-transform hover:-translate-y-px sm:px-5 sm:text-[13px]"
              >
                <span className="size-1.5 rounded-full bg-lime shadow-[0_0_8px_#16e664]" />
                شروع رایگان
              </a>
              <button
                type="button"
                onClick={() => setOpen((value) => !value)}
                className={cn(
                  "grid size-10 place-items-center rounded-full border transition-colors lg:hidden",
                  dark
                    ? "border-white/15 bg-white/5 text-white hover:bg-white/10"
                    : "border-line bg-white text-ink hover:bg-paper"
                )}
                aria-label={open ? "بستن منو" : "باز کردن منو"}
                aria-expanded={open}
              >
                {open ? <X size={18} /> : <Menu size={19} />}
              </button>
            </div>
          </div>

          {/* mobile menu */}
          <div
            onClick={() => setOpen(false)}
            aria-hidden="true"
            className={cn(
              "fixed inset-0 -z-10 bg-ink/40 backdrop-blur-[2px] transition-opacity duration-300 lg:hidden",
              open ? "opacity-100" : "pointer-events-none opacity-0"
            )}
          />
          <div
            className={cn(
              "overflow-hidden transition-all duration-500 lg:hidden",
              open ? "mt-2 max-h-[600px] opacity-100" : "max-h-0 opacity-0"
            )}
          >
            <div className="rounded-[26px] border border-line bg-white/95 p-3 shadow-lift backdrop-blur-xl">
              <nav className="flex flex-col" aria-label="ناوبری موبایل">
                {links.map((link, index) => (
                  <a
                    key={link.href}
                    href={link.href}
                    onClick={() => setOpen(false)}
                    className="flex items-center justify-between border-b border-line/70 px-3 py-3.5 text-[14px] font-semibold text-ink/80 last:border-0 hover:text-brand"
                  >
                    <span>{link.label}</span>
                    <span className="font-latin text-[10px] text-muted/50">0{index + 1}</span>
                  </a>
                ))}
              </nav>
              <div className="mt-3 grid grid-cols-2 gap-2 px-1 pb-1">
                <a
                  href="#start"
                  onClick={() => setOpen(false)}
                  className="flex items-center justify-center gap-2 rounded-full border border-line bg-white px-4 py-3 text-[13px] font-bold text-ink"
                >
                  ورود به حساب
                </a>
                <a
                  href="#start"
                  onClick={() => setOpen(false)}
                  className="btn-cobalt flex items-center justify-center gap-2 rounded-full px-4 py-3 text-[13px] font-bold text-white"
                >
                  دموی رایگان
                  <ArrowLeft size={15} />
                </a>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* floating mobile dock */}
      <div
        className={cn(
          "fixed inset-x-3 bottom-3 z-40 transition-all duration-500 sm:hidden",
          showDock && !open ? "translate-y-0 opacity-100" : "pointer-events-none translate-y-24 opacity-0"
        )}
      >
        <div className="flex items-center justify-between gap-3 rounded-full border border-white/10 bg-ink/90 p-1.5 pr-3 shadow-lift backdrop-blur-xl">
          <div className="flex items-center gap-2.5">
            <LogoMark className="size-8" />
            <div className="leading-tight">
              <p className="text-[11.5px] font-bold text-white">دموی رایگان، بدون ریسک</p>
              <p className="mt-0.5 text-[9.5px] text-white/50">در ۲ دقیقه شروع کنید</p>
            </div>
          </div>
          <a
            href="#start"
            className="flex items-center gap-1.5 rounded-full bg-lime px-4 py-2.5 text-[11.5px] font-extrabold text-ink"
          >
            شروع
            <ArrowLeft size={14} />
          </a>
        </div>
      </div>
    </>
  );
}
