import { useEffect, useState } from "react";
import {
  ArrowUpRight,
  Check,
  Eye,
  EyeOff,
  Flame,
  Rocket,
  ShieldCheck,
  Sparkles,
  TrendingUp,
} from "lucide-react";
import { cn } from "../utils/cn";
import {
  AreaChart,
  CoinBadge,
  LiveDot,
  LogoMark,
  usd,
  type Coin,
  coins,
} from "./ui";

/* -------------------------------------------------------------------------- */
/*                              account glass card                            */
/* -------------------------------------------------------------------------- */

const chartData = {
  "1D": {
    values: [42, 45, 44, 49, 47, 54, 52, 58, 61, 59, 66, 64, 70, 68, 74, 79, 76, 84, 88, 86, 92],
    change: "+2.84%",
    label: "امروز",
    price: 12518.34,
  },
  "1W": {
    values: [30, 36, 33, 40, 38, 45, 43, 51, 48, 56, 54, 62, 59, 66, 64, 72, 70, 78, 76, 84, 82, 91],
    change: "+8.46%",
    label: "این هفته",
    price: 12480.5,
  },
  "1M": {
    values: [20, 28, 25, 34, 30, 42, 38, 46, 45, 55, 50, 60, 57, 66, 63, 72, 78, 74, 84, 80, 90, 88, 96],
    change: "+22.9%",
    label: "این ماه",
    price: 12480.5,
  },
} as const;

type Range = keyof typeof chartData;

function AccountCard() {
  const [range, setRange] = useState<Range>("1W");
  const [hidden, setHidden] = useState(false);
  const data = chartData[range];
  const [balance, setBalance] = useState<number>(chartData["1W"].price);

  useEffect(() => {
    setBalance(data.price);
  }, [range, data.price]);

  useEffect(() => {
    const interval = window.setInterval(() => {
      setBalance((value) => value * (1 + (Math.random() - 0.5) * 0.0008));
    }, 5200);
    return () => window.clearInterval(interval);
  }, []);

  return (
    <div className="relative overflow-hidden rounded-[28px] border border-white/12 bg-white/[0.07] p-4 shadow-lift backdrop-blur-xl sm:p-5">
      <div className="pointer-events-none absolute -right-20 -top-24 size-64 rounded-full bg-brand/35 blur-[70px]" />
      <div className="pointer-events-none absolute -bottom-24 -left-16 size-56 rounded-full bg-lime/10 blur-[70px]" />

      <div className="relative flex items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <LogoMark glow className="size-9" />
          <div className="leading-tight">
            <p className="text-[12px] font-bold text-white">دلارینو</p>
            <p className="font-latin mt-0.5 text-[7px] font-bold tracking-[0.2em] text-white/40">
              DEMO ACCOUNT
            </p>
          </div>
        </div>
        <span className="inline-flex items-center gap-1.5 rounded-full border border-white/10 bg-white/5 px-2.5 py-1.5 text-[9.5px] font-semibold text-white/70">
          <LiveDot dark />
          ربات فعال
        </span>
      </div>

      <div className="relative mt-6">
        <div className="flex items-center gap-2 text-[10.5px] text-white/45">
          ارزش کل حساب
          <span className="inline-flex items-center gap-1 rounded-full border border-white/10 px-1.5 py-0.5 text-[8px] text-white/35">
            <LiveDot dark />
            لحظه‌ای
          </span>
          <button
            type="button"
            onClick={() => setHidden((value) => !value)}
            aria-label={hidden ? "نمایش موجودی" : "پنهان کردن موجودی"}
            className="grid size-6 place-items-center rounded-full bg-white/5 text-white/50 transition-colors hover:bg-white/10 hover:text-white"
          >
            {hidden ? <EyeOff size={12} /> : <Eye size={12} />}
          </button>
        </div>
        <div className="mt-1.5 flex flex-wrap items-end gap-x-2 gap-y-1.5">
          <p
            dir="ltr"
            className={cn(
              "font-latin text-[30px] font-extrabold leading-none tracking-tight transition-all sm:text-[35px]",
              hidden && "select-none blur-[7px]"
            )}
          >
            {hidden ? "8,420.00" : usd(balance)}
          </p>
          <span className="font-latin mb-0.5 text-[10px] font-bold tracking-wide text-white/40">USDT</span>
          <span className="mb-0.5 inline-flex items-center gap-1 rounded-full bg-mint-deep/20 px-2 py-1 text-[9.5px] font-bold text-[#4ef08f]">
            <TrendingUp size={10} />
            {data.change}
          </span>
        </div>
      </div>

      <div className="relative mt-5 flex items-center justify-between">
        <p className="text-[10px] font-medium text-white/40">عملکرد {data.label}</p>
        <div className="flex items-center gap-0.5 rounded-full border border-white/10 bg-white/[0.04] p-0.5">
          {(Object.keys(chartData) as Range[]).map((item) => (
            <button
              key={item}
              type="button"
              onClick={() => setRange(item)}
              aria-pressed={range === item}
              className={cn(
                "font-latin rounded-full px-2.5 py-1 text-[8.5px] font-bold transition-all",
                range === item ? "bg-lime text-ink shadow-sm" : "text-white/40 hover:text-white/80"
              )}
            >
              {item}
            </button>
          ))}
        </div>
      </div>

      <div className="relative mt-1 -mr-1">
        <AreaChart values={[...data.values]} stroke="#16E664" fill="#16E664" height={128} showDot grid />
      </div>

      <div className="relative mt-4 grid grid-cols-3 divide-x divide-x-reverse divide-white/10 rounded-2xl border border-white/10 bg-white/[0.03] py-3">
        <div className="px-2 text-center">
          <p className="text-[9px] text-white/40">سود امروز</p>
          <p dir="ltr" className="font-latin mt-1 text-[12px] font-bold text-[#4ef08f]">+$284.12</p>
        </div>
        <div className="px-2 text-center">
          <p className="text-[9px] text-white/40">پوزیشن باز</p>
          <p className="font-latin mt-1 text-[12px] font-bold text-white">7</p>
        </div>
        <div className="px-2 text-center">
          <p className="text-[9px] text-white/40">دقت سیگنال</p>
          <p className="font-latin mt-1 text-[12px] font-bold text-white">78%</p>
        </div>
      </div>

      <div className="relative mt-3 flex items-center justify-between gap-3">
        <a
          href="#panel"
          className="flex flex-1 items-center justify-center gap-2 rounded-xl bg-white px-3 py-2.5 text-[11px] font-extrabold text-ink transition-colors hover:bg-lime"
        >
          ورود به پنل
          <ArrowUpRight size={13} />
        </a>

      </div>
    </div>
  );
}

function AiInsightCard() {
  return (
    <div className="animate-float w-[206px] rounded-2xl border border-white/12 bg-white/[0.08] p-3 shadow-lift backdrop-blur-xl">
      <div className="flex items-center gap-2">
        <span className="grid size-7 place-items-center rounded-[9px] bg-lime text-ink">
          <Sparkles size={13} />
        </span>
        <div className="leading-tight">
          <p className="text-[9px] text-white/45">موتور دُربین</p>
          <p className="text-[11px] font-extrabold text-white">تحلیل زنده BTC</p>
        </div>
        <span className="mr-auto flex size-1.5 rounded-full bg-[#4ef08f]" />
      </div>
      <div className="mt-3 rounded-xl bg-white/[0.06] p-2.5">
        <div className="flex items-center justify-between text-[9.5px]">
          <span className="font-semibold text-white/70">روند صعودی</span>
          <span className="font-latin font-bold text-[#4ef08f]">+2.4%</span>
        </div>
        <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-white/10">
          <div className="h-full w-[86%] rounded-full bg-gradient-to-l from-lime to-[#7dffb0]" />
        </div>
        <div className="mt-1.5 flex items-center justify-between text-[8.5px] text-white/45">
          <span>اطمینان مدل</span>
          <span className="font-latin font-extrabold text-white">86%</span>
        </div>
      </div>
      <div className="mt-2 flex items-center gap-1.5 text-[9px] font-bold text-[#4ef08f]">
        <Check size={11} strokeWidth={3} />
        سیگنال خرید اجرا شد
      </div>
    </div>
  );
}

function WeekCard() {
  const bars = [38, 55, 43, 70, 58, 84, 74];
  return (
    <div className="animate-float-slow relative w-[178px] overflow-hidden rounded-2xl border border-white/12 bg-white/[0.08] p-3.5 shadow-lift backdrop-blur-xl">
      <LogoMark className="absolute -bottom-4 -left-4 size-16 opacity-[0.12]" />
      <div className="flex items-center justify-between">
        <p className="text-[9px] font-semibold text-white/50">نتیجه این هفته</p>
        <span className="rounded-full bg-lime px-1.5 py-0.5 text-[8px] font-bold text-ink">سود</span>
      </div>
      <p dir="ltr" className="font-latin mt-1 text-[23px] font-extrabold tracking-tight text-white">+12.8%</p>
      <div className="mt-2 flex h-8 items-end gap-1" dir="ltr">
        {bars.map((height, index) => (
          <span
            key={index}
            className={cn("flex-1 rounded-t-[2px]", index === bars.length - 1 ? "bg-lime" : "bg-white/20")}
            style={{ height: `${height}%` }}
          />
        ))}
      </div>
      <p className="mt-2 text-[8.5px] text-white/45">۷ ترید موفق از ۹ معامله</p>
    </div>
  );
}

function HeroStage() {
  return (
    <div className="relative mx-auto w-full max-w-[470px] lg:mr-0">
      <div className="pointer-events-none absolute inset-0 -z-10">
        <div className="absolute right-4 top-10 size-72 rounded-full bg-brand/30 blur-[80px]" />
        <div className="absolute bottom-0 left-0 size-56 rounded-full bg-lime/10 blur-[70px]" />
      </div>

      {/* orbit system */}
      <div className="pointer-events-none absolute -left-16 -top-14 hidden size-[300px] sm:block lg:-left-24 lg:-top-16 lg:size-[340px]" aria-hidden="true">
        <div className="orbit absolute inset-0" />
        <div className="orbit absolute inset-12 [animation-direction:reverse] [animation-duration:40s]" />
        <span className="absolute right-6 top-12 size-2 rounded-full bg-lime shadow-[0_0_12px_#16e664]" />
        <span className="absolute bottom-10 left-8 size-1.5 rounded-full bg-flame shadow-[0_0_10px_#ff8a00]" />
      </div>

      {/* real brand emblem — floats outside the glass so it stays crisp */}
      <div className="pointer-events-none absolute -bottom-12 -left-8 z-30 hidden size-[176px] sm:block lg:-left-14" aria-hidden="true">
        <div className="absolute inset-0 rounded-full bg-brand/30 blur-[40px]" />
        <div className="orbit absolute inset-0 [animation-duration:30s]" />
        <div className="animate-rocket absolute inset-5">
          <LogoMark glow className="size-full" />
        </div>
      </div>

      <div className="absolute -right-3 top-[188px] z-20 hidden sm:block lg:-right-10">
        <AiInsightCard />
      </div>

      <div className="relative z-10 ml-0 mr-auto w-full max-w-[390px] pb-2 sm:mt-2 lg:max-w-[398px]">
        <AccountCard />
      </div>

      <div className="relative z-20 -mt-5 hidden w-fit sm:block lg:mr-2">
        <WeekCard />
      </div>

      <div className="mt-3 grid grid-cols-2 gap-2 sm:hidden">
        <div className="rounded-2xl border border-white/12 bg-white/[0.07] p-3 backdrop-blur">
          <p className="flex items-center gap-1 text-[9px] font-bold text-lime">
            <Sparkles size={11} /> دُربین
          </p>
          <p className="mt-1 text-[10.5px] font-extrabold text-white">سیگنال خرید BTC</p>
          <p className="font-latin mt-1 text-[9px] font-bold text-[#4ef08f]">+2.4% · 86% اطمینان</p>
        </div>
        <div className="rounded-2xl border border-white/12 bg-white/[0.07] p-3 backdrop-blur">
          <p className="text-[9px] font-bold text-white/50">نتیجه این هفته</p>
          <p dir="ltr" className="font-latin mt-1 text-[18px] font-extrabold text-white">+12.8%</p>
          <p className="mt-1 text-[9px] text-[#4ef08f]">۷ ترید موفق</p>
        </div>
      </div>
    </div>
  );
}

/* -------------------------------------------------------------------------- */
/*                                market ribbon                               */
/* -------------------------------------------------------------------------- */

function TickerItem({ coin }: { coin: Coin }) {
  const positive = coin.change >= 0;
  return (
    <div className="flex shrink-0 items-center gap-2.5 border-l border-white/10 px-4 py-1 first:border-l-0 sm:px-5">
      <CoinBadge coin={coin} className="size-7 text-[9px]" />
      <div className="flex items-baseline gap-2">
        <span className="font-latin text-[11px] font-extrabold tracking-wide text-white">{coin.symbol}</span>
        <span className="font-latin text-[10.5px] font-semibold text-white/55">${usd(coin.price)}</span>
        <span
          className={cn("font-latin text-[9px] font-bold", positive ? "text-[#4ef08f]" : "text-[#ff8b8b]")}
          dir="ltr"
        >
          {positive ? "+" : ""}
          {coin.change.toFixed(2)}%
        </span>
      </div>
    </div>
  );
}

function MarketTicker() {
  const [live, setLive] = useState<Coin[]>(() => coins.map((coin) => ({ ...coin })));

  useEffect(() => {
    const interval = window.setInterval(() => {
      setLive((current) =>
        current.map((coin) => {
          const drift = 1 + (Math.random() - 0.48) * 0.0018;
          return {
            ...coin,
            price: coin.price * drift,
            change: Math.max(-9.9, Math.min(9.9, coin.change + (Math.random() - 0.5) * 0.06)),
          };
        })
      );
    }, 4200);
    return () => window.clearInterval(interval);
  }, []);

  return (
    <div className="relative border-t border-white/10 bg-white/[0.02]">
      <div className="container-x flex items-center gap-3 py-4 sm:gap-5">
        <div className="hidden shrink-0 items-center gap-2 border-l border-white/10 pl-4 sm:flex">
          <LiveDot dark />
          <span className="text-[10px] font-extrabold uppercase tracking-[0.16em] text-white/70">بازار زنده</span>
        </div>
        <div className="marquee marquee-mask flex-1 overflow-hidden" dir="ltr">
          <div className="marquee-track flex items-center">
            {[...live, ...live].map((coin, index) => (
              <TickerItem key={`${coin.symbol}-${index}`} coin={coin} />
            ))}
          </div>
        </div>
        <a
          href="#panel"
          className="hidden shrink-0 items-center gap-1.5 rounded-full border border-white/12 bg-white/5 px-3 py-1.5 text-[10px] font-bold text-white/70 transition-colors hover:border-white/30 hover:text-white md:inline-flex"
        >
          مشاهده بازار
          <ArrowUpRight size={12} />
        </a>
      </div>
    </div>
  );
}

/* -------------------------------------------------------------------------- */
/*                                    hero                                    */
/* -------------------------------------------------------------------------- */

const metrics = [
  { value: "30+", label: "ارز پرمعامله" },
  { value: "20", label: "پوزیشن همزمان" },
  { value: "24/7", label: "ربات فعال" },
  { value: "50x", label: "اهرم آزاد" },
];

export default function Hero() {
  return (
    <section id="home" className="relative overflow-hidden bg-ink pb-0 pt-28 text-white sm:pt-32 lg:pt-36">
      {/* aurora */}
      <div className="pointer-events-none absolute inset-0">
        <div className="stars absolute inset-0" />
        <div className="absolute -top-56 right-[-14%] size-[760px] rounded-full bg-brand/35 blur-[130px]" />
        <div className="absolute left-[18%] top-[30%] size-[380px] rounded-full bg-cyan/10 blur-[110px]" />
        <div className="absolute bottom-[-20%] left-[-12%] size-[520px] rounded-full bg-lime/[0.08] blur-[120px]" />
        <div className="absolute inset-x-0 bottom-0 h-40 bg-gradient-to-t from-ink to-transparent" />
      </div>

      <div className="container-x relative grid items-center gap-12 pb-12 lg:grid-cols-[0.92fr_1.08fr] lg:gap-8 lg:pb-16">
        {/* copy */}
        <div className="relative z-10 max-w-[600px]">
          <span className="animate-rise inline-flex items-center gap-2 rounded-full border border-white/12 bg-white/5 px-3 py-1.5 text-[11px] font-semibold text-white/75 backdrop-blur">
            <span className="relative flex size-2">
              <span className="animate-pulse-ring absolute inline-flex size-full rounded-full bg-lime" />
              <span className="relative inline-flex size-2 rounded-full bg-lime" />
            </span>
            نسخه ۶.۰ · سه موتور معاملاتی، یک پنل ساده
          </span>

          <h1 className="animate-rise mt-6 text-[2.25rem] font-extrabold leading-[1.45] tracking-[-0.04em] text-balance sm:text-[3.15rem] sm:leading-[1.35] lg:text-[3.85rem]">
            شما بخوابید؛
            <br />
            <span className="text-gradient-cobalt">دلارینو</span>{" "}
            <span className="relative inline-block">
              <span className="absolute inset-x-0 bottom-1 -z-10 h-2 rounded-full bg-lime/80 shadow-[0_0_24px_rgba(22,230,100,0.55)] sm:h-2.5" />
              بیدار
            </span>{" "}
            می‌ماند.
          </h1>

          <p className="animate-rise mt-6 max-w-[500px] text-[14px] leading-[2.15] text-white/60 sm:text-[15.5px]">
            سه موتور معاملاتی — هوش مصنوعی، استراتژی منتخب و کپی‌ترید — روی ۳۰+ ارز پرنقدینگی،
            بی‌وقفه کار می‌کنند. بدون نیاز به دانش پیچیده، بدون پایش لحظه‌ای چارت.
          </p>

          <div className="animate-rise mt-8 flex flex-col gap-2.5 sm:flex-row sm:items-center">
            <a
              href="#start"
              className="group inline-flex items-center justify-center gap-2.5 rounded-full bg-lime px-6 py-4 text-[13px] font-extrabold text-ink shadow-[0_14px_40px_-12px_rgba(22,230,100,0.7)] transition-all hover:bg-white sm:text-sm"
            >
              <Rocket size={16} className="transition-transform group-hover:-translate-y-0.5 group-hover:-translate-x-0.5" />
              شروع رایگان با حساب دمو
            </a>
            <a
              href="#panel"
              className="group inline-flex items-center justify-center gap-2.5 rounded-full border border-white/15 bg-white/[0.06] px-6 py-4 text-[13px] font-bold text-white backdrop-blur transition-colors hover:border-white/35 hover:bg-white/[0.12] sm:text-sm"
            >
              <Flame size={15} className="text-lime" />
              ببینید پنل چطور کار می‌کند
            </a>
          </div>

          <ul className="mt-7 flex flex-wrap items-center gap-x-5 gap-y-2 text-[11px] font-medium text-white/55 sm:text-[11.5px]">
            {["بدون کارت بانکی", "دموی نامحدود", "لغو در هر زمان"].map((item) => (
              <li key={item} className="flex items-center gap-1.5">
                <span className="grid size-4 place-items-center rounded-full bg-lime/15 text-lime">
                  <Check size={9} strokeWidth={3.5} />
                </span>
                {item}
              </li>
            ))}
          </ul>

          {/* metric strip */}
          <div className="mt-8 grid grid-cols-2 gap-x-6 gap-y-4 border-t border-white/10 pt-6 sm:grid-cols-4">
            {metrics.map((metric) => (
              <div key={metric.label}>
                <p
                  dir="ltr"
                  className="font-latin text-[24px] font-extrabold leading-none tracking-tight text-white"
                >
                  {metric.value}
                </p>
                <p className="mt-1.5 text-[10px] text-white/50">{metric.label}</p>
              </div>
            ))}
          </div>

          <div className="mt-6 flex items-center gap-3">
            <div className="flex -space-x-2.5 space-x-reverse" dir="ltr">
              {[
                { label: "س", color: "bg-white text-ink" },
                { label: "م", color: "bg-brand text-white" },
                { label: "ر", color: "bg-lime text-ink" },
                { label: "ن", color: "bg-white/25 text-white" },
              ].map((avatar) => (
                <span
                  key={avatar.label}
                  className={cn(
                    "grid size-8 place-items-center rounded-full text-[10px] font-extrabold ring-2 ring-ink",
                    avatar.color
                  )}
                >
                  {avatar.label}
                </span>
              ))}
              <span className="font-latin grid size-8 place-items-center rounded-full bg-white/10 text-[8px] font-extrabold text-white ring-2 ring-ink">
                +12K
              </span>
            </div>
            <p className="text-[10.5px] leading-relaxed text-white/50 sm:text-[11.5px]">
              <span className="font-bold text-white/85">معامله‌گران در ۲۴ کشور</span>
              <br />
              بازار را به دلارینو سپرده‌اند.
            </p>
            <span className="mr-auto hidden items-center gap-1.5 rounded-full border border-white/10 px-3 py-1.5 text-[9.5px] font-bold text-white/55 sm:flex">
              <ShieldCheck size={12} className="text-[#4ef08f]" />
              کلید محدود · بدون برداشت
            </span>
          </div>
        </div>

        {/* stage */}
        <div className="relative lg:pl-2">
          <HeroStage />
        </div>
      </div>

      <MarketTicker />
    </section>
  );
}
