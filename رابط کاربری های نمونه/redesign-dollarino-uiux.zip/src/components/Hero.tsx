import { useEffect, useState } from "react";
import {
  ArrowUpRight,
  Check,
  ChevronDown,
  Eye,
  EyeOff,
  Play,
  Sparkles,
  TrendingUp,
} from "lucide-react";
import { cn } from "../utils/cn";
import {
  AreaChart,
  CTA,
  CoinBadge,
  Eyebrow,
  LiveDot,
  LogoMark,
  usd,
  type Coin,
  coins,
} from "./ui";

/* -------------------------------------------------------------------------- */
/*                                Account card                                */
/* -------------------------------------------------------------------------- */

const chartData = {
  "1D": {
    values: [42, 45, 44, 49, 47, 54, 52, 58, 61, 59, 66, 64, 70, 68, 74, 79, 76, 84, 88, 86, 92],
    change: "+2.84%",
    label: "امروز",
    price: "12,518.34",
  },
  "1W": {
    values: [30, 36, 33, 40, 38, 45, 43, 51, 48, 56, 54, 62, 59, 66, 64, 72, 70, 78, 76, 84, 82, 91],
    change: "+8.46%",
    label: "این هفته",
    price: "12,480.50",
  },
  "1M": {
    values: [20, 28, 25, 34, 30, 42, 38, 46, 45, 55, 50, 60, 57, 66, 63, 72, 78, 74, 84, 80, 90, 88, 96],
    change: "+22.9%",
    label: "این ماه",
    price: "12,480.50",
  },
} as const;

type Range = keyof typeof chartData;

function AccountCard() {
  const [range, setRange] = useState<Range>("1W");
  const [hidden, setHidden] = useState(false);
  const data = chartData[range];

  return (
    <div className="relative z-10 overflow-hidden rounded-[30px] bg-ink p-4 text-white shadow-lift ring-1 ring-white/10 sm:p-5">
      <div className="pointer-events-none absolute -right-16 -top-20 size-52 rounded-full bg-brand/40 blur-[70px]" />
      <div className="pointer-events-none absolute -bottom-24 -left-16 size-52 rounded-full bg-lime/10 blur-[70px]" />
      <div className="pointer-events-none absolute inset-0 bg-gradient-to-b from-white/[0.06] to-transparent" />

      <div className="relative flex items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <LogoMark className="size-8 rounded-[10px] ring-1 ring-white/15" />
          <div className="leading-tight">
            <p className="text-[12px] font-bold text-white">دلارینو</p>
            <p className="font-latin mt-0.5 text-[7px] font-bold tracking-[0.2em] text-white/40">
              DEMO ACCOUNT
            </p>
          </div>
        </div>
        <span className="inline-flex items-center gap-1.5 rounded-full border border-white/10 bg-white/5 px-2.5 py-1.5 text-[9.5px] font-semibold text-white/70">
          <LiveDot dark />
          ربات فعال
        </span>
      </div>

      <div className="relative mt-6">
        <div className="flex items-center gap-2 text-[10.5px] text-white/45">
          ارزش کل حساب
          <button
            type="button"
            onClick={() => setHidden((value) => !value)}
            aria-label={hidden ? "نمایش موجودی" : "پنهان کردن موجودی"}
            className="grid size-6 place-items-center rounded-full bg-white/5 text-white/50 transition-colors hover:bg-white/10 hover:text-white"
          >
            {hidden ? <EyeOff size={12} /> : <Eye size={12} />}
          </button>
        </div>
        <div className="mt-1.5 flex flex-wrap items-end gap-x-2 gap-y-1.5">
          <p
            className={cn(
              "font-latin text-[29px] font-extrabold leading-none tracking-tight transition-all sm:text-[34px]",
              hidden && "blur-[7px] select-none"
            )}
          >
            {hidden ? "8,420.00" : data.price}
          </p>
          <span className="font-latin mb-0.5 text-[10px] font-bold tracking-wide text-white/40">USDT</span>
          <span className="mb-0.5 inline-flex items-center gap-1 rounded-full bg-mint-deep/20 px-2 py-1 text-[9.5px] font-bold text-[#7be7b9]">
            <TrendingUp size={10} />
            {data.change}
          </span>
        </div>
      </div>

      <div className="relative mt-5 flex items-center justify-between">
        <p className="text-[10px] font-medium text-white/40">عملکرد {data.label}</p>
        <div className="flex items-center gap-0.5 rounded-full border border-white/10 bg-white/[0.04] p-0.5">
          {(Object.keys(chartData) as Range[]).map((item) => (
            <button
              key={item}
              type="button"
              onClick={() => setRange(item)}
              aria-pressed={range === item}
              className={cn(
                "font-latin rounded-full px-2.5 py-1 text-[8.5px] font-bold transition-all",
                range === item
                  ? "bg-white text-ink shadow-sm"
                  : "text-white/40 hover:text-white/80"
              )}
            >
              {item}
            </button>
          ))}
        </div>
      </div>

      <div className="relative mt-1 -mr-1">
        <AreaChart
          values={[...data.values]}
          stroke="#ddf56f"
          fill="#ddf56f"
          height={128}
          showDot
          grid
        />
      </div>

      <div className="relative mt-4 grid grid-cols-3 divide-x divide-x-reverse divide-white/10 rounded-2xl border border-white/10 bg-white/[0.03] py-3">
        <div className="px-2 text-center">
          <p className="text-[9px] text-white/40">سود امروز</p>
          <p className="font-latin mt-1 text-[12px] font-bold text-[#88e9be]">+$284.12</p>
        </div>
        <div className="px-2 text-center">
          <p className="text-[9px] text-white/40">پوزیشن باز</p>
          <p className="font-latin mt-1 text-[12px] font-bold text-white">7</p>
        </div>
        <div className="px-2 text-center">
          <p className="text-[9px] text-white/40">دقت سیگنال</p>
          <p className="font-latin mt-1 text-[12px] font-bold text-white">78%</p>
        </div>
      </div>

      <div className="relative mt-3 flex items-center justify-between gap-3">
        <button
          type="button"
          className="flex flex-1 items-center justify-center gap-2 rounded-xl bg-white px-3 py-2.5 text-[11px] font-extrabold text-ink transition-colors hover:bg-lime"
        >
          ورود به پنل
          <ArrowUpRight size={13} />
        </button>
        <span className="font-latin hidden rounded-xl border border-white/10 px-3 py-2.5 text-[9px] font-bold tracking-wide text-white/45 sm:block">
          24 / 7 LIVE
        </span>
      </div>
    </div>
  );
}

function AiInsightCard() {
  return (
    <div className="animate-float w-[204px] rounded-2xl border border-line bg-white/95 p-3 shadow-lift backdrop-blur-xl">
      <div className="flex items-center gap-2">
        <span className="grid size-7 place-items-center rounded-[9px] bg-brand text-white">
          <Sparkles size={13} />
        </span>
        <div className="leading-tight">
          <p className="text-[9px] text-muted">موتور دُربین</p>
          <p className="text-[11px] font-extrabold text-ink">تحلیل زنده BTC</p>
        </div>
        <span className="mr-auto flex size-1.5 rounded-full bg-mint-deep" />
      </div>
      <div className="mt-3 rounded-xl bg-paper p-2.5">
        <div className="flex items-center justify-between text-[9.5px]">
          <span className="font-semibold text-ink/70">روند صعودی</span>
          <span className="font-latin font-bold text-up">+2.4%</span>
        </div>
        <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-line">
          <div className="h-full w-[86%] rounded-full bg-gradient-to-l from-brand to-[#9dabff]" />
        </div>
        <div className="mt-1.5 flex items-center justify-between text-[8.5px] text-muted">
          <span>اطمینان مدل</span>
          <span className="font-latin font-extrabold text-ink">86%</span>
        </div>
      </div>
      <div className="mt-2 flex items-center gap-1.5 text-[9px] font-bold text-up">
        <Check size={11} strokeWidth={3} />
        سیگنال خرید اجرا شد
      </div>
    </div>
  );
}

function WeekCard() {
  const bars = [38, 55, 43, 70, 58, 84, 74];
  return (
    <div className="animate-float-slow relative w-[174px] overflow-hidden rounded-2xl border border-line bg-white/95 p-3.5 shadow-lift backdrop-blur-xl">
      <LogoMark className="absolute -bottom-4 -left-4 size-16 opacity-[0.06]" />
      <div className="flex items-center justify-between">
        <p className="text-[9px] font-semibold text-muted">نتیجه این هفته</p>
        <span className="rounded-full bg-mint px-1.5 py-0.5 text-[8px] font-bold text-mint-deep">سود</span>
      </div>
      <p className="font-latin mt-1 text-[23px] font-extrabold tracking-tight text-ink">+12.8%</p>
      <div className="mt-2 flex h-8 items-end gap-1" dir="ltr">
        {bars.map((height, index) => (
          <span
            key={index}
            className={cn("flex-1 rounded-t-[2px]", index === bars.length - 1 ? "bg-brand" : "bg-brand/20")}
            style={{ height: `${height}%` }}
          />
        ))}
      </div>
      <p className="mt-2 text-[8.5px] text-muted">۷ ترید موفق از ۹ معامله</p>
    </div>
  );
}

function HeroVisual() {
  return (
    <div className="relative mx-auto w-full max-w-[470px] lg:mr-0">
      <div className="pointer-events-none absolute inset-0 -z-10">
        <div className="absolute right-4 top-10 size-72 rounded-full bg-brand/15 blur-[80px]" />
        <div className="absolute bottom-0 left-0 size-56 rounded-full bg-mint/60 blur-[70px]" />
      </div>

      <div className="absolute -right-4 top-[196px] z-20 hidden sm:block lg:-right-9">
        <AiInsightCard />
      </div>

      <div className="relative z-10 ml-0 mr-auto w-full max-w-[390px] pb-2 sm:mt-2 lg:max-w-[398px]">
        <AccountCard />
      </div>

      <div className="absolute -bottom-7 left-0 z-20 hidden sm:block lg:-left-8">
        <WeekCard />
      </div>

      <div className="pointer-events-none absolute -top-5 left-10 z-20 hidden items-center gap-2 rounded-full border border-line bg-white/90 px-3 py-1.5 shadow-soft backdrop-blur sm:flex">
        <LiveDot />
        <span className="text-[10px] font-bold text-ink/75">۲۴/۷ در حال رصد بازار</span>
        <ChevronDown size={11} className="text-muted" />
      </div>

      <div className="mt-3 grid grid-cols-2 gap-2 sm:hidden">
        <div className="rounded-2xl border border-line bg-white p-3 shadow-card">
          <p className="flex items-center gap-1 text-[9px] font-bold text-brand">
            <Sparkles size={11} /> دُربین
          </p>
          <p className="mt-1 text-[10.5px] font-extrabold text-ink">سیگنال خرید BTC</p>
          <p className="font-latin mt-1 text-[9px] font-bold text-up">+2.4% · 86% اطمینان</p>
        </div>
        <div className="rounded-2xl border border-line bg-white p-3 shadow-card">
          <p className="text-[9px] font-bold text-muted">نتیجه این هفته</p>
          <p className="font-latin mt-1 text-[18px] font-extrabold text-ink">+12.8%</p>
          <p className="mt-1 text-[9px] text-up">۷ ترید موفق</p>
        </div>
      </div>
    </div>
  );
}

/* -------------------------------------------------------------------------- */
/*                                   Ticker                                   */
/* -------------------------------------------------------------------------- */

function TickerItem({ coin }: { coin: Coin }) {
  const positive = coin.change >= 0;
  return (
    <div className="flex shrink-0 items-center gap-2.5 border-l border-line/80 px-4 py-1 first:border-l-0 sm:px-5">
      <CoinBadge coin={coin} className="size-7 text-[9px]" />
      <div className="flex items-baseline gap-2">
        <span className="font-latin text-[11px] font-extrabold tracking-wide text-ink">{coin.symbol}</span>
        <span className="font-latin text-[10.5px] font-semibold text-ink/60">${usd(coin.price)}</span>
        <span
          className={cn(
            "font-latin text-[9px] font-bold",
            positive ? "text-up" : "text-danger"
          )}
          dir="ltr"
        >
          {positive ? "+" : ""}
          {coin.change.toFixed(2)}%
        </span>
      </div>
    </div>
  );
}

export function MarketTicker() {
  const [live, setLive] = useState<Coin[]>(() => coins.map((coin) => ({ ...coin })));

  useEffect(() => {
    const interval = window.setInterval(() => {
      setLive((current) =>
        current.map((coin) => {
          const drift = 1 + (Math.random() - 0.48) * 0.0018;
          return {
            ...coin,
            price: coin.price * drift,
            change: Math.max(-9.9, Math.min(9.9, coin.change + (Math.random() - 0.5) * 0.06)),
          };
        })
      );
    }, 4200);
    return () => window.clearInterval(interval);
  }, []);

  return (
    <div className="relative mt-10 border-y border-line bg-white/60 sm:mt-4 lg:mt-8">
      <div className="container-x flex items-center gap-3 py-4 sm:gap-5">
        <div className="hidden shrink-0 items-center gap-2 border-l border-line pl-4 sm:flex">
          <LiveDot />
          <span className="text-[10px] font-extrabold uppercase tracking-[0.16em] text-ink/70">بازار زنده</span>
        </div>
        <div className="marquee marquee-mask flex-1 overflow-hidden" dir="ltr">
          <div className="marquee-track flex items-center">
            {[...live, ...live].map((coin, index) => (
              <TickerItem key={`${coin.symbol}-${index}`} coin={coin} />
            ))}
          </div>
        </div>
        <a
          href="#panel"
          className="hidden shrink-0 items-center gap-1.5 rounded-full border border-line bg-paper px-3 py-1.5 text-[10px] font-bold text-ink/70 transition-colors hover:border-ink/20 hover:text-ink md:inline-flex"
        >
          مشاهده بازار
          <ArrowUpRight size={12} />
        </a>
      </div>
    </div>
  );
}

/* -------------------------------------------------------------------------- */
/*                                    Hero                                    */
/* -------------------------------------------------------------------------- */

export default function Hero() {
  return (
    <>
      <section id="home" className="relative overflow-hidden pb-0 pt-28 sm:pt-30 lg:pt-32">
        <div className="pointer-events-none absolute inset-0 -z-10">
          <div className="absolute -right-32 top-0 size-[560px] rounded-full bg-brand/[0.07] blur-[110px]" />
          <div className="absolute -left-24 top-40 size-[420px] rounded-full bg-mint/50 blur-[100px]" />
          <div className="dot-grid absolute left-[42%] top-28 hidden h-40 w-56 opacity-40 lg:block" />
        </div>

        <div className="container-x grid items-center gap-12 pb-10 sm:pb-12 lg:grid-cols-[1.04fr_0.96fr] lg:gap-8 lg:pb-16">
          <div className="relative z-10 max-w-[620px]">
            <Eyebrow className="animate-rise">نسخه ۶.۰ · سه موتور معاملاتی، یک پنل ساده</Eyebrow>

            <h1 className="animate-rise mt-6 text-[2.15rem] font-extrabold leading-[1.5] tracking-[-0.035em] text-ink text-balance sm:text-[2.9rem] sm:leading-[1.4] lg:text-[3.5rem] lg:leading-[1.35]">
              بازار حرکت می‌کند،
              <br />
              <span className="relative inline-block">
                <span className="absolute inset-x-0 bottom-1 -z-10 h-1.5 rounded-full bg-lime/70 sm:h-2" />
                هوش مصنوعی
              </span>{" "}
              تصمیم می‌گیرد.
            </h1>

            <p className="animate-rise mt-6 max-w-[510px] text-[14px] leading-[2.1] text-muted sm:text-[15.5px]">
              دلارینو ۳۰+ ارز پرمعامله را بی‌وقفه رصد می‌کند و با سه موتور اختصاصی — هوش مصنوعی،
              استراتژی منتخب و کپی‌ترید — خودکار معامله می‌کند. ساده برای شروع، حرفه‌ای برای ماندن.
            </p>

            <div className="animate-rise mt-7 flex flex-col gap-2.5 sm:flex-row sm:items-center">
              <CTA href="#start" className="w-full sm:w-auto">
                شروع رایگان با حساب دمو
              </CTA>
              <a
                href="#how"
                className="group inline-flex items-center justify-center gap-2.5 rounded-full border border-line bg-white/70 px-5 py-3.5 text-[13px] font-bold text-ink backdrop-blur transition-colors hover:border-ink/25 hover:bg-white sm:text-sm"
              >
                <span className="grid size-6 place-items-center rounded-full bg-ink text-white transition-transform group-hover:scale-110">
                  <Play size={9} fill="currentColor" className="mr-px" />
                </span>
                ببینید چطور کار می‌کند
              </a>
            </div>

            <ul className="mt-6 flex flex-wrap items-center gap-x-5 gap-y-2 text-[11px] font-medium text-muted sm:text-[11.5px]">
              {["بدون کارت بانکی", "دموی نامحدود", "لغو در هر زمان"].map((item) => (
                <li key={item} className="flex items-center gap-1.5">
                  <span className="grid size-4 place-items-center rounded-full bg-mint text-mint-deep">
                    <Check size={9} strokeWidth={3.5} />
                  </span>
                  {item}
                </li>
              ))}
            </ul>

            <div className="mt-7 flex items-center gap-3.5 border-t border-line/80 pt-5 sm:mt-8">
              <div className="flex -space-x-2.5 space-x-reverse" dir="ltr">
                {[
                  { label: "س", color: "bg-[#182b24] text-lime" },
                  { label: "م", color: "bg-brand text-white" },
                  { label: "ر", color: "bg-[#dfd3b9] text-ink" },
                  { label: "ن", color: "bg-[#d1e8dc] text-mint-deep" },
                ].map((avatar) => (
                  <span
                    key={avatar.label}
                    className={cn(
                      "grid size-8 place-items-center rounded-full text-[10px] font-extrabold ring-2 ring-paper",
                      avatar.color
                    )}
                  >
                    {avatar.label}
                  </span>
                ))}
                <span className="font-latin grid size-8 place-items-center rounded-full bg-white text-[8px] font-extrabold text-ink ring-2 ring-paper">
                  +12K
                </span>
              </div>
              <p className="text-[10.5px] leading-relaxed text-muted sm:text-[11.5px]">
                <span className="font-bold text-ink">معامله‌گران در ۲۴ کشور</span>
                <br />
                بازار را به دلارینو سپرده‌اند.
              </p>
            </div>
          </div>

          <div className="relative lg:pl-2">
            <HeroVisual />
          </div>
        </div>
      </section>

      <MarketTicker />
    </>
  );
}
