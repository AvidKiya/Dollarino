import { useEffect, useState } from "react";
import { cn } from "../utils/cn";

const items = [
  { id: "features", label: "امکانات", num: "۰۱" },
  { id: "engines", label: "موتورها", num: "۰۲" },
  { id: "panel", label: "پنل", num: "۰۳" },
  { id: "weekly", label: "کارت هفتگی", num: "۰۴" },
  { id: "risk", label: "ریسک", num: "۰۵" },
  { id: "pricing", label: "تعرفه‌ها", num: "۰۶" },
  { id: "app", label: "اپلیکیشن", num: "۰۷" },
  { id: "faq", label: "سوالات", num: "۰۸" },
];

export default function Rail() {
  const [active, setActive] = useState<string>("");

  useEffect(() => {
    const sections = items
      .map((item) => document.getElementById(item.id))
      .filter((section): section is HTMLElement => Boolean(section));
    if (!sections.length) return;

    const observer = new IntersectionObserver(
      (entries) => {
        const visible = entries
          .filter((entry) => entry.isIntersecting)
          .sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
        if (visible) setActive(visible.target.id);
      },
      { rootMargin: "-30% 0px -55% 0px", threshold: [0.05, 0.3, 0.7] }
    );
    sections.forEach((section) => observer.observe(section));
    return () => observer.disconnect();
  }, []);

  return (
    <nav
      aria-label="فهرست بخش‌ها"
      className="fixed left-5 top-1/2 z-40 hidden -translate-y-1/2 min-[1420px]:block"
    >
      <ul className="flex flex-col gap-3.5">
        {items.map((item) => {
          const isActive = active === item.id;
          return (
            <li key={item.id}>
              <a
                href={`#${item.id}`}
                className="group flex items-center gap-2.5"
                aria-current={isActive ? "true" : undefined}
              >
                <span
                  className={cn(
                    "h-px transition-all duration-500",
                    isActive ? "w-7 bg-brand" : "w-3.5 bg-ink/20 group-hover:w-6 group-hover:bg-ink/40"
                  )}
                />
                <span
                  className={cn(
                    "font-latin text-[9px] font-extrabold tracking-[0.12em] transition-colors duration-300",
                    isActive ? "text-brand" : "text-ink/25 group-hover:text-ink/55"
                  )}
                >
                  {item.num}
                </span>
                <span
                  className={cn(
                    "text-[10px] font-bold transition-all duration-500",
                    isActive
                      ? "translate-x-0 text-ink opacity-100"
                      : "translate-x-1 text-ink/35 opacity-0 group-hover:translate-x-0 group-hover:opacity-100"
                  )}
                >
                  {item.label}
                </span>
              </a>
            </li>
          );
        })}
      </ul>
    </nav>
  );
}
