import { useState } from "react";
import {
  ArrowLeft,
  ArrowUpRight,
  Bell,
  Bot,
  CandlestickChart,
  Check,
  ChevronDown,
  Eye,
  LayoutDashboard,
  Lock,
  Plus,
  Search,
  Settings,
  Share2,
  ShieldCheck,
  Sparkles,
  Wallet,
  Zap,
} from "lucide-react";
import { cn } from "../utils/cn";
import { AreaChart, CTA, CoinBadge, Eyebrow, LiveDot, LogoMark, Reveal, coins, usd } from "./ui";

const navItems = [
  { label: "نمای کلی", icon: LayoutDashboard, active: true },
  { label: "ربات من", icon: Bot },
  { label: "معاملات", icon: CandlestickChart },
  { label: "کیف پول", icon: Wallet },
  { label: "کارت هفتگی", icon: Share2 },
  { label: "مدیریت", icon: Settings },
];

const ranges = {
  "1D": { values: [34, 39, 36, 44, 42, 49, 46, 54, 58, 55, 63, 61, 68, 66, 74, 72, 80, 78, 86], change: "+2.84%" },
  "1W": { values: [26, 32, 29, 37, 34, 43, 40, 49, 46, 55, 51, 60, 57, 66, 63, 72, 69, 79, 76, 86, 84, 92], change: "+8.46%" },
  "1M": { values: [18, 26, 22, 32, 27, 38, 34, 44, 41, 52, 47, 58, 54, 64, 60, 72, 68, 78, 83, 80, 90, 88, 96], change: "+22.9%" },
} as const;

type Range = keyof typeof ranges;

function WalletPreviewCard() {
  return (
    <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-[#2b4bf2] to-[#15279f] p-3.5 text-white shadow-soft sm:col-span-2 xl:col-span-1">
      <div className="pointer-events-none absolute -right-8 -top-10 size-28 rounded-full border border-white/15" />
      <div className="pointer-events-none absolute -bottom-12 -left-4 size-32 rounded-full border border-white/10" />
      <div className="relative flex items-center justify-between">
        <p className="text-[8px] font-semibold text-white/75">کیف پول دلارینو</p>
        <span className="font-latin rounded-full bg-white/15 px-1.5 py-0.5 text-[6.5px] font-bold tracking-wide text-white/80">
          DEMO
        </span>
      </div>
      <div className="relative mt-2 flex items-center gap-1.5">
        <p className="font-latin text-[19px] font-extrabold tracking-tight">$12,480.50</p>
        <span className="font-latin rounded-full bg-lime px-1.5 py-0.5 text-[6.5px] font-extrabold text-ink">+8.4%</span>
      </div>
      <p className="relative mt-1 font-latin text-[7.5px] tracking-wide text-white/50">USDT · AVAILABLE BALANCE</p>
      <div className="relative mt-3 flex items-center gap-1.5">
        <span className="flex flex-1 items-center justify-center gap-1 rounded-lg bg-white px-2 py-1.5 text-[7.5px] font-extrabold text-ink">
          <Plus size={9} /> معامله جدید
        </span>
        <span className="flex items-center justify-center gap-1 rounded-lg border border-white/20 bg-white/10 px-2 py-1.5 text-[7.5px] font-bold text-white">
          <Share2 size={9} /> کارت هفته
        </span>
      </div>
    </div>
  );
}

function ProfitPreviewCard() {
  return (
    <div className="rounded-2xl border border-line bg-white p-3.5">
      <div className="flex items-center justify-between">
        <p className="text-[8px] font-semibold text-muted">سود خالص هفته</p>
        <span className="flex size-5 items-center justify-center rounded-full bg-mint text-mint-deep">
          <ArrowUpRight size={10} />
        </span>
      </div>
      <p dir="ltr" className="font-latin mt-2 text-[19px] font-extrabold tracking-tight text-ink">+12.8%</p>
      <div className="mt-2 flex h-8 items-end gap-1" dir="ltr">
        {[34, 48, 40, 62, 55, 74, 88].map((height, index) => (
          <span
            key={index}
            className={cn("flex-1 rounded-t-sm", index === 6 ? "bg-brand" : "bg-brand/15")}
            style={{ height: `${height}%` }}
          />
        ))}
      </div>
      <p className="mt-1.5 text-[7px] text-muted">۷ ترید موفق از ۹ معامله</p>
    </div>
  );
}

function EnginePreviewCard() {
  return (
    <div className="rounded-2xl border border-line bg-white p-3.5">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-1.5">
          <span className="grid size-6 place-items-center rounded-lg bg-brand text-white">
            <Sparkles size={11} />
          </span>
          <p className="text-[8px] font-bold text-ink">دُربین · موتور فعال</p>
        </div>
        <LiveDot />
      </div>
      <div className="mt-2.5 flex items-center justify-between">
        <div>
          <p className="text-[7px] text-muted">وضعیت</p>
          <p className="mt-0.5 text-[8.5px] font-extrabold text-mint-deep">در حال رصد بازار</p>
        </div>
        <span className="font-latin rounded-lg bg-paper px-2 py-1 text-[7px] font-bold text-ink/60">24/7</span>
      </div>
      <div className="mt-2.5 h-1 overflow-hidden rounded-full bg-paper-2">
        <div className="h-full w-[86%] rounded-full bg-gradient-to-l from-mint-deep to-brand" />
      </div>
      <p className="mt-1.5 text-[7px] text-muted">۳ مدل فعال · ۳۰+ بازار تحت پوشش</p>
    </div>
  );
}

function PerformancePreview() {
  const [range, setRange] = useState<Range>("1W");
  const data = ranges[range];
  return (
    <div className="rounded-2xl border border-line bg-white p-3.5">
      <div className="flex items-center justify-between gap-2">
        <div>
          <p className="text-[9px] font-extrabold text-ink">عملکرد حساب</p>
          <p className="font-latin mt-0.5 text-[7px] text-muted">TOTAL EQUITY · USDT</p>
        </div>
        <div className="flex items-center gap-0.5 rounded-full bg-paper p-0.5">
          {(Object.keys(ranges) as Range[]).map((item) => (
            <button
              key={item}
              type="button"
              onClick={() => setRange(item)}
              aria-pressed={range === item}
              className={cn(
                "font-latin rounded-full px-2 py-1 text-[6.5px] font-bold transition-all",
                range === item ? "bg-white text-ink shadow-sm" : "text-muted hover:text-ink"
              )}
            >
              {item}
            </button>
          ))}
        </div>
      </div>
      <div className="mt-2 flex items-end justify-between">
        <p className="font-latin text-[18px] font-extrabold text-ink">$12,480.50</p>
        <span className="font-latin rounded-full bg-mint/60 px-1.5 py-0.5 text-[7px] font-extrabold text-mint-deep">
          {data.change}
        </span>
      </div>
      <AreaChart values={[...data.values]} stroke="#2b4bf2" height={98} showDot grid className="mt-1" />
    </div>
  );
}

function PositionsPreview() {
  return (
    <div className="rounded-2xl border border-line bg-white p-3.5">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-1.5">
          <p className="text-[9px] font-extrabold text-ink">پوزیشن‌های باز</p>
          <span className="font-latin rounded-full bg-brand-soft px-1.5 py-0.5 text-[6.5px] font-bold text-brand">7</span>
        </div>
        <span className="text-[7px] font-semibold text-muted">مشاهده همه</span>
      </div>

      <div className="mt-2.5 space-y-1">
        {[
          { coin: coins[0], side: "خرید", pnl: "+4.82%", up: true },
          { coin: coins[1], side: "خرید", pnl: "+2.16%", up: true },
          { coin: coins[2], side: "فروش", pnl: "-0.94%", up: false },
        ].map((row) => (
          <div key={row.coin.symbol} className="flex items-center gap-2 rounded-lg px-1 py-1.5 hover:bg-paper">
            <CoinBadge coin={row.coin} className="size-6 text-[8px]" />
            <div className="min-w-0">
              <p className="font-latin text-[7.5px] font-extrabold text-ink">{row.coin.symbol}/USDT</p>
              <p className="font-latin mt-0.5 text-[6.5px] text-muted">10x · ${usd(row.coin.price)}</p>
            </div>
            <span
              className={cn(
                "mr-auto rounded px-1 py-0.5 text-[6.5px] font-bold",
                row.up ? "bg-mint/60 text-mint-deep" : "bg-red-50 text-danger"
              )}
            >
              {row.side}
            </span>
            <span className={cn("font-latin text-[7.5px] font-extrabold", row.up ? "text-up" : "text-danger")}>
              {row.pnl}
            </span>
          </div>
        ))}
      </div>

      <div className="mt-2 flex items-center justify-between rounded-xl bg-paper px-2 py-2">
        <span className="flex items-center gap-1 text-[7px] font-bold text-ink/60">
          <ShieldCheck size={9} className="text-up" /> حد ضرر خودکار
        </span>
        <span className="text-[6.5px] text-muted">فعال برای همه</span>
      </div>
    </div>
  );
}

function DashboardPreview() {
  return (
    <div className="relative">
      <div className="relative rounded-[24px] border border-white/15 bg-white/[0.07] p-1.5 shadow-2xl backdrop-blur-sm sm:rounded-[28px] sm:p-2.5">
        <div className="flex items-center gap-2 px-2 pb-2 pt-1" dir="ltr">
          <div className="flex gap-1.5">
            <span className="size-2 rounded-full bg-white/20" />
            <span className="size-2 rounded-full bg-white/20" />
            <span className="size-2 rounded-full bg-white/20" />
          </div>
          <div className="mx-auto flex items-center gap-1.5 rounded-md bg-white/[0.06] px-3 py-1">
            <Lock size={7} className="text-white/30" />
            <span className="font-latin text-[7px] tracking-wide text-white/35">app.dollarino.io/panel</span>
          </div>
          <span className="font-latin rounded-full bg-lime/10 px-1.5 py-0.5 text-[6px] font-bold text-lime/70">LIVE</span>
        </div>

        <div className="overflow-hidden rounded-[16px] bg-[#f6f5ef] sm:rounded-[20px]">
          <div className="flex">
            {/* Sidebar */}
            <aside className="hidden w-[160px] shrink-0 flex-col border-l border-line bg-white p-3 lg:flex xl:w-[176px]">
              <div className="flex items-center gap-1.5">
                <LogoMark className="size-7 rounded-lg" />
                <span className="text-[12px] font-extrabold tracking-tight text-ink">دلارینو</span>
                <span className="font-latin mr-auto rounded bg-paper px-1 py-0.5 text-[5.5px] font-bold text-muted">
                  v6
                </span>
              </div>

              <button
                type="button"
                className="mt-3 flex items-center justify-between rounded-lg border border-line bg-paper/60 px-2 py-1.5"
              >
                <span className="flex items-center gap-1.5">
                  <span className="size-4 rounded-full bg-gradient-to-br from-[#2b4bf2] to-[#16239b]" />
                  <span className="text-[7px] font-bold text-ink">حساب دمو</span>
                </span>
                <ChevronDown size={9} className="text-muted" />
              </button>

              <nav className="mt-3 space-y-0.5">
                {navItems.map((item) => (
                  <div
                    key={item.label}
                    className={cn(
                      "flex items-center gap-2 rounded-lg px-2 py-1.5 text-[7.5px] font-semibold",
                      item.active ? "bg-ink text-white" : "text-muted"
                    )}
                  >
                    <item.icon size={10} />
                    {item.label}
                    {item.label === "معاملات" && (
                      <span className="font-latin mr-auto rounded-full bg-brand/10 px-1 text-[6px] font-bold text-brand">
                        7
                      </span>
                    )}
                  </div>
                ))}
              </nav>

              <div className="mt-auto rounded-xl bg-gradient-to-br from-[#182620] to-[#0e1714] p-2.5 text-white">
                <div className="flex items-center gap-1">
                  <Zap size={9} className="text-lime" />
                  <span className="text-[7px] font-bold">حالت Pro</span>
                </div>
                <p className="mt-1 text-[6px] leading-relaxed text-white/40">همه ابزارهای حرفه‌ای تریدرها</p>
                <span className="mt-1.5 block rounded-md bg-white/10 py-1 text-center text-[6px] font-bold">
                  فعال‌سازی
                </span>
              </div>
            </aside>

            {/* Main */}
            <div className="min-w-0 flex-1 p-2.5 sm:p-3.5">
              <div className="flex items-center justify-between gap-2">
                <div>
                  <p className="flex items-center gap-1 text-[10px] font-extrabold text-ink sm:text-[11px]">
                    سلام، آرش
                    <span className="text-[10px]">👋</span>
                  </p>
                  <p className="mt-0.5 text-[6.5px] text-muted">امروز سه‌شنبه، ۱۸ خرداد ۱۴۰۵</p>
                </div>
                <div className="flex items-center gap-1.5">
                  <span className="hidden size-6 items-center justify-center rounded-full border border-line bg-white text-muted sm:flex">
                    <Search size={9} />
                  </span>
                  <span className="relative flex size-6 items-center justify-center rounded-full border border-line bg-white text-muted">
                    <Bell size={9} />
                    <span className="absolute right-1 top-1 size-1 rounded-full bg-danger" />
                  </span>
                  <span className="flex items-center gap-1 rounded-full border border-line bg-white p-0.5 pl-2">
                    <span className="grid size-4.5 place-items-center rounded-full bg-[#dfd3b9] text-[6px] font-extrabold text-ink">
                      آ
                    </span>
                    <span className="hidden text-[6.5px] font-bold text-ink/70 sm:inline">آرش کیانی</span>
                  </span>
                </div>
              </div>

              <div className="mt-2.5 grid gap-2 sm:grid-cols-2 xl:grid-cols-3">
                <WalletPreviewCard />
                <ProfitPreviewCard />
                <EnginePreviewCard />
              </div>

              <div className="mt-2 grid gap-2 xl:grid-cols-[1.45fr_1fr]">
                <PerformancePreview />
                <PositionsPreview />
              </div>

              <div className="mt-2 flex items-center justify-between rounded-xl border border-line bg-white px-3 py-2">
                <span className="flex items-center gap-1.5 text-[6.5px] text-muted">
                  <Eye size={8} />
                  موجودی شما فقط برای خودتان قابل مشاهده است
                </span>
                <span className="flex items-center gap-1 text-[6.5px] font-bold text-mint-deep">
                  <Check size={8} strokeWidth={3} />
                  همه سیستم‌ها آنلاین
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="mt-3 flex flex-wrap items-center justify-center gap-2 text-[9px] text-white/35">
        <span className="flex items-center gap-1">
          <Check size={10} className="text-lime/60" /> نسخه موبایل و دسکتاپ
        </span>
        <span className="size-1 rounded-full bg-white/20" />
        <span>بدون نیاز به نصب</span>
        <span className="size-1 rounded-full bg-white/20" />
        <span className="flex items-center gap-1">
          <ShieldCheck size={10} className="text-lime/60" /> امن و رمزنگاری‌شده
        </span>
      </div>
    </div>
  );
}

export default function Showcase() {
  return (
    <section id="panel" className="pb-16 sm:pb-20 lg:pb-28">
      <div className="container-x">
        <div className="relative overflow-hidden rounded-[32px] bg-ink px-4 pb-6 pt-10 text-white sm:rounded-[40px] sm:px-8 sm:pt-12 lg:px-14 lg:pb-10 lg:pt-16">
          <div className="dot-grid-light pointer-events-none absolute inset-0 opacity-20" />
          <div className="pointer-events-none absolute -right-24 -top-24 size-[420px] rounded-full bg-brand/25 blur-[110px]" />
          <div className="pointer-events-none absolute -bottom-24 left-10 size-[320px] rounded-full bg-mint/10 blur-[90px]" />
          <div className="pointer-events-none absolute -left-20 top-1/3 size-72 rounded-full border border-white/[0.05]" />

          <div className="relative grid items-end gap-8 lg:grid-cols-[1.2fr_0.8fr]">
            <div>
              <Eyebrow light>پنل حرفه‌ای دلارینو</Eyebrow>
              <h2 className="mt-5 text-[1.85rem] font-extrabold leading-[1.45] tracking-[-0.035em] text-balance sm:text-[2.5rem] lg:text-[2.9rem]">
                همان پنلی که می‌خواستید.
                <br />
                <span className="text-lime">بدون شلوغی.</span>
              </h2>
              <p className="mt-4 max-w-lg text-[13px] leading-[2.05] text-white/55 sm:text-[14px]">
                کیف پول کبالت، دکمه مخفی موجودی، کارت هفتگی قابل اشتراک و مدیریت هم‌زمان ۲۰ پوزیشن؛
                همه در یک تجربه آرام و شبیه به اپ‌های موردعلاقه‌تان.
              </p>
            </div>

            <div>
              <div className="grid grid-cols-2 gap-2">
                {[
                  { icon: Wallet, label: "کیف پول کبالت" },
                  { icon: Eye, label: "مخفی کردن موجودی" },
                  { icon: Share2, label: "کارت هفتگی PNG" },
                  { icon: Zap, label: "حالت Pro تریدرها" },
                ].map((item) => (
                  <div
                    key={item.label}
                    className="flex items-center gap-2 rounded-xl border border-white/10 bg-white/[0.04] px-2.5 py-2.5 text-[9.5px] font-semibold text-white/65 backdrop-blur"
                  >
                    <item.icon size={12} className="shrink-0 text-lime/70" />
                    {item.label}
                  </div>
                ))}
              </div>
              <div className="mt-4 flex flex-col gap-2 sm:flex-row lg:justify-end">
                <CTA href="#start" variant="light" className="!px-4 !py-3 !text-[11px]">
                  ورود به پنل دمو
                </CTA>
                <CTA
                  href="#features"
                  variant="outlineLight"
                  arrow={false}
                  className="!px-4 !py-3 !text-[11px]"
                >
                  امکانات پنل
                  <ArrowLeft size={13} />
                </CTA>
              </div>
            </div>
          </div>

          <Reveal delay={100}>
            <div className="relative mt-9 lg:mt-12">
              <DashboardPreview />
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
