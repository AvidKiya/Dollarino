import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import "@fontsource-variable/vazirmatn";
import "@fontsource-variable/manrope";
import "./index.css";
import App from "./App";
import favicon from "./assets/logo-96.png";

const icon = document.querySelector<HTMLLinkElement>('link[rel="icon"]') ?? document.createElement("link");
icon.rel = "icon";
icon.type = "image/png";
icon.href = favicon;
document.head.appendChild(icon);

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <App />
  </StrictMode>
);
